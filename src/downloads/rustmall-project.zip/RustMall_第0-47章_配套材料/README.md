# RustMall 第0—47章完整配套材料

先进入rustmall/阅读README与docs/current-http-api.md，这是第47章完整累积工程。默认Compose的Edge为本机18086；TLS覆盖仅localhost18443。按步骤生成自己的私有profile与证书，不借用历史检查点的数据库和令牌。

- rustmall/：最终完整workspace、锁文件、迁移、测试、Docker、Compose、Helm与CI脚本。
- checkpoints/：历史完整检查点；各自按对应章节运行，不把不同版本拼装。36—46另有检查点阅读说明，区分旧gateway与新Edge。
- chapter_changes/：逐章新增或修改的源文件及少量明确标注的正文摘录；它们不能单独作为完整workspace。
- book_source/：校订源稿与展开稿，另有可编辑模板说明。
- verification/：分章内容核读、源码指纹与最终实际验证摘要；历史记录按当时范围保留，不把当时待验证等同于全书仍未验证。

最终403项常规测试与另选五项Docker测试分别通过。同一Linux arm64应用镜像完成TLS25组、无TLS21组、本机Kind/Helm8组。六库恢复含28张公共表与3个序列，历史迁移保留旧价与发货语义，旧请求键阻止重复付款。实际范围和负控参见最终校订与验证记录，不宣称真实银行、跨地域高可用、生产容量或远端发布已验证。

不包含生成凭据、私钥、恢复归档、target或作者私有环境。PDF视觉折行不改变源文件；实际代码从rustmall或相应检查点复制。
