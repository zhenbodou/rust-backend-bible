//! 订单领域模型与订单状态机。

use crate::ids::{OrderId, ProductId, UserId};
use crate::money;
use crate::quantity::Quantity;

/// 订单的简单状态，用于存储到数据库和对外展示。
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum OrderStatus {
    Pending,
    Paid,
    Shipped,
    Completed,
    Cancelled,
}

impl OrderStatus {
  /// 全部状态，便于遍历和测试。
  pub const ALL: [OrderStatus; 5] = [
         OrderStatus::Pending,
         OrderStatus::Paid,
         OrderStatus::Shipped,
         OrderStatus::Completed,
         OrderStatus::Cancelled,
    ];

    /// 数据库中存储的字符串。
    pub fn as_str(self) -> &'static str {
        match self {
            Self::Pending => "pending",
            Self::Paid => "paid",
            Self::Shipped => "shipped",
            Self::Completed => "completed",
            Self::Cancelled => "cancelled",
        }
    }

    /// 从数据库字符串解析；未知值返回 `None`，由调用方决定如何报错。
    pub fn parse(s: &str) -> Option<Self> {
        match s {
            "pending" => Some(Self::Pending),
            "paid" => Some(Self::Paid),
            "shipped" => Some(Self::Shipped),
            "completed" => Some(Self::Completed),
            "cancelled" => Some(Self::Cancelled),
            _ => None,
        }
    }

    /// 是否为终态（不能再发生任何转移）。
    pub fn is_terminal(self) -> bool {
        matches!(self, Self::Completed | Self::Cancelled)
    }
}

/// 订单的完整运行时状态：每个状态携带且只携带它需要的数据。
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum OrderState {
    Pending,
    Paid { paid_at: i64 },
    Shipped { paid_at: i64, tracking_no: String },
    Completed { paid_at: i64, tracking_no: String },
    Cancelled { reason: String },
}
impl OrderState {
    pub fn status(&self) -> OrderStatus {
        match self {
             Self::Pending => OrderStatus::Pending,
             Self::Paid { .. } => OrderStatus::Paid,
             Self::Shipped { .. } => OrderStatus::Shipped,
             Self::Completed { .. } => OrderStatus::Completed,
             Self::Cancelled { .. } => OrderStatus::Cancelled,
        }
    }
 }

 /// 订单操作可能出现的错误。
 #[derive(Debug, Clone, PartialEq, Eq)]
 pub enum OrderError {
     /// 输入不合法
     InvalidInput(&'static str),
     /// 金额计算溢出或超过单笔上限
     AmountOverflow,
     /// 当前状态不允许该操作
     IllegalTransition {
         from: OrderStatus,
         action: &'static str,
     },
 }

 /// 订单。
 ///
 /// ```
 /// use common::ids::{OrderId, ProductId, UserId};
 /// use common::order::{Order, OrderStatus};
 /// use common::quantity::Quantity;
 ///
 /// let qty = Quantity::try_new(2).expect("示例数量应当合法");
 /// let mut order = Order::new(OrderId::new(1), UserId::new(7), ProductId::new(42), 19_900,
///     qty).expect("示例订单应当合法");
/// assert_eq!(order.total_cents(), 39_800);
/// order.pay(1_760_000_000).expect("待支付订单应允许支付");
/// assert_eq!(order.status(), OrderStatus::Paid);
/// ```
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Order {
    id: OrderId,
    user_id: UserId,
    product_id: ProductId,
    quantity: Quantity,
    unit_price_cents: i64,
    total_cents: i64,
    state: OrderState,
}

impl Order {
    /// 创建待支付订单，自动计算总价。
    pub fn new(
        id: OrderId,
        user_id: UserId,
        product_id: ProductId,
        unit_price_cents: i64,
        quantity: Quantity,
    ) -> Result<Self, OrderError> {
        if unit_price_cents < 0 {
             return Err(OrderError::InvalidInput("单价不能为负数"));
        }
        let total_cents = money::line_total(unit_price_cents, i64::from(quantity.get()))
             .ok_or(OrderError::AmountOverflow)?;
    Ok(Self {
        id,
        user_id,
        product_id,
        quantity,
        unit_price_cents,
        total_cents,
        state: OrderState::Pending,
    })
}

// ---------- 只读访问 ----------

pub fn id(&self) -> OrderId {
    self.id
}

pub fn user_id(&self) -> UserId {
    self.user_id
}

pub fn product_id(&self) -> ProductId {
    self.product_id
}

pub fn quantity(&self) -> Quantity {
    self.quantity
}
pub fn unit_price_cents(&self) -> i64 {
    self.unit_price_cents
}

pub fn total_cents(&self) -> i64 {
    self.total_cents
}

pub fn state(&self) -> &OrderState {
    &self.state
}

pub fn status(&self) -> OrderStatus {
    self.state.status()
}

// ---------- 状态转移 ----------

/// 支付：待支付 → 已支付。
pub fn pay(&mut self, paid_at: i64) -> Result<(), OrderError> {
    match self.state {
        OrderState::Pending => {
            self.state = OrderState::Paid { paid_at };
            Ok(())
        }
        _ => Err(self.illegal("pay")),
    }
}

/// 发货：已支付 → 已发货。
pub fn ship(&mut self, tracking_no: &str) -> Result<(), OrderError> {
    let tracking_no = tracking_no.trim();
    if tracking_no.is_empty() {
        return Err(OrderError::InvalidInput("快递单号不能为空"));
    }
    match self.state {
        OrderState::Paid { paid_at } => {
            self.state = OrderState::Shipped {
                paid_at,
                tracking_no: tracking_no.to_string(),
            };
            Ok(())
        }
        _ => Err(self.illegal("ship")),
    }
}

/// 确认收货：已发货 → 已完成。快递单号从旧状态“搬”到新状态，不复制。
pub fn complete(&mut self) -> Result<(), OrderError> {
    // 先用占位值把旧状态整体取出，拿到其中 String 的所有权
    match std::mem::replace(&mut self.state, OrderState::Pending) {
        OrderState::Shipped {
            paid_at,
            tracking_no,
        } => {
            self.state = OrderState::Completed {
                paid_at,
                tracking_no,
            };
            Ok(())
        }
        other => {
            // 不允许转移：把旧状态原样放回
            self.state = other;
            Err(self.illegal("complete"))
        }
    }
}

/// 取消：待支付或已支付 → 已取消。
pub fn cancel(&mut self, reason: &str) -> Result<(), OrderError> {
    let reason = reason.trim();
    if reason.is_empty() {
        return Err(OrderError::InvalidInput("取消原因不能为空"));
    }
    match self.state {
        OrderState::Pending | OrderState::Paid { .. } => {
            self.state = OrderState::Cancelled {
                reason: reason.to_string(),
            };
            Ok(())
        }
            _ => Err(self.illegal("cancel")),
        }
    }

    fn illegal(&self, action: &'static str) -> OrderError {
        OrderError::IllegalTransition {
            from: self.status(),
            action,
        }
    }
}

#[cfg(test)]
mod tests {
  use super::*;

    fn new_order() -> Order {
        let qty = Quantity::try_new(2).expect("测试数量合法");
        Order::new(
            OrderId::new(1),
            UserId::new(7),
            ProductId::new(42),
            19_900,
            qty,
        )
        .expect("测试订单合法")
    }

    #[test]
    fn new_order_is_pending_with_total() {
        let order = new_order();
        assert_eq!(order.status(), OrderStatus::Pending);
        assert_eq!(order.total_cents(), 39_800);
    }

    #[test]
    fn happy_path() {
        let mut order = new_order();
        assert_eq!(order.pay(100), Ok(()));
        assert_eq!(order.ship(" SF123 "), Ok(()));
        assert_eq!(order.complete(), Ok(()));
        assert_eq!(
            order.state(),
            &OrderState::Completed {
                paid_at: 100,
                tracking_no: "SF123".to_string()
            }
        );
        assert!(order.status().is_terminal());
    }

    #[test]
    fn cannot_ship_before_pay() {
        let mut order = new_order();
        assert_eq!(
       order.ship("SF123"),
       Err(OrderError::IllegalTransition {
           from: OrderStatus::Pending,
           action: "ship"
       })
    );
    assert_eq!(order.status(), OrderStatus::Pending, "非法操作不能改变状态");
}

#[test]
fn failed_complete_keeps_state() {
    let mut order = new_order();
    assert_eq!(order.pay(100), Ok(()));
    assert!(order.complete().is_err());
    assert_eq!(
        order.state(),
        &OrderState::Paid { paid_at: 100 },
        "失败时旧状态必须被放回"
    );
}

#[test]
fn cancel_rules() {
    let mut paid = new_order();
    assert_eq!(paid.pay(100), Ok(()));
    assert_eq!(paid.cancel("不想要了"), Ok(()));
    assert!(paid.pay(200).is_err(), "已取消的订单不能再支付");

    let mut done = new_order();
    assert_eq!(done.pay(1), Ok(()));
    assert_eq!(done.ship("SF1"), Ok(()));
    assert_eq!(done.complete(), Ok(()));
    assert!(done.cancel("晚了").is_err());
    assert_eq!(
        new_order().cancel(" "),
        Err(OrderError::InvalidInput("取消原因不能为空"))
    );
}

#[test]
fn status_string_roundtrip_and_amount_overflow() {
    for s in OrderStatus::ALL {
        assert_eq!(OrderStatus::parse(s.as_str()), Some(s));
    }
    assert_eq!(OrderStatus::parse("unknown"), None);

    let qty = Quantity::try_new(99).expect("测试数量合法");
    let r = Order::new(
        OrderId::new(2),
        UserId::new(1),
        ProductId::new(1),
        i64::MAX,
        qty,
    );
        assert_eq!(r, Err(OrderError::AmountOverflow));
    }
}
