//! 强类型 ID。
//!
//! 每种实体的 ID 都是独立的类型，编译器会阻止把 `UserId` 传给需要 `ProductId` 的地方。
//! 运行时它们与 `i64` 完全相同，没有任何额外开销。

use std::fmt;

/// 用户 ID。
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, PartialOrd, Ord)]
#[repr(transparent)]
pub struct UserId(i64);

impl UserId {
    pub const fn new(value: i64) -> Self {
        Self(value)
    }
    pub const fn get(self) -> i64 {
        self.0
    }
}

impl fmt::Display for UserId {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{}", self.0)
    }
}

/// 商品 ID。
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, PartialOrd, Ord)]
#[repr(transparent)]
pub struct ProductId(i64);

impl ProductId {
  pub const fn new(value: i64) -> Self {
      Self(value)
  }

    pub const fn get(self) -> i64 {
        self.0
    }
}

impl fmt::Display for ProductId {
  fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
      write!(f, "{}", self.0)
  }
}

/// 订单 ID。
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, PartialOrd, Ord)]
#[repr(transparent)]
pub struct OrderId(i64);

impl OrderId {
  pub const fn new(value: i64) -> Self {
      Self(value)
  }

    pub const fn get(self) -> i64 {
        self.0
    }
}

impl fmt::Display for OrderId {
  fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
      write!(f, "{}", self.0)
  }
}

#[cfg(test)]
mod tests {
  use super::*;
  use std::collections::HashSet;

    #[test]
    fn ids_display_as_plain_numbers() {
        assert_eq!(UserId::new(7).to_string(), "7");
        assert_eq!(format!("订单 {}", OrderId::new(1001)), "订单 1001");
    }

    #[test]
    fn ids_can_be_hash_keys() {
        let set: HashSet<ProductId> =
            [ProductId::new(1), ProductId::new(1), ProductId::new(2)].into();
        assert_eq!(set.len(), 2);
    }
}
