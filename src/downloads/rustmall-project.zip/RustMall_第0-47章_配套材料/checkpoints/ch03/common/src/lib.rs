//! RustMall 公共库。
//!
//! 基础工具：
//! - [`money`]：金额计算与格式化（单位统一为“分”）
//! - [`pagination`]：分页参数换算
//! - [`search`]：搜索词解析（零拷贝）
//! - [`text`]：文本规范化与校验
//!
//! 领域模型（第 26 章拆分微服务时会迁移到各自的服务中）：
//! - [`ids`]：强类型 ID
//! - [`quantity`]：合法购买数量
//! - [`product`]：商品
//! - [`order`]：订单与订单状态机

pub mod ids;
pub mod money;
pub mod order;
pub mod pagination;
pub mod product;
pub mod quantity;
pub mod search;
pub mod text;
