//! RustMall 公共库。
//!
//! 常用类型可以一次性导入：`use common::prelude::*;`
//!
//! 基础工具：
//! - [`money`]：金额计算与格式化（单位统一为“分”）
//! - [`pagination`]：分页参数换算
//! - [`search`]：搜索词解析（零拷贝）
//! - [`text`]：文本规范化与校验
//! - [`validate`]：通用输入校验
//! - [`error`]：领域层统一错误
//! - [`repository`]：实体与仓储抽象
//! - [`shared`]：线程安全的共享仓储句柄
//! - [`id_gen`]：原子 ID 序列
//!
//! 领域模型（第 26 章拆分微服务时会迁移到各自的服务中）：
//! - [`ids`]：强类型 ID
//! - [`quantity`]：合法购买数量
//! - [`product`]：商品
//! - [`order`]：订单与订单状态机
//! - [`cart`]：购物车与优惠计算
//!
//! 测试支持：`fixtures` 模块在测试中或开启 `test-util` feature 时可用。

pub mod cart;
pub mod error;
pub mod id_gen;
pub mod ids;
pub mod money;
pub mod order;
pub mod pagination;
pub mod prelude;
pub mod product;
pub mod quantity;
pub mod repository;
pub mod search;
pub mod shared;
pub mod text;
pub mod validate;

#[cfg(any(test, feature = "test-util"))]
pub mod fixtures;
