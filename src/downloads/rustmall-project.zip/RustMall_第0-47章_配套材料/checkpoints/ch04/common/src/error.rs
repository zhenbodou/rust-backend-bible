//! RustMall 领域层统一错误类型。
//!
//! - [`ValidationError`]：输入校验失败的具体原因。
//! - [`DomainError`]：领域层对外暴露的唯一错误类型，所有领域函数都返回 [`DomainResult`]。
//! - [`ErrorKind`]：与传输协议无关的错误分类，HTTP 层和 gRPC 层据此映射状态码。

use thiserror::Error;

use crate::order::OrderError;

/// 输入校验失败的具体原因。
///
/// 字段名用 `&'static str`：字段名都是代码里写死的字面量，
/// 这样既不分配内存，又满足 `'static` 约束（见 4.4.6）。
#[derive(Debug, Clone, PartialEq, Eq, Error)]
pub enum ValidationError {
    #[error("字段 `{field}` 不能为空")]
    Empty { field: &'static str },

   #[error("字段 `{field}` 长度应为 {min}〜{max} 个字符，实际为 {actual} 个")]
   Length {
       field: &'static str,
       min: usize,
       max: usize,
       actual: usize,
    },
    #[error("字段 `{field}` 的值 {value} 超出范围 {min}〜{max}")]
    OutOfRange {
        field: &'static str,
        value: i64,
        min: i64,
        max: i64,
    },

    #[error("字段 `{field}` 格式不正确：{reason}")]
    Format { field: &'static str, reason: String },
}

/// 与传输协议无关的错误分类。
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum ErrorKind {
    /// 调用方传入的数据不合法。
    InvalidInput,
    /// 要操作的对象不存在。
    NotFound,
    /// 请求本身合法，但与当前业务状态冲突。
    Conflict,
    /// 服务端自身的问题。
    Internal,
}

impl ErrorKind {
    /// 稳定的机器可读错误码，会出现在 API 响应体里，发布后不要修改。
    pub const fn code(self) -> &'static str {
        match self {
            ErrorKind::InvalidInput => "INVALID_INPUT",
            ErrorKind::NotFound => "NOT_FOUND",
            ErrorKind::Conflict => "CONFLICT",
            ErrorKind::Internal => "INTERNAL",
        }
    }
}

/// 领域层统一错误。
#[derive(Debug, Error)]
pub enum DomainError {
    /// 输入校验失败。本层没有新信息，透明转发。
    #[error(transparent)]
    Validation(#[from] ValidationError),

    /// 订单状态机拒绝了某个操作。
    #[error(transparent)]
    Order(#[from] OrderError),

    #[error("{entity} {id} 不存在")]
    NotFound { entity: &'static str, id: String },

    #[error("商品 {product_id} 库存不足：需要 {requested}，剩余 {available}")]
     InsufficientStock {
         product_id: String,
         requested: u32,
         available: u32,
     },

     /// 不应该发生、但又不值得 panic 的情况。对外只显示“内部错误”，详情进日志。
     #[error("内部错误：{0}")]
     Internal(String),
 }

 impl DomainError {
     /// 构造“不存在”错误的便捷函数，`id` 接受任何能显示的类型。
     pub fn not_found(entity: &'static str, id: impl std::fmt::Display) -> Self {
         DomainError::NotFound {
             entity,
             id: id.to_string(),
         }
     }

     /// 返回错误分类，传输层据此决定状态码。
    pub fn kind(&self) -> ErrorKind {
        match self {
            DomainError::Validation(_) => ErrorKind::InvalidInput,
            DomainError::Order(OrderError::InvalidInput(_) | OrderError::AmountOverflow) => {
                ErrorKind::InvalidInput
            }
            DomainError::Order(OrderError::IllegalTransition { .. })
            | DomainError::InsufficientStock { .. } => ErrorKind::Conflict,
            DomainError::NotFound { .. } => ErrorKind::NotFound,
            DomainError::Internal(_) => ErrorKind::Internal,
        }
    }
}
/// 领域函数的统一返回类型。
pub type DomainResult<T> = Result<T, DomainError>;
#[cfg(test)]
mod tests {
    use super::*;

    // 引入 trait 才能调用 .source()
    use std::error::Error as _;

    fn require_name(name: &str) -> DomainResult<()> {
        // ValidationError 经 #[from] 自动转换
        crate::validate::non_empty("name", name)?;
        Ok(())
    }

    #[test]
    fn validation_error_converts_with_question_mark() {
        let err = require_name("   ").unwrap_err();
        assert!(matches!(
            err,
            DomainError::Validation(ValidationError::Empty { field: "name" })
        ));
        assert_eq!(err.kind(), ErrorKind::InvalidInput);
    }

    #[test]
    fn transparent_variant_forwards_display_and_source() {
        let err = DomainError::from(ValidationError::Empty { field: "name" });
        assert_eq!(err.to_string(), "字段 `name` 不能为空");
        assert!(err.source().is_none());
    }

    #[test]
    fn not_found_message_and_code() {
        let err = DomainError::not_found("商品", 42);
        assert_eq!(err.to_string(), "商品 42 不存在");
        assert_eq!(err.kind(), ErrorKind::NotFound);
        assert_eq!(err.kind().code(), "NOT_FOUND");
    }

    #[test]
    fn insufficient_stock_is_conflict() {
        let err = DomainError::InsufficientStock {
            product_id: "1001".to_string(),
            requested: 5,
            available: 2,
        };
        assert_eq!(err.to_string(), "商品 1001 库存不足：需要 5，剩余 2");
        assert_eq!(err.kind(), ErrorKind::Conflict);
    }

    #[test]
    fn errors_are_thread_safe_and_static() {
        fn assert_bounds<T: std::error::Error + Send + Sync + 'static>() {}
        assert_bounds::<DomainError>();
        assert_bounds::<ValidationError>();
    }

    #[test]
    fn order_errors_keep_their_business_classification() {
        use crate::order::OrderStatus;
        let invalid = DomainError::from(OrderError::InvalidInput("单价不能为负数"));
        assert_eq!(invalid.kind(), ErrorKind::InvalidInput);
        assert_eq!(
            DomainError::from(OrderError::AmountOverflow).kind(),
            ErrorKind::InvalidInput
        );
        let transition = DomainError::from(OrderError::IllegalTransition {
            from: OrderStatus::Pending,
            action: "ship",
        });
        assert_eq!(transition.kind(), ErrorKind::Conflict);
    }
}
