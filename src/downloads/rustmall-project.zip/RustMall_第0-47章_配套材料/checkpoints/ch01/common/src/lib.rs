//! RustMall 公共库。
//!
//! 存放所有服务都会用到、与具体业务无关的工具函数：
//! - [`money`]：金额计算与格式化（单位统一为“分”）
//! - [`pagination`]：分页参数换算
//! - [`text`]：文本规范化与校验

pub mod money;
pub mod pagination;
pub mod text;
