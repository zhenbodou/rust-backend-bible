//! 测试夹具：快速构造合法的领域对象。
//!
//! 只在本 crate 的测试中，或者其他 crate 开启 `test-util` feature 时编译。
//! 其他 crate 的用法（写在它们的 `[dev-dependencies]` 中）：
//!
//! ```toml
//! common = { path = "../common", features = ["test-util"] }
//! ```
//!
//! 夹具函数在参数不合法时直接 panic：测试数据写错属于测试代码的 bug，
//! 应当立即暴露，而不是返回 Result 让每个测试都去处理。

use crate::ids::ProductId;
use crate::product::Product;
use crate::quantity::Quantity;

/// 构造购买数量。
///
/// # Panics
/// `n` 不在 1~99 之间时 panic。
pub fn qty(n: i32) -> Quantity {
    Quantity::try_new(n).expect("夹具中的数量必须合法")
}

/// 构造商品。
///
/// # Panics
/// 名称为空、价格或库存为负时 panic。
pub fn product(id: i64, name: &str, price_cents: i64, stock: i32) -> Product {
    Product::try_new(ProductId::new(id), name, price_cents, stock).expect("夹具中的商品必须合法")
}

/// 一个常用的示例商品：ID 1，机械键盘，199 元，库存 100。
pub fn keyboard() -> Product {
    product(1, "机械键盘", 19_900, 100)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn fixtures_build_valid_objects() {
        let p = keyboard();
        assert_eq!(p.id(), ProductId::new(1));
        assert_eq!(p.stock(), 100);
        assert_eq!(qty(3).get(), 3);
    }

    #[test]
    #[should_panic(expected = "夹具中的数量必须合法")]
    fn invalid_fixture_panics_with_clear_message() {
        let _ = qty(0);
    }
}
