//! 常用类型的统一导入。
//!
//! ```
//! use common::prelude::*;
//!
//! let qty = Quantity::try_new(2).unwrap();
//! let product = Product::try_new(ProductId::new(1), "机械键盘", 19_900, 10).unwrap();
//! assert!(product.can_buy(qty));
//! ```

pub use crate::error::{DomainError, DomainResult, ErrorKind, ValidationError};
pub use crate::ids::{OrderId, ProductId, UserId};
pub use crate::order::{Order, OrderError, OrderState, OrderStatus};
pub use crate::product::Product;
pub use crate::quantity::Quantity;
pub use crate::repository::{Entity, InMemoryRepository, Repository};
