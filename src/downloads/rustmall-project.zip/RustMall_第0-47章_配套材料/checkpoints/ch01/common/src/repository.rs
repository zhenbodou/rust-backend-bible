//! 仓储（Repository）抽象：领域层通过它读写实体，不关心数据存放在哪里。
//!
//! 本章提供同步接口和内存实现，供单元测试和早期开发使用。
//! 接入 PostgreSQL 时，接口会改为异步，并新增数据库实现。

use std::collections::BTreeMap;
use std::collections::btree_map::Entry;
use std::fmt::Display;

 use crate::error::{DomainError, DomainResult};

/// 可以被仓储存取的实体。
pub trait Entity: Clone {
  /// 主键类型：要能克隆、排序（作为有序集合的键）、显示（用于错误信息）。
  type Id: Clone + Ord + Display;

     /// 实体的中文名称，用于错误信息和日志。
     const NAME: &'static str;

     /// 返回主键。
     fn id(&self) -> Self::Id;
 }

 /// 实体仓储。
 ///
 /// 读方法返回拥有所有权的实体（`E` 而不是 `&E`）：
 /// 数据库实现无法返回指向自身内部的引用，接口要为所有实现留出余地。
 pub trait Repository<E: Entity> {
     /// 新增实体；主键已存在时返回 [`DomainError::AlreadyExists`]。
     fn insert(&mut self, entity: E) -> DomainResult<()>;

     /// 按主键查询；不存在时返回 [`DomainError::NotFound`]。
     fn get(&self, id: &E::Id) -> DomainResult<E>;

    /// 整体替换已有实体；不存在时返回 [`DomainError::NotFound`]。
    fn update(&mut self, entity: E) -> DomainResult<()>;

    /// 删除并返回被删除的实体；不存在时返回 [`DomainError::NotFound`]。
    fn remove(&mut self, id: &E::Id) -> DomainResult<E>;

    /// 按主键升序分页列出实体。`offset` 超出范围时返回空列表。
    fn list(&self, offset: usize, limit: usize) -> Vec<E>;

    /// 实体总数。
    fn count(&self) -> usize;

    /// 主键是否存在。默认实现基于 `get`，具体实现可以覆盖成更高效的版本。
    fn contains(&self, id: &E::Id) -> bool {
        self.get(id).is_ok()
    }
}

/// 基于 `BTreeMap` 的内存仓储，按主键有序存放。
pub struct InMemoryRepository<E: Entity> {
    items: BTreeMap<E::Id, E>,
}
impl<E: Entity> InMemoryRepository<E> {
    /// 创建空仓储。
    pub fn new() -> Self {
        Self {
            items: BTreeMap::new(),
        }
    }
}

impl<E: Entity> Default for InMemoryRepository<E> {
    fn default() -> Self {
        Self::new()
    }
}

impl<E: Entity> Repository<E> for InMemoryRepository<E> {
    fn insert(&mut self, entity: E) -> DomainResult<()> {
        match self.items.entry(entity.id()) {
            Entry::Occupied(slot) => Err(DomainError::AlreadyExists {
                entity: E::NAME,
                id: slot.key().to_string(),
            }),
            Entry::Vacant(slot) => {
                slot.insert(entity);
                Ok(())
            }
        }
    }

    fn get(&self, id: &E::Id) -> DomainResult<E> {
        self.items
            .get(id)
            .cloned()
            .ok_or_else(|| DomainError::not_found(E::NAME, id))
     }

     fn update(&mut self, entity: E) -> DomainResult<()> {
         let id = entity.id();
         match self.items.get_mut(&id) {
             Some(slot) => {
                 *slot = entity;
                 Ok(())
             }
            None => Err(DomainError::not_found(E::NAME, id)),
        }
    }

    fn remove(&mut self, id: &E::Id) -> DomainResult<E> {
        self.items
            .remove(id)
            .ok_or_else(|| DomainError::not_found(E::NAME, id))
    }

    fn list(&self, offset: usize, limit: usize) -> Vec<E> {
        self.items
            .values()
            .skip(offset)
            .take(limit)
            .cloned()
            .collect()
    }

    fn count(&self) -> usize {
        self.items.len()
    }

    // 覆盖默认实现：直接查键，不必克隆实体
    fn contains(&self, id: &E::Id) -> bool {
        self.items.contains_key(id)
    }
}

#[cfg(test)]
mod tests {
  use super::*;
  use crate::error::ErrorKind;

    /// 测试专用实体，不依赖 Product 的具体字段
    #[derive(Debug, Clone, PartialEq, Eq)]
    struct Item {
        id: u32,
        name: String,
    }

    impl Entity for Item {
        type Id = u32;
        const NAME: &'static str = "测试商品";
        fn id(&self) -> u32 {
        self.id
    }
}

fn item(id: u32, name: &str) -> Item {
    Item {
        id,
        name: name.to_string(),
    }
}

/// 预先放入主键 1..=n 的仓储
fn seeded(n: u32) -> InMemoryRepository<Item> {
    let mut repo = InMemoryRepository::new();
    for id in 1..=n {
         repo.insert(item(id, &format!("商品{id}")))
             .expect("测试数据的主键互不重复");
    }
    repo
}

#[test]
fn insert_then_get() {
    let repo = seeded(1);
    assert_eq!(repo.get(&1).unwrap(), item(1, "商品1"));
    assert_eq!(repo.count(), 1);
}

#[test]
fn insert_duplicate_is_conflict_and_keeps_original() {
    let mut repo = seeded(1);
    let err = repo.insert(item(1, "重复")).unwrap_err();
    assert_eq!(err.kind(), ErrorKind::Conflict);
    assert_eq!(err.to_string(), "测试商品 1 已存在");
    assert_eq!(repo.get(&1).unwrap().name, "商品1");
}

#[test]
fn get_missing_is_not_found() {
    let repo = seeded(1);
    let err = repo.get(&9).unwrap_err();
    assert_eq!(err.kind(), ErrorKind::NotFound);
    assert_eq!(err.to_string(), "测试商品 9 不存在");
}
#[test]
fn update_replaces_existing_and_rejects_missing() {
    let mut repo = seeded(1);
    repo.update(item(1, "新名字")).unwrap();
    assert_eq!(repo.get(&1).unwrap().name, "新名字");

    let err = repo.update(item(2, "不存在")).unwrap_err();
    assert_eq!(err.kind(), ErrorKind::NotFound);

    // update 不会顺便插入
    assert_eq!(repo.count(), 1);
    }

    #[test]
    fn remove_returns_the_entity() {
        let mut repo = seeded(2);
        let removed = repo.remove(&1).unwrap();
        assert_eq!(removed.id, 1);
        assert!(!repo.contains(&1));
        assert!(repo.remove(&1).is_err());
        assert_eq!(repo.count(), 1);
    }

    #[test]
    fn list_paginates_in_id_order() {
        let mut repo = InMemoryRepository::new();
        for id in [3, 1, 5, 2, 4] {
            repo.insert(item(id, "x")).unwrap();
        }
        let ids = |page: Vec<Item>| page.into_iter().map(|i| i.id).collect::<Vec<_>>();

        assert_eq!(ids(repo.list(0, 2)), vec![1, 2]);
        assert_eq!(ids(repo.list(2, 2)), vec![3, 4]);
        assert_eq!(ids(repo.list(4, 2)), vec![5]);
        assert!(repo.list(10, 2).is_empty());
    }

    #[test]
    fn works_through_generics_and_trait_objects() {
        // 静态分发
        fn total<R: Repository<Item>>(repo: &R) -> usize {
            repo.count()
        }
        // 动态分发
        fn add(repo: &mut dyn Repository<Item>, it: Item) -> DomainResult<()> {
            repo.insert(it)
        }

        let mut repo = seeded(2);
        add(&mut repo, item(3, "经由 dyn 插入")).unwrap();
        assert_eq!(total(&repo), 3);

        let boxed: Box<dyn Repository<Item>> = Box::new(repo);
        assert!(boxed.contains(&3));
    }
}
