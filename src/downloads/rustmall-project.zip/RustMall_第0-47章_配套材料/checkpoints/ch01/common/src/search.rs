//! 商品搜索词解析。
//!
//! 分类和关键词借用解析输入；Vec 与 HashSet 仍需要存储空间，
//! 规范化步骤还可能创建拥有型字符串。
//! 适合“解析后立即用于构造查询”的短生命周期场景。

use std::borrow::Cow;
use std::collections::HashSet;

/// 一次搜索最多使用的关键词数量。
pub const MAX_KEYWORDS: usize = 5;

/// 解析后的搜索请求。
///
/// 生命周期 `'a` 表示：本结构体借用的字符串来自同一个输入，
/// 结构体实例不能比该输入活得更久。
#[derive(Debug, PartialEq, Eq)]
pub struct ParsedQuery<'a> {
    /// 分类前缀，例如 `外设`
    pub category: Option<&'a str>,
    /// 去重后的关键词，按出现顺序
    pub keywords: Vec<&'a str>,
}

/// 规范化搜索词：去除首尾空白并转为小写。
///
/// 无需大小写转换时直接借用输入（`Cow::Borrowed`，零分配）；
/// 需要大小写转换时才分配新字符串（`Cow::Owned`）。
pub fn normalize_query(input: &str) -> Cow<'_, str> {
    let trimmed = input.trim();
    if trimmed
        .chars()
        .any(|c| c.to_lowercase().ne(std::iter::once(c)))
    {
        Cow::Owned(trimmed.to_lowercase())
    } else {
        Cow::Borrowed(trimmed)
    }
}

/// 拆分分类前缀，支持半角 `:` 与全角 `：`。
///
/// 返回 `(分类, 其余部分)`，两者都借用自 `query`。
pub fn split_category(query: &str) -> (Option<&str>, &str) {
    let is_sep = |c: char| c == ':' || c == '：';
    match query.find(is_sep) {
        Some(index) => {
            let (category, rest) = query.split_at(index);
            // 分隔符可能是 1 字节（:）或 3 字节（：），按实际字符长度跳过
            let sep_len = rest.chars().next().map_or(0, char::len_utf8);
            let category = category.trim();
            let keywords = rest[sep_len..].trim();
            ((!category.is_empty()).then_some(category), keywords)
         }
         None => (None, query.trim()),
     }
 }

 /// 按空白与中英文逗号切分关键词，保序去重，最多保留 [`MAX_KEYWORDS`] 个。
 pub fn split_keywords(text: &str) -> Vec<&str> {
     let mut seen = HashSet::new();
     text.split(|c: char| c.is_whitespace() || c == ',' || c == '，')
         .filter(|word| !word.is_empty())
         .filter(|word| seen.insert(*word))
         .take(MAX_KEYWORDS)
         .collect()
 }

 /// 返回字符数最多的关键词；并列时返回最后一个。
 ///
 /// 注意签名中的 `'a`：返回值借自**原始文本**，而不是借自切片 `keywords` 本身，
 /// 因此即使关键词列表被释放，返回值依然有效。
 pub fn longest_keyword<'a>(keywords: &[&'a str]) -> Option<&'a str> {
     keywords.iter().copied().max_by_key(|k| k.chars().count())
 }

 /// 完整解析一个搜索请求。
 ///
 /// ```
 /// use common::search::parse;
 /// let p = parse("外设: 机械键盘 青轴");
 /// assert_eq!(p.category, Some("外设"));
 /// assert_eq!(p.keywords, vec!["机械键盘", "青轴"]);
 /// ```
 pub fn parse(query: &str) -> ParsedQuery<'_> {
     let (category, rest) = split_category(query);
     ParsedQuery {
         category,
         keywords: split_keywords(rest),
     }
 }

#[cfg(test)]
mod tests {
  use super::*;

     #[test]
     fn normalize_borrows_when_possible() {
         assert!(matches!(normalize_query(" 键盘 "), Cow::Borrowed("键盘")));
        assert!(matches!(normalize_query("RGB键盘"), Cow::Owned(_)));
        assert_eq!(normalize_query("RGB键盘"), "rgb键盘");
        // 标题形式字母也可能需要转换，不能只检查 is_uppercase
        assert_eq!(normalize_query("ǅ"), "ǆ");
    }

    #[test]
    fn category_supports_full_width_colon() {
        assert_eq!(
            split_category("外设：机械键盘 青轴"),
            (Some("外设"), "机械键盘 青轴")
        );
        assert_eq!(split_category(" : 键盘"), (None, "键盘"));
        assert_eq!(split_category("键盘"), (None, "键盘"));
    }

    #[test]
    fn keywords_are_deduplicated_in_order() {
        assert_eq!(
            split_keywords("键盘 鼠标,键盘，耳机"),
            vec!["键盘", "鼠标", "耳机"]
        );
    }

    #[test]
    fn keywords_are_limited() {
        assert_eq!(split_keywords("a b c d e f g").len(), MAX_KEYWORDS);
    }

    #[test]
    fn longest_keyword_outlives_the_list() {
        let text = String::from("键盘 机械键盘 鼠标");
        let best;
        {
            let keywords = split_keywords(&text);
            best = longest_keyword(&keywords);

           // keywords 在这里被释放，但 best 借自 text，仍然有效
        }
        assert_eq!(best, Some("机械键盘"));
    }
    #[test]
    fn parse_after_normalize() {
        let raw = String::from("   外设: RGB 键盘 ");

        // Cow：可能借用 raw，也可能拥有新字符串
        let normalized = normalize_query(&raw);

        // parsed 借用 normalized
        let parsed = parse(&normalized);
        assert_eq!(parsed.category, Some("外设"));
        assert_eq!(parsed.keywords, vec!["rgb", "键盘"]);
    }
}
