//! 文本规范化与校验。

/// 用户名最少字符数。
pub const USERNAME_MIN_CHARS: usize = 3;
/// 用户名最多字符数（按字符计，不是字节）。
pub const USERNAME_MAX_CHARS: usize = 20;

/// 规范化用户名：去除首尾空白、转为小写，并校验长度与字符。
///
/// 合法字符：字母（含中文等 Unicode 字母）、数字、下划线。
/// 不合法时返回描述原因的 `Err(String)`。
///
/// ```
/// use common::text::normalize_username;
/// assert_eq!(normalize_username(" Alice_01 "), Ok("alice_01".to_string()));
/// assert!(normalize_username("ab").is_err());
/// ```
pub fn normalize_username(input: &str) -> Result<String, String> {
    let name = input.trim().to_lowercase();
    let count = name.chars().count();
    if !(USERNAME_MIN_CHARS..=USERNAME_MAX_CHARS).contains(&count) {
        return Err(format!(
             "用户名长度需为 {USERNAME_MIN_CHARS}〜{USERNAME_MAX_CHARS} 个字符，当前为 {count} 个"
        ));
    }
    if let Some(bad) = name.chars().find(|c| !(c.is_alphanumeric() || *c == '_')) {
        return Err(format!("用户名包含不允许的字符：{bad:?}"));
    }
    Ok(name)
}

/// 按 Unicode 标量值数量截断；上限为 0 时返回空串，省略号也计入上限。
/// 这保证 UTF-8 边界，但不保证组合字形完整。用于简单的日志、列表摘要展示。
pub fn truncate_chars(s: &str, max_chars: usize) -> String {
    if max_chars == 0 {
        return String::new();
    }
    if s.chars().count() <= max_chars {
        return s.to_string();
    }
    let kept: String = s.chars().take(max_chars.saturating_sub(1)).collect();
    format!("{kept}…")
}

/// 本阶段只识别大小写固定的 `Bearer ` 前缀，返回非空令牌。
/// 这是教学用字符串处理函数，不是完整的 HTTP 认证解析与令牌验证。
pub fn bearer_token(header_value: &str) -> Option<&str> {
    header_value
        .strip_prefix("Bearer ")
        .map(str::trim)
        .filter(|t| !t.is_empty())
}

#[cfg(test)]
mod tests {
  use super::*;

    #[test]
    fn username_counts_chars_not_bytes() {
        // 3 个汉字 = 9 字节，但只算 3 个字符，应当合法
        assert_eq!(normalize_username("张三丰"), Ok("张三丰".to_string()));
        assert!(normalize_username("a b c").is_err());
        assert!(normalize_username(&"a".repeat(21)).is_err());
    }

    #[test]
    fn truncate_keeps_char_boundaries() {
        assert_eq!(truncate_chars("机械键盘青轴", 4), "机械键…");
        assert_eq!(truncate_chars("短", 4), "短");
        assert_eq!(truncate_chars("长文本", 0), "");
        assert_eq!(truncate_chars("长文本", 1), "…");
    }

    #[test]
    fn bearer_token_parsing() {
        assert_eq!(bearer_token("Bearer abc.def"), Some("abc.def"));
        assert_eq!(bearer_token("Basic xyz"), None);
        assert_eq!(bearer_token("Bearer   "), None);
    }
}
