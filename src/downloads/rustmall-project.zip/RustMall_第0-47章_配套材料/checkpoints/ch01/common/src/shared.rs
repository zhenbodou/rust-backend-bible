//! 线程安全的共享仓储句柄。
//!
//! [`Shared<R>`] 把任意仓储包装进 `Arc<RwLock<R>>`，克隆句柄只增加引用计数，
//! 所有克隆指向同一份数据。读写通过闭包进行，调用方拿不到锁守卫，
//! 因此锁的持有范围永远局限在闭包内部。

use std::sync::{Arc, PoisonError, RwLock};

use crate::error::{DomainError, DomainResult};
use crate::ids::ProductId;
use crate::product::Product;
use crate::quantity::Quantity;
use crate::repository::Repository;

/// 可在线程间克隆、共享的仓储句柄。
pub struct Shared<R> {
    inner: Arc<RwLock<R>>,
}

// 手写 Clone：#[derive(Clone)] 会生成 `impl<R: Clone> Clone`，
// 要求仓储本身可克隆，而克隆句柄只需要克隆 Arc。
impl<R> Clone for Shared<R> {
    fn clone(&self) -> Self {
        Self { inner: Arc::clone(&self.inner) }
    }
}

impl<R> Shared<R> {
    /// 包装一个仓储。
    pub fn new(inner: R) -> Self {
        Self { inner: Arc::new(RwLock::new(inner)) }
    }

    /// 持有读锁执行闭包。多个线程可以同时读。
    pub fn read<T>(&self, f: impl FnOnce(&R) -> T) -> T {
        let guard = self.inner.read().unwrap_or_else(PoisonError::into_inner);
        f(&*guard)
    }

    /// 持有写锁执行闭包。同一时刻只有一个写者，且没有读者。
    pub fn write<T>(&self, f: impl FnOnce(&mut R) -> T) -> T {
        let mut guard = self.inner.write().unwrap_or_else(PoisonError::into_inner);
        f(&mut *guard)
    }
}

/// 扣减商品库存，返回扣减后的商品。
///
/// 读取、检查、扣减、写回在同一把写锁内完成，因此任意多个线程并发调用也不会超卖。
///
/// # Errors
/// - 商品不存在：[`DomainError::NotFound`]
/// - 库存不足：[`DomainError::InsufficientStock`]，此时库存不变
pub fn reserve_stock<R>(repo: &Shared<R>, id: ProductId, qty: Quantity) -> 
    DomainResult<Product>
where
    R: Repository<Product>,
{
    repo.write(|r| {
        let mut product = r.get(&id)?;
        if !product.can_buy(qty) {
            return Err(DomainError::InsufficientStock {
                product_id: id.to_string(),
                requested: u32::try_from(qty.get()).unwrap_or(0),
                available: u32::try_from(product.stock()).unwrap_or(0),
            });
        }
        product.deduct_stock(qty).map_err(DomainError::Internal)?;
        r.update(product.clone())?;
        Ok(product)
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::error::ErrorKind;
    use crate::repository::{InMemoryRepository, Repository};
    use std::thread;

    type ProductStore = Shared<InMemoryRepository<Product>>;

    fn qty(n: i32) -> Quantity {
        Quantity::try_new(n).expect("测试数量合法")
    }

    /// 只有一个商品（ID 为 1）的共享仓储
    fn seeded(stock: i32) -> ProductStore {
        let mut repo = InMemoryRepository::new();
        let product = Product::try_new(ProductId::new(1), "限量键盘", 19_900, stock).expect("测试商品合法");
        repo.insert(product).expect("首次插入成功");
        Shared::new(repo)
    }

    fn stock_of(store: &ProductStore) -> Option<i32> {
        store.read(|r| r.get(&ProductId::new(1)).map(|p| p.stock())).ok()
    }

    #[test]
    fn reserve_reduces_stock_and_returns_product() {
        let store = seeded(5);
        let product = reserve_stock(&store, ProductId::new(1), qty(2)).expect("库存充足");
        assert_eq!(product.stock(), 3);
        assert_eq!(stock_of(&store), Some(3));
    }

    #[test]
    fn insufficient_stock_is_conflict_and_unchanged() {
        let store = seeded(1);
        let err = reserve_stock(&store, ProductId::new(1), qty(2)).expect_err("库存不足");
        assert_eq!(err.kind(), ErrorKind::Conflict);
        assert_eq!(err.to_string(), "商品 1 库存不足：需要 2，剩余 1");
        assert_eq!(stock_of(&store), Some(1));
    }

    #[test]
    fn missing_product_is_not_found() {
        let store = seeded(1);
        let err = reserve_stock(&store, ProductId::new(99), qty(1)).expect_err("商品不存在");
        assert_eq!(err.kind(), ErrorKind::NotFound);
    }

    #[test]
    fn concurrent_reservations_never_oversell() {
        let store = seeded(5);
        let one = qty(1);
        let successes = thread::scope(|s| {
            let mut handles = Vec::new();
            for _ in 0..8 {
                handles.push(s.spawn(|| reserve_stock(&store, ProductId::new(1), 
                    one).is_ok()));
            }
            handles
                .into_iter()
                .map(|h| h.join().expect("线程不应 panic"))
                .filter(|&ok| ok)
                .count()
        });
        assert_eq!(successes, 5, "8 个线程抢 5 件，恰好 5 个成功");
        assert_eq!(stock_of(&store), Some(0));
    }

    #[test]
    fn handle_moves_into_spawned_threads() {
        let store = seeded(10);
        let one = qty(1);
        let workers: Vec<_> = (0..4)
            .map(|_| {
                // 每个线程一个句柄，指向同一份数据
                let handle = store.clone();
                thread::spawn(move || reserve_stock(&handle, ProductId::new(1), one).is_ok())
            })
            .collect();
        for w in workers {
            assert!(w.join().expect("线程不应 panic"));
        }
        assert_eq!(stock_of(&store), Some(6));
    }
}
