//! 合法的购买数量（解析而非校验）。

/// 单笔购买数量，取值 1〜[`Quantity::MAX`]。
///
/// 字段私有，只能通过 [`Quantity::try_new`] 创建，
/// 因此任何 `Quantity` 实例都一定是合法的。
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, PartialOrd, Ord)]
pub struct Quantity(i32);

impl Quantity {
  /// 单笔最大购买数量。
  pub const MAX: i32 = 99;

    /// 校验并创建购买数量。
    pub fn try_new(n: i32) -> Result<Self, String> {
        if (1..=Self::MAX).contains(&n) {
            Ok(Self(n))
        } else {
            Err(format!("购买数量需为 1〜{} 件，当前为 {n}", Self::MAX))
        }
    }

    pub const fn get(self) -> i32 {
        self.0
    }
}

#[cfg(test)]
mod tests {
  use super::*;

    #[test]
    fn quantity_bounds() {
        assert!(Quantity::try_new(0).is_err());
        assert!(Quantity::try_new(-3).is_err());
        assert!(Quantity::try_new(100).is_err());
        assert_eq!(Quantity::try_new(1).map(Quantity::get), Ok(1));
        assert_eq!(Quantity::try_new(99).map(Quantity::get), Ok(99));
    }
}
