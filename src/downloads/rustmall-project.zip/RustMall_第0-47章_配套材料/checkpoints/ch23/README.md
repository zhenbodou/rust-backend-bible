# RustMall 第 23 章检查点

本目录从原书第 18 章单体代码顺序合入第 20-23 章变更，保持 common、monolith 与新增 platform。它不包含未来微服务。

请按对应章节准备依赖与配置。真实数据库测试需独立实验 PostgreSQL，ignored 测试还需 Docker。不要连接生产数据库。工作流只在符合条件的 GitHub 仓库环境中发布。

恢复来源和本次实测范围见 ../../review/ 下记录；未运行的 Docker 镜像、远端 Actions 或 Kubernetes 部分不得视为已通过。
