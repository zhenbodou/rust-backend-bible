#![allow(clippy::unwrap_used)]
//! 端到端冒烟测试：在一个全新的 PostgreSQL 17 容器中执行全部迁移并跑通主流程（第 17.6 节）。
//!
//! 它回答的问题是“从零开始的环境能否工作”，而不是测试某条业务规则。
//! 需要本机运行 Docker，默认被忽略。运行方式：
//!
//! ```text
//! cargo test -p monolith --test pg_container -- --ignored
//! ```

mod support;

use axum::http::StatusCode;
use sqlx::postgres::PgPoolOptions;
use support::*;
use testcontainers_modules::postgres::Postgres;
use testcontainers_modules::testcontainers::ImageExt;
use testcontainers_modules::testcontainers::runners::AsyncRunner;

/// 与 `scripts/dev-db.sh`、生产环境保持一致的 PostgreSQL 版本。
const POSTGRES_TAG: &str = "17-alpine";

#[tokio::test]
#[ignore = "需要 Docker：cargo test -p monolith --test pg_container -- --ignored"]
async fn migrations_and_main_flow_on_fresh_postgres() {
    // 容器必须保存在变量中直到测试结束：它被丢弃时容器随之删除
    let container = Postgres::default()
        .with_tag(POSTGRES_TAG)
        .start()
        .await
        .expect("启动 PostgreSQL 容器（Docker 是否在运行？）");
    let host = container.get_host().await.expect("容器主机");
    let port = container
        .get_host_port_ipv4(5432)
        .await
        .expect("映射后的端口");
    let url = format!("postgres://postgres:postgres@{host}:{port}/postgres");

    let pool = PgPoolOptions::new()
        .max_connections(5)
        .connect(&url)
        .await
        .expect("连接容器中的数据库");
    // 与服务启动时执行的是同一组迁移（第 14.10 节）
    monolith::db::MIGRATOR
        .run(&pool)
        .await
        .expect("在全新数据库上执行迁移");

    // 主流程：注册管理员 → 登录 → 创建商品 → 匿名浏览 → 下架
    let app = app(pool.clone());
    let token = admin_token(&app, &pool).await;
    let id = create_product(&app, &token, "容器里的键盘").await;

    let uri = format!("/api/v1/products/{id}");
    let (status, product) = send(&app, get(&uri)).await;
    assert_eq!(status, StatusCode::OK);
    assert_eq!(product["name"], "容器里的键盘");

    let (status, _) = send(&app, with_token(delete(&uri), &token)).await;
    assert_eq!(status, StatusCode::NO_CONTENT);
    assert_eq!(send(&app, get(&uri)).await.0, StatusCode::NOT_FOUND);
}
