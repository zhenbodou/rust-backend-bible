#![allow(clippy::unwrap_used)]
//! API 契约快照（第 17.7 节）：固定响应的“形状”--状态码、字段名、字段类型、错误码。
//!
//! 字段的增删、改名、类型变化都会让快照不一致，必须在代码审查中被明确接受。
//! 快照文件在 `tests/snapshots/` 中：生成与更新用 `cargo insta review`，`.snap` 文件需要提交。

mod support;

use axum::http::StatusCode;
use insta::assert_json_snapshot;
use serde_json::{Value, json};
use sqlx::PgPool;
use support::*;

/// 把状态码和响应体放进同一个快照，两者都是契约的一部分。
fn snapshot(status: StatusCode, body: Value) -> Value {
    json!({ "status": status.as_u16(), "body": body })
}

fn product_body() -> Value {
    json!({ "name": "机械键盘", "price_cents": 19_900, "stock": 10 })
}

#[sqlx::test]
async fn register_response(pool: PgPool) {
    let app = app(pool);

    let (status, body) = register(&app, "alice_01", "S3cure-Passw0rd").await;

    // 注册时间每次都不同：脱敏为固定文字，但保留“字段存在”这一事实
    assert_json_snapshot!(snapshot(status, body), {
        ".body.created_at" => "[timestamp]",
    });
}

#[sqlx::test]
async fn login_response(pool: PgPool) {
    let app = app(pool);
    register(&app, "alice_01", "S3cure-Passw0rd").await;
    let credentials = json!({ "username": "alice_01", "password": "S3cure-Passw0rd" });

    let request = json_request("POST", "/api/v1/auth/login", &credentials);

    let (status, body) = send(&app, request).await;

    assert_json_snapshot!(snapshot(status, body), { ".body.access_token" => "[jwt]" });
}

#[sqlx::test]
async fn product_list_page(pool: PgPool) {
    let app = app(pool.clone());
    let token = admin_token(&app, &pool).await;
    create_product(&app, &token, "机械键盘").await;
    create_product(&app, &token, "无线鼠标").await;

    let (status, body) = send(&app, get("/api/v1/products")).await;

    assert_json_snapshot!(snapshot(status, body));
}

#[sqlx::test]
async fn not_found_error(pool: PgPool) {
    let (status, body) = send(&app(pool), get("/api/v1/products/999")).await;

    assert_json_snapshot!(snapshot(status, body));
}

#[sqlx::test]
async fn missing_token_error(pool: PgPool) {
    let request = json_request("POST", "/api/v1/products", &product_body());

    let (status, body) = send(&app(pool), request).await;

    assert_json_snapshot!(snapshot(status, body));
}

#[sqlx::test]
async fn non_admin_error(pool: PgPool) {
    let app = app(pool);
    register(&app, "alice_01", "S3cure-Passw0rd").await;
    let token = login(&app, "alice_01", "S3cure-Passw0rd").await;
    let request = json_request("POST", "/api/v1/products", &product_body());
    let request = with_token(request, &token);

    let (status, body) = send(&app, request).await;

    assert_json_snapshot!(snapshot(status, body));
}
