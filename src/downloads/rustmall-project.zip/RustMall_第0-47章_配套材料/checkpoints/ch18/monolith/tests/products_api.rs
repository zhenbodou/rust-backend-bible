#![allow(clippy::unwrap_used)]
//! 商品接口的 HTTP 层测试。写操作需要管理员令牌（第 16 章）。

mod support;

use axum::body::Body;
use axum::http::{Request, StatusCode};
use serde_json::{Value, json};
use sqlx::PgPool;
use support::*;
use tower::ServiceExt;

fn product_json(name: &str, price_cents: i64, stock: i32) -> Value {
    json!({ "name": name, "price_cents": price_cents, "stock": stock })
}

#[sqlx::test]
async fn health_live_is_ok(pool: PgPool) {
    let (status, body) = send(&app(pool), get("/health/live")).await;
    assert_eq!(status, StatusCode::OK);
    assert_eq!(body, json!({ "status": "ok" }));
}

#[sqlx::test]
async fn health_ready_checks_database(pool: PgPool) {
    let (status, body) = send(&app(pool), get("/health/ready")).await;
    assert_eq!(status, StatusCode::OK);
    assert_eq!(body, json!({ "status": "ok" }));
}

#[sqlx::test]
async fn create_then_get(pool: PgPool) {
    let app = app(pool.clone());
    let token = admin_token(&app, &pool).await;
    let request = with_token(
        json_request(
            "POST",
            "/api/v1/products",
            &product_json("机械键盘", 19_900, 10),
        ),
        &token,
    );
    let (status, created) = send(&app, request).await;
    assert_eq!(status, StatusCode::CREATED);
    assert_eq!(
        created,
        json!({ "id": 1, "name": "机械键盘", "price_cents": 19900, "stock": 10
        })
    );

    // 浏览商品不需要登录
    let (status, fetched) = send(&app, get("/api/v1/products/1")).await;
    assert_eq!(status, StatusCode::OK);
    assert_eq!(fetched, created);
}

#[sqlx::test]
async fn create_sets_location_header(pool: PgPool) {
    let app = app(pool.clone());
    let token = admin_token(&app, &pool).await;
    let request = with_token(
        json_request(
            "POST",
            "/api/v1/products",
            &product_json("机械键盘", 19_900, 10),
        ),
        &token,
    );
    let response = app.oneshot(request).await.unwrap();
    assert_eq!(response.status(), StatusCode::CREATED);
    assert_eq!(response.headers()["location"], "/api/v1/products/1");
}

#[sqlx::test]
async fn create_rejects_invalid_product(pool: PgPool) {
    let app = app(pool.clone());
    let token = admin_token(&app, &pool).await;
    let request = with_token(
        json_request("POST", "/api/v1/products", &product_json("键盘", -1, 0)),
        &token,
    );
    let (status, error) = send(&app, request).await;
    assert_eq!(status, StatusCode::UNPROCESSABLE_ENTITY);
    assert_eq!(error["code"], "INVALID_INPUT");
}

#[sqlx::test]
async fn create_rejects_unknown_field(pool: PgPool) {
    let app = app(pool.clone());
    let token = admin_token(&app, &pool).await;
    let body = json!({ "id": 99, "name": "键盘", "price_cents": 100, "stock": 1 });
    let (status, error) = send(
        &app,
        with_token(json_request("POST", "/api/v1/products", &body), &token),
    )
    .await;
    assert_eq!(status, StatusCode::UNPROCESSABLE_ENTITY);
    assert_eq!(error["code"], "INVALID_INPUT");
}

#[sqlx::test]
async fn malformed_json_is_400(pool: PgPool) {
    let app = app(pool.clone());
    let token = admin_token(&app, &pool).await;
    let request = Request::post("/api/v1/products")
        .header("content-type", "application/json")
        .body(Body::from("{ not json"))
        .unwrap();
    let (status, error) = send(&app, with_token(request, &token)).await;
    assert_eq!(status, StatusCode::BAD_REQUEST);
    assert_eq!(error["code"], "BAD_REQUEST");
}

#[sqlx::test]
async fn get_missing_is_404(pool: PgPool) {
    let (status, error) = send(&app(pool), get("/api/v1/products/999")).await;
    assert_eq!(status, StatusCode::NOT_FOUND);
    assert_eq!(
        error,
        json!({ "code": "NOT_FOUND", "message": "商品 999 不存在" })
    );
}

#[sqlx::test]
async fn update_replaces_product(pool: PgPool) {
    let app = app(pool.clone());
    let token = admin_token(&app, &pool).await;
    let id = create_product(&app, &token, "旧名字").await;
    let uri = format!("/api/v1/products/{id}");

    let request = with_token(
        json_request("PUT", &uri, &product_json("新名字", 500, 7)),
        &token,
    );
    let (status, updated) = send(&app, request).await;
    assert_eq!(status, StatusCode::OK);
    assert_eq!(
        updated,
        json!({ "id": id, "name": "新名字", "price_cents": 500, "stock": 7 })
    );

    let (_, fetched) = send(&app, get(&uri)).await;
    assert_eq!(fetched, updated);
}

#[sqlx::test]
async fn update_missing_is_404(pool: PgPool) {
    let app = app(pool.clone());
    let token = admin_token(&app, &pool).await;
    let request = with_token(
        json_request("PUT", "/api/v1/products/42", &product_json("键盘", 100, 1)),
        &token,
    );
    let (status, _) = send(&app, request).await;
    assert_eq!(status, StatusCode::NOT_FOUND);
}

#[sqlx::test]
async fn delete_delists_product(pool: PgPool) {
    let app = app(pool.clone());
    let token = admin_token(&app, &pool).await;
    let id = create_product(&app, &token, "键盘").await;
    let uri = format!("/api/v1/products/{id}");

    let (status, body) = send(&app, with_token(delete(&uri), &token)).await;
    assert_eq!(status, StatusCode::NO_CONTENT);
    assert_eq!(body, Value::Null);

    assert_eq!(send(&app, get(&uri)).await.0, StatusCode::NOT_FOUND);
    assert_eq!(
        send(&app, with_token(delete(&uri), &token)).await.0,
        StatusCode::NOT_FOUND
    );
}

#[sqlx::test]
async fn list_excludes_delisted_and_paginates_newest_first(pool: PgPool) {
    let app = app(pool.clone());
    let token = admin_token(&app, &pool).await;
    let a = create_product(&app, &token, "A").await;
    let b = create_product(&app, &token, "B").await;
    let c = create_product(&app, &token, "C").await;
    send(
        &app,
        with_token(delete(&format!("/api/v1/products/{b}")), &token),
    )
    .await;

    let (status, page1) = send(&app, get("/api/v1/products?page=1&page_size=1")).await;
    assert_eq!(status, StatusCode::OK);
    assert_eq!(page1["total"], 2);
    assert_eq!(page1["items"][0]["id"], c);

    let (_, page2) = send(&app, get("/api/v1/products?page=2&page_size=1")).await;
    assert_eq!(page2["items"][0]["id"], a);
}

#[sqlx::test]
async fn unknown_route_is_404_json(pool: PgPool) {
    let (status, error) = send(&app(pool), get("/api/v1/nothing-here")).await;
    assert_eq!(status, StatusCode::NOT_FOUND);
    assert_eq!(error["code"], "NOT_FOUND");
}

#[sqlx::test]
async fn responses_carry_request_id(pool: PgPool) {
    let app = app(pool);
    let response = app.clone().oneshot(get("/health/live")).await.unwrap();
    let generated = response.headers()["x-request-id"].to_str().unwrap();
    assert_eq!(generated.len(), 36, "应当是 UUID：{generated}");

    let request = Request::get("/health/live")
        .header("x-request-id", "abc-123")
        .body(Body::empty())
        .unwrap();
    let response = app.oneshot(request).await.unwrap();
    assert_eq!(response.headers()["x-request-id"], "abc-123");
}
