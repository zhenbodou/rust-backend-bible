-- 测试夹具：商品目录（第 17.3.3 节）。
--
-- 1 号最早上架；2 号已下架；3 号与 4 号的创建时间完全相同，用来检验“时间相同按 ID 倒序”。
-- 期望的列表顺序：4、3、1。

-- products.id 是 GENERATED ALWAYS AS IDENTITY，手动指定 ID 必须加 OVERRIDING SYSTEM VALUE
INSERT INTO products (id, name, price_cents, stock, created_at, updated_at, delisted_at)
OVERRIDING SYSTEM VALUE
VALUES
    (1, '旧款机械键盘', 9900, 5, '2026-01-01T00:00:00Z', '2026-01-01T00:00:00Z', NULL),
    (2, '停产鼠标', 4900, 0, '2026-02-01T00:00:00Z', '2026-03-01T00:00:00Z',
        '2026-03-01T00:00:00Z'),
    (3, '新款机械键盘', 19900, 8, '2026-03-01T00:00:00Z', '2026-03-01T00:00:00Z', NULL),
    (4, '降噪耳机', 29900, 3, '2026-03-01T00:00:00Z', '2026-03-01T00:00:00Z', NULL);

-- 手动指定 ID 不会推进序列；不推进的话，下一次自动分配的 ID 是 1，与上面的数据冲突
SELECT setval(pg_get_serial_sequence('products', 'id'), (SELECT max(id) FROM products));
