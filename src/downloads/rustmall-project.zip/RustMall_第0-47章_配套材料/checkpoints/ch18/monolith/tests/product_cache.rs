#![allow(clippy::unwrap_used)]
//! 两级缓存与真实 Redis 的集成测试（第 18.10 节）。
//!
//! 需要 Docker（testcontainers 启动 Redis）和开发数据库，默认被忽略。运行方式：
//!
//! ```text
//! cargo test -p monolith --test product_cache -- --ignored
//! ```

use std::time::{Duration, Instant};

use common::error::ErrorKind;
use common::ids::ProductId;
use common::product::{NewProduct, Product};
use monolith::cache::{ProductCache, connect_redis, product_key};
use monolith::repo::ProductRepository;
use monolith::repo::cached::CachedProductRepo;
use monolith::repo::products::PgProductRepo;
use monolith::settings::{CacheSettings, RedisSettings};
use redis::AsyncCommands;
use sqlx::PgPool;
use testcontainers_modules::testcontainers::core::{IntoContainerPort, WaitFor};
use testcontainers_modules::testcontainers::runners::AsyncRunner;
use testcontainers_modules::testcontainers::{ContainerAsync, GenericImage};

/// 启动一个全新的 Redis 容器，返回容器（必须持有到测试结束）与连接地址。
async fn start_redis() -> (ContainerAsync<GenericImage>, String) {
    let container = GenericImage::new("redis", "7.4-alpine")
        .with_exposed_port(6379.tcp())
        .with_wait_for(WaitFor::message_on_stdout("Ready to accept connections"))
        .start()
        .await
        .expect("启动 Redis 容器（Docker 是否在运行？）");
    let host = container.get_host().await.expect("容器主机");
    let port = container
        .get_host_port_ipv4(6379)
        .await
        .expect("映射后的端口");
    (container, format!("redis://{host}:{port}"))
}

/// 模拟一个服务实例：独立的进程内缓存，与其他实例共享同一个 Redis 和数据库。
async fn instance(pool: &PgPool, url: &str) -> CachedProductRepo<PgProductRepo> {
    let settings = RedisSettings {
        url: Some(url.to_string()),
        ..RedisSettings::default()
    };
    let redis = connect_redis(&settings).await;
    assert!(redis.is_some(), "应当能连接测试用的 Redis");
    let op_timeout = Duration::from_millis(settings.op_timeout_ms);
    let cache = ProductCache::new(&CacheSettings::default(), redis, op_timeout);
    CachedProductRepo::new(PgProductRepo::new(pool.clone()), cache)
}

fn keyboard(id: ProductId, name: &str) -> Product {
    Product::try_new(id, name, 19_900, 10).unwrap()
}

#[sqlx::test]
#[ignore = "需要 Docker：cargo test -p monolith --test product_cache -- --ignored"]
async fn redis_is_shared_between_instances_until_invalidated(pool: PgPool) {
    let (_redis, url) = start_redis().await;
    let a = instance(&pool, &url).await;
    let draft = NewProduct::try_new("机械键盘", 19_900, 10).unwrap();
    let id = a.insert(&draft).await.unwrap().id();
    // 实例 A 回源，并把结果写入 Redis
    a.get(id).await.unwrap();

    // 绕过缓存直接修改数据库，制造“缓存与数据库不一致”
    sqlx::query("UPDATE products SET name = '被直接改掉的名字' WHERE id = $1")
        .bind(id.get())
        .execute(&pool)
        .await
        .unwrap();

    // 实例 B 的进程内缓存是空的，读到的是 Redis 中的值：证明 L2 在实例之间共享
    let b = instance(&pool, &url).await;
    assert_eq!(b.get(id).await.unwrap().name(), "机械键盘");

    // 通过仓储写入会删除 Redis 中的键：之后启动的实例 C 读到最新数据
    a.update(&keyboard(id, "静音机械键盘")).await.unwrap();
    let c = instance(&pool, &url).await;
    assert_eq!(c.get(id).await.unwrap().name(), "静音机械键盘");
}

#[sqlx::test]
#[ignore = "需要 Docker：cargo test -p monolith --test product_cache -- --ignored"]
async fn missing_marker_is_short_lived(pool: PgPool) {
    let (_redis, url) = start_redis().await;
    let repo = instance(&pool, &url).await;
    let missing = ProductId::new(999);

    let err = repo.get(missing).await.unwrap_err();
    assert_eq!(err.kind(), ErrorKind::NotFound);

    let client = redis::Client::open(url.as_str()).unwrap();
    let mut con = client.get_multiplexed_async_connection().await.unwrap();
    let raw: Option<String> = con.get(product_key(missing)).await.unwrap();
    assert_eq!(raw.as_deref(), Some(r#"{"state":"missing"}"#));
    let ttl: i64 = con.ttl(product_key(missing)).await.unwrap();
    assert!(
        (1..=30).contains(&ttl),
        "“不存在”标记应当短期过期，实际 TTL：{ttl}"
    );
}

#[sqlx::test]
#[ignore = "需要 Docker：cargo test -p monolith --test product_cache -- --ignored"]
async fn redis_outage_degrades_to_database(pool: PgPool) {
    let (redis, url) = start_redis().await;
    let repo = instance(&pool, &url).await;
    let draft = NewProduct::try_new("机械键盘", 19_900, 10).unwrap();
    let id = repo.insert(&draft).await.unwrap().id();

    // Redis 宕机
    redis.stop().await.expect("停止 Redis 容器");

    let started = Instant::now();
    assert_eq!(repo.get(id).await.unwrap().name(), "机械键盘");
    repo.update(&keyboard(id, "静音机械键盘")).await.unwrap();
    assert_eq!(repo.get(id).await.unwrap().name(), "静音机械键盘");
    // 每次 Redis 操作最多等待 200 毫秒，而不是一直卡住
    assert!(
        started.elapsed() < Duration::from_secs(3),
        "耗时 {:?}",
        started.elapsed()
    );
}

#[sqlx::test]
#[ignore = "需要 Docker：cargo test -p monolith --test product_cache -- --ignored"]
async fn mismatched_cached_product_id_falls_back_to_database(pool: PgPool) {
    let (_redis, url) = start_redis().await;
    let source = PgProductRepo::new(pool.clone());
    let wanted = source.insert(&NewProduct::try_new("实际商品", 19900, 10).unwrap()).await.unwrap();
    let other = source.insert(&NewProduct::try_new("另一商品", 9900, 3).unwrap()).await.unwrap();
    let client = redis::Client::open(url.as_str()).unwrap();
    let mut connection = client.get_multiplexed_async_connection().await.unwrap();
    let wrong = serde_json::json!({"state":"found", "id":other.id().get(),
        "name":other.name(), "price_cents":other.price_cents(), "stock":other.stock()});
    let _: () = connection.set_ex(product_key(wanted.id()), wrong.to_string(), 30).await.unwrap();
    let repo = instance(&pool, &url).await;
    let read = repo.get(wanted.id()).await.unwrap();
    assert_eq!(read.id(), wanted.id());
    assert_eq!(read.name(), "实际商品");
    let raw: String = connection.get(product_key(wanted.id())).await.unwrap();
    let repaired: serde_json::Value = serde_json::from_str(&raw).unwrap();
    assert_eq!(repaired["id"], wanted.id().get());
}
