#![allow(clippy::unwrap_used)]
//! 基于 SQL 夹具的商品列表测试：数据由 `tests/fixtures/catalog.sql` 精确构造（第 17.3.3 节）。

mod support;

use axum::http::StatusCode;
use serde_json::Value;
use sqlx::PgPool;
use support::*;

/// 取出列表响应中各商品的 ID，保持顺序。
fn ids(page: &Value) -> Vec<i64> {
    page["items"]
        .as_array()
        .expect("items 应当是数组")
        .iter()
        .map(|item| item["id"].as_i64().expect("id 应当是整数"))
        .collect()
}

#[sqlx::test(fixtures("catalog"))]
async fn list_orders_by_created_at_then_id(pool: PgPool) {
    let (status, page) = send(&app(pool), get("/api/v1/products?page_size=10")).await;

    assert_eq!(status, StatusCode::OK);
    // 3、4 号创建时间相同，按 ID 倒序；2 号已下架，不出现
    assert_eq!(ids(&page), [4, 3, 1]);
    assert_eq!(page["total"], 3);
}

#[sqlx::test(fixtures("catalog"))]
async fn delisted_product_is_not_found(pool: PgPool) {
    let (status, error) = send(&app(pool), get("/api/v1/products/2")).await;

    assert_eq!(status, StatusCode::NOT_FOUND);
    assert_eq!(error["code"], "NOT_FOUND");
}

#[sqlx::test(fixtures("catalog"))]
async fn new_product_continues_after_fixture_ids(pool: PgPool) {
    let app = app(pool.clone());
    let token = admin_token(&app, &pool).await;

    let id = create_product(&app, &token, "新上架的鼠标").await;

    // 夹具末尾的 setval 让序列从 5 继续
    assert_eq!(id, 5);
    let (_, page) = send(&app, get("/api/v1/products?page_size=1")).await;
    assert_eq!(ids(&page), [5]);
}
