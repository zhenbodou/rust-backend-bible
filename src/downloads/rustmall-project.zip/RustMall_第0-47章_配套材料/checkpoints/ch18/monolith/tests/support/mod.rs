//! 集成测试共享的辅助函数。
//!
//! `tests/` 下的每个 .rs 文件都会编译成一个独立的测试程序；放在子目录 `support/mod.rs` 中的代码
//! 不会被单独编译，而是由各测试文件通过 `mod support;` 引入。

// 每个测试程序只用到其中一部分函数，未使用的函数不应产生警告
#![allow(dead_code)]

use axum::Router;
use axum::body::Body;
use axum::http::{HeaderValue, Request, StatusCode, header};
use http_body_util::BodyExt;
use monolith::auth::jwt::JwtKeys;
use monolith::cache::ProductCache;
use monolith::http::routes::router;
use monolith::settings::CacheSettings;
use monolith::settings::CorsSettings;
use monolith::state::AppState;
use secrecy::SecretString;
use serde_json::{Value, json};
use sqlx::PgPool;
use tower::ServiceExt;

/// 测试专用的 JWT 密钥。
pub const TEST_SECRET: &str = "integration-test-secret-0123456789abcdef";

/// 管理员账号（由 `admin_token` 创建）。
pub const ADMIN: (&str, &str) = ("admin", "admin-passw0rd");

pub fn app(pool: PgPool) -> Router {
    let jwt = JwtKeys::new(
        &SecretString::from(TEST_SECRET.to_string()),
        "rustmall",
        900,
    );
    router(
        AppState::new(
            pool,
            jwt,
            ProductCache::local_only(&CacheSettings::default()),
        ),
        &CorsSettings::default(),
    )
}
/// 发送请求，返回状态码与 JSON 响应体（空响应体为 Null）。
pub async fn send(app: &Router, request: Request<Body>) -> (StatusCode, Value) {
    let response = app
        .clone()
        .oneshot(request)
        .await
        .expect("Router 不会返回错误");
    let status = response.status();
    let bytes = response
        .into_body()
        .collect()
        .await
        .expect("读取响应体")
        .to_bytes();
    let body = if bytes.is_empty() {
        Value::Null
    } else {
        serde_json::from_slice(&bytes).expect("响应体应当是 JSON")
    };
    (status, body)
}

pub fn get(uri: &str) -> Request<Body> {
    Request::get(uri).body(Body::empty()).expect("合法的请求")
}

pub fn delete(uri: &str) -> Request<Body> {
    Request::delete(uri)
        .body(Body::empty())
        .expect("合法的请求")
}

pub fn json_request(method: &str, uri: &str, body: &Value) -> Request<Body> {
    Request::builder()
        .method(method)
        .uri(uri)
        .header("content-type", "application/json")
        .body(Body::from(body.to_string()))
        .expect("合法的请求")
}

/// 给请求加上 `Authorization: Bearer <token>`。
pub fn with_token(mut request: Request<Body>, token: &str) -> Request<Body> {
    let value = HeaderValue::from_str(&format!("Bearer {token}")).expect("合法的请求头");
    request.headers_mut().insert(header::AUTHORIZATION, value);
    request
}

/// 注册用户，返回响应状态与响应体。
pub async fn register(app: &Router, username: &str, password: &str) -> (StatusCode, Value) {
    let body = json!({ "username": username, "password": password });
    send(app, json_request("POST", "/api/v1/auth/register", &body)).await
}

/// 登录并返回访问令牌；登录失败时测试直接失败。
pub async fn login(app: &Router, username: &str, password: &str) -> String {
    let body = json!({ "username": username, "password": password });
    let (status, token) = send(app, json_request("POST", "/api/v1/auth/login", &body)).await;
    assert_eq!(status, StatusCode::OK, "登录失败：{token}");
    token["access_token"]
        .as_str()
        .expect("响应中应当有 access_token")
        .to_string()
}

/// 注册一个用户、在数据库中把它提升为管理员，然后登录，返回管理员的访问令牌。
pub async fn admin_token(app: &Router, pool: &PgPool) -> String {
    let (status, body) = register(app, ADMIN.0, ADMIN.1).await;
    assert_eq!(status, StatusCode::CREATED, "注册管理员失败：{body}");
    sqlx::query("UPDATE users SET role = 'admin' WHERE username = $1")
        .bind(ADMIN.0)
        .execute(pool)
        .await
        .expect("提升为管理员");
    // 角色在登录时写入令牌，所以必须在提升之后再登录
    login(app, ADMIN.0, ADMIN.1).await
}

/// 以管理员身份创建一个商品，返回商品 ID。
pub async fn create_product(app: &Router, token: &str, name: &str) -> i64 {
    let body = json!({ "name": name, "price_cents": 100, "stock": 1 });
    let request = with_token(json_request("POST", "/api/v1/products", &body), token);
    let (status, created) = send(app, request).await;
    assert_eq!(status, StatusCode::CREATED, "创建商品失败：{created}");
    created["id"].as_i64().expect("响应中应当有数字 id")
}
