#![allow(clippy::unwrap_used)]
//! 认证与授权接口的 HTTP 层测试。

mod support;

use axum::http::StatusCode;
use serde_json::json;
use sqlx::PgPool;
use support::*;
use tower::ServiceExt;

#[sqlx::test]
async fn register_returns_201_with_normalized_user(pool: PgPool) {
    let (status, user) = register(&app(pool), "  Alice_01 ", "S3cure-Passw0rd").await;
    assert_eq!(status, StatusCode::CREATED);
    assert_eq!(
        (
            user["id"].as_i64(),
            user["username"].as_str(),
            user["role"].as_str()
        ),
        (Some(1), Some("alice_01"), Some("user"))
    );
    // created_at 是 RFC 3339 时间字符串；响应中绝不包含密码哈希
    assert!(
        user["created_at"].as_str().is_some_and(|s| s.contains('T')),
        "{user}"
    );
    assert!(user.get("password_hash").is_none());
}

#[sqlx::test]
async fn duplicate_username_is_409_case_insensitively(pool: PgPool) {
    let app = app(pool);
    register(&app, "alice_01", "S3cure-Passw0rd").await;
    let (status, error) = register(&app, "ALICE_01", "Another-Passw0rd").await;
    assert_eq!(status, StatusCode::CONFLICT);
    assert_eq!(error["message"], "用户名 alice_01 已存在");
}

#[sqlx::test]
async fn invalid_registration_reports_all_fields(pool: PgPool) {
    let (status, error) = register(&app(pool), "ab", "short").await;
    assert_eq!(status, StatusCode::UNPROCESSABLE_ENTITY);
    let message = error["message"].as_str().unwrap();
    assert!(
        message.contains("username") && message.contains("password"),
        "{message}"
    );
}

#[sqlx::test]
async fn login_returns_bearer_token(pool: PgPool) {
    let app = app(pool);
    register(&app, "alice_01", "S3cure-Passw0rd").await;
    let body = json!({ "username": "alice_01", "password": "S3cure-Passw0rd" });
    let (status, token) = send(&app, json_request("POST", "/api/v1/auth/login", &body)).await;
    assert_eq!(status, StatusCode::OK);
    assert_eq!(
        (token["token_type"].as_str(), token["expires_in"].as_u64()),
        (Some("Bearer"), Some(900))
    );
    assert_eq!(
        token["access_token"].as_str().unwrap().split('.').count(),
        3,
        "JWT 由三段组成"
    );
}

#[sqlx::test]
async fn wrong_password_and_unknown_user_get_identical_401(pool: PgPool) {
    let app = app(pool);
    register(&app, "alice_01", "S3cure-Passw0rd").await;

    let wrong = json!({ "username": "alice_01", "password": "wrong-password" });
    let response = app
        .clone()
        .oneshot(json_request("POST", "/api/v1/auth/login", &wrong))
        .await
        .unwrap();
    assert_eq!(response.status(), StatusCode::UNAUTHORIZED);
    assert_eq!(response.headers()["www-authenticate"], "Bearer");

    let (_, wrong_body) = send(&app, json_request("POST", "/api/v1/auth/login", &wrong)).await;
    let unknown = json!({ "username": "nobody", "password": "wrong-password" });
    let (status, unknown_body) =
        send(&app, json_request("POST", "/api/v1/auth/login", &unknown)).await;
    assert_eq!(status, StatusCode::UNAUTHORIZED);
    assert_eq!(wrong_body, unknown_body);
}

#[sqlx::test]
async fn me_requires_a_valid_token(pool: PgPool) {
    let app = app(pool);
    let (status, error) = send(&app, get("/api/v1/users/me")).await;
    assert_eq!(
        (status, error["code"].as_str()),
        (StatusCode::UNAUTHORIZED, Some("UNAUTHORIZED"))
    );

    let (status, _) = send(&app, with_token(get("/api/v1/users/me"), "not.a.jwt")).await;
    assert_eq!(status, StatusCode::UNAUTHORIZED);
}

#[sqlx::test]
async fn me_returns_current_user(pool: PgPool) {
    let app = app(pool);
    register(&app, "alice_01", "S3cure-Passw0rd").await;
    let token = login(&app, "alice_01", "S3cure-Passw0rd").await;
    let (status, me) = send(&app, with_token(get("/api/v1/users/me"), &token)).await;
    assert_eq!(status, StatusCode::OK);
    assert_eq!(me["username"], "alice_01");
}

#[sqlx::test]
async fn product_management_requires_admin(pool: PgPool) {
    let app = app(pool.clone());
    let body = json!({ "name": "键盘", "price_cents": 100, "stock": 1 });

    // 未登录：401
    let (status, _) = send(&app, json_request("POST", "/api/v1/products", &body)).await;
    assert_eq!(status, StatusCode::UNAUTHORIZED);

    // 普通用户：403
    register(&app, "alice_01", "S3cure-Passw0rd").await;
    let user_token = login(&app, "alice_01", "S3cure-Passw0rd").await;
    let (status, error) = send(
        &app,
        with_token(json_request("POST", "/api/v1/products", &body), &user_token),
    )
    .await;
    assert_eq!(
        (status, error["code"].as_str()),
        (StatusCode::FORBIDDEN, Some("FORBIDDEN"))
    );

    // 管理员：201
    let admin = admin_token(&app, &pool).await;
    let (status, _) = send(
        &app,
        with_token(json_request("POST", "/api/v1/products", &body), &admin),
    )
    .await;
    assert_eq!(status, StatusCode::CREATED);
}
