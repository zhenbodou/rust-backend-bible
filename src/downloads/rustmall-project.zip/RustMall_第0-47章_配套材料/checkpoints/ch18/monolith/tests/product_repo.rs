#![allow(clippy::unwrap_used)]
//! 商品仓储与数据库错误转换的集成测试。

use common::error::ErrorKind;
use common::ids::ProductId;
use common::product::{NewProduct, Product};
use monolith::db;
use monolith::repo::ProductRepository;
use monolith::repo::products::PgProductRepo;
use sqlx::PgPool;

/// 构造一个已校验的待插入商品。
fn draft(name: &str, price_cents: i64, stock: i32) -> NewProduct {
    NewProduct::try_new(name, price_cents, stock).expect("合法的测试商品")
}

#[sqlx::test]
async fn insert_assigns_increasing_ids_and_trims_name(pool: PgPool) {
    let repo = PgProductRepo::new(pool);
    let first = repo.insert(&draft("  键盘  ", 100, 1)).await.unwrap();
    let second = repo.insert(&draft("鼠标", 200, 2)).await.unwrap();

    assert_eq!(first.id(), ProductId::new(1));
    assert_eq!(second.id(), ProductId::new(2));
    // try_new 去掉了首尾空白，数据库中保存的是规范化后的名称
    assert_eq!(first.name(), "键盘");
    assert_eq!(repo.get(first.id()).await.unwrap(), first);
}

#[sqlx::test]
async fn get_missing_returns_not_found(pool: PgPool) {
    let err = PgProductRepo::new(pool)
        .get(ProductId::new(42))
        .await
        .unwrap_err();
    assert_eq!(err.kind(), ErrorKind::NotFound);
    assert_eq!(err.to_string(), "商品 42 不存在");
}

#[sqlx::test]
async fn delisted_product_is_invisible_but_row_is_kept(pool: PgPool) {
    let repo = PgProductRepo::new(pool.clone());
    let product = repo.insert(&draft("键盘", 100, 1)).await.unwrap();
    repo.delist(product.id()).await.unwrap();

    assert_eq!(
        repo.get(product.id()).await.unwrap_err().kind(),
        ErrorKind::NotFound
    );
    assert_eq!(
        repo.update(&product).await.unwrap_err().kind(),
        ErrorKind::NotFound
    );
    assert_eq!(
        repo.delist(product.id()).await.unwrap_err().kind(),
        ErrorKind::NotFound
    );

    // 软删除：行仍然存在，只是记录了下架时间
    let delisted: i64 =
        sqlx::query_scalar("SELECT count(*) FROM products WHERE delisted_at IS NOT NULL")
            .fetch_one(&pool)
            .await
            .unwrap();
    assert_eq!(delisted, 1);
}

#[sqlx::test]
async fn list_counts_only_listed_products(pool: PgPool) {
    let repo = PgProductRepo::new(pool);
    for name in ["A", "B", "C"] {
        repo.insert(&draft(name, 100, 1)).await.unwrap();
    }
    repo.delist(ProductId::new(2)).await.unwrap();

    let (items, total) = repo.list(10, 0).await.unwrap();
    assert_eq!(total, 2);
    let names: Vec<&str> = items.iter().map(Product::name).collect();
    assert_eq!(names, ["C", "A"]);
}
#[sqlx::test]
async fn check_violation_becomes_internal_error(pool: PgPool) {
    // 绕过领域校验直接写入非法价格，模拟“代码规则与约束不一致”的缺陷
    let err =
        sqlx::query("INSERT INTO products (name, price_cents, stock) VALUES ('坏商品', -1, 0)")
            .execute(&pool)
            .await
            .unwrap_err();
    assert_eq!(db::to_domain(err).kind(), ErrorKind::Internal);
}

#[sqlx::test]
async fn foreign_key_violation_becomes_conflict(pool: PgPool) {
    // 用户 1 不存在：违反 cart_items.user_id 的外键约束
    let err =
        sqlx::query("INSERT INTO cart_items (user_id, product_id, quantity) VALUES (1, 1, 1)")
            .execute(&pool)
            .await
            .unwrap_err();
    let domain = db::to_domain(err);
    assert_eq!(domain.kind(), ErrorKind::Conflict);
    assert!(
        domain.to_string().contains("cart_items_"),
        "实际消息：{domain}"
    );
}
