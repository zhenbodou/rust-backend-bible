-- 迁移 0002：商品下架（软删除）。
-- 有订单引用的商品不能物理删除（orders.product_id 外键，第 13.9.4 节），
-- 所以 DELETE /api/v1/products/{id} 改为记录下架时间。

-- 可空、无默认值的列：PostgreSQL 只修改表的元数据，不重写已有数据，对大表也是瞬间完成
ALTER TABLE products ADD COLUMN delisted_at TIMESTAMPTZ;

-- 列表只查询在售商品：把排序索引换成只包含在售商品的部分索引（第 13.6.3 节）
DROP INDEX products_created_at_id_idx;
CREATE INDEX products_listed_created_idx
    ON products (created_at DESC, id DESC)
    WHERE delisted_at IS NULL;
