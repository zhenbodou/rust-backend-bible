-- RustMall 单体阶段的数据库结构。
-- 第 14 章起作为 sqlx 迁移文件 monolith/migrations/0001_init.sql 由程序执行。

-- 模糊搜索扩展（商品名搜索，见 13.6.3 节）
CREATE EXTENSION IF NOT EXISTS pg_trgm;

-- ---------------------------------------------------------------- 用户
CREATE TABLE users (
    id            BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    username      TEXT        NOT NULL UNIQUE
                              CHECK (char_length(username) BETWEEN 3 AND 20),
    password_hash TEXT        NOT NULL,
    role          TEXT        NOT NULL DEFAULT 'user'
                              CHECK (role IN ('user', 'admin')),
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ---------------------------------------------------------------- 商品
CREATE TABLE products (
    id          BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    name        TEXT        NOT NULL CHECK (char_length(name) BETWEEN 1 AND 100),
    price_cents BIGINT      NOT NULL CHECK (price_cents >= 0),
    stock       INTEGER     NOT NULL CHECK (stock >= 0),
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 商品列表按创建时间倒序分页（13.5.5 节）
CREATE INDEX products_created_at_id_idx ON products (created_at DESC, id DESC);
-- 商品名模糊搜索
CREATE INDEX products_name_trgm_idx ON products USING gin (name gin_trgm_ops);

-- ---------------------------------------------------------------- 购物车
CREATE TABLE cart_items (
    user_id    BIGINT      NOT NULL REFERENCES users (id) ON DELETE CASCADE,
    product_id BIGINT      NOT NULL REFERENCES products (id) ON DELETE CASCADE,
    quantity   INTEGER     NOT NULL CHECK (quantity BETWEEN 1 AND 99),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (user_id, product_id)
);

-- ---------------------------------------------------------------- 订单
CREATE TABLE orders (
    id               BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    user_id          BIGINT      NOT NULL REFERENCES users (id),
    product_id       BIGINT      NOT NULL REFERENCES products (id),
    quantity         INTEGER     NOT NULL CHECK (quantity BETWEEN 1 AND 99),
    unit_price_cents BIGINT      NOT NULL CHECK (unit_price_cents >= 0),
    total_cents      BIGINT      NOT NULL,
    status           TEXT        NOT NULL DEFAULT 'pending'
                                 CHECK (status IN ('pending', 'paid', 'shipped', 'completed', 'cancelled')),
    paid_at          TIMESTAMPTZ,
    tracking_no      TEXT,
    cancel_reason    TEXT,
    idempotency_key  UUID        NOT NULL,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at       TIMESTAMPTZ NOT NULL DEFAULT now(),

    CONSTRAINT orders_total_matches CHECK (total_cents = unit_price_cents * quantity),
    CONSTRAINT orders_tracking_by_status CHECK ((status IN ('shipped', 'completed')) = 
        (tracking_no IS NOT NULL)),
    CONSTRAINT orders_reason_by_status CHECK ((status = 'cancelled') = (cancel_reason IS NOT 
        NULL)),
    CONSTRAINT orders_paid_at_by_status CHECK (status NOT IN ('paid', 'shipped', 'completed') OR paid_at IS NOT NULL),
    CONSTRAINT orders_idempotency UNIQUE (user_id, idempotency_key)
);

-- “我的订单”按时间倒序分页
CREATE INDEX orders_user_created_idx ON orders (user_id, created_at DESC, id DESC);
-- 超时未支付订单的扫描只关心 pending（部分索引，13.6.3 节）
CREATE INDEX orders_pending_created_idx ON orders (created_at) WHERE status = 'pending';
-- 外键列不会自动建索引；按商品统计销量、删除商品前检查引用时需要
CREATE INDEX orders_product_idx ON orders (product_id);
