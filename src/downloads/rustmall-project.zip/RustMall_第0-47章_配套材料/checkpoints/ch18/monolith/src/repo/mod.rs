//! 仓储层：数据的存取。服务层只依赖这里的 trait，不依赖具体数据库。

pub mod cached;
pub mod products;
pub mod users;

use std::future::Future;

use crate::auth::User;
use common::error::DomainResult;
use common::ids::{ProductId, UserId};
use common::product::{NewProduct, Product};

/// 商品仓储。
///
/// 返回类型写成 `impl Future + Send` 而不是 `async fn`：保证返回的 Future 可以在线程间移动，
/// Axum 处理函数才能调用它（第 15.5.3 节）。实现时仍然可以直接写 `async fn`。
pub trait ProductRepository: Clone + Send + Sync + 'static {
    /// 新增商品，ID 由存储分配。
    fn insert(&self, draft: &NewProduct) -> impl Future<Output = DomainResult<Product>> + Send;

    /// 按 ID 查询在售商品；不存在或已下架时返回“不存在”。
    fn get(&self, id: ProductId) -> impl Future<Output = DomainResult<Product>> + Send;

    /// 按创建时间倒序分页列出在售商品，并返回在售商品总数。
    fn list(
        &self,
        limit: i64,
        offset: i64,
    ) -> impl Future<Output = DomainResult<(Vec<Product>, i64)>> + Send;

    /// 整体替换在售商品的可修改字段。
    fn update(&self, product: &Product) -> impl Future<Output = DomainResult<Product>> + Send;

    /// 下架商品。
    fn delist(&self, id: ProductId) -> impl Future<Output = DomainResult<()>> + Send;
}

/// 登录校验需要的数据：用户信息 + 密码哈希。只在仓储与认证服务之间传递，从不返回给客戶端。
#[derive(Debug, Clone)]
pub struct UserCredentials {
    pub user: User,
    pub password_hash: String,
}

/// 用户仓储。
pub trait UserRepository: Clone + Send + Sync + 'static {
    /// 新增用户（角色为普通用户）。用户名已存在时返回 `AlreadyExists`。
    fn insert(
        &self,
        username: &str,
        password_hash: &str,
    ) -> impl Future<Output = DomainResult<User>> + Send;

    /// 按（已规范化的）用户名查询登录凭证；不存在时返回 `None`。
    fn find_credentials(
        &self,
        username: &str,
    ) -> impl Future<Output = DomainResult<Option<UserCredentials>>> + Send;

    /// 按 ID 查询用户。
    fn get(&self, id: UserId) -> impl Future<Output = DomainResult<User>> + Send;
}
