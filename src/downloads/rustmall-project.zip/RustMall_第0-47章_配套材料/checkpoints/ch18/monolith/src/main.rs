//! RustMall 单体服务入口：配置 → 日志 → 数据库 → 组装 → 运行 → 停机。

use std::time::Duration;

use anyhow::Context;
use monolith::auth::jwt::JwtKeys;
use monolith::cache::{ProductCache, connect_redis};
use monolith::settings::Settings;
use monolith::state::AppState;
use monolith::{background, db, http, shutdown, telemetry};
use tokio_util::sync::CancellationToken;

#[tokio::main]
async fn main() -> anyhow::Result<()> {
    // 0. 本地开发：加载 .env（文件不存在时忽略；已存在的环境变量不会被覆盖）
    dotenvy::dotenv().ok();

    // 1. 配置。此时日志系统还没有初始化，失败时由 anyhow 把错误打印到标准错误
    let settings = Settings::load().context("加载配置失败")?;

    // 2. 日志
    telemetry::init(&settings.log).context("初始化日志失败")?;
    tracing::info!(?settings, "配置已加载");

    // 3. 数据库
    let pool = db::connect(&settings.database)
        .await
        .context("连接数据库失败")?;
    db::MIGRATOR
        .run(&pool)
        .await
        .context("执行数据库迁移失败")?;
    tracing::info!("数据库已连接，迁移已是最新");

    // 4. 信号处理与后台任务
    let token = CancellationToken::new();
    tokio::spawn(shutdown::wait_for_signal(token.clone()));

    let cleaner = tokio::spawn(background::run_periodic(
        Duration::from_secs(60),
        token.clone(),
        || async { tracing::debug!("清理过期的购物车") },
    ));

    // 5. HTTP 服务
    let jwt = JwtKeys::new(
        &settings.auth.jwt_secret,
        &settings.auth.issuer,
        settings.auth.access_token_ttl_secs,
    );
    let redis = connect_redis(&settings.redis).await;
    let cache = ProductCache::new(
        &settings.cache,
        redis,
        Duration::from_millis(settings.redis.op_timeout_ms),
    );
    let app = http::routes::router(AppState::new(pool.clone(), jwt, cache), &settings.cors);
    let addr = settings.server.addr();
    let listener = tokio::net::TcpListener::bind(&addr)
        .await
        .with_context(|| format!("绑定地址 {addr} 失败"))?;
    tracing::info!(%addr, "RustMall 单体服务已启动");

    axum::serve(listener, app)
        .with_graceful_shutdown(token.clone().cancelled_owned())
        .await
        .context("HTTP 服务异常退出")?;
    tracing::info!("HTTP 服务已停止，等待后台任务结束");

    // 6. 停机
    let grace = settings.server.shutdown_grace();
    match tokio::time::timeout(grace, cleaner).await {
        Ok(Ok(runs)) => tracing::info!(runs, "后台任务已停止"),
        Ok(Err(e)) => tracing::error!(error = %e, "后台任务异常退出"),
        Err(_) => tracing::warn!(?grace, "后台任务未能按时停止，强制退出"),
    }

    pool.close().await;
    tracing::info!("数据库连接池已关闭，服务退出");
    Ok(())
}
