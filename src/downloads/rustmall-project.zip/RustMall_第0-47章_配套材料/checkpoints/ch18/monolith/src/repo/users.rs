//! 用户仓储的 PostgreSQL 实现。

use chrono::{DateTime, Utc};
use common::error::{DomainError, DomainResult};
use common::ids::UserId;
use sqlx::PgPool;
use tracing::instrument;

use super::{UserCredentials, UserRepository};
use crate::auth::{Role, User};
use crate::db;

#[derive(Debug, sqlx::FromRow)]
struct UserRow {
    id: i64,
    username: String,
    role: String,
    created_at: DateTime<Utc>,
}

impl UserRow {
    fn into_user(self) -> DomainResult<User> {
        Ok(User {
            id: UserId::new(self.id),
            username: self.username,
            role: Role::from_db(&self.role)?,
            created_at: self.created_at,
        })
    }
}

/// 用户信息 + 密码哈希：`flatten` 让 UserRow 的字段从同一行中读取（第 14.4.5 节）。
#[derive(Debug, sqlx::FromRow)]
struct CredentialsRow {
    #[sqlx(flatten)]
    user: UserRow,
    password_hash: String,
}

#[derive(Debug, Clone)]
pub struct PgUserRepo {
    pool: PgPool,
}

impl PgUserRepo {
    pub fn new(pool: PgPool) -> Self {
        Self { pool }
    }
}

impl UserRepository for PgUserRepo {
    #[instrument(level = "debug", skip(self, password_hash))]
    async fn insert(&self, username: &str, password_hash: &str) -> DomainResult<User> {
        let result = sqlx::query_as::<_, UserRow>(
            "INSERT INTO users (username, password_hash) VALUES ($1, $2) \
             RETURNING id, username, role, created_at",
        )
        .bind(username)
        .bind(password_hash)
        .fetch_one(&self.pool)
        .await;

        match result {
            Ok(row) => row.into_user(),
            // 用户名唯一约束：翻译成比通用 Conflict 更具体的错误
            Err(err) if is_unique_violation(&err) => Err(DomainError::AlreadyExists {
                entity: "用户名",
                id: username.to_string(),
            }),
            Err(err) => Err(db::to_domain(err)),
        }
    }

    #[instrument(level = "debug", skip(self))]
    async fn find_credentials(&self, username: &str) -> DomainResult<Option<UserCredentials>> {
        let row = sqlx::query_as::<_, CredentialsRow>(
            "SELECT id, username, role, created_at, password_hash FROM users WHERE username = $1",
        )
        .bind(username)
        .fetch_optional(&self.pool)
        .await
        .map_err(db::to_domain)?;

        row.map(|r| {
            Ok(UserCredentials {
                user: r.user.into_user()?,
                password_hash: r.password_hash,
            })
        })
        .transpose()
    }

    #[instrument(level = "debug", skip(self))]
    async fn get(&self, id: UserId) -> DomainResult<User> {
        sqlx::query_as::<_, UserRow>(
            "SELECT id, username, role, created_at FROM users WHERE 
            id = $1",
        )
        .bind(id.get())
        .fetch_optional(&self.pool)
        .await
        .map_err(db::to_domain)?
        .ok_or_else(|| DomainError::not_found("用户", id))?
        .into_user()
    }
}

fn is_unique_violation(err: &sqlx::Error) -> bool {
    err.as_database_error()
        .is_some_and(|db_err| matches!(db_err.kind(), sqlx::error::ErrorKind::UniqueViolation))
}
