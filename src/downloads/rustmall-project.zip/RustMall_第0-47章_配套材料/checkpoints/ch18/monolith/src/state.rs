//! 应用状态：把各层组装在一起，供所有请求共享。

use sqlx::PgPool;

use crate::auth::jwt::JwtKeys;
use crate::cache::ProductCache;
use crate::repo::cached::CachedProductRepo;
use crate::repo::products::PgProductRepo;
use crate::repo::users::PgUserRepo;
use crate::service::auth::AuthService;
use crate::service::products::ProductService;

/// 商品服务使用的仓储：数据库仓储外面包一层两级缓存（第 18 章）。
pub type ProductRepo = CachedProductRepo<PgProductRepo>;

/// 每个字段都能廉价克隆：连接池、缓存、密钥内部都是 `Arc`。
#[derive(Clone)]
pub struct AppState {
    /// 连接池本身：健康检查等不属于任何服务的查询使用
    pub pool: PgPool,
    /// 商品服务
    pub products: ProductService<ProductRepo>,
    /// 认证服务
    pub auth: AuthService<PgUserRepo>,
}

impl AppState {
    pub fn new(pool: PgPool, jwt: JwtKeys, cache: ProductCache) -> Self {
        let products = CachedProductRepo::new(PgProductRepo::new(pool.clone()), cache);
        Self {
            products: ProductService::new(products),
            auth: AuthService::new(PgUserRepo::new(pool.clone()), jwt),
            pool,
        }
    }
}
