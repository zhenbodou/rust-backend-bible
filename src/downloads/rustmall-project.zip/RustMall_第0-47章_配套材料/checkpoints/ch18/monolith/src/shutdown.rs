//! 停机信号处理。

use tokio_util::sync::CancellationToken;

/// 等待 Ctrl+C（所有平台）或 SIGTERM（Unix），收到任一信号后取消 `token`。
///
/// 本地开发按 Ctrl+C 发送的是 SIGINT；Docker 停止容器、Kubernetes 删除 Pod 时发送的是 SIGTERM。
/// 某个信号无法监听时只记录错误并忽略它，另一个信号仍然有效。
pub async fn wait_for_signal(token: CancellationToken) {
    let ctrl_c = async {
        if let Err(e) = tokio::signal::ctrl_c().await {
            tracing::error!(error = %e, "无法监听 Ctrl+C");
            std::future::pending::<()>().await;
        }
    };

    #[cfg(unix)]
    let terminate = async {
        match tokio::signal::unix::signal(tokio::signal::unix::SignalKind::terminate()) {
            Ok(mut sig) => {
                sig.recv().await;
            }
            Err(e) => {
                tracing::error!(error = %e, "无法监听 SIGTERM");
                std::future::pending::<()>().await;
            }
        }
    };

    #[cfg(not(unix))]
    let terminate = std::future::pending::<()>();

    tokio::select! {
        () = ctrl_c => {}
        () = terminate => {}
    }
    tracing::info!("收到停机信号，开始优雅停机");
    token.cancel();
}
