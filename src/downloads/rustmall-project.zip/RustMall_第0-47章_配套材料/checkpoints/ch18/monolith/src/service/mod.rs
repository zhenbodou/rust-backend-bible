//! 服务层：业务流程与规则。只依赖领域类型与仓储 trait，不知道 HTTP 与 SQL 的存在。

pub mod auth;
pub mod products;
