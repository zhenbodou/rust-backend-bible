//! 认证基础设施：用户模型、密码哈希、访问令牌。

pub mod jwt;
pub mod password;

use chrono::{DateTime, Utc};
use common::error::{DomainError, DomainResult};
use common::ids::UserId;
use serde::{Deserialize, Serialize};

/// 用户角色。数据库中以小写文本存储（第 13.9.4 节的 CHECK 约束）。
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum Role {
    User,
    Admin,
}

impl Role {
    /// 数据库中的文本表示。
    pub const fn as_str(self) -> &'static str {
        match self {
            Role::User => "user",
            Role::Admin => "admin",
        }
    }

    /// 从数据库文本解析。数据库有 CHECK 约束，出现未知值说明数据被破坏，按内部错误处理。
    pub fn from_db(text: &str) -> DomainResult<Self> {
        match text {
            "user" => Ok(Role::User),
            "admin" => Ok(Role::Admin),
            other => Err(DomainError::Internal(format!("未知的用户角色：{other}"))),
        }
    }
}

/// 对外可见的用户信息（不含密码哈希）。JSON 形状见 `docs/api-v1.md` 5.1 节。
#[derive(Debug, Clone, PartialEq, Eq, Serialize)]
pub struct User {
    pub id: UserId,
    pub username: String,
    pub role: Role,
    pub created_at: DateTime<Utc>,
}
