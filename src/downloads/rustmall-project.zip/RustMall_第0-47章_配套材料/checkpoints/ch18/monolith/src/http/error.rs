//! HTTP 层的统一错误：把领域错误和请求解析错误转换为 `{code, message}` 响应。

use axum::Json;
use axum::http::{HeaderValue, StatusCode, header};
use axum::response::{IntoResponse, Response};
use common::error::{DomainError, ErrorKind};
use serde::Serialize;

/// 错误响应体，格式见 `docs/api-v1.md` 第 2 节。
#[derive(Debug, Serialize)]
pub struct ErrorBody {
    pub code: &'static str,
    pub message: String,
}

/// 处理函数返回的错误类型。
#[derive(Debug)]
pub enum ApiError {
    /// 请求无法解析：JSON 语法错误、缺少 Content-Type 等
    BadRequest(String),
    /// 请求体结构不符合要求：缺少字段、类型不对、取值不合法、存在未知字段
    Unprocessable(String),
    /// 领域层返回的错误
    Domain(DomainError),
}

impl From<DomainError> for ApiError {
    fn from(e: DomainError) -> Self {
        ApiError::Domain(e)
    }
}

impl IntoResponse for ApiError {
    fn into_response(self) -> Response {
        let (status, code, message) = match self {
            ApiError::BadRequest(message) => (StatusCode::BAD_REQUEST, "BAD_REQUEST", message),
            ApiError::Unprocessable(message) => (
                StatusCode::UNPROCESSABLE_ENTITY,
                ErrorKind::InvalidInput.code(),
                message,
            ),
            ApiError::Domain(e) => {
                let kind = e.kind();
                let status = match kind {
                    ErrorKind::InvalidInput => StatusCode::UNPROCESSABLE_ENTITY,
                    ErrorKind::Unauthorized => StatusCode::UNAUTHORIZED,
                    ErrorKind::Forbidden => StatusCode::FORBIDDEN,
                    ErrorKind::NotFound => StatusCode::NOT_FOUND,
                    ErrorKind::Conflict => StatusCode::CONFLICT,
                    ErrorKind::Internal => StatusCode::INTERNAL_SERVER_ERROR,
                };
                let message = if kind == ErrorKind::Internal {
                    // 内部错误的细节只进日志（带上当前请求 span 的请求 ID），绝不返回给客戶端
                    tracing::error!(error = ?e, "内部错误");
                    "服务器内部错误".to_string()
                } else {
                    e.to_string()
                };
                (status, kind.code(), message)
            }
        };

        let mut response = (status, Json(ErrorBody { code, message })).into_response();
        if status == StatusCode::UNAUTHORIZED {
            // RFC 7235：401 响应应当告诉客戶端使用哪种认证方式
            response
                .headers_mut()
                .insert(header::WWW_AUTHENTICATE, HeaderValue::from_static("Bearer"));
        }
        response
    }
}
