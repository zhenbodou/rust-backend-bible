//! 认证服务：注册、登录、令牌校验。

use std::sync::Arc;

use common::error::{DomainError, DomainResult, ValidationError};
use common::ids::UserId;
use common::text::normalize_username;
use secrecy::{ExposeSecret, SecretString};
use tracing::{info, instrument};

use crate::auth::jwt::{AccessToken, Claims, JwtKeys};
use crate::auth::{User, password};
use crate::repo::UserRepository;

/// 密码长度范围（按字符计）。上限防止超长输入拖慢哈希计算。
pub const PASSWORD_MIN_CHARS: usize = 8;
pub const PASSWORD_MAX_CHARS: usize = 64;

/// 注册或登录的输入。密码以 `SecretString` 保存，Debug 输出不会泄露。
#[derive(Debug)]
pub struct Credentials {
    pub username: String,
    pub password: SecretString,
}

#[derive(Clone)]
pub struct AuthService<R> {
    repo: R,
    jwt: Arc<JwtKeys>,
}
impl<R: UserRepository> AuthService<R> {
    pub fn new(repo: R, jwt: JwtKeys) -> Self {
        Self {
            repo,
            jwt: Arc::new(jwt),
        }
    }

    /// 注册普通用户。
    #[instrument(skip_all, fields(username = %input.username))]
    pub async fn register(&self, input: Credentials) -> DomainResult<User> {
        let username = normalize_username(&input.username).map_err(|reason| {
            DomainError::from(ValidationError::Format {
                field: "username",
                reason,
            })
        })?;

        let chars = input.password.expose_secret().chars().count();
        if !(PASSWORD_MIN_CHARS..=PASSWORD_MAX_CHARS).contains(&chars) {
            return Err(ValidationError::Length {
                field: "password",
                min: PASSWORD_MIN_CHARS,
                max: PASSWORD_MAX_CHARS,
                actual: chars,
            }
            .into());
        }

        let hash = password::hash(input.password).await?;
        let user = self.repo.insert(&username, &hash).await?;
        info!(user_id = %user.id, "用户已注册");
        Ok(user)
    }

    /// 登录。用户不存在与密码错误返回完全相同的错误，耗时也相同。
    #[instrument(skip_all, fields(username = %input.username))]
    pub async fn login(&self, input: Credentials) -> DomainResult<AccessToken> {
        // 用户名格式不合法时，按“用户不存在”处理，不返回 422（不泄露注册规则以外的信息）
        let credentials = match normalize_username(&input.username) {
            Ok(name) => self.repo.find_credentials(&name).await?,
            Err(_) => None,
        };

        let stored_hash = credentials.as_ref().map(|c| c.password_hash.clone());
        let password_ok = password::verify(input.password, stored_hash).await?;

        match credentials {
            Some(c) if password_ok => {
                let token = self.jwt.issue(&c.user)?;
                info!(user_id = %c.user.id, "登录成功");
                Ok(token)
            }
            _ => {
                info!("登录失败：用户名或密码错误");
                Err(DomainError::Unauthorized("用户名或密码错误".to_string()))
            }
        }
    }

    /// 校验访问令牌。纯计算，不访问数据库，所以是同步函数。
    pub fn verify_token(&self, token: &str) -> DomainResult<Claims> {
        self.jwt.verify(token)
    }

    /// 当前用户的信息。
    #[instrument(skip(self))]
    pub async fn me(&self, id: UserId) -> DomainResult<User> {
        self.repo.get(id).await
    }
}

#[cfg(test)]
mod tests {
    use std::sync::{Arc, Mutex};

    use chrono::Utc;
    use common::error::ErrorKind;

    use super::*;
    use crate::auth::Role;
    use crate::repo::UserCredentials;

    /// 内存版用户仓储。
    #[derive(Clone, Default)]
    struct FakeUsers {
        rows: Arc<Mutex<Vec<UserCredentials>>>,
    }

    impl UserRepository for FakeUsers {
        async fn insert(&self, username: &str, password_hash: &str) -> DomainResult<User> {
            let mut rows = self.rows.lock().unwrap();
            if rows.iter().any(|r| r.user.username == username) {
                return Err(DomainError::AlreadyExists {
                    entity: "用户名",
                    id: username.to_string(),
                });
            }
            let id = i64::try_from(rows.len()).unwrap() + 1;
            let user = User {
                id: UserId::new(id),
                username: username.to_string(),
                role: Role::User,
                created_at: Utc::now(),
            };
            rows.push(UserCredentials {
                user: user.clone(),
                password_hash: password_hash.to_string(),
            });
            Ok(user)
        }

        async fn find_credentials(&self, username: &str) -> DomainResult<Option<UserCredentials>> {
            Ok(self
                .rows
                .lock()
                .unwrap()
                .iter()
                .find(|r| r.user.username == username)
                .cloned())
        }

        async fn get(&self, id: UserId) -> DomainResult<User> {
            let rows = self.rows.lock().unwrap();
            rows.iter()
                .find(|r| r.user.id == id)
                .map(|r| r.user.clone())
                .ok_or_else(|| DomainError::not_found("用户", id))
        }
    }

    fn service() -> AuthService<FakeUsers> {
        let secret = SecretString::from("unit-test-secret- 0123456789abcdef0123".to_string());
        AuthService::new(FakeUsers::default(), JwtKeys::new(&secret, "rustmall", 900))
    }

    fn creds(username: &str, password: &str) -> Credentials {
        Credentials {
            username: username.to_string(),
            password: SecretString::from(password.to_string()),
        }
    }

    #[tokio::test]
    async fn register_normalizes_username() {
        let user = service()
            .register(creds("  Alice_01 ", "S3cure- Passw0rd"))
            .await
            .unwrap();
        assert_eq!(user.username, "alice_01");
        assert_eq!(user.role, Role::User);
    }

    #[tokio::test]
    async fn register_rejects_bad_input() {
        let svc = service();
        let err = svc
            .register(creds("ab", "S3cure-Passw0rd"))
            .await
            .unwrap_err();
        assert_eq!(err.kind(), ErrorKind::InvalidInput);
        let err = svc.register(creds("alice_01", "short")).await.unwrap_err();
        assert_eq!(err.kind(), ErrorKind::InvalidInput);
        assert!(err.to_string().contains("password"), "{err}");
    }

    #[tokio::test]
    async fn register_twice_is_conflict_regardless_of_case() {
        let svc = service();
        svc.register(creds("alice_01", "S3cure-Passw0rd"))
            .await
            .unwrap();
        let err = svc
            .register(creds("ALICE_01", "Another-Passw0rd"))
            .await
            .unwrap_err();
        assert_eq!(err.kind(), ErrorKind::Conflict);
    }

    #[tokio::test]
    async fn login_issues_a_verifiable_token() {
        let svc = service();
        let user = svc
            .register(creds("alice_01", "S3cure-Passw0rd"))
            .await
            .unwrap();
        let token = svc
            .login(creds("Alice_01", "S3cure-Passw0rd"))
            .await
            .unwrap();
        let claims = svc.verify_token(&token.access_token).unwrap();
        assert_eq!(claims.user_id().unwrap(), user.id);
        assert_eq!(claims.role, Role::User);
    }

    #[tokio::test]
    async fn wrong_password_and_unknown_user_look_identical() {
        let svc = service();
        svc.register(creds("alice_01", "S3cure-Passw0rd"))
            .await
            .unwrap();
        let wrong = svc
            .login(creds("alice_01", "wrong-password"))
            .await
            .unwrap_err();
        let unknown = svc
            .login(creds("nobody", "S3cure-Passw0rd"))
            .await
            .unwrap_err();
        assert_eq!(wrong.kind(), ErrorKind::Unauthorized);
        assert_eq!(wrong.to_string(), unknown.to_string());
    }
    #[tokio::test]
    async fn malformed_username_on_login_is_unauthorized() {
        let err = service()
            .login(creds("x", "whatever-password"))
            .await
            .unwrap_err();
        assert_eq!(err.kind(), ErrorKind::Unauthorized);
    }
}
