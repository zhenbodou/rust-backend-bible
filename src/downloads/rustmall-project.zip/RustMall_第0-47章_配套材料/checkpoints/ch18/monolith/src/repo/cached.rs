//! 带缓存的商品仓储：按 cache-aside 模式包装任意 `ProductRepository`（第 18.9 节）。
//!
//! 读：进程内缓存 → Redis → 被包装的仓储（数据库）；回源结果写回 Redis。
//! 写：先写被包装的仓储，成功后删除两级缓存。

use std::sync::Arc;

use common::error::{DomainError, DomainResult, ErrorKind};
use common::ids::ProductId;
use common::product::{NewProduct, Product};
use tracing::debug;

use crate::cache::{Lookup, ProductCache};
use crate::repo::ProductRepository;

const ENTITY: &str = "商品";

#[derive(Clone)]
pub struct CachedProductRepo<R> {
    inner: R,
    cache: ProductCache,
}

impl<R: ProductRepository> CachedProductRepo<R> {
    pub fn new(inner: R, cache: ProductCache) -> Self {
        Self { inner, cache }
    }

    /// 进程内缓存未命中时执行。同一个 ID 同时只有一个任务执行它，其余任务等待结果。
    async fn load(&self, id: ProductId) -> DomainResult<Lookup> {
        if let Some(hit) = self.cache.redis_get(id).await {
            debug!(%id, "商品缓存：Redis 命中");
            return Ok(hit);
        }
        let loaded = match self.inner.get(id).await {
            Ok(product) => Some(product),
            Err(err) if err.kind() == ErrorKind::NotFound => None,
            Err(err) => return Err(err),
        };
        debug!(%id, found = loaded.is_some(), "商品缓存：未命中，已回源");
        self.cache.redis_put(id, &loaded).await;
        Ok(loaded)
    }
}

impl<R: ProductRepository> ProductRepository for CachedProductRepo<R> {
    async fn insert(&self, draft: &NewProduct) -> DomainResult<Product> {
        let product = self.inner.insert(draft).await?;
        // 新分配的 ID 可能已经被缓存为“不存在”（有人提前查询过它）
        self.cache.invalidate(product.id()).await;
        Ok(product)
    }

    async fn get(&self, id: ProductId) -> DomainResult<Product> {
        let lookup = self
            .cache
            .local()
            .try_get_with(id, self.load(id))
            .await
            .map_err(unshare)?;
        lookup.ok_or_else(|| DomainError::not_found(ENTITY, id))
    }

    async fn list(&self, limit: i64, offset: i64) -> DomainResult<(Vec<Product>, i64)> {
        // 列表的组合太多（页码 × 每页数量），任何一次写入都会让它们全部过时，暂不缓存
        self.inner.list(limit, offset).await
    }

    async fn update(&self, product: &Product) -> DomainResult<Product> {
        let updated = self.inner.update(product).await?;
        self.cache.invalidate(updated.id()).await;
        Ok(updated)
    }

    async fn delist(&self, id: ProductId) -> DomainResult<()> {
        self.inner.delist(id).await?;
        self.cache.invalidate(id).await;
        Ok(())
    }
}

/// `try_get_with` 把加载错误包在 `Arc` 中交给所有等待者。
/// 只剩一个持有者时直接取出原错误；否则保留错误信息，转为内部错误。
fn unshare(err: Arc<DomainError>) -> DomainError {
    Arc::try_unwrap(err).unwrap_or_else(|shared| DomainError::Internal(shared.to_string()))
}

#[cfg(test)]
mod tests {
    use std::sync::Mutex;
    use std::sync::atomic::{AtomicBool, AtomicUsize, Ordering};

    use super::*;
    use crate::settings::CacheSettings;

    /// 最多保存一个商品的内存仓储，记录 `get` 被调用（即回源）的次数。
    #[derive(Clone, Default)]
    struct CountingRepo {
        product: Arc<Mutex<Option<Product>>>,
        gets: Arc<AtomicUsize>,
        fail_next_get: Arc<AtomicBool>,
    }

    impl CountingRepo {
        fn with(product: Product) -> Self {
            let repo = Self::default();
            *repo.product.lock().unwrap() = Some(product);
            repo
        }

        fn gets(&self) -> usize {
            self.gets.load(Ordering::SeqCst)
        }
    }

    impl ProductRepository for CountingRepo {
        async fn insert(&self, draft: &NewProduct) -> DomainResult<Product> {
            let product = draft.clone().into_product(ProductId::new(1));
            *self.product.lock().unwrap() = Some(product.clone());
            Ok(product)
        }

        async fn get(&self, id: ProductId) -> DomainResult<Product> {
            self.gets.fetch_add(1, Ordering::SeqCst);
            // 让出执行权，模拟一次数据库往返，让并发的请求有机会同时到达
            tokio::task::yield_now().await;
            if self.fail_next_get.swap(false, Ordering::SeqCst) {
                return Err(DomainError::Internal("数据库暂时不可用".to_string()));
            }
            let current = self.product.lock().unwrap().clone();
            current
                .filter(|p| p.id() == id)
                .ok_or_else(|| DomainError::not_found(ENTITY, id))
        }

        async fn list(&self, _limit: i64, _offset: i64) -> DomainResult<(Vec<Product>, i64)> {
            unreachable!("缓存测试不使用 list")
        }

        async fn update(&self, product: &Product) -> DomainResult<Product> {
            *self.product.lock().unwrap() = Some(product.clone());
            Ok(product.clone())
        }

        async fn delist(&self, _id: ProductId) -> DomainResult<()> {
            *self.product.lock().unwrap() = None;
            Ok(())
        }
    }

    fn keyboard(name: &str) -> Product {
        Product::try_new(ProductId::new(1), name, 19_900, 10).unwrap()
    }

    fn cached(repo: &CountingRepo) -> CachedProductRepo<CountingRepo> {
        let cache = ProductCache::local_only(&CacheSettings::default());
        CachedProductRepo::new(repo.clone(), cache)
    }

    #[tokio::test]
    async fn second_get_is_served_from_local_cache() {
        let repo = CountingRepo::with(keyboard("机械键盘"));
        let cached = cached(&repo);

        let first = cached.get(ProductId::new(1)).await.unwrap();
        let second = cached.get(ProductId::new(1)).await.unwrap();

        assert_eq!((first.name(), second.name()), ("机械键盘", "机械键盘"));
        assert_eq!(repo.gets(), 1);
    }

    #[tokio::test]
    async fn missing_product_is_cached_too() {
        let repo = CountingRepo::default();
        let cached = cached(&repo);

        for _ in 0..3 {
            let err = cached.get(ProductId::new(99)).await.unwrap_err();
            assert_eq!(err.kind(), ErrorKind::NotFound);
        }

        assert_eq!(repo.gets(), 1);
    }

    #[tokio::test]
    async fn update_invalidates_cached_entry() {
        let repo = CountingRepo::with(keyboard("机械键盘"));
        let cached = cached(&repo);
        cached.get(ProductId::new(1)).await.unwrap();

        cached.update(&keyboard("静音机械键盘")).await.unwrap();

        assert_eq!(
            cached.get(ProductId::new(1)).await.unwrap().name(),
            "静音机械键盘"
        );
        assert_eq!(repo.gets(), 2);
    }

    #[tokio::test]
    async fn insert_clears_a_cached_missing_marker() {
        let repo = CountingRepo::default();
        let cached = cached(&repo);
        // 有人提前查询了即将被分配的 ID 1，“不存在”被缓存了下来
        assert!(cached.get(ProductId::new(1)).await.is_err());

        let draft = NewProduct::try_new("机械键盘", 19_900, 10).unwrap();
        cached.insert(&draft).await.unwrap();

        assert_eq!(
            cached.get(ProductId::new(1)).await.unwrap().name(),
            "机械键盘"
        );
    }

    #[tokio::test]
    async fn concurrent_misses_load_once() {
        let repo = CountingRepo::with(keyboard("机械键盘"));
        let cached = cached(&repo);

        let tasks: Vec<_> = (0..8)
            .map(|_| {
                let cached = cached.clone();
                tokio::spawn(async move { cached.get(ProductId::new(1)).await })
            })
            .collect();
        for task in tasks {
            assert!(task.await.unwrap().is_ok());
        }

        // 8 个请求同时未命中，只有一个回源（防缓存击穿）
        assert_eq!(repo.gets(), 1);
    }

    #[tokio::test]
    async fn errors_are_not_cached() {
        let repo = CountingRepo::with(keyboard("机械键盘"));
        repo.fail_next_get.store(true, Ordering::SeqCst);
        let cached = cached(&repo);

        let err = cached.get(ProductId::new(1)).await.unwrap_err();
        assert_eq!(err.kind(), ErrorKind::Internal);

        assert!(cached.get(ProductId::new(1)).await.is_ok());
        assert_eq!(repo.gets(), 2);
    }
}
