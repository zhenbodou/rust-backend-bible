//! 认证接口与身份提取器。

use axum::extract::{FromRequestParts, State};
use axum::http::request::Parts;
use axum::http::{StatusCode, header};
use common::error::DomainError;
use common::ids::UserId;
use secrecy::SecretString;
use serde::Deserialize;
use validator::Validate;

use crate::auth::jwt::AccessToken;
use crate::auth::{Role, User};
use crate::http::error::ApiError;
use crate::http::extract::{AppJson, ValidJson};
use crate::service::auth::Credentials;
use crate::state::AppState;

/// 注册请求体。故意不派生 Debug：其中的密码是明文字符串。
#[derive(Deserialize, Validate)]
#[serde(deny_unknown_fields)]
pub struct RegisterInput {
    #[validate(length(min = 3, max = 20, message = "长度需为 3~20 个字符"))]
    pub username: String,
    #[validate(length(min = 8, max = 64, message = "长度需为 8~64 个字符"))]
    pub password: String,
}

/// 登录请求体：不做格式校验，任何不正确的输入都统一返回 401。
#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
pub struct LoginInput {
    pub username: String,
    pub password: String,
}

/// `POST /api/v1/auth/register`
pub async fn register(
    State(state): State<AppState>,
    ValidJson(input): ValidJson<RegisterInput>,
) -> Result<(StatusCode, AppJson<User>), ApiError> {
    let credentials = Credentials {
        username: input.username,
        password: SecretString::from(input.password),
    };
    let user = state.auth.register(credentials).await?;
    Ok((StatusCode::CREATED, AppJson(user)))
}

/// `POST /api/v1/auth/login`
pub async fn login(
    State(state): State<AppState>,
    AppJson(input): AppJson<LoginInput>,
) -> Result<AppJson<AccessToken>, ApiError> {
    let credentials = Credentials {
        username: input.username,
        password: SecretString::from(input.password),
    };
    Ok(AppJson(state.auth.login(credentials).await?))
}

/// `GET /api/v1/users/me`
pub async fn me(
    State(state): State<AppState>,
    user: CurrentUser,
) -> Result<AppJson<User>, ApiError> {
    Ok(AppJson(state.auth.me(user.id).await?))
}

/// 当前登录用户。作为处理函数参数时，请求必须带有效的 `Authorization: Bearer <令牌>`。
#[derive(Debug, Clone, Copy)]
pub struct CurrentUser {
    pub id: UserId,
    pub role: Role,
}

impl FromRequestParts<AppState> for CurrentUser {
    type Rejection = ApiError;

    async fn from_request_parts(
        parts: &mut Parts,
        state: &AppState,
    ) -> Result<Self, Self::Rejection> {
        let token = bearer_token(parts)
            .ok_or_else(|| DomainError::Unauthorized("缺少访问令牌，请先登录".to_string()))?;
        let claims = state.auth.verify_token(token)?;
        Ok(CurrentUser {
            id: claims.user_id()?,
            role: claims.role,
        })
    }
}

/// 管理员。作为处理函数参数时，请求者必须已登录且角色为管理员。
#[derive(Debug, Clone, Copy)]
pub struct AdminUser(pub CurrentUser);

impl FromRequestParts<AppState> for AdminUser {
    type Rejection = ApiError;

    async fn from_request_parts(
        parts: &mut Parts,
        state: &AppState,
    ) -> Result<Self, Self::Rejection> {
        let user = CurrentUser::from_request_parts(parts, state).await?;
        if user.role != Role::Admin {
            return Err(DomainError::Forbidden("需要管理员权限".to_string()).into());
        }
        Ok(AdminUser(user))
    }
}

/// 从 `Authorization` 头中取出 Bearer 令牌。方案名不区分大小写（RFC 7235）。
fn bearer_token(parts: &Parts) -> Option<&str> {
    let value = parts.headers.get(header::AUTHORIZATION)?.to_str().ok()?;
    let (scheme, token) = value.split_once(' ')?;
    let token = token.trim();
    (scheme.eq_ignore_ascii_case("bearer") && !token.is_empty()).then_some(token)
}
