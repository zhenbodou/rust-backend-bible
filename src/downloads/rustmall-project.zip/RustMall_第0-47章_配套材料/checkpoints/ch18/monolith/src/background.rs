//! 后台周期任务。

use std::future::Future;
use std::time::Duration;

use tokio::time::MissedTickBehavior;
use tokio_util::sync::CancellationToken;

/// 每隔 `period` 执行一次 `job`，直到 `token` 被取消，返回执行的次数。
///
/// - 第一次执行在启动时立即发生。
/// - 某次执行耗时超过周期时，下一次立即开始并从那时起重新计时，不会连续补跑错过的次数。
/// - 取消优先：已取消时不再开始新的一次；正在执行的那一次会完整结束。
pub async fn run_periodic<F, Fut>(period: Duration, token: CancellationToken, mut job: F) -> u64
where
    F: FnMut() -> Fut,
    Fut: Future<Output = ()>,
{
    let mut ticker = tokio::time::interval(period);
    ticker.set_missed_tick_behavior(MissedTickBehavior::Delay);
    let mut runs = 0;
    loop {
        tokio::select! {
            biased;
            () = token.cancelled() => break,
            _ = ticker.tick() => {
                job().await;
                runs += 1;
            }
        }
    }
    runs
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::sync::Arc;
    use std::sync::atomic::{AtomicU64, Ordering};

    #[tokio::test(start_paused = true)]
    async fn runs_on_schedule_until_cancelled() {
        let token = CancellationToken::new();
        let counter = Arc::new(AtomicU64::new(0));
        let c = Arc::clone(&counter);
        let handle = tokio::spawn(run_periodic(
            Duration::from_secs(10),
            token.clone(),
            move || {
                let c = Arc::clone(&c);
                async move {
                    c.fetch_add(1, Ordering::SeqCst);
                }
            },
        ));

        // 暂停的时间会被自动推进，瞬间完成
        tokio::time::sleep(Duration::from_secs(35)).await;
        token.cancel();

        // 第 0、10、20、30 秒各执行一次
        assert_eq!(handle.await.expect("任务不应 panic"), 4);
        assert_eq!(counter.load(Ordering::SeqCst), 4);
    }

    #[tokio::test(start_paused = true)]
    async fn already_cancelled_runs_nothing() {
        let token = CancellationToken::new();
        token.cancel();
        let runs = run_periodic(Duration::from_secs(1), token, || async {}).await;
        assert_eq!(
            runs, 0,
            "biased 保证先检查取消，立即就绪的第一次 tick 不会被执行"
        );
    }

    #[tokio::test(start_paused = true)]
    async fn slow_job_delays_next_run() {
        let token = CancellationToken::new();
        let handle = tokio::spawn(run_periodic(
            Duration::from_secs(10),
            token.clone(),
            || async {
                // 每次执行 25 秒，超过 10 秒的周期
                tokio::time::sleep(Duration::from_secs(25)).await;
            },
        ));

        tokio::time::sleep(Duration::from_secs(60)).await;
        token.cancel();

        // 0~25 秒第 1 次；25~50 秒第 2 次（顺延，不补跑）；50~75 秒第 3 次，
        // 第 60 秒取消时第 3 次正在执行，执行完后才退出
        assert_eq!(handle.await.expect("任务不应 panic"), 3);
    }
}
