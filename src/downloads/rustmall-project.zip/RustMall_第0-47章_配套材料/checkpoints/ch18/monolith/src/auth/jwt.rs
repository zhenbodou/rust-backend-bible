//! JWT 访问令牌：HS256 签名。

use common::error::{DomainError, DomainResult};
use common::ids::UserId;
use jsonwebtoken::{
    Algorithm, DecodingKey, EncodingKey, Header, Validation, decode, encode, get_current_timestamp,
};
use secrecy::{ExposeSecret, SecretString};
use serde::{Deserialize, Serialize};

use super::{Role, User};

/// 令牌载荷。只放身份与角色，不放任何敏感信息（载荷可以被任何人解码）。
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Claims {
    /// 用户 ID（JWT 规范要求 sub 为字符串）
    pub sub: String,
    pub role: Role,
    pub iss: String,
    pub iat: u64,
    pub exp: u64,
}

impl Claims {
    /// 解析出用户 ID。签名正确但 sub 不是数字，只可能是签发逻辑有缺陷，按“令牌无效”处理。
    pub fn user_id(&self) -> DomainResult<UserId> {
        self.sub
            .parse::<i64>()
            .map(UserId::new)
            .map_err(|_| invalid_token())
    }
}

/// 登录接口的响应体。
#[derive(Debug, Serialize)]
pub struct AccessToken {
    pub access_token: String,
    pub token_type: &'static str,
    /// 有效期（秒）
    pub expires_in: u64,
}

/// 签名与校验所需的一切。启动时由配置构造一次，之后只读共享。
pub struct JwtKeys {
    encoding: EncodingKey,
    decoding: DecodingKey,
    validation: Validation,
    issuer: String,
    ttl_secs: u64,
}

impl JwtKeys {
    pub fn new(secret: &SecretString, issuer: &str, ttl_secs: u64) -> Self {
        let bytes = secret.expose_secret().as_bytes();
        let mut validation = Validation::new(Algorithm::HS256);
        validation.set_issuer(&[issuer]);
        validation.set_required_spec_claims(&["exp", "sub", "iss"]);
        validation.leeway = 30;
        Self {
            encoding: EncodingKey::from_secret(bytes),
            decoding: DecodingKey::from_secret(bytes),
            validation,
            issuer: issuer.to_string(),
            ttl_secs,
        }
    }

    /// 为用户签发访问令牌。
    pub fn issue(&self, user: &User) -> DomainResult<AccessToken> {
        let now = get_current_timestamp();
        let claims = Claims {
            sub: user.id.to_string(),
            role: user.role,
            iss: self.issuer.clone(),
            iat: now,
            exp: now + self.ttl_secs,
        };
        let token = self.sign(&claims)?;
        Ok(AccessToken {
            access_token: token,
            token_type: "Bearer",
            expires_in: self.ttl_secs,
        })
    }

    /// 校验令牌，返回载荷。任何失败都统一为“令牌无效”，具体原因只写 DEBUG 日志。
    pub fn verify(&self, token: &str) -> DomainResult<Claims> {
        decode::<Claims>(token, &self.decoding, &self.validation)
            .map(|data| data.claims)
            .map_err(|e| {
                tracing::debug!(error = %e, "访问令牌校验失败");
                invalid_token()
            })
    }

    fn sign(&self, claims: &Claims) -> DomainResult<String> {
        encode(&Header::new(Algorithm::HS256), claims, &self.encoding)
            .map_err(|e| DomainError::Internal(format!("签发令牌失败：{e}")))
    }
}

fn invalid_token() -> DomainError {
    DomainError::Unauthorized("登录已过期或令牌无效，请重新登录".to_string())
}

#[cfg(test)]
mod tests {
    use chrono::Utc;
    use common::error::ErrorKind;

    use super::*;

    fn keys(secret: &str, issuer: &str) -> JwtKeys {
        JwtKeys::new(&SecretString::from(secret.to_string()), issuer, 900)
    }

    fn alice() -> User {
        User {
            id: UserId::new(7),
            username: "alice".into(),
            role: Role::Admin,
            created_at: Utc::now(),
        }
    }

    const SECRET: &str = "unit-test-secret-0123456789abcdef0123";

    #[test]
    fn issue_then_verify() {
        let k = keys(SECRET, "rustmall");
        let token = k.issue(&alice()).unwrap();
        assert_eq!((token.token_type, token.expires_in), ("Bearer", 900));

        let claims = k.verify(&token.access_token).unwrap();
        assert_eq!(claims.user_id().unwrap(), UserId::new(7));
        assert_eq!(claims.role, Role::Admin);
    }

    #[test]
    fn token_signed_with_another_secret_is_rejected() {
        let token = keys("another-secret-0123456789abcdef0123", "rustmall")
            .issue(&alice())
            .unwrap();
        let err = keys(SECRET, "rustmall")
            .verify(&token.access_token)
            .unwrap_err();
        assert_eq!(err.kind(), ErrorKind::Unauthorized);
    }

    #[test]
    fn expired_token_is_rejected() {
        let k = keys(SECRET, "rustmall");
        let now = get_current_timestamp();
        // 两分钟前就过期了，超过 30 秒的容差
        let claims = Claims {
            sub: "7".into(),
            role: Role::User,
            iss: "rustmall".into(),
            iat: now - 1000,
            exp: now - 120,
        };
        let token = k.sign(&claims).unwrap();
        assert_eq!(
            k.verify(&token).unwrap_err().kind(),
            ErrorKind::Unauthorized
        );
    }

    #[test]
    fn token_from_another_issuer_is_rejected() {
        let token = keys(SECRET, "someone-else").issue(&alice()).unwrap();
        assert!(
            keys(SECRET, "rustmall")
                .verify(&token.access_token)
                .is_err()
        );
    }
}
