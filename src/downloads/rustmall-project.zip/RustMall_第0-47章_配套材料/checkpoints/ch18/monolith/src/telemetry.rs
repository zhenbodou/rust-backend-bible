//! 日志（tracing）初始化。第 38 章会在这里加入 OpenTelemetry 导出。

use tracing_subscriber::layer::SubscriberExt;
use tracing_subscriber::util::SubscriberInitExt;
use tracing_subscriber::{EnvFilter, Layer, fmt};

use crate::settings::{LogFormat, LogSettings};

/// 安装全局日志订阅者。整个进程只能调用一次。
///
/// 过滤规则：设置了 `RUST_LOG` 时使用它，否则使用配置中的 `log.level`。
pub fn init(settings: &LogSettings) -> anyhow::Result<()> {
    let filter = match EnvFilter::try_from_default_env() {
        Ok(filter) => filter,
        Err(_) => EnvFilter::try_new(&settings.level)?,
    };

    // 两种格式的层类型不同，装箱后才能放进同一个 match
    let fmt_layer = match settings.format {
        LogFormat::Json => fmt::layer().json().boxed(),
        LogFormat::Pretty => fmt::layer().boxed(),
    };

    tracing_subscriber::registry()
        .with(fmt_layer)
        .with(filter)
        .try_init()?;
    Ok(())
}
