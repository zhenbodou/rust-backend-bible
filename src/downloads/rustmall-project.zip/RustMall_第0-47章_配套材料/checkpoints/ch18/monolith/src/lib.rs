#![cfg_attr(test, allow(clippy::unwrap_used))]
//! RustMall 单体服务。
//!
//! - 第 11 章：运行时骨架（信号处理、后台任务、优雅停机）
//! - 第 12 章：HTTP 服务、商品接口、统一错误响应
//! - 第 14 章：PostgreSQL 连接池、迁移、商品仓储
//! - 第 15 章：配置、日志、HTTP / 服务 / 仓储三层结构

pub mod auth;
pub mod background;
pub mod cache;
pub mod db;
pub mod http;
pub mod repo;
pub mod service;
pub mod settings;
pub mod shutdown;
pub mod state;
pub mod telemetry;
