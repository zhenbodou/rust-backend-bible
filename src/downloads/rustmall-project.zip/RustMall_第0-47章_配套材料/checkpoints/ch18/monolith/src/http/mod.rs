//! HTTP 层：请求解析、格式校验、调用服务、组装响应，以及路由与中间件。

pub mod auth;
pub mod error;
pub mod extract;
pub mod health;
pub mod products;
pub mod routes;
