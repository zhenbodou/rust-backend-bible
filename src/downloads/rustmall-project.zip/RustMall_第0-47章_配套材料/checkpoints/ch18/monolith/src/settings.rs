//! 配置：结构定义、分层加载与启动时校验。

use secrecy::{ExposeSecret, SecretString};
use serde::Deserializer;
use std::fmt;
use std::time::Duration;

use config::builder::DefaultState;
use config::{Config, ConfigBuilder, Environment, File};
use serde::Deserialize;
use validator::Validate;

/// 选择环境配置文件的环境变量，例如 `APP_ENV=production`。
pub const ENV_VAR: &str = "APP_ENV";
/// 覆盖配置目录的环境变量（Docker 镜像中使用，第 20 章）。
pub const DIR_VAR: &str = "APP_CONFIG_DIR";

/// 加载配置时可能出现的错误。
#[derive(Debug, thiserror::Error)]
pub enum SettingsError {
    #[error("配置不合法：{0}")]
    Rule(String),
    #[error("读取配置失败：{0}")]
    Load(#[from] config::ConfigError),
    #[error("配置不合法：{0}")]
    Invalid(#[from] validator::ValidationErrors),
}

/// 全部配置。只在启动时读取一次，各组件取用需要的部分。
#[derive(Debug, Deserialize, Validate)]
pub struct Settings {
    #[validate(nested)]
    pub server: ServerSettings,
    #[validate(nested)]
    pub database: DatabaseSettings,
    pub log: LogSettings,
    #[serde(default)]
    pub cors: CorsSettings,
    #[validate(nested)]
    pub auth: AuthSettings,
    /// Redis。整个段可以省略，省略时不使用 Redis。
    #[serde(default)]
    #[validate(nested)]
    pub redis: RedisSettings,
    /// 商品缓存。整个段可以省略，省略时使用默认值。
    #[serde(default)]
    #[validate(nested)]
    pub cache: CacheSettings,
}
#[derive(Debug, Clone, Deserialize, Validate)]
pub struct ServerSettings {
    pub host: String,
    #[validate(range(min = 1, message = "端口不能为 0"))]
    pub port: u16,
    #[validate(range(min = 1, max = 300))]
    pub shutdown_grace_secs: u64,
}

impl ServerSettings {
    /// 监听地址，例如 `0.0.0.0:8080`。
    pub fn addr(&self) -> String {
        format!("{}:{}", self.host, self.port)
    }

    pub fn shutdown_grace(&self) -> Duration {
        Duration::from_secs(self.shutdown_grace_secs)
    }
}

/// 数据库配置。连接字符串含有密码，所以手动实现 Debug。
#[derive(Clone, Deserialize, Validate)]
pub struct DatabaseSettings {
    #[validate(length(min = 1, message = "数据库地址不能为空"))]
    pub url: String,
    #[validate(range(min = 1, max = 100))]
    pub max_connections: u32,
    #[validate(range(min = 1, max = 60))]
    pub acquire_timeout_secs: u64,
}

impl fmt::Debug for DatabaseSettings {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("DatabaseSettings")
            .field("url", &redact_url(&self.url))
            .field("max_connections", &self.max_connections)
            .field("acquire_timeout_secs", &self.acquire_timeout_secs)
            .finish()
    }
}

/// 隐藏连接字符串中的账号与密码：`postgres://u:p@host/db` → `postgres://***@host/db`。
fn redact_url(url: &str) -> String {
    match (url.find("://"), url.rfind('@')) {
        (Some(scheme_end), Some(at)) if at > scheme_end => {
            format!("{}***{}", &url[..scheme_end + 3], &url[at..])
        }
        _ => url.to_string(),
    }
}

#[derive(Debug, Clone, Deserialize)]
pub struct LogSettings {
    /// EnvFilter 过滤表达式
    pub level: String,
    pub format: LogFormat,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum LogFormat {
    Pretty,
    Json,
}

#[derive(Debug, Clone, Default, Deserialize)]
pub struct CorsSettings {
    #[serde(default)]
    pub allowed_origins: Vec<String>,
}

/// 认证配置。
#[derive(Debug, Deserialize, Validate)]
pub struct AuthSettings {
    /// HS256 签名密钥。Debug 输出为 `[REDACTED]`。
    #[serde(deserialize_with = "deserialize_secret")]
    pub jwt_secret: SecretString,
    pub issuer: String,
    #[validate(range(min = 60, max = 86400))]
    pub access_token_ttl_secs: u64,
}

/// HS256 密钥的最短长度（字节）。
const MIN_JWT_SECRET_BYTES: usize = 32;

/// 先按普通字符串反序列化，再包装为 `SecretString`。
fn deserialize_secret<'de, D: Deserializer<'de>>(
    deserializer: D,
) -> Result<SecretString, D::Error> {
    String::deserialize(deserializer).map(SecretString::from)
}

/// Redis 配置（第 18 章）。`url` 为空时不使用 Redis。
#[derive(Deserialize, Validate)]
#[serde(default)]
pub struct RedisSettings {
    pub url: Option<String>,
    #[validate(range(min = 1, max = 30))]
    pub connect_timeout_secs: u64,
    #[validate(range(min = 10, max = 5_000))]
    pub op_timeout_ms: u64,
}

impl Default for RedisSettings {
    fn default() -> Self {
        Self {
            url: None,
            connect_timeout_secs: 3,
            op_timeout_ms: 200,
        }
    }
}

/// 连接地址中可能带有密码，Debug 输出时隐藏（与 `DatabaseSettings` 相同）。
impl fmt::Debug for RedisSettings {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("RedisSettings")
            .field("url", &self.url.as_deref().map(redact_url))
            .field("connect_timeout_secs", &self.connect_timeout_secs)
            .field("op_timeout_ms", &self.op_timeout_ms)
            .finish()
    }
}

/// 商品缓存配置（第 18.10 节）。
#[derive(Debug, Clone, Deserialize, Validate)]
#[serde(default)]
pub struct CacheSettings {
    #[validate(range(min = 1, max = 86_400))]
    pub product_ttl_secs: u64,
    #[validate(range(min = 1, max = 3_600))]
    pub missing_ttl_secs: u64,
    #[validate(range(min = 1, max = 600))]
    pub local_ttl_secs: u64,
    #[validate(range(min = 1, max = 1_000_000))]
    pub local_capacity: u64,
}

impl Default for CacheSettings {
    fn default() -> Self {
        Self {
            product_ttl_secs: 300,
            missing_ttl_secs: 30,
            local_ttl_secs: 10,
            local_capacity: 10_000,
        }
    }
}

impl Settings {
    /// 按“默认文件 → 环境文件 → 环境变量”的顺序加载并校验。
    pub fn load() -> Result<Self, SettingsError> {
        let dir = std::env::var(DIR_VAR)
            .unwrap_or_else(|_| concat!(env!("CARGO_MANIFEST_DIR"), "/config").to_string());
        let env = std::env::var(ENV_VAR).unwrap_or_else(|_| "development".to_string());

        let builder = Config::builder()
            .add_source(File::with_name(&format!("{dir}/default")))
            .add_source(File::with_name(&format!("{dir}/{env}")).required(false))
            .add_source(
                Environment::with_prefix("APP")
                    .prefix_separator("_")
                    .separator("__")
                    .try_parsing(true),
            )
            // 兼容通用的 DATABASE_URL（sqlx-cli、各类部署平台都使用它），优先级最高
            .set_override_option("database.url", std::env::var("DATABASE_URL").ok())?;

        Self::from_builder(builder)
    }

    /// 从构建器生成配置并校验。单独拆出来，测试可以传入不依赖磁盘与环境变量的来源。
    fn from_builder(builder: ConfigBuilder<DefaultState>) -> Result<Self, SettingsError> {
        let settings: Settings = builder.build()?.try_deserialize()?;
        settings.validate()?;
        if settings.auth.jwt_secret.expose_secret().len() < MIN_JWT_SECRET_BYTES {
            return Err(SettingsError::Rule(format!(
                "auth.jwt_secret 至少需要 {MIN_JWT_SECRET_BYTES} 字节，请使用随机生成的长密钥"
            )));
        }
        Ok(settings)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use config::FileFormat;

    const DEFAULT: &str = include_str!("../config/default.toml");
    const DEVELOPMENT: &str = include_str!("../config/development.toml");
    const PRODUCTION: &str = include_str!("../config/production.toml");

    fn load(sources: &[&str]) -> Result<Settings, SettingsError> {
        let mut builder = Config::builder();
        for text in sources {
            builder = builder.add_source(File::from_str(text, FileFormat::Toml));
        }
        Settings::from_builder(builder)
    }

    /// 开发环境：默认配置 + development.toml + 额外覆盖。
    fn load_dev(overlay: &str) -> Result<Settings, SettingsError> {
        load(&[DEFAULT, DEVELOPMENT, overlay])
    }

    #[test]
    fn development_config_is_valid() {
        let s = load_dev("").unwrap();
        assert_eq!(s.server.addr(), "0.0.0.0:8080");
        assert_eq!(s.log.format, LogFormat::Pretty);
        assert_eq!(s.auth.access_token_ttl_secs, 900);
    }

    #[test]
    fn production_requires_jwt_secret_from_environment() {
        // 生产配置文件中没有密钥：必须启动失败
        let err = load(&[DEFAULT, PRODUCTION]).unwrap_err();
        assert!(matches!(err, SettingsError::Load(_)), "实际错误：{err}");
        // 由“环境变量”（这里用覆盖层模拟）提供密钥后可以启动
        let secret = "[auth]\njwt_secret = \"0123456789abcdef0123456789abcdef-prod\"";
        let s = load(&[DEFAULT, PRODUCTION, secret]).unwrap();
        assert_eq!(s.log.format, LogFormat::Json);
        assert_eq!(s.cors.allowed_origins, ["https://shop.rustmall.com"]);
    }

    #[test]
    fn invalid_values_are_rejected_at_startup() {
        let err = load_dev("[server]\nport = 0").unwrap_err();
        assert!(matches!(err, SettingsError::Invalid(_)), "实际错误：{err}");
        let err = load_dev("[log]\nformat = \"xml\"").unwrap_err();
        assert!(matches!(err, SettingsError::Load(_)), "实际错误：{err}");
        let err = load_dev("[auth]\njwt_secret = \"short\"").unwrap_err();
        assert!(matches!(err, SettingsError::Rule(_)), "实际错误：{err}");
    }

    #[test]
    fn debug_output_hides_secrets() {
        let s = load_dev("").unwrap();
        let text = format!("{s:?}");
        assert!(
            text.contains("postgres://***@localhost:5432/rustmall"),
            "{text}"
        );
        assert!(!text.contains("rustmall:rustmall"), "{text}");
        assert!(!text.contains("dev-only-jwt-secret"), "{text}");
    }
}
