//! 商品服务。

use crate::repo::ProductRepository;
use common::error::{DomainError, DomainResult, ValidationError};
use common::ids::ProductId;
use common::pagination::{self, Page};
use common::product::{NewProduct, Product};
use tracing::{info, instrument};

/// 新增或修改商品的命令：与传输协议无关的输入数据。
///
/// HTTP 层把 JSON 请求体转换为它；将来的 gRPC 接口（第 25 章）把 protobuf 消息转换为它。
#[derive(Debug, Clone)]
pub struct ProductCommand {
    pub name: String,
    pub price_cents: i64,
    pub stock: i32,
}

/// 商品服务。泛型参数 `R` 是仓储的具体类型：生产中是 `PgProductRepo`，测试中是内存实现。
#[derive(Clone)]
pub struct ProductService<R> {
    repo: R,
}

impl<R: ProductRepository> ProductService<R> {
    pub fn new(repo: R) -> Self {
        Self { repo }
    }

    /// 新增商品：先校验不变量，再交给仓储保存。
    #[instrument(skip_all, fields(name = %cmd.name))]
    pub async fn create(&self, cmd: ProductCommand) -> DomainResult<Product> {
        let draft = NewProduct::try_new(&cmd.name, cmd.price_cents, cmd.stock).map_err(invalid)?;
        let product = self.repo.insert(&draft).await?;
        info!(product_id = %product.id(), "商品已创建");
        Ok(product)
    }

    #[instrument(skip(self))]
    pub async fn get(&self, id: ProductId) -> DomainResult<Product> {
        self.repo.get(id).await
    }

    /// 分页列出在售商品。页码与每页条数的规范化规则见第 1.6 节 `pagination`。
    #[instrument(skip(self))]
    pub async fn list(
        &self,
        page: Option<u32>,
        page_size: Option<u32>,
    ) -> DomainResult<Page<Product>> {
        let (page_no, size) = pagination::normalize(page, page_size);
        let (limit, offset) = pagination::limit_offset(page, page_size);
        let (items, total) = self.repo.list(limit, offset).await?;
        Ok(Page::new(items, page_no, size, total))
    }

    /// 整体替换商品的可修改字段。
    #[instrument(skip(self, cmd))]
    pub async fn update(&self, id: ProductId, cmd: ProductCommand) -> DomainResult<Product> {
        let product =
            Product::try_new(id, &cmd.name, cmd.price_cents, cmd.stock).map_err(invalid)?;
        let saved = self.repo.update(&product).await?;
        info!(product_id = %id, "商品已修改");
        Ok(saved)
    }

    /// 下架商品。
    #[instrument(skip(self))]
    pub async fn delist(&self, id: ProductId) -> DomainResult<()> {
        self.repo.delist(id).await?;
        info!(product_id = %id, "商品已下架");
        Ok(())
    }
}

/// 领域构造函数的错误文字 → 校验错误。
fn invalid(reason: String) -> DomainError {
    ValidationError::Format {
        field: "product",
        reason,
    }
    .into()
}

#[cfg(test)]
mod tests {
    use std::sync::{Arc, Mutex};

    use common::error::ErrorKind;

    use super::*;

    /// 内存版仓储：只用于测试服务层，行为与 PostgreSQL 实现保持一致（新的在前、下架即不可见）。
    #[derive(Clone, Default)]
    struct FakeRepo {
        items: Arc<Mutex<Vec<Product>>>,
        next_id: Arc<Mutex<i64>>,
    }

    impl ProductRepository for FakeRepo {
        async fn insert(&self, draft: &NewProduct) -> DomainResult<Product> {
            let mut next = self.next_id.lock().unwrap();
            *next += 1;
            let product = draft.clone().into_product(ProductId::new(*next));
            self.items.lock().unwrap().push(product.clone());
            Ok(product)
        }

        async fn get(&self, id: ProductId) -> DomainResult<Product> {
            let items = self.items.lock().unwrap();
            items
                .iter()
                .find(|p| p.id() == id)
                .cloned()
                .ok_or_else(|| DomainError::not_found("商品", id))
        }

        async fn list(&self, limit: i64, offset: i64) -> DomainResult<(Vec<Product>, i64)> {
            let items = self.items.lock().unwrap();
            let total = i64::try_from(items.len()).unwrap();
            let page = items
                .iter()
                .rev()
                .skip(usize::try_from(offset).unwrap())
                .take(usize::try_from(limit).unwrap())
                .cloned()
                .collect();
            Ok((page, total))
        }

        async fn update(&self, product: &Product) -> DomainResult<Product> {
            let mut items = self.items.lock().unwrap();
            let slot = items
                .iter_mut()
                .find(|p| p.id() == product.id())
                .ok_or_else(|| DomainError::not_found("商品", product.id()))?;
            *slot = product.clone();
            Ok(product.clone())
        }

        async fn delist(&self, id: ProductId) -> DomainResult<()> {
            let mut items = self.items.lock().unwrap();
            let before = items.len();
            items.retain(|p| p.id() != id);
            if items.len() == before {
                return Err(DomainError::not_found("商品", id));
            }
            Ok(())
        }
    }

    fn service() -> ProductService<FakeRepo> {
        ProductService::new(FakeRepo::default())
    }

    fn cmd(name: &str, price_cents: i64) -> ProductCommand {
        ProductCommand {
            name: name.to_string(),
            price_cents,
            stock: 1,
        }
    }

    #[tokio::test]
    async fn create_validates_before_saving() {
        let svc = service();
        let err = svc.create(cmd("   ", 100)).await.unwrap_err();
        assert_eq!(err.kind(), ErrorKind::InvalidInput);
        // 校验失败时仓储完全没有被调用
        assert_eq!(svc.list(None, None).await.unwrap().total, 0);
    }

    #[tokio::test]
    async fn create_then_get() {
        let svc = service();
        let created = svc.create(cmd("键盘", 100)).await.unwrap();
        assert_eq!(created.id(), ProductId::new(1));
        assert_eq!(svc.get(created.id()).await.unwrap(), created);
    }

    #[tokio::test]
    async fn list_paginates_newest_first() {
        let svc = service();
        for name in ["A", "B", "C"] {
            svc.create(cmd(name, 100)).await.unwrap();
        }
        let page = svc.list(Some(2), Some(2)).await.unwrap();
        assert_eq!((page.page, page.page_size, page.total), (2, 2, 3));
        let names: Vec<&str> = page.items.iter().map(Product::name).collect();
        assert_eq!(names, ["A"]);
    }

    #[tokio::test]
    async fn update_rejects_invalid_and_missing() {
        let svc = service();
        let err = svc
            .update(ProductId::new(1), cmd("键盘", -5))
            .await
            .unwrap_err();
        assert_eq!(err.kind(), ErrorKind::InvalidInput);
        let err = svc
            .update(ProductId::new(1), cmd("键盘", 5))
            .await
            .unwrap_err();
        assert_eq!(err.kind(), ErrorKind::NotFound);
    }

    #[tokio::test]
    async fn delist_hides_product() {
        let svc = service();
        let p = svc.create(cmd("键盘", 100)).await.unwrap();
        svc.delist(p.id()).await.unwrap();
        assert_eq!(
            svc.get(p.id()).await.unwrap_err().kind(),
            ErrorKind::NotFound
        );
        assert_eq!(
            svc.delist(p.id()).await.unwrap_err().kind(),
            ErrorKind::NotFound
        );
    }
}

/// 用 mockall 测试服务层与仓储之间的“交互”（第 17.5 节）：
/// 仓储是否被调用、收到了什么参数、仓储的错误是否被原样传递。
#[cfg(test)]
mod mock_tests {
    use std::sync::Arc;

    use common::error::{DomainError, ErrorKind};
    use mockall::mock;
    use mockall::predicate::eq;

    use super::*;

    // 与 `ProductRepository` 一一对应的同步版本。
    // 同步的 mock 不涉及任何异步细节；异步与 `Clone` 由下面的适配器负责。
    mock! {
        Store {
            fn insert(&self, draft: &NewProduct) -> DomainResult<Product>;
            fn get(&self, id: ProductId) -> DomainResult<Product>;
            fn list(&self, limit: i64, offset: i64) -> DomainResult<(Vec<Product>, i64)>;
            fn update(&self, product: &Product) -> DomainResult<Product>;
            fn delist(&self, id: ProductId) -> DomainResult<()>;
        }
    }

    /// 适配器：`Arc` 让它满足仓储 trait 的 `Clone` 约束，每个方法只是转发给 mock。
    #[derive(Clone)]
    struct MockedRepo(Arc<MockStore>);

    impl ProductRepository for MockedRepo {
        async fn insert(&self, draft: &NewProduct) -> DomainResult<Product> {
            self.0.insert(draft)
        }

        async fn get(&self, id: ProductId) -> DomainResult<Product> {
            self.0.get(id)
        }

        async fn list(&self, limit: i64, offset: i64) -> DomainResult<(Vec<Product>, i64)> {
            self.0.list(limit, offset)
        }

        async fn update(&self, product: &Product) -> DomainResult<Product> {
            self.0.update(product)
        }

        async fn delist(&self, id: ProductId) -> DomainResult<()> {
            self.0.delist(id)
        }
    }

    /// 期望必须在放进 `Arc` 之前设置好：设置期望需要 `&mut`。
    fn service(store: MockStore) -> ProductService<MockedRepo> {
        ProductService::new(MockedRepo(Arc::new(store)))
    }

    fn cmd(name: &str, price_cents: i64) -> ProductCommand {
        ProductCommand {
            name: name.to_string(),
            price_cents,
            stock: 3,
        }
    }

    #[tokio::test]
    async fn invalid_input_never_reaches_repository() {
        let mut store = MockStore::new();
        store.expect_insert().never();

        let err = service(store).create(cmd("   ", 100)).await.unwrap_err();

        assert_eq!(err.kind(), ErrorKind::InvalidInput);
    }

    #[tokio::test]
    async fn create_passes_trimmed_draft_to_repository() {
        let mut store = MockStore::new();
        store
            .expect_insert()
            .withf(|draft: &NewProduct| draft.name() == "机械键盘" && draft.price_cents() == 19_900)
            .times(1)
            .returning(|draft| Ok(draft.clone().into_product(ProductId::new(42))));

        let created = service(store)
            .create(cmd("  机械键盘  ", 19_900))
            .await
            .unwrap();

        assert_eq!(created.id(), ProductId::new(42));
        assert_eq!(created.name(), "机械键盘");
    }

    #[tokio::test]
    async fn repository_errors_pass_through_unchanged() {
        let mut store = MockStore::new();
        store
            .expect_get()
            .with(eq(ProductId::new(7)))
            .times(1)
            .returning(|_| Err(DomainError::Internal("连接池耗尽".to_string())));

        let err = service(store).get(ProductId::new(7)).await.unwrap_err();

        assert_eq!(err.kind(), ErrorKind::Internal);
    }

    #[tokio::test]
    async fn list_translates_page_into_limit_and_offset() {
        let mut store = MockStore::new();
        // 第 3 页、每页 10 条 → LIMIT 10 OFFSET 20
        store
            .expect_list()
            .with(eq(10_i64), eq(20_i64))
            .times(1)
            .returning(|_, _| Ok((Vec::new(), 25)));

        let page = service(store).list(Some(3), Some(10)).await.unwrap();

        assert_eq!((page.page, page.page_size, page.total), (3, 10, 25));
        assert!(page.items.is_empty());
    }
}
