//! 商品接口：`/api/v1/products`。只负责 HTTP 与服务层之间的转换。

use axum::extract::{Path, Query, State};
use axum::http::{StatusCode, header};
use axum::response::IntoResponse;
use common::ids::ProductId;
use common::pagination::Page;
use common::product::Product;
use serde::Deserialize;
use validator::Validate;

use crate::http::auth::AdminUser;
use crate::http::error::ApiError;
use crate::http::extract::{AppJson, ValidJson};
use crate::service::products::ProductCommand;
use crate::state::AppState;

/// 新增、修改商品的请求体。
///
/// 这里的规则只负责“一次告诉调用方所有字段的问题”；真正的不变量由 `NewProduct::try_new` /
/// `Product::try_new` 在服务层保证（第 15.4.4 节）。
#[derive(Debug, Deserialize, Validate)]
#[serde(deny_unknown_fields)]
pub struct ProductInput {
    #[validate(length(min = 1, max = 100, message = "长度需为 1~100 个字符"))]
    pub name: String,
    #[validate(range(min = 0, message = "不能为负数"))]
    pub price_cents: i64,
    #[validate(range(min = 0, message = "不能为负数"))]
    pub stock: i32,
}

impl From<ProductInput> for ProductCommand {
    fn from(input: ProductInput) -> Self {
        ProductCommand {
            name: input.name,
            price_cents: input.price_cents,
            stock: input.stock,
        }
    }
}

/// 列表查询参数。
#[derive(Debug, Default, Deserialize)]
pub struct ListQuery {
    pub page: Option<u32>,
    pub page_size: Option<u32>,
}

/// `GET /api/v1/products?page=&page_size=`
pub async fn list(
    State(state): State<AppState>,
    Query(query): Query<ListQuery>,
) -> Result<AppJson<Page<Product>>, ApiError> {
    Ok(AppJson(
        state.products.list(query.page, query.page_size).await?,
    ))
}

/// `GET /api/v1/products/{id}`
pub async fn get_one(
    State(state): State<AppState>,
    Path(id): Path<ProductId>,
) -> Result<AppJson<Product>, ApiError> {
    Ok(AppJson(state.products.get(id).await?))
}

/// `POST /api/v1/products`
pub async fn create(
    State(state): State<AppState>,
    _admin: AdminUser,
    ValidJson(input): ValidJson<ProductInput>,
) -> Result<impl IntoResponse, ApiError> {
    let product = state.products.create(input.into()).await?;
    let location = format!("/api/v1/products/{}", product.id());
    Ok((
        StatusCode::CREATED,
        [(header::LOCATION, location)],
        AppJson(product),
    ))
}

/// `PUT /api/v1/products/{id}`：整体替换
pub async fn update(
    State(state): State<AppState>,
    _admin: AdminUser,
    Path(id): Path<ProductId>,
    ValidJson(input): ValidJson<ProductInput>,
) -> Result<AppJson<Product>, ApiError> {
    Ok(AppJson(state.products.update(id, input.into()).await?))
}

/// `DELETE /api/v1/products/{id}`：下架（软删除）
pub async fn remove(
    State(state): State<AppState>,
    _admin: AdminUser,
    Path(id): Path<ProductId>,
) -> Result<StatusCode, ApiError> {
    state.products.delist(id).await?;
    Ok(StatusCode::NO_CONTENT)
}
