//! 商品仓储的 PostgreSQL 实现。
//!
//! 只有在售商品（`delisted_at IS NULL`）对外可见：下架的商品在查询、修改、再次下架时
//! 都表现为“不存在”。
use common::error::{DomainError, DomainResult};
use common::ids::ProductId;
use common::product::{NewProduct, Product};
use sqlx::PgPool;
use tracing::instrument;

use super::ProductRepository;
use crate::db;

/// 实体名称，用于“不存在”错误信息。
const ENTITY: &str = "商品";

/// 数据库中的一行商品，字段与 SELECT / RETURNING 的列一一对应。
#[derive(Debug, sqlx::FromRow)]
struct ProductRow {
    id: i64,
    name: String,
    price_cents: i64,
    stock: i32,
}

impl ProductRow {
    /// 行 → 领域对象。依然经过 `Product::try_new`，商品的不变量在任何来源下都成立。
    fn into_product(self) -> DomainResult<Product> {
        let id = self.id;
        Product::try_new(ProductId::new(id), &self.name, self.price_cents, self.stock).map_err(
            |reason| DomainError::Internal(format!("数据库中的商品 {id} 不满足不变量：{reason}")),
        )
    }
}

/// 商品仓储。内部只有一个连接池，克隆的代价是一次引用计数加一。
#[derive(Debug, Clone)]
pub struct PgProductRepo {
    pool: PgPool,
}

impl PgProductRepo {
    pub fn new(pool: PgPool) -> Self {
        Self { pool }
    }
}

impl ProductRepository for PgProductRepo {
    #[instrument(level = "debug", skip_all)]
    async fn insert(&self, draft: &NewProduct) -> DomainResult<Product> {
        sqlx::query_as::<_, ProductRow>(
            "INSERT INTO products (name, price_cents, stock) VALUES ($1, $2, $3) \
             RETURNING id, name, price_cents, stock",
        )
        .bind(draft.name())
        .bind(draft.price_cents())
        .bind(draft.stock())
        .fetch_one(&self.pool)
        .await
        .map_err(db::to_domain)?
        .into_product()
    }

    #[instrument(level = "debug", skip(self))]
    async fn get(&self, id: ProductId) -> DomainResult<Product> {
        sqlx::query_as::<_, ProductRow>(
            "SELECT id, name, price_cents, stock FROM products \
             WHERE id = $1 AND delisted_at IS NULL",
        )
        .bind(id.get())
        .fetch_optional(&self.pool)
        .await
        .map_err(db::to_domain)?
        .ok_or_else(|| DomainError::not_found(ENTITY, id))?
        .into_product()
    }

    #[instrument(level = "debug", skip(self))]
    async fn list(&self, limit: i64, offset: i64) -> DomainResult<(Vec<Product>, i64)> {
        let rows = sqlx::query_as::<_, ProductRow>(
            "SELECT id, name, price_cents, stock FROM products \
             WHERE delisted_at IS NULL \
             ORDER BY created_at DESC, id DESC \
             LIMIT $1 OFFSET $2",
        )
        .bind(limit)
        .bind(offset)
        .fetch_all(&self.pool);

        let total =
            sqlx::query_scalar::<_, i64>("SELECT count(*) FROM products WHERE delisted_at IS NULL")
                .fetch_one(&self.pool);

        // 两条查询互不依赖：并发执行，各自从池中借一个连接
        let (rows, total) = tokio::try_join!(rows, total).map_err(db::to_domain)?;

        let items = rows
            .into_iter()
            .map(ProductRow::into_product)
            .collect::<DomainResult<Vec<_>>>()?;
        Ok((items, total))
    }

    #[instrument(level = "debug", skip_all, fields(product_id = %product.id()))]
    async fn update(&self, product: &Product) -> DomainResult<Product> {
        sqlx::query_as::<_, ProductRow>(
            "UPDATE products SET name = $2, price_cents = $3, stock = $4, updated_at = now() \
             WHERE id = $1 AND delisted_at IS NULL \
             RETURNING id, name, price_cents, stock",
        )
        .bind(product.id().get())
        .bind(product.name())
        .bind(product.price_cents())
        .bind(product.stock())
        .fetch_optional(&self.pool)
        .await
        .map_err(db::to_domain)?
        .ok_or_else(|| DomainError::not_found(ENTITY, product.id()))?
        .into_product()
    }

    #[instrument(level = "debug", skip(self))]
    async fn delist(&self, id: ProductId) -> DomainResult<()> {
        let result = sqlx::query(
            "UPDATE products SET delisted_at = now(), updated_at = now() \
             WHERE id = $1 AND delisted_at IS NULL",
        )
        .bind(id.get())
        .execute(&self.pool)
        .await
        .map_err(db::to_domain)?;

        if result.rows_affected() == 0 {
            return Err(DomainError::not_found(ENTITY, id));
        }
        Ok(())
    }
}
