//! 密码哈希（Argon2id）。计算在阻塞线程池中进行，不占用异步工作线程（第 16.2.5 节）。

use std::sync::LazyLock;

use argon2::Argon2;
use argon2::password_hash::rand_core::OsRng;
use argon2::password_hash::{PasswordHash, PasswordHasher, PasswordVerifier, SaltString};
use common::error::{DomainError, DomainResult};
use secrecy::{ExposeSecret, SecretString};

/// 用户不存在时用于校验的假哈希，让“用户不存在”与“密码错误”耗时一致（第 16.2.6 节）。
static DUMMY_HASH: LazyLock<String> = LazyLock::new(|| {
    let salt = SaltString::generate(&mut OsRng);
    Argon2::default()
        .hash_password(b"rustmall-dummy-password", &salt)
        .map(|h| h.to_string())
        .expect("对固定输入计算 Argon2 哈希不会失败")
});

/// 计算密码哈希，返回 PHC 格式字符串。
pub async fn hash(password: SecretString) -> DomainResult<String> {
    tokio::task::spawn_blocking(move || {
        let salt = SaltString::generate(&mut OsRng);
        Argon2::default()
            .hash_password(password.expose_secret().as_bytes(), &salt)
            .map(|h| h.to_string())
    })
    .await
    .map_err(|e| DomainError::Internal(format!("密码哈希任务失败：{e}")))?
    .map_err(|e| DomainError::Internal(format!("密码哈希失败：{e}")))
}

/// 校验密码。`stored` 为 `None`（用户不存在）时与假哈希比较，结果一定是 `false`，但耗时相同。
pub async fn verify(password: SecretString, stored: Option<String>) -> DomainResult<bool> {
    tokio::task::spawn_blocking(move || {
        let user_exists = stored.is_some();
        let hash = stored.unwrap_or_else(|| DUMMY_HASH.clone());
        let parsed = PasswordHash::new(&hash)?;
        let matches = Argon2::default()
            .verify_password(password.expose_secret().as_bytes(), &parsed)
            .is_ok();
        Ok::<bool, argon2::password_hash::Error>(user_exists && matches)
    })
    .await
    .map_err(|e| DomainError::Internal(format!("密码校验任务失败：{e}")))?
    .map_err(|e| DomainError::Internal(format!("存储的密码哈希格式不正确：{e}")))
}

#[cfg(test)]
mod tests {
    use super::*;

    fn secret(s: &str) -> SecretString {
        SecretString::from(s.to_string())
    }

    #[tokio::test]
    async fn hash_then_verify() {
        let hash = hash(secret("S3cure-Passw0rd")).await.unwrap();
        assert!(hash.starts_with("$argon2id$"));
        assert!(
            verify(secret("S3cure-Passw0rd"), Some(hash.clone()))
                .await
                .unwrap()
        );
        assert!(!verify(secret("wrong-password"), Some(hash)).await.unwrap());
    }

    #[tokio::test]
    async fn unknown_user_never_matches() {
        // 即使恰好输入了假哈希对应的密码，用户不存在时也必须返回 false
        assert!(
            !verify(secret("rustmall-dummy-password"), None)
                .await
                .unwrap()
        );
    }
}
