//! 健康检查（第 23 章 Kubernetes 的探针会调用）。

use std::time::Duration;

use axum::Json;
use axum::extract::State;
use axum::http::StatusCode;
use serde_json::{Value, json};

use crate::state::AppState;

/// 就绪检查访问数据库的最长时间。
const READY_TIMEOUT: Duration = Duration::from_secs(1);

/// 存活检查：进程能响应即可，不访问任何依赖。
pub async fn live() -> Json<Value> {
    Json(json!({ "status": "ok" }))
}

/// 就绪检查：数据库在 1 秒内可用才返回 200，否则返回 503。
pub async fn ready(State(state): State<AppState>) -> (StatusCode, Json<Value>) {
    let ping = sqlx::query("SELECT 1").execute(&state.pool);
    match tokio::time::timeout(READY_TIMEOUT, ping).await {
        Ok(Ok(_)) => (StatusCode::OK, Json(json!({ "status": "ok" }))),
        // 超时或数据库错误：暂时不要把流量分给本实例
        _ => (
            StatusCode::SERVICE_UNAVAILABLE,
            Json(json!({ "status": "unavailable" })),
        ),
    }
}
