//! 自定义提取器：
//! - `AppJson`：与 `axum::Json` 用法相同，解析失败时返回统一格式的错误；
//! - `ValidJson`：在 `AppJson` 的基础上再执行 `validator` 校验。

use axum::extract::rejection::JsonRejection;
use axum::extract::{FromRequest, Request};
use axum::response::{IntoResponse, Response};
use serde::Serialize;
use serde::de::DeserializeOwned;
use validator::{Validate, ValidationErrors};

use crate::http::error::ApiError;

/// 与 `axum::Json` 用法相同，但提取失败时返回 [`ApiError`]。
#[derive(Debug, FromRequest)]
#[from_request(via(axum::Json), rejection(ApiError))]
pub struct AppJson<T>(pub T);

impl<T: Serialize> IntoResponse for AppJson<T> {
    fn into_response(self) -> Response {
        axum::Json(self.0).into_response()
    }
}

impl From<JsonRejection> for ApiError {
    fn from(rejection: JsonRejection) -> Self {
        match rejection {
            // 语法正确但不符合目标类型：缺少字段、类型错误、try_from 校验失败、未知字段
            JsonRejection::JsonDataError(e) => ApiError::Unprocessable(e.body_text()),
            // 其余：JSON 语法错误、缺少 Content-Type、读取请求体失败
            other => ApiError::BadRequest(other.body_text()),
        }
    }
}
/// 解析 JSON 并执行 `Validate` 校验；校验失败时一次性返回所有字段的错误（422）。
#[derive(Debug)]
pub struct ValidJson<T>(pub T);

impl<T, S> FromRequest<S> for ValidJson<T>
where
    T: DeserializeOwned + Validate,
    S: Send + Sync,
{
    type Rejection = ApiError;

    async fn from_request(req: Request, state: &S) -> Result<Self, Self::Rejection> {
        let AppJson(value) = AppJson::<T>::from_request(req, state).await?;
        value
            .validate()
            .map_err(|errors| ApiError::Unprocessable(describe(&errors)))?;
        Ok(ValidJson(value))
    }
}

/// 把校验错误整理成一行可读文字，例如 `name：长度需为 1~100 个字符；price_cents：不能为负数`。
fn describe(errors: &ValidationErrors) -> String {
    let mut parts = Vec::new();
    for (field, errs) in errors.field_errors() {
        for e in errs {
            let detail = e.message.as_deref().unwrap_or(&e.code);
            parts.push(format!("{field}：{detail}"));
        }
    }
    // field_errors() 是 HashMap，顺序不固定；排序让同样的请求总是得到同样的消息
    parts.sort();
    parts.join("；")
}
