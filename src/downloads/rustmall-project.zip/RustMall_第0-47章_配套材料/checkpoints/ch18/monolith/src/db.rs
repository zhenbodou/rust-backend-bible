use std::time::Duration;

use common::error::DomainError;
use sqlx::PgPool;
use sqlx::error::ErrorKind;
use sqlx::migrate::Migrator;
use sqlx::postgres::{PgConnectOptions, PgPoolOptions};

use crate::settings::DatabaseSettings;

/// 按配置创建连接池。会立即建立一个连接，地址或账号错误时在启动阶段就失败。
pub async fn connect(settings: &DatabaseSettings) -> Result<PgPool, sqlx::Error> {
    let options: PgConnectOptions = settings.url.parse()?;
    PgPoolOptions::new()
        .max_connections(settings.max_connections)
        .acquire_timeout(Duration::from_secs(settings.acquire_timeout_secs))
        .idle_timeout(Duration::from_secs(600))
        .max_lifetime(Duration::from_secs(1800))
        .connect_with(options.application_name("rustmall-monolith"))
        .await
}

pub static MIGRATOR: Migrator = sqlx::migrate!();

/// 把数据库错误转换为领域错误。
///
/// - 唯一约束、外键约束冲突：数据之间的关系由数据库裁决，属于业务冲突，对应 409；
/// - 其余错误（含 CHECK 约束冲突）：说明程序有缺陷或基础设施故障，作为内部错误处理，
///   详情只进日志，不返回给客戶端（见 14.8.3 节）。
pub fn to_domain(err: sqlx::Error) -> DomainError {
    if let Some(db_err) = err.as_database_error() {
        let constraint = db_err.constraint().unwrap_or("未知约束");
        match db_err.kind() {
            ErrorKind::UniqueViolation => {
                return DomainError::Conflict(format!("数据已存在（违反唯一约束{constraint}）"));
            }
            ErrorKind::ForeignKeyViolation => {
                return DomainError::Conflict(format!(
                    "关联的数据不存在或仍被引用（{constraint}）"
                ));
            }
            // ErrorKind 是 non_exhaustive 枚举，必须有兜底分支
            _ => {}
        }
    }
    DomainError::Internal(format!("数据库错误：{err}"))
}
