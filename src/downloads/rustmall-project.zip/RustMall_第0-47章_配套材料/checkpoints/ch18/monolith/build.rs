//! 构建脚本：`migrations` 目录变化时重新编译，让 `sqlx::migrate!` 嵌入最新的迁移文件。

fn main() {
    println!("cargo:rerun-if-changed=migrations");
}
