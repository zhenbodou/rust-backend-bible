#!/usr/bin/env bash
# 生成测试覆盖率报告（第 17.9 节）。需要先运行 ./scripts/dev-db.sh 启动开发数据库。
#
# 用法：
#   ./scripts/coverage.sh            终端摘要 + HTML 报告（target/llvm-cov/html/index.html）
#   ./scripts/coverage.sh --lcov     生成 lcov.info，供编辑器插件或 CI 使用
#
# 环境变量：
#   COVERAGE_MIN=80                  行覆盖率低于该值时以失败状态退出（默认不检查）
set -euo pipefail
cd "$(dirname "$0")/.."

if ! cargo llvm-cov --version > /dev/null 2>&1; then
    echo "未安装 cargo-llvm-cov，请先执行：cargo install cargo-llvm-cov --locked" >&2
    exit 1
fi

# main.rs 只做组装，由端到端测试与手动验证覆盖，不计入统计
IGNORE='monolith/src/main\.rs'

# 清除旧数据，运行全部测试并收集覆盖率（只收集，不生成报告）
cargo llvm-cov clean --workspace
cargo llvm-cov --workspace --no-report

# 从同一份数据生成报告
threshold=()
if [[ -n "${COVERAGE_MIN:-}" ]]; then
    threshold=(--fail-under-lines "$COVERAGE_MIN")
fi
cargo llvm-cov report --ignore-filename-regex "$IGNORE" --summary-only "${threshold[@]}"

if [[ "${1:-}" == "--lcov" ]]; then
    cargo llvm-cov report --ignore-filename-regex "$IGNORE" --lcov --output-path lcov.info
    echo "已生成 lcov.info"
else
    cargo llvm-cov report --ignore-filename-regex "$IGNORE" --html
    echo "HTML 报告：target/llvm-cov/html/index.html"
fi
