#!/usr/bin/env bash
# 启动（或重新启动）开发用的 PostgreSQL 容器。
# 用法：./scripts/dev-db.sh
set -euo pipefail

NAME=rustmall-pg
VOLUME=rustmall-pgdata
IMAGE=postgres:17

docker volume create "$VOLUME" > /dev/null

if docker ps -a --format '{{.Names}}' | grep -qx "$NAME"; then
    docker start "$NAME" > /dev/null
    echo "已启动已有容器 $NAME"
else
    docker run -d --name "$NAME" \
        -p 5432:5432 \
        -e POSTGRES_USER=rustmall \
        -e POSTGRES_PASSWORD=rustmall \
        -e POSTGRES_DB=rustmall \
        -v "$VOLUME":/var/lib/postgresql/data \
        "$IMAGE" > /dev/null
    echo "已创建并启动容器 $NAME"
fi

# 等待数据库可以接受连接（最多 30 秒）
for _ in $(seq 1 30); do
    if docker exec "$NAME" pg_isready -U rustmall > /dev/null 2>&1; then
        echo "PostgreSQL 已就绪：postgres://rustmall:rustmall@localhost:5432/rustmall"
        exit 0
    fi
    sleep 1
done
echo "等待 PostgreSQL 启动超时" >&2
exit 1
