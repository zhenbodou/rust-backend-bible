#!/usr/bin/env bash
# 启动本地开发用的 Redis 容器（第 18.2 节）。重复执行是安全的。
#
# - 开启 AOF 持久化，数据保存在 Docker 卷 rustmall-redis-data 中，重启容器后数据仍在
# - 内存上限 256 MB，满了按 LRU 淘汰：作缓存用的 Redis 必须设置这两项（第 18.5 节）
set -euo pipefail

NAME=rustmall-redis
IMAGE=redis:7.4-alpine

if docker ps --format '{{.Names}}' | grep -qx "$NAME"; then
    echo "Redis 已在运行"
elif docker ps -a --format '{{.Names}}' | grep -qx "$NAME"; then
    docker start "$NAME" > /dev/null
else
    docker run -d --name "$NAME" \
        -p 6379:6379 \
        -v rustmall-redis-data:/data \
        "$IMAGE" \
        redis-server --appendonly yes --maxmemory 256mb --maxmemory-policy allkeys-lru \
        > /dev/null
fi

for _ in $(seq 1 30); do
    if docker exec "$NAME" redis-cli ping 2> /dev/null | grep -q PONG; then
        echo "Redis 已就绪：redis://localhost:6379"
        exit 0
    fi
    sleep 0.5
done

echo "Redis 启动超时，请执行 docker logs $NAME 查看原因" >&2
exit 1
