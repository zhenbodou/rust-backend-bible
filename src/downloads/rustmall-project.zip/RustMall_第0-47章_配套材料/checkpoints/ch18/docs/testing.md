# RustMall 测试约定

## 测试分层

| 层次 | 位置 | 依赖 | 何时写 |
| --- | --- | --- | --- |
| 单元测试 | `src/` 中的 `#[cfg(test)] mod tests` | 无 | 每条业务规则、每个分支 |
| mock 测试 | `src/service/*.rs` 中的 `mod mock_tests` | 无 | 交互验证、错误注入 |
| 性质测试 | `common/tests/properties.rs` | 无 | 纯函数的往返、幂等、不变量 |
| 数据库与 HTTP 集成测试 | `monolith/tests/*.rs` | 开发数据库 | 每个接口的成功与主要错误路径 |
| 契约快照 | `monolith/tests/api_contract.rs` | 开发数据库 | 新增接口或修改响应格式时 |
| 端到端测试 | `tests/pg_container.rs` | Docker | 修改迁移、升级数据库前 |

## 常用命令

```bash
./scripts/dev-db.sh                       # 启动开发数据库
cargo test --workspace                    # 全部测试（不含被忽略的）
cargo test -p monolith --test pg_container -- --ignored   # 端到端测试
cargo insta review                        # 审阅快照变化
./scripts/coverage.sh                     # 覆盖率报告
```

## 规则

1. 测试名描述“情况与结果”，例如 `create_rejects_negative_price`。
2. 一个测试只验证一个行为；正文按“准备-执行-断言”分为三段。
3. 测试之间不共享状态：数据库测试一律使用 `#[sqlx::test]`，不修改环境变量。
4. 不使用 `sleep` 等待异步结果；需要时间的测试使用 `start_paused`。
5. 快照只用于 API 形状；业务规则用明确的断言。
6. `.snap` 文件和 proptest 的回归文件都要提交；`.snap.new` 不提交。
7. 覆盖率用来寻找盲区，不作为考核指标。
