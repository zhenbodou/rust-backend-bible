//! 运行：cargo run -p common --example error_report

use anyhow::{Context, Result};
use common::validate;

/// 把用户输入的价格字符串解析为“分”，并做范围校验。
fn load_price(raw: &str) -> Result<i64> {
    let cents: i64 = raw
        .trim()
        .parse()
        .with_context(|| format!("无法把 {raw:?} 解析为价格（单位：分）"))?;
    // ValidationError 实现了 Error + Send + Sync + 'static，可以直接 ? 进 anyhow::Error
    validate::in_range("price_cents", cents, 1, 100_000_000)?;
    Ok(cents)
}
fn main() -> Result<()> {
    for raw in ["1999", "abc", "0"] {
        match load_price(raw).context("读取商品价格失败") {
            Ok(cents) => println!("{raw} -> {cents} 分"),
            Err(e) => println!("{raw} -> 错误：{e:#}"),
        }
    }
    Ok(())
}
