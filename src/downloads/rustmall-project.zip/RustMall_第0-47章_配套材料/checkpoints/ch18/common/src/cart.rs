//! 购物车与优惠计算。
//!
//! 购物车只在内存中计算金额，不扣减库存；库存在下单时由订单流程处理。

use crate::error::{DomainError, DomainResult, ValidationError};
use crate::ids::ProductId;
use crate::money;
use crate::product::Product;
use crate::quantity::Quantity;

/// 购物车中的一行：某个商品及其数量。单价是加入购物车时的商品价格快照。
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct CartLine {
    product_id: ProductId,
    name: String,
    unit_price_cents: i64,
    quantity: Quantity,
}

impl CartLine {
    /// 根据商品的当前信息创建一行。
    ///
    /// 只能从 [`Product`] 创建，因此单价一定不为负（`Product` 的不变量）。
    pub fn from_product(product: &Product, quantity: Quantity) -> Self {
        Self {
            product_id: product.id(),
            name: product.name().to_string(),
            unit_price_cents: product.price_cents(),
            quantity,
        }
    }

    pub fn product_id(&self) -> ProductId {
        self.product_id
    }

    pub fn name(&self) -> &str {
        &self.name
    }

    pub fn unit_price_cents(&self) -> i64 {
        self.unit_price_cents
    }
    pub fn quantity(&self) -> Quantity {
        self.quantity
    }

    /// 本行小计；溢出或超过单笔上限时返回 `None`。
    pub fn subtotal_cents(&self) -> Option<i64> {
        money::line_total(self.unit_price_cents, i64::from(self.quantity.get()))
    }
}

/// 优惠规则。多条规则之间不叠加，结算时自动选择优惠最多的一条。
#[derive(Debug, Clone, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
#[serde(tag = "type", rename_all = "snake_case")]
pub enum Promotion {
    /// 满 `threshold_cents` 减 `off_cents`。
    FullReduction {
        threshold_cents: i64,
        off_cents: i64,
    },
    /// 全场折扣，`percent` 取 1~99，90 表示九折。
    Discount { percent: i64 },
}

impl Promotion {
    /// 计算本规则对给定小计能优惠多少分。
    ///
    /// 不满足条件或规则本身不合法时返回 0；优惠最多减到 0 元。
    ///
    /// ```
    /// use common::cart::Promotion;
    /// let rule = Promotion::FullReduction { threshold_cents: 30_000, off_cents: 5_000 };
    /// assert_eq!(rule.discount_for(49_700), 5_000);
    /// assert_eq!(rule.discount_for(29_999), 0);
    /// ```
    pub fn discount_for(&self, subtotal_cents: i64) -> i64 {
        match *self {
            Promotion::FullReduction {
                threshold_cents,
                off_cents,
            } => {
                if threshold_cents >= 0 && subtotal_cents >= threshold_cents {
                    off_cents.clamp(0, subtotal_cents)
                } else {
                    0
                }
            }
            Promotion::Discount { percent } => {
                if !(1..=99).contains(&percent) {
                    return 0;
                }
                money::apply_discount(subtotal_cents, percent)
                    .map_or(0, |after| subtotal_cents - after)
            }
        }
    }
}

/// 结算明细。
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct PriceBreakdown {
    /// 优惠前小计
    pub subtotal_cents: i64,
    /// 优惠金额
    pub discount_cents: i64,
    /// 应付金额
    pub payable_cents: i64,
    /// 实际使用的优惠规则；没有满足条件的规则时为 `None`
    pub applied: Option<Promotion>,
}

/// 购物车。
#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct Cart {
    lines: Vec<CartLine>,
}

impl Cart {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn lines(&self) -> &[CartLine] {
        &self.lines
    }

    pub fn is_empty(&self) -> bool {
        self.lines.is_empty()
    }
    /// 商品总件数。
    pub fn item_count(&self) -> i32 {
        self.lines.iter().map(|line| line.quantity.get()).sum()
    }

    /// 加入购物车。
    ///
    /// 同一商品合并数量，单价更新为最新快照；合并后超过上限时拒绝，购物车保持不变。
    pub fn add(&mut self, line: CartLine) -> DomainResult<()> {
        if let Some(existing) = self
            .lines
            .iter_mut()
            .find(|l| l.product_id == line.product_id)
        {
            let total = existing.quantity.get() + line.quantity.get();
            // 先校验、成功后才赋值：`?` 提前返回时 existing 没有被修改
            existing.quantity =
                Quantity::try_new(total).map_err(|_| ValidationError::OutOfRange {
                    field: "quantity",
                    value: i64::from(total),
                    min: 1,
                    max: i64::from(Quantity::MAX),
                })?;
            existing.unit_price_cents = line.unit_price_cents;
            return Ok(());
        }
        self.lines.push(line);
        Ok(())
    }

    /// 移除某个商品，返回是否确实移除了。
    pub fn remove(&mut self, product_id: ProductId) -> bool {
        let before = self.lines.len();
        self.lines.retain(|line| line.product_id != product_id);
        self.lines.len() != before
    }

    /// 所有行的小计之和。
    pub fn subtotal_cents(&self) -> DomainResult<i64> {
        self.lines
            .iter()
            .try_fold(0_i64, |acc, line| acc.checked_add(line.subtotal_cents()?))
            .ok_or_else(|| DomainError::Internal("购物车金额溢出或超过单笔上限".to_string()))
    }
    /// 按给定的优惠规则结算，自动选择优惠金额最大的一条。
    pub fn price(&self, promotions: &[Promotion]) -> DomainResult<PriceBreakdown> {
        let subtotal = self.subtotal_cents()?;
        let best = promotions
            .iter()
            .map(|rule| (rule, rule.discount_for(subtotal)))
            .filter(|&(_, discount)| discount > 0)
            .max_by_key(|&(_, discount)| discount);
        let (applied, discount) = match best {
            Some((rule, discount)) => (Some(rule.clone()), discount),
            None => (None, 0),
        };
        Ok(PriceBreakdown {
            subtotal_cents: subtotal,
            discount_cents: discount,
            payable_cents: subtotal - discount,
            applied,
        })
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::error::ErrorKind;

    fn qty(n: i32) -> Quantity {
        Quantity::try_new(n).expect("测试数量合法")
    }

    fn product(id: i64, name: &str, price_cents: i64) -> Product {
        Product::try_new(ProductId::new(id), name, price_cents, 100).expect("测试商品合法")
    }

    /// 键盘 199 元 × 2 + 鼠标 99 元 × 1 = 497 元
    fn sample_cart() -> Cart {
        let mut cart = Cart::new();
        cart.add(CartLine::from_product(
            &product(1, "机械键盘", 19_900),
            qty(2),
        ))
        .expect("加入成功");
        cart.add(CartLine::from_product(&product(2, "鼠标", 9_900), qty(1)))
            .expect("加入成功");
        cart
    }

    #[test]
    fn add_creates_lines() {
        let cart = sample_cart();
        assert_eq!(cart.lines().len(), 2);
        assert_eq!(cart.item_count(), 3);
        assert_eq!(cart.lines()[1].name(), "鼠标");
    }

    #[test]
    fn same_product_is_merged_with_latest_price() {
        let mut cart = sample_cart();
        cart.add(CartLine::from_product(
            &product(1, "机械键盘", 17_900),
            qty(3),
        ))
        .expect("合并成功");
        assert_eq!(cart.lines().len(), 2);
        let keyboard = &cart.lines()[0];
        assert_eq!(keyboard.quantity().get(), 5);
        assert_eq!(keyboard.unit_price_cents(), 17_900);
    }

    #[test]
    fn merge_over_limit_is_rejected_and_cart_unchanged() {
        let mut cart = sample_cart();
        let before = cart.clone();
        let err = cart
            .add(CartLine::from_product(
                &product(1, "机械键盘", 15_900),
                qty(98),
            ))
            .expect_err("2 + 98 超过上限");
        assert_eq!(err.kind(), ErrorKind::InvalidInput);
        assert_eq!(cart, before, "失败的加入不能修改购物车");
    }

    #[test]
    fn remove_reports_whether_removed() {
        let mut cart = sample_cart();
        assert!(cart.remove(ProductId::new(2)));
        assert!(!cart.remove(ProductId::new(2)));
        assert_eq!(cart.item_count(), 2);
        assert!(!cart.is_empty());
    }
    #[test]
    fn subtotal_sums_all_lines() {
        assert_eq!(sample_cart().subtotal_cents().expect("不会溢出"), 49_700);
        assert_eq!(Cart::new().subtotal_cents().expect("空购物车为 0"), 0);
    }

    #[test]
    fn full_reduction_requires_threshold() {
        let rule = Promotion::FullReduction {
            threshold_cents: 30_000,
            off_cents: 5_000,
        };
        assert_eq!(rule.discount_for(30_000), 5_000);
        assert_eq!(rule.discount_for(29_999), 0);
    }

    #[test]
    fn best_promotion_is_chosen() {
        let promos = [
            Promotion::Discount { percent: 90 },
            Promotion::FullReduction {
                threshold_cents: 30_000,
                off_cents: 5_000,
            },
        ];
        let price = sample_cart().price(&promos).expect("结算成功");
        // 九折优惠 49700 - 44730 = 4970 分，满减优惠 5000 分，选满减
        assert_eq!(price.discount_cents, 5_000);
        assert_eq!(price.payable_cents, 44_700);
        assert_eq!(price.applied, Some(promos[1].clone()));
    }

    #[test]
    fn no_applicable_promotion() {
        let promos = [Promotion::FullReduction {
            threshold_cents: 60_000,
            off_cents: 5_000,
        }];
        let price = sample_cart().price(&promos).expect("结算成功");
        assert_eq!(price.applied, None);
        assert_eq!(price.discount_cents, 0);
        assert_eq!(price.payable_cents, price.subtotal_cents);
    }

    #[test]
    fn invalid_or_excessive_promotions() {
        assert_eq!(Promotion::Discount { percent: 0 }.discount_for(10_000), 0);
        assert_eq!(Promotion::Discount { percent: 100 }.discount_for(10_000), 0);
        assert_eq!(
            Promotion::FullReduction {
                threshold_cents: 0,
                off_cents: -100
            }
            .discount_for(10_000),
            0
        );
        // 满减金额超过小计：最多减到 0 元
        assert_eq!(
            Promotion::FullReduction {
                threshold_cents: 0,
                off_cents: 99_999
            }
            .discount_for(10_000),
            10_000
        );
    }

    #[test]
    fn overflow_is_internal_error() {
        let mut cart = Cart::new();
        // 单价 90 万元 × 2 超过单笔上限 100 万元；加入时不计算金额，所以加入本身成功
        cart.add(CartLine::from_product(
            &product(9, "金条", 90_000_000),
            qty(2),
        ))
        .expect("加入成功");
        let err = cart.subtotal_cents().expect_err("超过单笔上限");
        assert_eq!(err.kind(), ErrorKind::Internal);
    }
}
