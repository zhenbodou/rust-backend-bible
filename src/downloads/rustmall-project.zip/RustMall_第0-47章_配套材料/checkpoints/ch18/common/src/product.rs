//! 商品领域模型。

use crate::ids::ProductId;
use crate::money;
use crate::quantity::Quantity;

/// 商品。
///
/// 所有字段私有：只能通过 [`Product::try_new`] 创建，只能通过业务方法修改，
/// 因此任何实例都满足以下不变量：
/// - 名称去除首尾空白后为 1〜100 个字符
/// - 价格（分）不为负
/// - 库存不为负
#[derive(Debug, Clone, PartialEq, Eq, serde::Serialize)]
pub struct Product {
    id: ProductId,
    name: String,
    price_cents: i64,
    stock: i32,
}

impl Product {
    /// 商品名最大字符数。
    pub const NAME_MAX_CHARS: usize = 100;

    /// 校验并创建商品。
    pub fn try_new(
        id: ProductId,
        name: &str,
        price_cents: i64,
        stock: i32,
    ) -> Result<Self, String> {
        let name = name.trim();
        let chars = name.chars().count();
        if chars == 0 || chars > Self::NAME_MAX_CHARS {
            return Err(format!("商品名长度需为 1〜{} 个字符", Self::NAME_MAX_CHARS));
        }
        if price_cents < 0 {
            return Err("价格不能为负数".to_string());
        }
        if stock < 0 {
            return Err("库存不能为负数".to_string());
        }
        Ok(Self {
            id,
            name: name.to_string(),
            price_cents,
            stock,
        })
    }

    // ---------- 只读访问（getter） ----------

    pub fn id(&self) -> ProductId {
        self.id
    }

    pub fn name(&self) -> &str {
        &self.name
    }

    pub fn price_cents(&self) -> i64 {
        self.price_cents
    }

    pub fn stock(&self) -> i32 {
        self.stock
    }

    /// 价格的“元”表示，例如 `"199.00"`。
    pub fn price_yuan(&self) -> String {
        money::format_yuan(self.price_cents)
    }
    pub fn in_stock(&self) -> bool {
        self.stock > 0
    }

    pub fn can_buy(&self, qty: Quantity) -> bool {
        self.stock >= qty.get()
    }
    // ---------- 业务操作 ----------

    /// 扣减库存。库存不足时返回错误，且**不修改**库存。
    pub fn deduct_stock(&mut self, qty: Quantity) -> Result<(), String> {
        if !self.can_buy(qty) {
            return Err(format!("库存不足：剩余 {}，需要 {}", self.stock, qty.get()));
        }
        self.stock -= qty.get();
        Ok(())
    }

    /// 补货，数量必须为正。
    pub fn restock(&mut self, qty: i32) -> Result<(), String> {
        if qty <= 0 {
            return Err("补货数量必须大于 0".to_string());
        }
        self.stock = self
            .stock
            .checked_add(qty)
            .ok_or_else(|| "库存数量溢出".to_string())?;
        Ok(())
    }

    /// 调整价格，不能为负。
    pub fn change_price(&mut self, price_cents: i64) -> Result<(), String> {
        if price_cents < 0 {
            return Err("价格不能为负数".to_string());
        }
        self.price_cents = price_cents;
        Ok(())
    }
}

impl crate::repository::Entity for Product {
    type Id = ProductId;
    const NAME: &'static str = "商品";

    fn id(&self) -> ProductId {
        // 调用 Product 的固有方法 id()。固有方法优先于同名的 trait 方法，所以这里不会递归。
        self.id()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn qty(n: i32) -> Quantity {
        Quantity::try_new(n).expect("测试中的数量应当合法")
    }

    fn keyboard(stock: i32) -> Product {
        Product::try_new(ProductId::new(1), "   机械键盘 ", 19_900, stock)
            .expect("测试商品应当合法")
    }

    #[test]
    fn try_new_validates_and_trims() {
        assert_eq!(keyboard(0).name(), "机械键盘");
        assert!(Product::try_new(ProductId::new(1), "  ", 100, 0).is_err());
        assert!(Product::try_new(ProductId::new(1), "键盘", -1, 0).is_err());
        assert!(Product::try_new(ProductId::new(1), "键盘", 100, -1).is_err());
        assert!(Product::try_new(ProductId::new(1), &"字".repeat(101), 100, 0).is_err());
    }

    #[test]
    fn deduct_stock_never_goes_negative() {
        let mut p = keyboard(3);
        assert!(p.deduct_stock(qty(2)).is_ok());
        assert_eq!(p.stock(), 1);
        assert!(p.deduct_stock(qty(2)).is_err());
        assert_eq!(p.stock(), 1, "失败的扣减不能修改库存");
    }

    #[test]
    fn restock_and_price_rules() {
        let mut p = keyboard(0);
        assert!(!p.in_stock());
        assert!(p.restock(0).is_err());
        assert!(p.restock(10).is_ok());
        assert!(p.in_stock());
        assert!(p.restock(i32::MAX).is_err());
        assert!(p.change_price(-5).is_err());
        assert_eq!(p.price_yuan(), "199.00");
    }
}

/// 尚未分配 ID 的商品：新增商品时使用。
///
/// 校验规则与 [`Product::try_new`] 完全相同；ID 由存储层分配后，
/// 通过 [`NewProduct::into_product`] 成为正式商品。
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct NewProduct {
    name: String,
    price_cents: i64,
    stock: i32,
}

impl NewProduct {
    /// 校验并创建。复用 `Product::try_new`，规则只写在一个地方。
    pub fn try_new(name: &str, price_cents: i64, stock: i32) -> Result<Self, String> {
        let checked = Product::try_new(ProductId::new(0), name, price_cents, stock)?;
        Ok(Self {
            name: checked.name,
            price_cents: checked.price_cents,
            stock: checked.stock,
        })
    }

    pub fn name(&self) -> &str {
        &self.name
    }

    pub fn price_cents(&self) -> i64 {
        self.price_cents
    }

    pub fn stock(&self) -> i32 {
        self.stock
    }

    /// 分配 ID，成为正式商品。字段已经校验过，不需要再次校验。
    pub fn into_product(self, id: ProductId) -> Product {
        Product {
            id,
            name: self.name,
            price_cents: self.price_cents,
            stock: self.stock,
        }
    }
}
