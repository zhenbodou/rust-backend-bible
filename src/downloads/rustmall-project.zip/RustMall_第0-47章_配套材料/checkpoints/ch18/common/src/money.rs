//! 金额工具。
//!
//! 全项目统一约定：金额一律使用 `i64` 表示，单位为“分”。
//! 例如 199.50 元表示为 `19950`。禁止使用浮点数表示金额。

/// 每元等于多少分。
pub const CENTS_PER_YUAN: i64 = 100;

/// 单笔订单允许的最大金额：100 万元。
pub const MAX_ORDER_CENTS: i64 = 1_000_000 * CENTS_PER_YUAN;

/// 计算 `单价 × 数量` 的总价，溢出或超过上限时返回 `None`。
///
/// # Examples
///
/// ```
/// use common::money::line_total;
/// assert_eq!(line_total(19_900, 3), Some(59_700));
/// assert_eq!(line_total(i64::MAX, 2), None);
/// ```
pub fn line_total(unit_cents: i64, qty: i64) -> Option<i64> {
    if unit_cents < 0 || qty <= 0 {
        return None;
    }
    let total = unit_cents.checked_mul(qty)?;
    if total > MAX_ORDER_CENTS {
        return None;
    }
    Some(total)
}

/// 按百分比打折，结果向下取整到分。`percent` 取值 1〜100，90 表示九折。
///
/// 金额为负、折扣超出范围或乘法溢出时返回 `None`。
pub fn apply_discount(total_cents: i64, percent: i64) -> Option<i64> {
    if total_cents < 0 || !(1..=100).contains(&percent) {
        return None;
    }
    // 先乘后除，避免先除导致的精度损失：19950 * 90 / 100 = 17955
    Some(total_cents.checked_mul(percent)? / 100)
}

/// 把“分”格式化为“元”的字符串，支持负数（退款）。
///
/// ```
/// use common::money::format_yuan;
/// assert_eq!(format_yuan(19_950), "199.50");
/// assert_eq!(format_yuan(5), "0.05");
/// assert_eq!(format_yuan(-1_050), "-10.50");
/// ```
pub fn format_yuan(cents: i64) -> String {
    let sign = if cents < 0 { "-" } else { "" };
    // unsigned_abs 返回 u64，避免 i64::MIN.abs() 溢出
    let abs = cents.unsigned_abs();
    let per_yuan = CENTS_PER_YUAN.unsigned_abs();
    format!("{sign}{}.{:02}", abs / per_yuan, abs % per_yuan)
}

/// 把用户输入的“元”字符串解析为“分”，最多两位小数。
///
/// 接受 `"199"`、`"199.5"`、`"199.50"`；拒绝负数、三位小数和非数字。
/// 不使用浮点数解析，避免精度问题。
pub fn parse_yuan(input: &str) -> Option<i64> {
    let s = input.trim();
    let (yuan_part, cent_part) = match s.split_once('.') {
        Some((y, c)) => (y, c),
        None => (s, ""),
    };
    if yuan_part.is_empty() || cent_part.len() > 2 {
        return None;
    }
    if !yuan_part.chars().all(|c| c.is_ascii_digit())
        || !cent_part.chars().all(|c| c.is_ascii_digit())
    {
        return None;
    }
    let yuan: i64 = yuan_part.parse().ok()?;
    // "5" 表示 50 分，"05" 表示 5 分，空表示 0 分
    let cents: i64 = match cent_part.len() {
        0 => 0,
        1 => cent_part.parse::<i64>().ok()? * 10,
        _ => cent_part.parse().ok()?,
    };
    yuan.checked_mul(CENTS_PER_YUAN)?.checked_add(cents)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn line_total_rejects_invalid_input() {
        assert_eq!(line_total(100, 0), None);
        assert_eq!(line_total(-1, 1), None);
        assert_eq!(line_total(MAX_ORDER_CENTS, 2), None);
    }
    #[test]
    fn discount_rounds_down() {
        assert_eq!(apply_discount(19_950, 90), Some(17_955));

        // 999 分的 33% 是 329.67 分，取整后为 329 分
        assert_eq!(apply_discount(999, 33), Some(329));
        assert_eq!(apply_discount(100, 0), None);
        assert_eq!(apply_discount(100, 101), None);
        assert_eq!(apply_discount(-1, 90), None);
        assert_eq!(apply_discount(i64::MAX, 100), None);
    }

    #[test]
    fn parse_yuan_cases() {
        assert_eq!(parse_yuan("199"), Some(19_900));
        assert_eq!(parse_yuan(" 199.5 "), Some(19_950));
        assert_eq!(parse_yuan("0.05"), Some(5));
        assert_eq!(parse_yuan("1.234"), None);
        assert_eq!(parse_yuan("-1"), None);
        assert_eq!(parse_yuan("abc"), None);
        assert_eq!(parse_yuan(".5"), None);
    }

    #[test]
    fn format_and_parse_roundtrip() {
        for cents in [0, 1, 99, 100, 19_950, 1_000_000] {
            assert_eq!(parse_yuan(&format_yuan(cents)), Some(cents));
        }
    }
}
