//! 进程内的单调递增 ID 序列。
//!
//! 只用于内存实现和测试。接入数据库后，ID 由数据库的自增序列生成（第 14 章），
//! 微服务之间需要全局唯一 ID 时使用 UUID v7 或雪花算法（第 29 章）。

use std::sync::atomic::{AtomicI64, Ordering};
/// 线程安全的递增序列。
///
/// 可以放进 `static`，也可以作为结构体字段通过 `Arc` 共享。
///
/// ```
/// use common::id_gen::Sequence;
///
/// static ORDER_NO: Sequence = Sequence::starting_at(1001);
/// assert_eq!(ORDER_NO.next_value(), 1001);
/// assert_eq!(ORDER_NO.next_value(), 1002);
/// ```
#[derive(Debug)]
pub struct Sequence {
    next: AtomicI64,
}

impl Sequence {
    /// 从 `first` 开始的序列。`const fn`，因此可以用于 `static`。
    pub const fn starting_at(first: i64) -> Self {
        Self {
            next: AtomicI64::new(first),
        }
    }

    /// 取下一个值。多个线程同时调用也不会得到重复的值。
    ///
    /// 达到 `i64::MAX` 后会回绕为负数；按每秒一百万个计算，需要约 29 万年。
    pub fn next_value(&self) -> i64 {
        // 只需要“每个值只被取走一次”，不用它同步其他数据，所以 Relaxed 足够
        self.next.fetch_add(1, Ordering::Relaxed)
    }
}

impl Default for Sequence {
    fn default() -> Self {
        Self::starting_at(1)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::collections::HashSet;
    use std::thread;
    #[test]
    fn values_are_sequential() {
        let seq = Sequence::default();
        let values: Vec<i64> = (0..3).map(|_| seq.next_value()).collect();
        assert_eq!(values, vec![1, 2, 3]);
    }

    #[test]
    fn concurrent_values_are_unique() {
        let seq = Sequence::default();
        let all: Vec<i64> = thread::scope(|s| {
            let mut handles = Vec::new();
            for _ in 0..8 {
                handles.push(s.spawn(|| (0..1_000).map(|_| seq.next_value()).collect::<Vec<_>>()));
            }
            handles
                .into_iter()
                .flat_map(|h| h.join().expect("线程不应 panic"))
                .collect()
        });
        let unique: HashSet<i64> = all.iter().copied().collect();
        assert_eq!(all.len(), 8_000);
        assert_eq!(unique.len(), 8_000, "不能出现重复的 ID");
        assert_eq!(all.iter().max(), Some(&8_000));
    }
}
