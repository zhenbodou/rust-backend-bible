//! 合法的购买数量（解析而非校验）。

use serde::{Deserialize, Serialize};

/// 单笔购买数量，取值 1~[`Quantity::MAX`]。
///
/// 字段私有，只能通过 [`Quantity::try_new`] 或 `TryFrom<i32>` 创建，
/// 因此任何 `Quantity` 实例都一定是合法的。JSON 中表示为数字，
/// 反序列化时同样执行校验。
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, PartialOrd, Ord, Serialize, Deserialize)]
#[serde(try_from = "i32", into = "i32")]
pub struct Quantity(i32);
impl Quantity {
    /// 单笔最大购买数量。
    pub const MAX: i32 = 99;

    /// 校验并创建购买数量。
    pub fn try_new(n: i32) -> Result<Self, String> {
        if (1..=Self::MAX).contains(&n) {
            Ok(Self(n))
        } else {
            Err(format!("购买数量需为 1~{} 件，当前为 {n}", Self::MAX))
        }
    }

    pub const fn get(self) -> i32 {
        self.0
    }
}

impl TryFrom<i32> for Quantity {
    type Error = String;
    fn try_from(n: i32) -> Result<Self, Self::Error> {
        Self::try_new(n)
    }
}

impl From<Quantity> for i32 {
    fn from(q: Quantity) -> i32 {
        q.0
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn quantity_bounds() {
        assert!(Quantity::try_new(0).is_err());
        assert!(Quantity::try_new(-3).is_err());
        assert!(Quantity::try_new(100).is_err());
        assert_eq!(Quantity::try_new(1).map(Quantity::get), Ok(1));
        assert_eq!(Quantity::try_new(99).map(Quantity::get), Ok(99));
    }

    #[test]
    fn std_conversions_match_try_new() {
        assert_eq!(Quantity::try_from(5), Quantity::try_new(5));
        assert!(Quantity::try_from(0).is_err());
        assert_eq!(i32::from(Quantity::try_new(7).expect("合法")), 7);
    }
}
