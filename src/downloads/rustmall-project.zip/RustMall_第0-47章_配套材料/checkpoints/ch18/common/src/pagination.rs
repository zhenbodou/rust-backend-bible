//! 分页参数换算。
//!
//! 前端传入“第几页、每页几条”，数据库需要 `LIMIT`（取几条）和 `OFFSET`（跳过几条）。
/// 默认每页条数。
pub const DEFAULT_PAGE_SIZE: u32 = 20;
/// 每页最大条数，防止客户端一次请求过多数据拖垮数据库。
pub const MAX_PAGE_SIZE: u32 = 100;

/// 把可选的页码和每页条数规范化为合法值。
///
/// - 页码缺省或小于 1 时视为 1
/// - 每页条数缺省时为 [`DEFAULT_PAGE_SIZE`]，并限制在 1〜[`MAX_PAGE_SIZE`] 之间
pub fn normalize(page: Option<u32>, page_size: Option<u32>) -> (u32, u32) {
    let page = page.unwrap_or(1).max(1);
    let size = page_size
        .unwrap_or(DEFAULT_PAGE_SIZE)
        .clamp(1, MAX_PAGE_SIZE);
    (page, size)
}

/// 计算 SQL 需要的 `(limit, offset)`，类型为 `i64` 以便直接绑定到 PostgreSQL 的 BIGINT。
///
/// ```
/// use common::pagination::limit_offset;
/// assert_eq!(limit_offset(Some(3), Some(20)), (20, 40));
/// assert_eq!(limit_offset(None, Some(1000)), (100, 0));
/// ```
pub fn limit_offset(page: Option<u32>, page_size: Option<u32>) -> (i64, i64) {
    let (page, size) = normalize(page, page_size);
    let limit = i64::from(size);

    // u32 → i64 用 from，不可能失败
    let offset = i64::from(page - 1) * limit;
    (limit, offset)
}

/// 根据总条数计算总页数。
pub fn total_pages(total_items: i64, page_size: u32) -> i64 {
    // 负数视为 0；转成无符号类型后可以使用标准库的向上取整除法 div_ceil
    let items = u64::try_from(total_items).unwrap_or(0);
    let size = u64::from(page_size.max(1));
    i64::try_from(items.div_ceil(size)).unwrap_or(i64::MAX)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn normalize_handles_edges() {
        assert_eq!(normalize(None, None), (1, DEFAULT_PAGE_SIZE));
        assert_eq!(normalize(Some(0), Some(0)), (1, 1));
        assert_eq!(normalize(Some(5), Some(500)), (5, MAX_PAGE_SIZE));
    }

    #[test]
    fn total_pages_rounds_up() {
        assert_eq!(total_pages(0, 20), 0);
        assert_eq!(total_pages(1, 20), 1);
        assert_eq!(total_pages(40, 20), 2);
        assert_eq!(total_pages(41, 20), 3);
    }
}

use serde::Serialize;

/// 分页响应，JSON 形状见 `docs/api-v1.md` 第 3 节。
#[derive(Debug, Clone, PartialEq, Eq, Serialize)]
pub struct Page<T> {
    pub items: Vec<T>,
    pub page: u32,
    pub page_size: u32,
    pub total: i64,
}

impl<T> Page<T> {
    pub fn new(items: Vec<T>, page: u32, page_size: u32, total: i64) -> Self {
        Self {
            items,
            page,
            page_size,
            total,
        }
    }

    /// 转换每个元素（例如实体 → 响应 DTO），分页信息保持不变。
    pub fn map<U>(self, f: impl FnMut(T) -> U) -> Page<U> {
        Page {
            items: self.items.into_iter().map(f).collect(),
            page: self.page,
            page_size: self.page_size,
            total: self.total,
        }
    }
}
