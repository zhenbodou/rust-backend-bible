//! 通用输入校验函数。
//!
//! 每个函数只检查一件事，失败时返回带字段名的 [`ValidationError`]。
//! 多个检查用 `?` 串联，遇到第一个失败就返回。

use crate::error::ValidationError;

/// 去掉首尾空白后不能为空。
pub fn non_empty(field: &'static str, value: &str) -> Result<(), ValidationError> {
    if value.trim().is_empty() {
        Err(ValidationError::Empty { field })
    } else {
        Ok(())
    }
}

/// 按字符数（而不是字节数）检查长度，闭区间 `[min, max]`。
///
/// ```
/// use common::validate::char_len;
/// assert!(char_len("name", "机械键盘", 1, 4).is_ok()); // 4 个字符，12 个字节
/// ```
pub fn char_len(
    field: &'static str,
    value: &str,
    min: usize,
    max: usize,
) -> Result<(), ValidationError> {
    let actual = value.chars().count();
    if (min..=max).contains(&actual) {
        Ok(())
    } else {
        Err(ValidationError::Length {
            field,
            min,
            max,
            actual,
        })
    }
}

/// 整数范围检查，闭区间 `[min, max]`。
pub fn in_range(
    field: &'static str,
    value: i64,
    min: i64,
    max: i64,
) -> Result<(), ValidationError> {
    if (min..=max).contains(&value) {
        Ok(())
    } else {
        Err(ValidationError::OutOfRange {
            field,
            value,
            min,
            max,
        })
    }
}

/// 只允许 ASCII 字母、数字、`-` 和 `_`，用于 SKU 编码等。
/// 空字符串会通过本检查，需要时先调用 [`non_empty`]。
pub fn ascii_code(field: &'static str, value: &str) -> Result<(), ValidationError> {
    let is_allowed = |c: char| c.is_ascii_alphanumeric() || c == '-' || c == '_';
    match value.chars().find(|&c| !is_allowed(c)) {
        None => Ok(()),
        Some(bad) => Err(ValidationError::Format {
            field,
            reason: format!("包含不允许的字符 {bad:?}"),
        }),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn non_empty_rejects_whitespace_only() {
        assert_eq!(
            non_empty("name", " \t\n"),
            Err(ValidationError::Empty { field: "name" })
        );
        assert!(non_empty("name", " 键盘 ").is_ok());
    }
    #[test]
    fn char_len_counts_chars_not_bytes() {
        assert_eq!("机械键盘".len(), 12);
        assert!(char_len("name", "机械键盘", 1, 4).is_ok());
        assert!(char_len("name", "机械键盘!", 1, 4).is_err());
    }

    #[test]
    fn char_len_error_message() {
        let err = char_len("name", "", 1, 50).unwrap_err();
        assert_eq!(
            err.to_string(),
            "字段 `name` 长度应为 1〜50 个字符，实际为 0 个"
        );
    }

    #[test]
    fn in_range_is_inclusive() {
        assert!(in_range("qty", 1, 1, 99).is_ok());
        assert!(in_range("qty", 99, 1, 99).is_ok());
        assert!(in_range("qty", 0, 1, 99).is_err());
        assert!(in_range("qty", 100, 1, 99).is_err());
    }

    #[test]
    fn ascii_code_reports_first_bad_char() {
        assert!(ascii_code("sku", "KB-001_a").is_ok());
        let err = ascii_code("sku", "KB 001").unwrap_err();
        assert_eq!(
            err.to_string(),
            "字段 `sku` 格式不正确：包含不允许的字符 ' '"
        );
    }

    #[test]
    fn checks_compose_with_question_mark() {
        fn validate_product(
            name: &str,
            sku: &str,
            price_cents: i64,
        ) -> Result<(), ValidationError> {
            non_empty("name", name)?;
            char_len("name", name, 1, 50)?;
            non_empty("sku", sku)?;
            ascii_code("sku", sku)?;
            in_range("price_cents", price_cents, 1, 100_000_000)?;
            Ok(())
        }

        assert!(validate_product("机械键盘", "KB-001", 29_900).is_ok());
        assert!(matches!(
            validate_product("机械键盘", "KB-001", 0),
            Err(ValidationError::OutOfRange {
                field: "price_cents",
                ..
            })
        ));
    }
}
