//! 强类型 ID。
//!
//! 每种实体的 ID 都是独立的类型，编译器会阻止把 `UserId` 传给需要 `ProductId` 的地方。
//! 运行时它们与 `i64` 完全相同，没有任何额外开销。
//! 所有 ID 类型由本模块私有的 `define_id!` 宏生成，保证行为一致。

/// 生成一个包装 `i64` 的 ID 类型。
///
/// 生成的内容：
/// - `#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, PartialOrd, Ord)]`
/// - `const fn new(i64) -> Self` 与 `const fn get(self) -> i64`
/// - `Display`：输出内部数字
/// - `From<ID> for i64`：可以写 `i64::from(id)` 或 `let raw: i64 =
/// id.into();`
///
/// 宏调用前写的文档注释会成为生成类型的文档。
macro_rules! define_id {
    ($(#[$meta:meta])* $name:ident) => {
        $(#[$meta])*
        #[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, PartialOrd, Ord, ::serde::Serialize, ::serde::Deserialize)]
        #[serde(transparent)]
        pub struct $name(i64);

        impl $name {
            pub const fn new(value: i64) -> Self {
                Self(value)
            }

            pub const fn get(self) -> i64 {
                self.0
            }
        }

        impl ::std::fmt::Display for $name {
            fn fmt(&self, f: &mut ::std::fmt::Formatter<'_>) -> ::std::fmt::Result {
                write!(f, "{}", self.0)
            }
        }

        impl ::std::convert::From<$name> for i64 {
            fn from(id: $name) -> i64 {
                id.0
            }
        }
    };
}
define_id!(
    /// 用户 ID。
    UserId
);

define_id!(
    /// 商品 ID。
    ProductId
);

define_id!(
    /// 订单 ID。
    OrderId
);

#[cfg(test)]
mod tests {
    use super::*;
    use std::collections::HashSet;

    #[test]
    fn ids_display_as_plain_numbers() {
        assert_eq!(UserId::new(7).to_string(), "7");
        assert_eq!(format!("订单 {}", OrderId::new(1001)), "订单 1001");
    }

    #[test]
    fn ids_can_be_hash_keys() {
        let set: HashSet<ProductId> =
            [ProductId::new(1), ProductId::new(1), ProductId::new(2)].into();
        assert_eq!(set.len(), 2);
    }

    #[test]
    fn ids_convert_to_i64() {
        let raw: i64 = ProductId::new(42).into();
        assert_eq!(raw, 42);
        assert_eq!(i64::from(UserId::new(7)), 7);
        assert_eq!(OrderId::new(3).get(), 3);
    }
}
