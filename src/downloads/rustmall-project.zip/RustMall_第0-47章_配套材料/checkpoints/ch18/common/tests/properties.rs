#![allow(clippy::unwrap_used)]
//! common 的性质测试：用大量随机输入验证“对所有输入都成立”的规律（第 17.8 节）。
//!
//! 每个性质默认运行 256 个随机输入；临时加大次数：`PROPTEST_CASES=10000 cargo test -p common`。

use common::cart::Promotion;
use common::ids::ProductId;
use common::money::{format_yuan, parse_yuan};
use common::pagination::{MAX_PAGE_SIZE, limit_offset, normalize};
use common::product::Product;
use common::text::{USERNAME_MAX_CHARS, USERNAME_MIN_CHARS, normalize_username};
use proptest::prelude::*;

/// 任意一条优惠规则。字段故意取任意值（包括负数和超出范围的百分比），
/// 因为 `Promotion::discount_for` 承诺对不合法的规则返回 0。
fn any_promotion() -> impl Strategy<Value = Promotion> {
    prop_oneof![
        (any::<i64>(), any::<i64>()).prop_map(|(threshold_cents, off_cents)| {
            Promotion::FullReduction {
                threshold_cents,
                off_cents,
            }
        }),
        any::<i64>().prop_map(|percent| Promotion::Discount { percent }),
    ]
}

proptest! {
    /// 往返：任意非负金额，格式化为“元”再解析，回到原值。
    #[test]
    fn yuan_round_trip(cents in 0..=i64::MAX) {
        prop_assert_eq!(parse_yuan(&format_yuan(cents)), Some(cents));
    }

    /// 负数金额可以格式化（用于退款展示），但用户输入中的负数一律被拒绝。
    #[test]
    fn negative_yuan_is_rejected_by_parser(cents in i64::MIN..0) {
        prop_assert!(format_yuan(cents).starts_with('-'));
        prop_assert_eq!(parse_yuan(&format_yuan(cents)), None);
    }

    /// 不变量：无论客戶端传什么，分页参数都被规范到合法范围，且 offset 与 limit 一致。
    #[test]
    fn pagination_is_always_in_range(
        page in any::<Option<u32>>(),
        size in any::<Option<u32>>(),
    ) {
        let (page_no, page_size) = normalize(page, size);
        prop_assert!(page_no >= 1);
        prop_assert!((1..=MAX_PAGE_SIZE).contains(&page_size));

        let (limit, offset) = limit_offset(page, size);
        prop_assert_eq!(limit, i64::from(page_size));
        prop_assert_eq!(offset, i64::from(page_no - 1) * limit);
    }

    /// 幂等：规范化后的用户名再规范化一次，结果不变；长度不合法时一定被拒绝。
    #[test]
    fn username_normalization_is_idempotent(
        input in "[ \t]{0,2}[A-Za-z0-9_]{0,25}[ \t]{0,2}",
    ) {
        let trimmed_chars = input.trim().chars().count();
        let allowed = USERNAME_MIN_CHARS..=USERNAME_MAX_CHARS;
        let length_ok = allowed.contains(&trimmed_chars);

        match normalize_username(&input) {
            Ok(name) => {
                prop_assert!(length_ok);
                prop_assert_eq!(&name.to_lowercase(), &name);
                prop_assert_eq!(normalize_username(&name), Ok(name));
            }
            // 字符集只包含合法字符，所以失败的唯一原因是长度
            Err(_) => prop_assert!(!length_ok),
        }
    }

    /// 不变量：对任意规则和任意非负小计，优惠金额总在 0 与小计之间（最多减到 0 元）。
    #[test]
    fn discount_never_exceeds_subtotal(
        rule in any_promotion(),
        subtotal in 0..=i64::MAX,
    ) {
        let discount = rule.discount_for(subtotal);
        prop_assert!(
            (0..=subtotal).contains(&discount),
            "rule = {:?}, subtotal = {}, discount = {}",
            rule,
            subtotal,
            discount
        );
    }

    /// 合法性判定：构造函数接受的输入，恰好是规则允许的输入；接受时名称已去除首尾空白。
    #[test]
    fn product_accepts_exactly_the_valid_inputs(
        name in "\\PC{0,110}",
        price_cents in any::<i64>(),
        stock in any::<i32>(),
    ) {
        let name_chars = name.trim().chars().count();
        let valid = (1..=Product::NAME_MAX_CHARS).contains(&name_chars)
            && price_cents >= 0
            && stock >= 0;

        match Product::try_new(ProductId::new(1), &name, price_cents, stock) {
            Ok(product) => {
                prop_assert!(valid);
                prop_assert_eq!(product.name(), name.trim());
                prop_assert_eq!(product.price_cents(), price_cents);
                prop_assert_eq!(product.stock(), stock);
            }
            Err(_) => prop_assert!(!valid),
        }
    }
}
