#![allow(clippy::unwrap_used)]
//! JSON 契约测试：保证领域类型的 JSON 表示与 docs/api-v1.md 一致。
//!
//! 这是集成测试：它是一个独立的 crate，只能使用 common 的公开 API。

use common::cart::Promotion;
use common::ids::ProductId;
use common::order::OrderStatus;
use common::pagination::Page;
use common::product::Product;
use common::quantity::Quantity;
use serde_json::json;

#[test]
fn ids_are_plain_numbers() {
    assert_eq!(serde_json::to_string(&ProductId::new(42)).unwrap(), "42");
    let id: ProductId = serde_json::from_str("42").unwrap();
    assert_eq!(id, ProductId::new(42));
}

#[test]
fn quantity_is_validated_on_deserialize() {
    let q: Quantity = serde_json::from_str("3").unwrap();
    assert_eq!(q.get(), 3);
    let err = serde_json::from_str::<Quantity>("0").unwrap_err();
    assert!(
        err.to_string().contains("购买数量需为 1~99 件"),
        "实际错误：{err}"
    );
    assert_eq!(serde_json::to_string(&q).unwrap(), "3");
}

#[test]
fn order_status_uses_lowercase_strings() {
    for status in OrderStatus::ALL {
        assert_eq!(
            serde_json::to_value(status).unwrap(),
            json!(status.as_str())
        );
    }
    let s: OrderStatus = serde_json::from_str(r#""cancelled""#).unwrap();
    assert_eq!(s, OrderStatus::Cancelled);
    assert!(serde_json::from_str::<OrderStatus>(r#""Paid""#).is_err());
}

#[test]
fn promotion_is_internally_tagged() {
    let rule = Promotion::FullReduction {
        threshold_cents: 30_000,
        off_cents: 5_000,
    };
    assert_eq!(
        serde_json::to_value(&rule).unwrap(),
        json!({ "type": "full_reduction", "threshold_cents": 30000, "off_cents": 5000 })
    );
    let discount: Promotion = serde_json::from_value(json!({ "type": "discount", "percent": 90
    }))
    .unwrap();
    assert_eq!(discount, Promotion::Discount { percent: 90 });
}

#[test]
fn product_serializes_public_fields() {
    let p = Product::try_new(ProductId::new(42), "机械键盘", 19_900, 10).unwrap();
    assert_eq!(
        serde_json::to_value(&p).unwrap(),
        json!({ "id": 42, "name": "机械键盘", "price_cents": 19900, "stock":
10 })
    );
}

#[test]
fn page_has_documented_shape() {
    let page = Page::new(vec![1, 2], 1, 20, 2);
    assert_eq!(
        serde_json::to_value(&page).unwrap(),
        json!({ "items": [1, 2], "page": 1, "page_size": 20, "total": 2 })
    );
}
