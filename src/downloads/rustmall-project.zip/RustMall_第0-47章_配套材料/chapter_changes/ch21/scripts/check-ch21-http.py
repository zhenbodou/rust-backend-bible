"""只读检查第 21 章已启动的 HTTP 契约；失败返回非零。"""
import argparse
import json
import sys
import urllib.error
import urllib.request

parser = argparse.ArgumentParser()
parser.add_argument("--base", default="http://127.0.0.1:58080")
args = parser.parse_args()
base = args.base.rstrip("/")


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, request, fp, code, message, headers, new_url):
        return None


opener = urllib.request.build_opener(NoRedirect())


def fetch(path):
    request = urllib.request.Request(base + path, method="GET")
    try:
        response = opener.open(request, timeout=3)
    except urllib.error.HTTPError as error:
        response = error
    with response:
        body = response.read(128 * 1024 + 1)
        if len(body) > 128 * 1024:
            raise ValueError("响应体超过本检查器上限")
        return response.status, json.loads(body)


try:
    for path in ["/health/live", "/health/ready"]:
        status, body = fetch(path)
        if status != 200 or not isinstance(body, dict):
            raise ValueError(f"{path} 未满足健康接口契约")
        print(f"PASS {path}")
    status, body = fetch("/api/v1/products?page=1&page_size=2")
    if status != 200 or not isinstance(body, dict):
        raise ValueError("商品列表没有返回成功 JSON 对象")
    if not isinstance(body.get("items"), list):
        raise ValueError("items 不是数组")
    if type(body.get("total")) is not int or body["total"] < 0:
        raise ValueError("total 不是非负整数")
    print("PASS 商品列表结构")
except (OSError, ValueError, KeyError, TypeError) as error:
    print(f"FAIL {error}", file=sys.stderr)
    raise SystemExit(1)
print("ALL 3 CHECKS PASSED；只验证已列出的只读契约。")
