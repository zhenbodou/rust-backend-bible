"""在 RustMall 根目录生成本地 Compose 插值文件；拒绝覆盖。"""
from pathlib import Path
import os
import secrets

values = {
    "DB_USER": "rustmall",
    "DB_NAME": "rustmall",
    "DB_PASSWORD": secrets.token_urlsafe(36),
    "JWT_SECRET": secrets.token_urlsafe(48),
}
path = Path("compose.dev.env")
fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
with os.fdopen(fd, "w") as output:
    for key, value in values.items():
        output.write(f"{key}={value}\n")
print("已生成 compose.dev.env；没有输出秘密值。")
