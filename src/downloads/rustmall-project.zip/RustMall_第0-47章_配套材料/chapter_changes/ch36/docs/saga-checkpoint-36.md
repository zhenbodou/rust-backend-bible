# 第36章完整订单隔离实验

同一累积工程新增orders/worker/catalog-http/edge，从新users域读取身份。旧monolith/gateway阶段保留，不自动迁移旧用户或以相同整数认人。

1. cargo build --locked --workspace --all-features --bins。
2. python3 scripts/create-saga-env.py一次创建私有.saga.local（0700/0600，拒绝覆盖）。
3. docker compose -p rustmall-saga36 --env-file .saga.local/infra.env -f deploy/saga36/compose.yaml up -d --wait。
4. run-saga-role.py catalog/users/payments/orders分别加--migrate（一次一个角色）。
5. 分终端运行run-saga-role.py catalog、users、payments、orders、catalog-http、edge、worker。先等catalog开始监听。默认生成的公共入口http://127.0.0.1:18086。
6. python3 scripts/check-saga-http.py --local-admin-fixture，保留新用户、商品和订单供核对，不打印密码/令牌。

订单API按用户/请求键幂等，先查原收据再取当前商品，冻结正金额，GET按真实actor隔离。worker依次reserving/charging/confirming，或refunding/releasing；completed/cancelled/manual终态不再自动领取。15秒租约，推进/延后必须匹配ID、步骤、token和未过期条件；旧worker的迟到RPC仍靠参与者收据保护。租约和副作用幂等承担不同职责。

商品适配器保留管理员幂等创建、资料PUT与软下架；库存覆盖仍409。edge保留CORS Idempotency-Key、白名单、逐跳头规则与请求/响应限制。它和catalog-http不建立数据库池；worker不需要users、商品读凭据或JWT密钥。

本地四库共用实验管理员，不是已验证的生产最小权限。停止角色/Compose之前保留profile；down默认保留卷，只有丢弃此数据集时加--volumes，清理后再删除profile。复制项目、归档源码和后续阶段必须排除.saga.local。

下一章增加projection数据库时，已有PG卷不会重跑init.sql；必须明确创建新增库并执行其迁移，不删除本章卷来伪造连续升级。真实身份导入/ID映射、完整镜像、远端CI和集群留待后续验收。
