CREATE DATABASE rustmall_saga_catalog;
CREATE DATABASE rustmall_saga_users;
CREATE DATABASE rustmall_saga_payments;
CREATE DATABASE rustmall_saga_orders;
