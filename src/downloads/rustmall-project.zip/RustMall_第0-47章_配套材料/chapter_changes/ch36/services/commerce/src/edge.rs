use crate::runtime::*;
use axum::{
    Router,
    body::{Body, to_bytes},
    extract::{Request, State},
    http::{HeaderValue, Method, StatusCode},
    response::Response,
    routing::{any, get},
};
use std::{sync::Arc, time::Duration};
use tokio::sync::Semaphore;
use tower_http::cors::CorsLayer;
#[derive(Clone)]
pub struct Edge {
    client: reqwest::Client,
    users: String,
    orders: String,
    catalog: String,
    capacity: Arc<Semaphore>,
    origin: HeaderValue,
}
fn origin(raw: &str) -> anyhow::Result<String> {
    let url = reqwest::Url::parse(raw)?;
    anyhow::ensure!(
        matches!(url.scheme(), "http" | "https")
            && url.host_str().is_some()
            && url.username().is_empty()
            && url.password().is_none()
            && url.path() == "/"
            && url.query().is_none()
            && url.fragment().is_none(),
        "HTTP origin without credentials required"
    );
    Ok(url.origin().ascii_serialization())
}
impl Edge {
    pub fn new(
        users: &str,
        orders: &str,
        catalog: &str,
        allowed_origin: &str,
    ) -> anyhow::Result<Self> {
        let client = reqwest::Client::builder()
            .no_proxy()
            .connect_timeout(Duration::from_millis(300))
            .timeout(Duration::from_secs(3))
            .redirect(reqwest::redirect::Policy::none())
            .build()?;
        Ok(Self {
            client,
            users: origin(users)?,
            orders: origin(orders)?,
            catalog: origin(catalog)?,
            capacity: capacity(),
            origin: origin(allowed_origin)?.parse()?,
        })
    }
}
pub fn router(s: Edge) -> Router {
    let ready = s.clone();
    let cors = CorsLayer::new()
        .allow_origin(s.origin.clone())
        .allow_methods([Method::GET, Method::POST, Method::PUT, Method::DELETE])
        .allow_headers([
            axum::http::header::AUTHORIZATION,
            axum::http::header::CONTENT_TYPE,
            axum::http::HeaderName::from_static("idempotency-key"),
        ])
        .expose_headers([axum::http::HeaderName::from_static("x-request-id")]);
    Router::new()
        .route("/api/v1/auth/{*tail}", any(proxy))
        .route("/api/v1/users/me", any(proxy))
        .route("/api/v1/orders", any(proxy))
        .route("/api/v1/orders/{id}", any(proxy))
        .route("/api/v1/products", any(proxy))
        .route("/api/v1/products/{id}", any(proxy))
        .route("/healthz", get(|| async { StatusCode::OK }))
        .route(
            "/readyz",
            get(move || {
                let s = ready.clone();
                async move {
                    let checks = s.client.get(format!("{}/readyz", s.users)).send();
                    let b = s.client.get(format!("{}/readyz", s.orders)).send();
                    let c = s.client.get(format!("{}/readyz", s.catalog)).send();
                    match tokio::time::timeout(Duration::from_secs(2), async {
                        tokio::join!(checks, b, c)
                    })
                    .await
                    {
                        Ok((Ok(a), Ok(b), Ok(c)))
                            if [a.status(), b.status(), c.status()]
                                .iter()
                                .all(|s| *s == StatusCode::OK) =>
                        {
                            StatusCode::OK
                        }
                        _ => StatusCode::SERVICE_UNAVAILABLE,
                    }
                }
            }),
        )
        .layer(cors)
        .with_state(s)
}
async fn proxy(State(s): State<Edge>, r: Request) -> ApiResult<Response> {
    let _permit = enter(&s.capacity)?;
    let path = r.uri().path_and_query().ok_or_else(invalid)?.as_str();
    let base =
        if r.uri().path().starts_with("/api/v1/auth/") || r.uri().path() == "/api/v1/users/me" {
            &s.users
        } else if r.uri().path().starts_with("/api/v1/orders") {
            &s.orders
        } else {
            &s.catalog
        };
    let mut upstream = s
        .client
        .request(r.method().clone(), format!("{base}{path}"));
    let mut hop = Vec::new();
    for value in r.headers().get_all("connection") {
        let value = value.to_str().map_err(|_| invalid())?;
        for name in value.split(',').map(str::trim) {
            hop.push(axum::http::HeaderName::from_bytes(name.as_bytes()).map_err(|_| invalid())?);
        }
    }
    // Whitelist preserves no client-supplied role, service credential or hop-by-hop headers.
    for name in ["authorization", "content-type", "idempotency-key"] {
        if r.headers().get_all(name).iter().count() > 1 {
            return Err(invalid());
        }
        if hop.iter().any(|h| h.as_str() == name) {
            continue;
        }
        if let Some(value) = r.headers().get(name) {
            upstream = upstream.header(name, value);
        }
    }
    let body = to_bytes(r.into_body(), 64 * 1024)
        .await
        .map_err(|_| ApiError(StatusCode::PAYLOAD_TOO_LARGE, "body too large"))?;
    let mut response = upstream
        .body(body)
        .send()
        .await
        .map_err(|_| unavailable())?;
    let status = response.status();
    let ct = response.headers().get("content-type").cloned();
    let mut bytes = Vec::new();
    while let Some(chunk) = response.chunk().await.map_err(|_| unavailable())? {
        if bytes.len().saturating_add(chunk.len()) > 1024 * 1024 {
            return Err(unavailable());
        }
        bytes.extend_from_slice(&chunk);
    }
    let mut out = Response::new(Body::from(bytes));
    *out.status_mut() = status;
    if let Some(ct) = ct {
        out.headers_mut().insert("content-type", ct);
    }
    out.headers_mut()
        .insert("cache-control", HeaderValue::from_static("no-store"));
    Ok(out)
}
