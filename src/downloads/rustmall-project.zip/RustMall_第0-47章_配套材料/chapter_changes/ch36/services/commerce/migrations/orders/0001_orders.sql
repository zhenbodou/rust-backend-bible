CREATE TABLE orders (
 id UUID PRIMARY KEY CHECK(id<>'00000000-0000-0000-0000-000000000000'),
 actor_id BIGINT NOT NULL CHECK(actor_id>0),
 request_key UUID NOT NULL CHECK(request_key<>'00000000-0000-0000-0000-000000000000'),
 product_id BIGINT NOT NULL CHECK(product_id>0),
 quantity INTEGER NOT NULL CHECK(quantity BETWEEN 1 AND 999),
 unit_price BIGINT NOT NULL CHECK(unit_price BETWEEN 1 AND 100000000),
 amount BIGINT NOT NULL CHECK(amount BETWEEN 1 AND 100000000),
 state TEXT NOT NULL DEFAULT 'reserving' CHECK(state IN
 ('reserving','charging','confirming','releasing','refunding','completed','cancelled','manual')),
 attempts INTEGER NOT NULL DEFAULT 0 CHECK(attempts BETWEEN 0 AND 1000000),
 next_attempt TIMESTAMPTZ NOT NULL DEFAULT now(),
 lease_token UUID, leased_until TIMESTAMPTZ,
 last_error TEXT CHECK(char_length(last_error)<=64),
 created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 UNIQUE(actor_id,request_key),
 CHECK(amount=unit_price*quantity),
 CHECK((lease_token IS NULL)=(leased_until IS NULL)),
 CHECK(lease_token IS NULL OR lease_token<>'00000000-0000-0000-0000-000000000000'),
 CHECK(state NOT IN ('completed','cancelled','manual') OR lease_token IS NULL)
);
CREATE INDEX orders_work ON orders(next_attempt,id)
 WHERE state NOT IN ('completed','cancelled','manual');
CREATE TABLE order_transitions (
 id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
 order_id UUID NOT NULL REFERENCES orders(id),
 from_state TEXT NOT NULL, to_state TEXT NOT NULL,
 reason TEXT NOT NULL CHECK(char_length(reason) BETWEEN 1 AND 64),
 occurred_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 UNIQUE(order_id,from_state),
 CHECK(
  (from_state='reserving' AND to_state IN ('charging','cancelled','manual')) OR
  (from_state='charging' AND to_state IN ('confirming','releasing','manual')) OR
  (from_state='confirming' AND to_state IN ('completed','refunding','manual')) OR
  (from_state='refunding' AND to_state IN ('releasing','manual')) OR
  (from_state='releasing' AND to_state IN ('cancelled','manual'))
 )
);
