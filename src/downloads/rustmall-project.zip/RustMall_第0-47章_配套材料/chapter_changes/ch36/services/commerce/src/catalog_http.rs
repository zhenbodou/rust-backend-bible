use crate::{catalog_link::CatalogRemote, runtime::*, users::UserRemote};
use axum::{
    Json, Router,
    extract::{Path, Query, State, rejection::QueryRejection},
    http::{HeaderMap, StatusCode},
    routing::get,
};
use contracts::catalog::{CreateProductRequest, UpdateProductRequest};
use serde::Deserialize;
use serde_json::{Value, json};
use uuid::Uuid;
#[derive(Clone)]
pub struct CatalogHttp {
    pub catalog: CatalogRemote,
    pub users: UserRemote,
}
#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct Page {
    #[serde(default = "one")]
    page: i64,
    #[serde(default = "twenty")]
    page_size: i64,
}
fn one() -> i64 {
    1
}
fn twenty() -> i64 {
    20
}
#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct Draft {
    name: String,
    price_cents: i64,
    stock: i32,
}
fn value(p: contracts::catalog::Product) -> Value {
    json!({"id":p.id,"name":p.name,"price_cents":p.price_cents,"stock":p.stock})
}
fn id(raw: &str) -> ApiResult<i64> {
    raw.parse::<i64>()
        .ok()
        .filter(|n| *n > 0)
        .ok_or_else(invalid)
}
async fn admin(s: &CatalogHttp, h: &HeaderMap) -> ApiResult<i64> {
    let user = s.users.identity(h).await?;
    if user.role != "admin" {
        return Err(ApiError(StatusCode::FORBIDDEN, "administrator required"));
    }
    Ok(user.id)
}
pub fn router(s: CatalogHttp) -> Router {
    let ready = s.clone();
    Router::new()
        .route("/api/v1/products", get(list).post(create))
        .route(
            "/api/v1/products/{id}",
            get(find).put(update).delete(delist),
        )
        .route("/healthz", get(|| async { StatusCode::OK }))
        .route(
            "/readyz",
            get(move || {
                let s = ready.clone();
                async move {
                    let (catalog, users) = tokio::join!(s.catalog.ready(), s.users.ready());
                    if catalog && users {
                        StatusCode::OK
                    } else {
                        StatusCode::SERVICE_UNAVAILABLE
                    }
                }
            }),
        )
        .layer(axum::extract::DefaultBodyLimit::max(4096))
        .with_state(s)
}
async fn list(
    State(s): State<CatalogHttp>,
    page: Result<Query<Page>, QueryRejection>,
) -> ApiResult<Json<Value>> {
    let Query(p) = page.map_err(|_| invalid())?;
    if p.page < 1 || !(1..=100).contains(&p.page_size) {
        return Err(invalid());
    }
    let offset = (p.page - 1).checked_mul(p.page_size).ok_or_else(invalid)?;
    let rows = s.catalog.list(p.page_size, offset).await?;
    Ok(Json(
        json!({"items":rows.items.into_iter().map(value).collect::<Vec<_>>(),"total":rows.total,"page":p.page,"page_size":p.page_size}),
    ))
}
async fn find(State(s): State<CatalogHttp>, Path(raw): Path<String>) -> ApiResult<Json<Value>> {
    Ok(Json(value(s.catalog.get(id(&raw)?).await?)))
}
async fn create(
    State(s): State<CatalogHttp>,
    h: HeaderMap,
    BodyJson(d): BodyJson<Draft>,
) -> ApiResult<(StatusCode, Json<Value>)> {
    let actor = admin(&s, &h).await?;
    if h.get_all("idempotency-key").iter().count() != 1 {
        return Err(invalid());
    }
    let key = h
        .get("idempotency-key")
        .and_then(|v| v.to_str().ok())
        .and_then(|v| Uuid::parse_str(v).ok())
        .filter(|v| !v.is_nil())
        .ok_or_else(invalid)?;
    let p = s
        .catalog
        .create(CreateProductRequest {
            name: d.name,
            price_cents: d.price_cents,
            stock: d.stock,
            idempotency_key: key.to_string(),
            actor_id: actor,
        })
        .await?;
    Ok((StatusCode::CREATED, Json(value(p))))
}
async fn update(
    State(s): State<CatalogHttp>,
    h: HeaderMap,
    Path(raw): Path<String>,
    BodyJson(d): BodyJson<Draft>,
) -> ApiResult<Json<Value>> {
    admin(&s, &h).await?;
    Ok(Json(value(
        s.catalog
            .update(UpdateProductRequest {
                id: id(&raw)?,
                name: d.name,
                price_cents: d.price_cents,
                stock: d.stock,
            })
            .await?,
    )))
}
async fn delist(
    State(s): State<CatalogHttp>,
    h: HeaderMap,
    Path(raw): Path<String>,
) -> ApiResult<StatusCode> {
    admin(&s, &h).await?;
    s.catalog.delist(id(&raw)?).await?;
    Ok(StatusCode::NO_CONTENT)
}
