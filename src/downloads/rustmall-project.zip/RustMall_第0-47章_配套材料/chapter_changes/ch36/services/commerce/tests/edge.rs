use axum::{
    Router,
    body::Body,
    http::{HeaderMap, Request, StatusCode},
    routing::get,
};
use commerce::{
    edge::{self, Edge},
    runtime::bounded,
};
use http_body_util::BodyExt;
use tokio_util::sync::CancellationToken;
use tower::ServiceExt;
async fn server(app: Router) -> (String, CancellationToken, tokio::task::JoinHandle<()>) {
    let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
    let base = format!("http://{}", listener.local_addr().unwrap());
    let stop = CancellationToken::new();
    let shutdown = stop.clone();
    let task = tokio::spawn(async move {
        axum::serve(listener, app)
            .with_graceful_shutdown(shutdown.cancelled_owned())
            .await
            .unwrap();
    });
    (base, stop, task)
}
async fn close(stop: CancellationToken, mut task: tokio::task::JoinHandle<()>) {
    stop.cancel();
    match tokio::time::timeout(std::time::Duration::from_secs(3), &mut task).await {
        Ok(r) => r.unwrap(),
        Err(_) => {
            task.abort();
            let _ = task.await;
            panic!("server shutdown timeout");
        }
    }
}
#[tokio::test]
async fn whitelisted_headers_and_connection_nominations_are_respected() {
    let upstream = Router::new().route(
        "/api/v1/users/me",
        get(|h: HeaderMap| async move {
            assert!(!h.contains_key("x-user-role"));
            assert!(!h.contains_key("x-rustmall-service-token"));
            assert!(!h.contains_key("authorization"));
            "ok"
        }),
    );
    let (base, stop, task) = server(upstream).await;
    let app = bounded(edge::router(
        Edge::new(&base, &base, &base, "http://localhost:3000").unwrap(),
    ));
    let req = Request::builder()
        .uri("/api/v1/users/me")
        .header("x-user-role", "admin")
        .header("x-rustmall-service-token", "secret")
        .header("authorization", "Bearer test")
        .header("connection", "authorization")
        .body(Body::empty())
        .unwrap();
    assert_eq!(app.oneshot(req).await.unwrap().status(), StatusCode::OK);
    close(stop, task).await;
}
#[tokio::test]
async fn browser_preflight_allows_idempotency_key_only_for_configured_origin() {
    let app = bounded(edge::router(
        Edge::new(
            "http://127.0.0.1:1",
            "http://127.0.0.1:1",
            "http://127.0.0.1:1",
            "http://localhost:3000",
        )
        .unwrap(),
    ));
    for origin in ["http://localhost:3000", "https://untrusted.invalid"] {
        let req = Request::builder()
            .method("OPTIONS")
            .uri("/api/v1/orders")
            .header("origin", origin)
            .header("access-control-request-method", "POST")
            .header(
                "access-control-request-headers",
                "authorization,content-type,idempotency-key",
            )
            .body(Body::empty())
            .unwrap();
        let r = app.clone().oneshot(req).await.unwrap();
        if origin == "http://localhost:3000" {
            assert_eq!(r.headers()["access-control-allow-origin"], origin);
            assert!(
                r.headers()["access-control-allow-headers"]
                    .to_str()
                    .unwrap()
                    .contains("idempotency-key")
            );
        } else {
            assert_ne!(
                r.headers()
                    .get("access-control-allow-origin")
                    .and_then(|h| h.to_str().ok()),
                Some(origin)
            );
        }
    }
}
#[tokio::test]
async fn duplicate_auth_is_rejected_and_internal_paths_are_not_public() {
    let app = bounded(edge::router(
        Edge::new(
            "http://127.0.0.1:1",
            "http://127.0.0.1:1",
            "http://127.0.0.1:1",
            "http://localhost:3000",
        )
        .unwrap(),
    ));
    let mut req = Request::builder()
        .uri("/api/v1/orders")
        .body(Body::empty())
        .unwrap();
    req.headers_mut()
        .append("authorization", "Bearer one".parse().unwrap());
    req.headers_mut()
        .append("authorization", "Bearer two".parse().unwrap());
    assert_eq!(
        app.clone().oneshot(req).await.unwrap().status(),
        StatusCode::BAD_REQUEST
    );
    let r = app
        .oneshot(
            Request::builder()
                .uri("/internal/payments")
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();
    assert_eq!(r.status(), StatusCode::NOT_FOUND);
}
#[tokio::test]
async fn oversized_upstream_response_is_bounded() {
    let (base, stop, task) = server(Router::new().route(
        "/api/v1/products",
        get(|| async { "x".repeat(1024 * 1024 + 1) }),
    ))
    .await;
    let app = bounded(edge::router(
        Edge::new(&base, &base, &base, "http://localhost:3000").unwrap(),
    ));
    let r = app
        .oneshot(
            Request::builder()
                .uri("/api/v1/products")
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();
    assert_eq!(r.status(), StatusCode::SERVICE_UNAVAILABLE);
    let bytes = r.into_body().collect().await.unwrap().to_bytes();
    assert!(bytes.len() < 1024);
    close(stop, task).await;
}
