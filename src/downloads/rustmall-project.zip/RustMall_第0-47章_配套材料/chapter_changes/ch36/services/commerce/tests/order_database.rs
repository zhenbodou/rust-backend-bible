use commerce::orders::{self, Draft};
use sqlx::PgPool;
use uuid::Uuid;
async fn create(pool: &PgPool) -> orders::Order {
    orders::insert(
        pool,
        7,
        Uuid::new_v4(),
        &Draft {
            product_id: 1,
            quantity: 2,
        },
        100,
    )
    .await
    .unwrap()
}
async fn state(pool: &PgPool, id: Uuid) -> String {
    sqlx::query_scalar("SELECT state FROM orders WHERE id=$1")
        .bind(id)
        .fetch_one(pool)
        .await
        .unwrap()
}
async fn count(pool: &PgPool, id: Uuid) -> i64 {
    sqlx::query_scalar("SELECT count(*) FROM order_transitions WHERE order_id=$1")
        .bind(id)
        .fetch_one(pool)
        .await
        .unwrap()
}
#[sqlx::test(migrations = "./migrations/orders")]
async fn concurrent_first_requests_share_winning_price_and_identity(pool: PgPool) {
    let d = Draft {
        product_id: 1,
        quantity: 2,
    };
    let key = Uuid::new_v4();
    let (a, b) = tokio::join!(
        orders::insert(&pool, 7, key, &d, 100),
        orders::insert(&pool, 7, key, &d, 200)
    );
    let a = a.unwrap();
    let b = b.unwrap();
    assert_eq!(a, b);
    assert!(matches!(a.unit_price, 100 | 200));
    assert_eq!(a.amount, a.unit_price * 2);
    let replay = orders::insert(&pool, 7, key, &d, 300).await.unwrap();
    assert_eq!(replay, a);
    assert_eq!(count(&pool, a.id).await, 0);
}
#[sqlx::test(migrations = "./migrations/orders")]
async fn request_key_is_actor_scoped_and_changed_input_conflicts(pool: PgPool) {
    let d = Draft {
        product_id: 1,
        quantity: 2,
    };
    let key = Uuid::new_v4();
    let a = orders::insert(&pool, 7, key, &d, 100).await.unwrap();
    let b = orders::insert(&pool, 8, key, &d, 100).await.unwrap();
    assert_ne!(a.id, b.id);
    let bad = Draft { quantity: 3, ..d };
    assert_eq!(
        orders::insert(&pool, 7, key, &bad, 100)
            .await
            .unwrap_err()
            .0
            .as_u16(),
        409
    );
    assert_eq!(orders::existing(&pool, 7, key).await.unwrap().unwrap(), a);
}
#[sqlx::test(migrations = "./migrations/orders")]
async fn invalid_price_quantity_and_overflow_never_insert(pool: PgPool) {
    for (quantity, price) in [
        (0, 100),
        (1000, 100),
        (1, 0),
        (999, i64::MAX),
        (2, 100000000),
    ] {
        assert_eq!(
            orders::insert(
                &pool,
                7,
                Uuid::new_v4(),
                &Draft {
                    product_id: 1,
                    quantity
                },
                price
            )
            .await
            .unwrap_err()
            .0
            .as_u16(),
            400
        );
    }
    let n: i64 = sqlx::query_scalar("SELECT count(*) FROM orders")
        .fetch_one(&pool)
        .await
        .unwrap();
    assert_eq!(n, 0);
}
#[sqlx::test(migrations = "./migrations/orders")]
async fn concurrent_claims_have_one_live_owner(pool: PgPool) {
    create(&pool).await;
    let (a, b) = tokio::join!(orders::claim(&pool), orders::claim(&pool));
    let rows = [a.unwrap(), b.unwrap()];
    assert_eq!(rows.iter().filter(|r| r.is_some()).count(), 1);
    let owner = rows.into_iter().flatten().next().unwrap();
    assert_eq!(owner.0.attempts, 1);
    assert!(!owner.1.is_nil());
}
#[sqlx::test(migrations = "./migrations/orders")]
async fn expired_and_replaced_tokens_cannot_advance_or_defer(pool: PgPool) {
    let id = create(&pool).await.id;
    let (a, old) = orders::claim(&pool).await.unwrap().unwrap();
    sqlx::query("UPDATE orders SET leased_until=clock_timestamp()-interval '1 second' WHERE id=$1")
        .bind(id)
        .execute(&pool)
        .await
        .unwrap();
    assert!(
        !orders::advance(&pool, &a, old, "charging", "inventory-held")
            .await
            .unwrap()
    );
    assert!(!orders::defer(&pool, &a, old, "unknown").await.unwrap());
    let (b, new) = orders::claim(&pool).await.unwrap().unwrap();
    assert_ne!(old, new);
    assert_eq!(b.attempts, 2);
    assert!(
        !orders::advance(&pool, &a, old, "charging", "inventory-held")
            .await
            .unwrap()
    );
    assert!(!orders::defer(&pool, &a, old, "unknown").await.unwrap());
    assert!(
        orders::advance(&pool, &b, new, "charging", "inventory-held")
            .await
            .unwrap()
    );
    assert_eq!(state(&pool, id).await, "charging");
    assert_eq!(count(&pool, id).await, 1);
}
#[sqlx::test(migrations = "./migrations/orders")]
async fn advancement_is_conditional_and_rejects_illegal_jump(pool: PgPool) {
    let id = create(&pool).await.id;
    let (row, key) = orders::claim(&pool).await.unwrap().unwrap();
    assert!(
        orders::advance(&pool, &row, key, "completed", "skip")
            .await
            .is_err()
    );
    assert_eq!(state(&pool, id).await, "reserving");
    assert!(
        orders::advance(&pool, &row, key, "charging", "inventory-held")
            .await
            .unwrap()
    );
    assert!(
        !orders::advance(&pool, &row, key, "charging", "inventory-held")
            .await
            .unwrap()
    );
    assert_eq!(count(&pool, id).await, 1);
}
#[sqlx::test(migrations = "./migrations/orders")]
async fn failed_audit_rolls_back_state_and_retains_lease(pool: PgPool) {
    let id = create(&pool).await.id;
    let (row, key) = orders::claim(&pool).await.unwrap().unwrap();
    sqlx::query("ALTER TABLE order_transitions ADD CONSTRAINT injected CHECK(false) NOT VALID")
        .execute(&pool)
        .await
        .unwrap();
    assert!(
        orders::advance(&pool, &row, key, "charging", "inventory-held")
            .await
            .is_err()
    );
    assert_eq!(state(&pool, id).await, "reserving");
    assert_eq!(count(&pool, id).await, 0);
    let token: Uuid = sqlx::query_scalar("SELECT lease_token FROM orders WHERE id=$1")
        .bind(id)
        .fetch_one(&pool)
        .await
        .unwrap();
    assert_eq!(token, key);
    sqlx::query("ALTER TABLE order_transitions DROP CONSTRAINT injected")
        .execute(&pool)
        .await
        .unwrap();
    assert!(
        orders::advance(&pool, &row, key, "charging", "inventory-held")
            .await
            .unwrap()
    );
}
#[sqlx::test(migrations = "./migrations/orders")]
async fn deferred_work_saves_backoff_without_terminal_transition(pool: PgPool) {
    let id = create(&pool).await.id;
    let (row, key) = orders::claim(&pool).await.unwrap().unwrap();
    assert!(
        orders::defer(&pool, &row, key, "payment-result-unknown")
            .await
            .unwrap()
    );
    assert!(orders::claim(&pool).await.unwrap().is_none());
    assert_eq!(state(&pool, id).await, "reserving");
    assert_eq!(count(&pool, id).await, 0);
    let(error,cleared,delay):(String,bool,bool)=sqlx::query_as("SELECT last_error,lease_token IS NULL,next_attempt>clock_timestamp() FROM orders WHERE id=$1").bind(id).fetch_one(&pool).await.unwrap();
    assert_eq!(error, "payment-result-unknown");
    assert!(cleared && delay);
}
#[sqlx::test(migrations = "./migrations/orders")]
async fn terminal_orders_are_never_automatically_claimed(pool: PgPool) {
    for terminal in ["completed", "cancelled", "manual"] {
        let row = create(&pool).await;
        sqlx::query("UPDATE orders SET state=$2 WHERE id=$1")
            .bind(row.id)
            .bind(terminal)
            .execute(&pool)
            .await
            .unwrap();
    }
    assert!(orders::claim(&pool).await.unwrap().is_none());
}
#[sqlx::test(migrations = "./migrations/orders")]
async fn attempt_counter_saturates_instead_of_overflowing(pool: PgPool) {
    let id = create(&pool).await.id;
    sqlx::query("UPDATE orders SET attempts=1000000 WHERE id=$1")
        .bind(id)
        .execute(&pool)
        .await
        .unwrap();
    let (row, key) = orders::claim(&pool).await.unwrap().unwrap();
    assert_eq!(row.attempts, 1000000);
    assert!(orders::defer(&pool, &row, key, "unknown").await.unwrap());
    let bounded: bool = sqlx::query_scalar(
        "SELECT next_attempt<=clock_timestamp()+interval '37 seconds' FROM orders WHERE id=$1",
    )
    .bind(id)
    .fetch_one(&pool)
    .await
    .unwrap();
    assert!(bounded);
}
