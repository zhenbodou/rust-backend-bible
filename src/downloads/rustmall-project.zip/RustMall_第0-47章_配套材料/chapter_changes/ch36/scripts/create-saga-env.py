"""Create an isolated chapter-36 dataset profile, without replacing earlier env files."""
from pathlib import Path
import os
import secrets

root = Path('.saga.local')
root.mkdir(mode=0o700)  # Fails before writing if an existing profile is present.
pg, redis, jwt, catalog, inventory, payment = [secrets.token_urlsafe(48) for _ in range(6)]
def db(name): return f'postgres://rustmall:{pg}@127.0.0.1:55439/rustmall_saga_{name}'
users, payments = 'http://127.0.0.1:18082', 'http://127.0.0.1:18083'
endpoint = 'http://127.0.0.1:15051'
profiles = {
 'infra': {'SAGA36_PG_PASSWORD': pg, 'SAGA36_REDIS_PASSWORD': redis},
 'catalog': {'DATABASE_URL': db('catalog'), 'RUSTMALL_CATALOG_TOKEN': catalog, 'RUSTMALL_INVENTORY_TOKEN': inventory, 'CATALOG_ADDR': '127.0.0.1:15051', 'RUSTMALL_CATALOG_ENDPOINT': endpoint},
 'users': {'DATABASE_URL': db('users'), 'REDIS_URL': f'redis://:{redis}@127.0.0.1:56381/0', 'JWT_SECRET': jwt, 'HTTP_ADDR': '127.0.0.1:18082'},
 'payments': {'DATABASE_URL': db('payments'), 'PAYMENT_TOKEN': payment, 'HTTP_ADDR': '127.0.0.1:18083', 'PAYMENTS_BASE_URL': payments},
 'orders': {'DATABASE_URL': db('orders'), 'USERS_BASE_URL': users, 'RUSTMALL_CATALOG_ENDPOINT': endpoint, 'RUSTMALL_CATALOG_TOKEN': catalog, 'HTTP_ADDR': '127.0.0.1:18084'},
 'worker': {'DATABASE_URL': db('orders'), 'RUSTMALL_CATALOG_ENDPOINT': endpoint, 'RUSTMALL_INVENTORY_TOKEN': inventory, 'PAYMENT_TOKEN': payment, 'PAYMENTS_BASE_URL': payments},
 'catalog-http': {'USERS_BASE_URL': users, 'RUSTMALL_CATALOG_ENDPOINT': endpoint, 'RUSTMALL_CATALOG_TOKEN': catalog, 'HTTP_ADDR': '127.0.0.1:18085'},
 'edge': {'USERS_BASE_URL': users, 'ORDERS_BASE_URL': 'http://127.0.0.1:18084', 'CATALOG_HTTP_BASE_URL': 'http://127.0.0.1:18085', 'EDGE_ALLOWED_ORIGIN': 'http://localhost:3000', 'HTTP_ADDR': '127.0.0.1:18086'},
}
for name, values in profiles.items():
    fd = os.open(root / (name + '.env'), os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, 'w') as out:
        for key, value in values.items(): out.write(f'{key}={value}\n')
print('Created private .saga.local profile; no secret values printed. Keep it with its database volume.')
