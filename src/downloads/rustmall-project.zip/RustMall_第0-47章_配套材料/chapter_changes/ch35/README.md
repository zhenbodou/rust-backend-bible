# RustMall 第0—35章累积工程

固定Rust1.92.0。当前组件：common、platform、contracts、monolith（过渡HTTP/用户认证）、catalog（独立商品gRPC与数据库）、gateway（HTTP边界）、messaging（Outbox/Inbox/Kafka投影）、inventory（商品库内预留事务与可信CLI）、commerce（独立users与实验payments）。

请按合订教材第26—35章顺序运行。scripts/create-catalog-env.py、create-facade-env.py、create-projection-env.py分别创建商品、身份、投影数据库的本地配置，均拒绝覆盖且不打印秘密。不要交换迁移入口，不要把新服务迁移应用到旧库。

## 运行顺序

1. 准备Rust1.92.0、Docker/Compose、C/C++工具链与CMake。核对本机端口55433/55434/55435和50051/8080/8081/9092。
2. 第26章创建商品数据库并运行catalog-migrate，加载商品配置后启动catalog。
3. 第27章创建独立身份数据库、执行rustmall-migrate。接口层终端先加载catalog配置再加载facade配置，启用RUSTMALL_CATALOG_ENDPOINT，最后启动monolith。网关使用GATEWAY_UPSTREAM指向接口层，再启动gateway。
4. 第28章启动deploy/messaging/compose.yaml内单节点Kafka，显式创建各实验主题。text-lab、demo与snapshots主题不能混用格式。
5. 第29章初始化独立投影库，运行projection-migrate；outbox-relay用CATALOG_DATABASE_URL，projection-worker用PROJECTION_DATABASE_URL，业务主题rustmall.catalog.snapshots.v1。
6. 第30章执行catalog第三次迁移。可信inventory-command直接访问商品库，只供本地实验/受控管理，本章保留该本地工具。

7. 第31章运行scripts/create-inventory-env.py生成独立库存凭据。catalog终端另加载.env.inventory.local；商品与库存令牌必须不同。可信调用方只加载库存令牌和RUSTMALL_CATALOG_ENDPOINT，用inventory-rpc跨网络操作，不授予它DATABASE_URL。第31章详细命令和独立小实验见书稿。

8. 第32章执行catalog-migrate新增第四次商品迁移。inventory-adjust apply/query UUID PRODUCT_ID DELTA ACTOR_ID REASON --local-admin只供持有商品库写凭据的受控管理终端；actor参数不是认证证明。重复同一操作保留UUID及全部输入。补货/盘亏不会绕开预留与释放空间约束。

Remote模式公共POST /api/v1/products要求一个UUID Idempotency-Key。最终用户权限仍由JWT/AdminUser验证，内部服务令牌不替代用户身份。商品PUT不能直接改库存：请求stock须等于锁定后的当前值，违反返回409；通过库存预留/释放改变可售量。初始创建库存可指定，补货/盘亏使用第32章专门调整命令。

## 检查

专用测试PostgreSQL的DATABASE_URL账号需能创建测试数据库，绝不能指向生产。

```bash
cargo +1.92.0 fmt --all --check
cargo +1.92.0 clippy --locked --workspace --all-targets --all-features -- -D warnings
cargo +1.92.0 test --locked --workspace --all-features -- --test-threads=2
cargo +1.92.0 test --locked -p monolith --test pg_container -- --ignored --test-threads=1
cargo +1.92.0 test --locked -p monolith --test product_cache -- --ignored --test-threads=1
```

不同章节同名包应使用独立CARGO_TARGET_DIR，避免检查时混入另一检查点的旧产物。需要自定义CMake路径时设置CMAKE指向实际可执行文件，不复制作者机器的绝对路径。

现有Dockerfile/compose/Helm是前面单体交付练习，并非全部微服务的最终部署。完整微服务镜像、TLS、集群与高可用交付将继续在后续章节实现；当前验证范围见随包的verification记录。不要将原生进程测试等同于Linux镜像或远端CI已运行。

第33章工程检查：python3 scripts/check-checkpoint.py 检查角色/二进制/迁移结构；加 --role catalog 等参数检查当前进程环境（仅本地回环HTTP实验）。cargo test --locked -p contracts --test compatibility 检查已审阅v1描述符账本。检查不等于实际账号权限、生产TLS或部署证明。详见docs/checkpoint-33.md。


第34章新增独立users实验，保留现有gateway/facade作为过渡路径，尚未把公网认证切到users。运行python3 scripts/create-users-env.py一次，再用docker compose -p rustmall-users34 --env-file .env.users.local -f deploy/users/compose.yaml up -d --wait启动独立PG/Redis。服务终端加载.env.users.local，运行python3 scripts/check-checkpoint.py --role users，再运行cargo run --locked -p commerce --bin rustmall-service -- migrate-users和同命令users。用户服务默认8082，避开已有8081网关。

python3 scripts/check-users-http.py运行本章HTTP练习；角色/端口/会话及故障说明见第34章正文。用户测试额外需要REDIS_URL指向隔离Redis，CI已增加该服务。用户库与旧接口层身份库不是自动同步的同一套账号；切流前需制定身份/ID/会话迁移，不能用相同i64编号跨两个签发者猜身份。完整后续工程继续34之后增量演进。


第35章新增独立实验payments，不连接真实渠道。python3 scripts/create-payments-env.py生成一次配置；docker compose -p rustmall-payments35 --env-file .env.payments.local -f deploy/payments/compose.yaml up -d --wait启动PG55437。专用服务终端加载该文件，运行check-checkpoint.py --role payments，随后cargo run --locked -p commerce --bin rustmall-service -- migrate-payments，再以payments模式启动（默认8083）。它无需Redis或JWT_SECRET。

可信payment-command客户端只接收PAYMENTS_BASE_URL和PAYMENT_TOKEN，不授予DATABASE_URL。命令参数charge/refund/query UUID ACTOR_ID AMOUNT_CENTS。三种业务状态paid/declined/refunded，固定阈值500000分；payment_effects区分paid后refunded与refund_barrier，不是复式账户账本。超时可能已经提交，保持原身份与绑定恢复。UserRemote和用户会话、第33章契约及旧库存写入口保护继续保留。公开订单协调与统一网关将于后续继续实现。
