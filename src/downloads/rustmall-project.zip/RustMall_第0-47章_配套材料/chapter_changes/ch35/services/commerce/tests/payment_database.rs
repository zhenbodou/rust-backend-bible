use axum::{
    body::Body,
    http::{Request, StatusCode},
    middleware::{self, Next},
};
use commerce::{
    payments::{self, Action, Charge, PaymentRemote, Payments, RemoteError, State},
    runtime::bounded,
};
use http_body_util::BodyExt;
use inventory::rpc::ServiceKey;
use serde_json::Value;
use sqlx::PgPool;
use std::sync::{
    Arc,
    atomic::{AtomicBool, Ordering},
};
use tokio::sync::Notify;
use tokio_util::sync::CancellationToken;
use tower::ServiceExt;
use uuid::Uuid;
const KEY: &str = "payment-test-key-not-used-by-real-service-0001";
fn command(amount: i64) -> Charge {
    Charge {
        saga_id: Uuid::new_v4(),
        actor_id: 7,
        amount,
    }
}
async fn effects(pool: &PgPool, id: Uuid) -> Vec<String> {
    sqlx::query_scalar("SELECT kind FROM payment_effects WHERE saga_id=$1 ORDER BY kind")
        .bind(id)
        .fetch_all(pool)
        .await
        .unwrap()
}
fn app(pool: &PgPool) -> axum::Router {
    bounded(payments::router(Payments {
        pool: pool.clone(),
        key: ServiceKey::parse(KEY).unwrap(),
    }))
}

#[sqlx::test(migrations = "./migrations/payments")]
async fn paid_replay_and_query_have_one_effect(pool: PgPool) {
    let c = command(19900);
    let first = payments::apply(&pool, &c, Action::Charge).await.unwrap();
    assert_eq!(first.state, State::Paid);
    assert_eq!(
        payments::apply(&pool, &c, Action::Charge).await.unwrap(),
        first
    );
    assert_eq!(payments::find(&pool, c.saga_id).await.unwrap(), Some(first));
    assert_eq!(effects(&pool, c.saga_id).await, ["paid"]);
}
#[sqlx::test(migrations = "./migrations/payments")]
async fn declined_is_stable_even_after_refund(pool: PgPool) {
    let c = command(500001);
    for action in [
        Action::Charge,
        Action::Charge,
        Action::Refund,
        Action::Charge,
    ] {
        assert_eq!(
            payments::apply(&pool, &c, action).await.unwrap().state,
            State::Declined
        );
    }
    assert_eq!(effects(&pool, c.saga_id).await, ["declined"]);
}
#[sqlx::test(migrations = "./migrations/payments")]
async fn refund_first_is_a_durable_barrier(pool: PgPool) {
    let c = command(100);
    for action in [
        Action::Refund,
        Action::Charge,
        Action::Refund,
        Action::Charge,
    ] {
        assert_eq!(
            payments::apply(&pool, &c, action).await.unwrap().state,
            State::Refunded
        );
    }
    assert_eq!(effects(&pool, c.saga_id).await, ["refund_barrier"]);
}
#[sqlx::test(migrations = "./migrations/payments")]
async fn paid_then_refunded_retains_both_facts(pool: PgPool) {
    let c = command(100);
    payments::apply(&pool, &c, Action::Charge).await.unwrap();
    for action in [Action::Refund, Action::Refund, Action::Charge] {
        assert_eq!(
            payments::apply(&pool, &c, action).await.unwrap().state,
            State::Refunded
        );
    }
    assert_eq!(effects(&pool, c.saga_id).await, ["paid", "refunded"]);
}
#[sqlx::test(migrations = "./migrations/payments")]
async fn identity_changes_do_not_modify_any_effect(pool: PgPool) {
    let c = command(100);
    payments::apply(&pool, &c, Action::Charge).await.unwrap();
    for changed in [
        Charge {
            actor_id: 8,
            ..c.clone()
        },
        Charge {
            amount: 101,
            ..c.clone()
        },
    ] {
        for action in [Action::Charge, Action::Refund] {
            assert_eq!(
                payments::apply(&pool, &changed, action)
                    .await
                    .unwrap_err()
                    .0,
                StatusCode::CONFLICT
            );
        }
    }
    assert_eq!(
        payments::find(&pool, c.saga_id)
            .await
            .unwrap()
            .unwrap()
            .state,
        State::Paid
    );
    assert_eq!(effects(&pool, c.saga_id).await, ["paid"]);
}
#[sqlx::test(migrations = "./migrations/payments")]
async fn concurrent_duplicate_charge_has_one_effect(pool: PgPool) {
    let c = command(100);
    let (a, b) = tokio::join!(
        payments::apply(&pool, &c, Action::Charge),
        payments::apply(&pool, &c, Action::Charge)
    );
    assert_eq!(a.unwrap(), b.unwrap());
    assert_eq!(effects(&pool, c.saga_id).await, ["paid"]);
}
#[sqlx::test(migrations = "./migrations/payments")]
async fn concurrent_charge_refund_can_never_reopen_payment(pool: PgPool) {
    let c = command(100);
    let (a, b) = tokio::join!(
        payments::apply(&pool, &c, Action::Charge),
        payments::apply(&pool, &c, Action::Refund)
    );
    assert!(matches!(a.unwrap().state, State::Paid | State::Refunded));
    assert_eq!(b.unwrap().state, State::Refunded);
    assert_eq!(
        payments::apply(&pool, &c, Action::Charge)
            .await
            .unwrap()
            .state,
        State::Refunded
    );
    let rows = effects(&pool, c.saga_id).await;
    assert!(rows == ["refund_barrier"] || rows == ["paid", "refunded"]);
}
#[sqlx::test(migrations = "./migrations/payments")]
async fn concurrent_refunds_append_once(pool: PgPool) {
    let c = command(100);
    payments::apply(&pool, &c, Action::Charge).await.unwrap();
    let (a, b) = tokio::join!(
        payments::apply(&pool, &c, Action::Refund),
        payments::apply(&pool, &c, Action::Refund)
    );
    assert_eq!(a.unwrap(), b.unwrap());
    assert_eq!(effects(&pool, c.saga_id).await, ["paid", "refunded"]);
}
#[sqlx::test(migrations = "./migrations/payments")]
async fn initial_audit_failure_rolls_back_receipt(pool: PgPool) {
    sqlx::query("ALTER TABLE payment_effects ADD CONSTRAINT injected CHECK(false) NOT VALID")
        .execute(&pool)
        .await
        .unwrap();
    let c = command(100);
    assert!(payments::apply(&pool, &c, Action::Charge).await.is_err());
    assert!(payments::find(&pool, c.saga_id).await.unwrap().is_none());
    assert!(effects(&pool, c.saga_id).await.is_empty());
}
#[sqlx::test(migrations = "./migrations/payments")]
async fn refund_audit_failure_preserves_paid_and_retry_can_finish(pool: PgPool) {
    let c = command(100);
    payments::apply(&pool, &c, Action::Charge).await.unwrap();
    sqlx::query(
        "ALTER TABLE payment_effects ADD CONSTRAINT injected CHECK(kind<>'refunded') NOT VALID",
    )
    .execute(&pool)
    .await
    .unwrap();
    assert!(payments::apply(&pool, &c, Action::Refund).await.is_err());
    assert_eq!(
        payments::find(&pool, c.saga_id)
            .await
            .unwrap()
            .unwrap()
            .state,
        State::Paid
    );
    assert_eq!(effects(&pool, c.saga_id).await, ["paid"]);
    sqlx::query("ALTER TABLE payment_effects DROP CONSTRAINT injected")
        .execute(&pool)
        .await
        .unwrap();
    assert_eq!(
        payments::apply(&pool, &c, Action::Refund)
            .await
            .unwrap()
            .state,
        State::Refunded
    );
    assert_eq!(effects(&pool, c.saga_id).await, ["paid", "refunded"]);
}
#[sqlx::test(migrations = "./migrations/payments")]
async fn invalid_inputs_and_missing_query_have_no_effect(pool: PgPool) {
    let c = command(100);
    for bad in [
        Charge {
            saga_id: Uuid::nil(),
            ..c.clone()
        },
        Charge {
            actor_id: 0,
            ..c.clone()
        },
        Charge {
            amount: 0,
            ..c.clone()
        },
        Charge {
            amount: 100000001,
            ..c.clone()
        },
    ] {
        assert_eq!(
            payments::apply(&pool, &bad, Action::Charge)
                .await
                .unwrap_err()
                .0,
            StatusCode::BAD_REQUEST
        );
    }
    assert!(payments::find(&pool, c.saga_id).await.unwrap().is_none());
    let count: i64 = sqlx::query_scalar("SELECT count(*) FROM payments")
        .fetch_one(&pool)
        .await
        .unwrap();
    assert_eq!(count, 0);
}
#[sqlx::test(migrations = "./migrations/payments")]
async fn lock_timeout_has_no_refund_effect(pool: PgPool) {
    let c = command(100);
    payments::apply(&pool, &c, Action::Charge).await.unwrap();
    let mut blocker = pool.begin().await.unwrap();
    sqlx::query("SELECT saga_id FROM payments WHERE saga_id=$1 FOR UPDATE")
        .bind(c.saga_id)
        .execute(&mut *blocker)
        .await
        .unwrap();
    let start = std::time::Instant::now();
    let error = payments::apply(&pool, &c, Action::Refund)
        .await
        .unwrap_err();
    blocker.rollback().await.unwrap();
    assert_eq!(error.0, StatusCode::SERVICE_UNAVAILABLE);
    assert!(start.elapsed() < std::time::Duration::from_secs(2));
    assert_eq!(
        payments::find(&pool, c.saga_id)
            .await
            .unwrap()
            .unwrap()
            .state,
        State::Paid
    );
    assert_eq!(effects(&pool, c.saga_id).await, ["paid"]);
}
#[sqlx::test(migrations = "./migrations/payments")]
async fn auth_runs_before_body_decoding_and_rejects_duplicate_bearer(pool: PgPool) {
    for keys in [vec![], vec!["wrong"], vec![KEY, KEY]] {
        let mut request = Request::builder()
            .method("POST")
            .uri("/internal/payments")
            .header("content-type", "application/json")
            .body(Body::from("{"))
            .unwrap();
        for key in keys {
            request
                .headers_mut()
                .append("authorization", format!("Bearer {key}").parse().unwrap());
        }
        let response = app(&pool).oneshot(request).await.unwrap();
        assert_eq!(response.status(), StatusCode::UNAUTHORIZED);
    }
    let count: i64 = sqlx::query_scalar("SELECT count(*) FROM payments")
        .fetch_one(&pool)
        .await
        .unwrap();
    assert_eq!(count, 0);
}
#[sqlx::test(migrations = "./migrations/payments")]
async fn http_json_status_and_query_contract(pool: PgPool) {
    let c = command(500001);
    let app = app(&pool);
    for (method, path, body, expected) in [
        (
            "POST",
            "/internal/payments".into(),
            serde_json::to_string(&c).unwrap(),
            200,
        ),
        (
            "GET",
            format!("/internal/payments/{}", c.saga_id),
            "".into(),
            200,
        ),
        (
            "GET",
            "/internal/payments/not-a-uuid".into(),
            "".into(),
            400,
        ),
        (
            "GET",
            format!("/internal/payments/{}", Uuid::new_v4()),
            "".into(),
            404,
        ),
    ] {
        let req = Request::builder()
            .method(method)
            .uri(path)
            .header("content-type", "application/json")
            .header("authorization", format!("Bearer {KEY}"))
            .body(Body::from(body))
            .unwrap();
        let r = app.clone().oneshot(req).await.unwrap();
        assert_eq!(r.status().as_u16(), expected);
        assert_eq!(r.headers()["cache-control"], "no-store");
        let bytes = r.into_body().collect().await.unwrap().to_bytes();
        let reply: Value = serde_json::from_slice(&bytes).unwrap();
        if expected == 200 {
            assert_eq!(reply["state"], "declined");
        } else {
            assert!(reply["code"].is_string());
        }
    }
}
#[sqlx::test(migrations = "./migrations/payments")]
async fn committed_but_withheld_response_recovers_without_second_effect(pool: PgPool) {
    let first = Arc::new(AtomicBool::new(true));
    let committed = Arc::new(Notify::new());
    let release = Arc::new(Notify::new());
    let (f, n, r) = (first.clone(), committed.clone(), release.clone());
    let app = app(&pool).layer(middleware::from_fn(
        move |req: axum::extract::Request, next: Next| {
            let (f, n, r) = (f.clone(), n.clone(), r.clone());
            async move {
                let hold =
                    req.uri().path() == "/internal/payments" && f.swap(false, Ordering::SeqCst);
                let response = next.run(req).await;
                if hold {
                    n.notify_one();
                    r.notified().await;
                }
                response
            }
        },
    ));
    let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
    let base = format!("http://{}", listener.local_addr().unwrap());
    let stop = CancellationToken::new();
    let shutdown = stop.clone();
    let mut server = tokio::spawn(async move {
        axum::serve(listener, app)
            .with_graceful_shutdown(shutdown.cancelled_owned())
            .await
            .unwrap();
    });
    let remote = PaymentRemote::new(&base, KEY.into()).unwrap();
    let c = command(100);
    let (r, c2) = (remote.clone(), c.clone());
    let task = tokio::spawn(async move { r.apply(&c2, Action::Charge).await });
    tokio::time::timeout(std::time::Duration::from_secs(1), committed.notified())
        .await
        .unwrap();
    assert_eq!(
        payments::find(&pool, c.saga_id)
            .await
            .unwrap()
            .unwrap()
            .state,
        State::Paid
    );
    assert_eq!(
        tokio::time::timeout(std::time::Duration::from_secs(3), task)
            .await
            .unwrap()
            .unwrap()
            .unwrap_err(),
        RemoteError::Deadline
    );
    release.notify_one();
    assert_eq!(remote.query(&c).await.unwrap().unwrap().state, State::Paid);
    assert_eq!(
        remote.apply(&c, Action::Charge).await.unwrap().state,
        State::Paid
    );
    assert_eq!(effects(&pool, c.saga_id).await, ["paid"]);
    stop.cancel();
    match tokio::time::timeout(std::time::Duration::from_secs(3), &mut server).await {
        Ok(result) => result.unwrap(),
        Err(_) => {
            server.abort();
            let _ = server.await;
            panic!("test server shutdown exceeded budget");
        }
    }
}
