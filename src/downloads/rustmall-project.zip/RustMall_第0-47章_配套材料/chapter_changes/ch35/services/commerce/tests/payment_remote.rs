use axum::{Router, body::Body, http::StatusCode, routing::get, routing::post};
use commerce::payments::{Action, Charge, PaymentRemote, RemoteError};
use tokio_util::sync::CancellationToken;
use uuid::Uuid;
const KEY: &str = "payment-test-key-not-used-by-real-service-0001";
fn command() -> Charge {
    Charge {
        saga_id: Uuid::new_v4(),
        actor_id: 7,
        amount: 100,
    }
}
async fn server(app: Router) -> (String, CancellationToken, tokio::task::JoinHandle<()>) {
    let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
    let base = format!("http://{}", listener.local_addr().unwrap());
    let stop = CancellationToken::new();
    let shutdown = stop.clone();
    let task = tokio::spawn(async move {
        axum::serve(listener, app)
            .with_graceful_shutdown(shutdown.cancelled_owned())
            .await
            .unwrap();
    });
    (base, stop, task)
}
async fn close(stop: CancellationToken, mut task: tokio::task::JoinHandle<()>) {
    stop.cancel();
    match tokio::time::timeout(std::time::Duration::from_secs(3), &mut task).await {
        Ok(result) => result.unwrap(),
        Err(_) => {
            task.abort();
            let _ = task.await;
            panic!("test server shutdown exceeded budget");
        }
    }
}
#[tokio::test]
async fn successful_rpc_still_checks_identity_state_and_size() {
    let c = command();
    let valid = serde_json::json!({"saga_id":c.saga_id,"actor_id":c.actor_id,"amount":c.amount,"state":"paid"});
    for field in ["saga_id", "actor_id", "amount", "state", "oversized"] {
        let mut changed = valid.clone();
        match field {
            "saga_id" => changed[field] = serde_json::json!(Uuid::new_v4()),
            "actor_id" => changed[field] = serde_json::json!(8),
            "amount" => changed[field] = serde_json::json!(101),
            "state" => changed[field] = serde_json::json!("future_state"),
            _ => {}
        }
        let text = if field == "oversized" {
            "x".repeat(4097)
        } else {
            changed.to_string()
        };
        let (base, stop, task) = server(Router::new().route(
            "/internal/payments",
            post(move || {
                let text = text.clone();
                async move { text }
            }),
        ))
        .await;
        assert_eq!(
            PaymentRemote::new(&base, KEY.into())
                .unwrap()
                .apply(&c, Action::Charge)
                .await
                .unwrap_err(),
            RemoteError::Protocol
        );
        close(stop, task).await;
    }
}
#[tokio::test]
async fn typed_status_does_not_turn_a_failure_into_declined() {
    for (code, expected) in [
        (401, RemoteError::Unauthenticated),
        (409, RemoteError::IdentityConflict),
        (503, RemoteError::Unavailable),
        (504, RemoteError::Deadline),
    ] {
        let (base, stop, task) = server(Router::new().route(
            "/internal/payments",
            post(move || async move { StatusCode::from_u16(code).unwrap() }),
        ))
        .await;
        assert_eq!(
            PaymentRemote::new(&base, KEY.into())
                .unwrap()
                .apply(&command(), Action::Charge)
                .await
                .unwrap_err(),
            expected
        );
        close(stop, task).await;
    }
}
#[tokio::test]
async fn absent_query_is_none_but_absent_command_is_protocol_error() {
    let app = Router::new()
        .route(
            "/internal/payments",
            post(|| async { StatusCode::NOT_FOUND }),
        )
        .route(
            "/internal/payments/{id}",
            get(|| async { StatusCode::NOT_FOUND }),
        );
    let (base, stop, task) = server(app).await;
    let remote = PaymentRemote::new(&base, KEY.into()).unwrap();
    let c = command();
    assert_eq!(remote.query(&c).await.unwrap(), None);
    assert_eq!(
        remote.apply(&c, Action::Charge).await.unwrap_err(),
        RemoteError::Protocol
    );
    close(stop, task).await;
}
#[tokio::test]
async fn redirect_is_not_followed_with_service_credentials() {
    let (base, stop, task) = server(Router::new().route(
        "/internal/payments",
        post(|| async { axum::response::Redirect::temporary("http://127.0.0.1:1/steal") }),
    ))
    .await;
    assert_eq!(
        PaymentRemote::new(&base, KEY.into())
            .unwrap()
            .apply(&command(), Action::Charge)
            .await
            .unwrap_err(),
        RemoteError::Protocol
    );
    close(stop, task).await;
}
#[tokio::test]
async fn stalled_body_has_a_total_deadline() {
    let (base, stop, task) = server(Router::new().route(
        "/internal/payments",
        post(|| async {
            axum::http::Response::new(Body::from_stream(futures_util::stream::pending::<
                Result<axum::body::Bytes, std::io::Error>,
            >()))
        }),
    ))
    .await;
    let start = std::time::Instant::now();
    assert_eq!(
        PaymentRemote::new(&base, KEY.into())
            .unwrap()
            .apply(&command(), Action::Charge)
            .await
            .unwrap_err(),
        RemoteError::Deadline
    );
    assert!(start.elapsed() < std::time::Duration::from_secs(3));
    close(stop, task).await;
}
#[tokio::test]
async fn constructor_and_local_input_reject_unsafe_configuration() {
    for base in [
        "file:///tmp/payments",
        "http://name:secret@localhost:8083",
        "http://localhost:8083/path",
    ] {
        assert!(PaymentRemote::new(base, KEY.into()).is_err());
    }
    assert!(PaymentRemote::new("http://localhost:8083", "short".into()).is_err());
    let c = Charge {
        amount: 0,
        ..command()
    };
    assert_eq!(
        PaymentRemote::new("http://127.0.0.1:1", KEY.into())
            .unwrap()
            .apply(&c, Action::Charge)
            .await
            .unwrap_err(),
        RemoteError::InvalidInput
    );
}
