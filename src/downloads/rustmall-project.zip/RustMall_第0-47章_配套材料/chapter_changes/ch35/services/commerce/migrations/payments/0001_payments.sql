CREATE TABLE payments (
    saga_id UUID PRIMARY KEY CHECK(saga_id <> '00000000-0000-0000-0000-000000000000'),
    actor_id BIGINT NOT NULL CHECK(actor_id > 0),
    amount BIGINT NOT NULL CHECK(amount BETWEEN 1 AND 100000000),
    state TEXT NOT NULL CHECK(state IN ('paid','declined','refunded')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
-- Teaching audit entries, not a bank's double-entry ledger.
CREATE TABLE payment_effects (
    effect_id UUID PRIMARY KEY,
    saga_id UUID NOT NULL REFERENCES payments(saga_id),
    kind TEXT NOT NULL CHECK(kind IN ('paid','declined','refund_barrier','refunded')),
    amount BIGINT NOT NULL CHECK(amount BETWEEN 1 AND 100000000),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE(saga_id,kind)
);
