# 第35章支付模拟器

本章是确定性模拟，不转移真实资金。金额整数分1—100000000，首次Charge在500000分以内Paid，以上Declined。状态Refunded关闭原意图：已付后退款保留paid/refunded，退款先到只有refund_barrier。当前表不是账户复式账本。

生成.env.payments.local一次，启动deploy/payments/compose.yaml（项目rustmall-payments35，PG55437）。专用服务终端加载该配置，check-checkpoint.py --role payments，rustmall-service migrate-payments，再payments（HTTP8083）。运行角色无需Redis或JWT_SECRET。原users8082/migrate-users继续保留。

可信payment-command只需要PAYMENTS_BASE_URL和PAYMENT_TOKEN，不授予DATABASE_URL。charge/refund/query UUID ACTOR_ID AMOUNT_CENTS。所有重试保留三项身份绑定；同UUID改actor/amount409。查询None不证明以后没有迟到提交，关闭用同身份Refund。

PaymentRemote::new(origin,key)私有client/base/key，2秒总预算、4KiB回复、禁重定向；apply接受Action枚举，query接受完整Charge核对回复。Payment.state是State枚举，未知值Protocol错误；RemoteError区分Unauthenticated/IdentityConflict/Deadline/Unavailable/InvalidInput/Protocol，不把传输错误当Declined。

11项集成记录覆盖workspace及实际原生服务/CLI/OS进程重启/PG故障；15DB中提交后阻止回复的真实HTTP用例验证同身份恢复。银行、公开网关切流、Linux应用镜像、远端CI和实际集群未执行。0—30已交付稿不变，后续订单协调继续从本检查点增量构建。
