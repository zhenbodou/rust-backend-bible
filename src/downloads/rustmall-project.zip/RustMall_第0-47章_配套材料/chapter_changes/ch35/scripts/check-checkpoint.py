"""Check chapter structure and optional local role configuration; never print values.

Python 3.11+ and Cargo are required. This is not a deployment or privilege audit.
"""
import argparse
import ipaddress
import json
import os
from pathlib import Path
import subprocess
import sys
from urllib.parse import urlsplit

ROOT = Path(__file__).resolve().parents[1]


def local_http(value):
    try:
        url = urlsplit(value)
        if url.scheme != "http" or not url.hostname or url.username or url.password:
            return False
        if url.path not in ("", "/") or url.query or url.fragment:
            return False
        if url.port is None or not 1 <= url.port <= 65535:
            return False
        if url.hostname == "localhost":
            return True
        return ipaddress.ip_address(url.hostname).is_loopback
    except ValueError:
        return False


def postgres(value):
    try:
        url = urlsplit(value)
        return (url.scheme in ("postgres", "postgresql") and bool(url.hostname)
                and bool(url.path.strip("/")) and bool(url.username)
                and (url.port is None or 1 <= url.port <= 65535))
    except ValueError:
        return False


def check_environment(role, spec, environment):
    errors = [f"missing {name}" for name in spec["required"] if not environment.get(name)]
    for name in spec["postgres"]:
        if environment.get(name) and not postgres(environment[name]):
            errors.append(f"invalid PostgreSQL URL in {name}")
    for name in spec["http"]:
        if environment.get(name) and not local_http(environment[name]):
            errors.append(f"{name} must be an explicit loopback HTTP endpoint with port")
    for name in ("RUSTMALL_CATALOG_TOKEN", "RUSTMALL_INVENTORY_TOKEN", "PAYMENT_TOKEN"):
        if name not in spec["required"] or not environment.get(name):
            continue
        value = environment[name]
        if not 32 <= len(value) <= 256 or not all(33 <= ord(c) <= 126 for c in value):
            errors.append(f"invalid service credential format in {name}")
        elif name in ("RUSTMALL_INVENTORY_TOKEN", "PAYMENT_TOKEN") and not all(
                c.isascii() and (c.isalnum() or c in "-_") for c in value):
            errors.append(f"invalid service credential alphabet in {name}")
    for name in spec.get("redis", []):
        try:
            url = urlsplit(environment.get(name, ""))
            host = f"[{url.hostname}]" if url.hostname and ":" in url.hostname else url.hostname
            port = url.port if url.port is not None else 6379
            valid = url.scheme == "redis" and url.hostname and local_http(f"http://{host}:{port}") and url.path in ("", "/0") and not url.query and not url.fragment
        except ValueError:
            valid = False
        if not valid:
            errors.append(f"{name} must be a local Redis database 0 URL")
    for name in spec.get("listen", []):
        if not local_http("http://" + environment.get(name, "")):
            errors.append(f"{name} must be a loopback listen address with port")
    if role == "users" and len(environment.get("JWT_SECRET", "").encode()) < 32:
        errors.append("JWT_SECRET must contain at least 32 bytes")
    if role == "catalog" and environment.get("RUSTMALL_CATALOG_TOKEN") == environment.get("RUSTMALL_INVENTORY_TOKEN"):
        errors.append("catalog and inventory credentials must differ")
    if role in ("payments", "payment-client") and environment.get("PAYMENT_TOKEN"):
        if any(environment.get(name) == environment["PAYMENT_TOKEN"] for name in ("RUSTMALL_CATALOG_TOKEN", "RUSTMALL_INVENTORY_TOKEN")):
            errors.append("payment credential must differ from other service credentials")
    if role == "facade":
        if environment.get("APP_ENV") != "production":
            errors.append("APP_ENV must be production for this checkpoint")
        if len(environment.get("APP_AUTH__JWT_SECRET", "").encode()) < 32:
            errors.append("APP_AUTH__JWT_SECRET must contain at least 32 bytes")
    if role in ("inventory-client", "payment-client") and environment.get("DATABASE_URL"):
        errors.append(f"{role} should not receive DATABASE_URL")
    return errors


def check_structure(ledger, metadata):
    packages = {p["name"]: p for p in metadata["packages"]}
    errors = []
    for role, spec in ledger["roles"].items():
        for package_name, binary in [(spec["package"], spec["binary"])] + (
            [(spec["migration_package"], spec["migration_binary"])] if "migration_binary" in spec else []
        ):
            package = packages.get(package_name)
            if package is None or not any(t["name"] == binary and "bin" in t["kind"] for t in package["targets"]):
                errors.append(f"{role}: missing binary {package_name}/{binary}")
        if "migration_path" in spec and not list((ROOT / spec["migration_path"]).glob("*.sql")):
            errors.append(f"{role}: no SQL migration files")
    return errors


def main():
    ledger = json.loads((ROOT / "docs/runtime-boundaries.json").read_text())
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--role", choices=sorted(ledger["roles"]))
    args = parser.parse_args()
    result = subprocess.run([os.environ.get("CARGO", "cargo"), "metadata", "--locked",
        "--offline", "--no-deps", "--format-version", "1", "--manifest-path", str(ROOT / "Cargo.toml")],
        text=True, capture_output=True)
    if result.returncode:
        print("FAIL cargo metadata; run cargo metadata separately for compiler diagnostics", file=sys.stderr)
        return 1
    errors = check_structure(ledger, json.loads(result.stdout))
    if args.role:
        errors += check_environment(args.role, ledger["roles"][args.role], os.environ)
    if errors:
        for error in errors:
            print("FAIL " + error, file=sys.stderr)
        return 1
    print(f"PASS chapter {ledger['chapter']} structure" + (f" and local {args.role} configuration" if args.role else ""))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
