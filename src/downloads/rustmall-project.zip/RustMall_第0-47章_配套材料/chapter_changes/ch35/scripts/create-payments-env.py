"""Create local simulated-payment credentials once without printing secrets."""
import os
import secrets
password = secrets.token_urlsafe(36)
values = {
    "POSTGRES_PASSWORD": password,
    "DATABASE_URL": f"postgres://rustmall:{password}@127.0.0.1:55437/rustmall_payments",
    "PAYMENT_TOKEN": secrets.token_urlsafe(48),
    "HTTP_ADDR": "127.0.0.1:8083",
    "PAYMENTS_BASE_URL": "http://127.0.0.1:8083",
}
fd = os.open(".env.payments.local", os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
with os.fdopen(fd, "w") as out:
    for name, value in values.items():
        out.write(f"{name}={value}\n")
print("Created .env.payments.local; credentials were not printed.")
