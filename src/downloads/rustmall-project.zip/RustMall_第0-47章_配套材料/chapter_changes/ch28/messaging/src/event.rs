use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use uuid::Uuid;

pub const MAX_EVENT_BYTES: usize = 64 * 1024;
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
#[serde(deny_unknown_fields)]
pub struct Snapshot {
    pub id: i64,
    pub name: String,
    pub price_cents: i64,
    pub stock: i32,
    pub listed: bool,
}
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
#[serde(deny_unknown_fields)]
pub struct Envelope {
    pub schema_version: u32,
    pub kind: String,
    pub event_id: Uuid,
    pub aggregate_id: i64,
    pub revision: i64,
    pub occurred_at_unix_ms: i64,
    pub payload: Snapshot,
}
impl Envelope {
    pub fn new(payload: Snapshot, revision: i64) -> Self {
        Self {
            schema_version: 1,
            kind: "product.snapshot.v1".into(),
            event_id: Uuid::new_v4(),
            aggregate_id: payload.id,
            revision,
            occurred_at_unix_ms: chrono::Utc::now().timestamp_millis(),
            payload,
        }
    }
    pub fn validate(&self) -> anyhow::Result<()> {
        anyhow::ensure!(
            self.schema_version == 1 && self.kind == "product.snapshot.v1",
            "unsupported event schema"
        );
        anyhow::ensure!(
            !self.event_id.is_nil()
                && self.aggregate_id > 0
                && self.aggregate_id == self.payload.id,
            "invalid event identity"
        );
        anyhow::ensure!(self.revision > 0, "invalid revision");
        anyhow::ensure!(
            (1..=100).contains(&self.payload.name.trim().chars().count()),
            "invalid product name"
        );
        anyhow::ensure!(
            self.payload.price_cents >= 0 && self.payload.stock >= 0,
            "invalid product values"
        );
        Ok(())
    }
    pub fn encode(&self) -> anyhow::Result<Vec<u8>> {
        self.validate()?;
        let bytes = serde_json::to_vec(self)?;
        anyhow::ensure!(bytes.len() <= MAX_EVENT_BYTES, "event too large");
        Ok(bytes)
    }
    pub fn decode(bytes: &[u8]) -> anyhow::Result<Self> {
        anyhow::ensure!(bytes.len() <= MAX_EVENT_BYTES, "event too large");
        let value: Self = serde_json::from_slice(bytes)?;
        value.validate()?;
        Ok(value)
    }
    pub fn digest(&self) -> anyhow::Result<Vec<u8>> {
        Ok(Sha256::digest(self.encode()?).to_vec())
    }
}
pub fn retry_delay_secs(attempts: i32) -> i64 {
    2_i64.pow(attempts.clamp(0, 9) as u32).min(300)
}
#[cfg(test)]
mod tests {
    use super::*;
    fn event() -> Envelope {
        Envelope::new(
            Snapshot {
                id: 1,
                name: "键盘".into(),
                price_cents: 19900,
                stock: 10,
                listed: true,
            },
            1,
        )
    }
    #[test]
    fn stable_retries_keep_the_event_identity() {
        let e = event();
        assert_eq!(Envelope::decode(&e.encode().unwrap()).unwrap(), e);
    }
    #[test]
    fn incompatible_versions_are_rejected() {
        let mut e = event();
        e.schema_version = 2;
        assert!(e.encode().is_err());
    }
    #[test]
    fn wrong_aggregate_identity_is_rejected() {
        let mut e = event();
        e.aggregate_id = 2;
        assert!(e.encode().is_err());
    }
    #[test]
    fn negative_money_is_not_a_valid_snapshot() {
        let mut e = event();
        e.payload.price_cents = -1;
        assert!(e.encode().is_err());
    }
    #[test]
    fn structured_digest_ignores_json_layout() {
        let e = event();
        let pretty = serde_json::to_vec_pretty(&e).unwrap();
        assert_eq!(
            e.digest().unwrap(),
            Envelope::decode(&pretty).unwrap().digest().unwrap()
        );
    }
    #[test]
    fn oversized_payload_is_rejected_before_json_parsing() {
        let error = Envelope::decode(&vec![b' '; MAX_EVENT_BYTES + 1]).unwrap_err();
        assert_eq!(error.to_string(), "event too large");
    }
    #[test]
    fn backoff_is_bounded() {
        assert_eq!(retry_delay_secs(1), 2);
        assert_eq!(retry_delay_secs(i32::MAX), 300);
        assert_eq!(retry_delay_secs(-1), 1);
    }
}
