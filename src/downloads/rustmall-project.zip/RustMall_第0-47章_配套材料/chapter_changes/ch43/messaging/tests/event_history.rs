use messaging::event::Envelope;
const HISTORY: &[u8] = include_bytes!("fixtures/product_snapshot_v1.json");
#[test]
fn historical_v1_snapshot_preserves_unicode_money_and_business_tombstone() {
    let event = Envelope::decode(HISTORY).unwrap();
    assert_eq!(event.aggregate_id, 42);
    assert_eq!(event.revision, 7);
    assert_eq!(event.payload.name, "旧版键盘⌨️");
    assert_eq!(event.payload.price_cents, 19900);
    assert!(!event.payload.listed);
    assert_eq!(Envelope::decode(&event.encode().unwrap()).unwrap(), event);
}
#[test]
fn adding_an_envelope_field_requires_an_explicit_compatibility_change() {
    let mut history: serde_json::Value = serde_json::from_slice(HISTORY).unwrap();
    history["new_optional_field"] = serde_json::json!("future");
    let error = Envelope::decode(&serde_json::to_vec(&history).unwrap()).unwrap_err();
    assert!(error.to_string().contains("unknown field"));
}
#[test]
fn adding_a_nested_snapshot_field_is_also_rejected() {
    let mut history: serde_json::Value = serde_json::from_slice(HISTORY).unwrap();
    history["payload"]["currency"] = serde_json::json!("CNY");
    let error = Envelope::decode(&serde_json::to_vec(&history).unwrap()).unwrap_err();
    assert!(error.to_string().contains("unknown field"));
}
