//! Never turn expired/missing historical offsets into a silent successful rebuild.
//! Zero bootstrap remains valid until a real processed offset is acknowledged.
use anyhow::{Context, ensure};
use rdkafka::{
    ClientConfig, Offset, TopicPartitionList,
    client::ClientContext,
    consumer::{BaseConsumer, Consumer, ConsumerContext, StreamConsumer},
    error::{KafkaError, RDKafkaErrorCode},
    message::BorrowedMessage,
    types::RDKafkaRespErr,
};
use std::{
    collections::HashSet,
    sync::{Arc, Mutex},
    time::{Duration, Instant},
};

#[derive(Default)]
pub struct StrictContext {
    initial_zero: Mutex<HashSet<(String, i32)>>,
    fatal: Mutex<Option<String>>,
}
impl ClientContext for StrictContext {}
impl crate::kafka::CommitProgress for StrictContext {
    fn processed_commit(&self, topic: &str, partition: i32) {
        self.initial_zero
            .lock()
            .unwrap()
            .remove(&(topic.to_owned(), partition));
    }
}

impl ConsumerContext for StrictContext {
    fn rebalance(
        &self,
        consumer: &BaseConsumer<Self>,
        error: RDKafkaRespErr,
        list: &mut TopicPartitionList,
    ) {
        // Explicit eager range assignment: do not reuse this callback for cooperative protocols.
        let result = match error {
            RDKafkaRespErr::RD_KAFKA_RESP_ERR__ASSIGN_PARTITIONS => {
                let zero = self.initial_zero.lock().unwrap();
                let selected: Vec<_> = list
                    .elements()
                    .into_iter()
                    .map(|p| (p.topic().to_owned(), p.partition()))
                    .filter(|key| zero.contains(key))
                    .collect();
                for (topic, partition) in selected {
                    if let Err(error) =
                        list.set_partition_offset(&topic, partition, Offset::Offset(0))
                    {
                        *self.fatal.lock().unwrap() = Some(error.to_string());
                        return;
                    }
                }
                tracing::info!(
                    partitions = list.count(),
                    "durable consumer assigned eager partitions"
                );
                consumer.assign(list)
            }
            RDKafkaRespErr::RD_KAFKA_RESP_ERR__REVOKE_PARTITIONS => {
                tracing::info!(
                    partitions = list.count(),
                    "durable consumer revoked eager partitions"
                );
                consumer.unassign()
            }
            _ => {
                *self.fatal.lock().unwrap() = Some(format!("rebalance failed: {error:?}"));
                consumer.unassign()
            }
        };
        if let Err(error) = result {
            *self.fatal.lock().unwrap() = Some(error.to_string());
        }
    }
}
pub type DurableConsumer = Arc<StreamConsumer<StrictContext>>;

/// Validate one partition without assuming that every visible message has a contiguous offset.
/// Transactions/control records can create visible gaps even when retention has removed nothing.
pub fn validate_start(low: i64, high: i64, committed: Offset) -> anyhow::Result<Option<i64>> {
    ensure!(low >= 0 && high >= low, "invalid Kafka watermark range");
    match committed {
        Offset::Invalid => {
            ensure!(
                low == 0,
                "new group has no baseline and retained history starts after zero"
            );
            Ok(Some(0))
        }
        Offset::Offset(next) => {
            ensure!(
                (low..=high).contains(&next),
                "committed offset is outside retained history; explicit recovery required"
            );
            Ok(None)
        }
        _ => anyhow::bail!("unexpected stored offset kind"),
    }
}
fn remaining(deadline: Instant) -> anyhow::Result<Duration> {
    let left = deadline.saturating_duration_since(Instant::now());
    ensure!(!left.is_zero(), "Kafka startup validation budget exhausted");
    Ok(left.min(Duration::from_secs(1)))
}
/// Retry transport/coordinator transitions, never authorization or semantic gaps.
fn startup_query<T>(
    deadline: Instant,
    mut query: impl FnMut(Duration) -> Result<T, KafkaError>,
) -> anyhow::Result<T> {
    loop {
        match query(remaining(deadline)?) {
            Ok(value) => return Ok(value),
            Err(error)
                if matches!(
                    error.rdkafka_error_code(),
                    Some(
                        RDKafkaErrorCode::NotCoordinator
                            | RDKafkaErrorCode::CoordinatorLoadInProgress
                            | RDKafkaErrorCode::CoordinatorNotAvailable
                            | RDKafkaErrorCode::WaitingForCoordinator
                            | RDKafkaErrorCode::BrokerTransportFailure
                            | RDKafkaErrorCode::AllBrokersDown
                            | RDKafkaErrorCode::OperationTimedOut
                            | RDKafkaErrorCode::TimedOutQueue
                            | RDKafkaErrorCode::RequestTimedOut
                            | RDKafkaErrorCode::LeaderNotAvailable
                            | RDKafkaErrorCode::NotLeaderForPartition
                    )
                ) =>
            {
                let pause = remaining(deadline)?.min(Duration::from_millis(50));
                std::thread::sleep(pause);
            }
            Err(error) => return Err(error.into()),
        }
    }
}
/// Blocking startup preflight: call on spawn_blocking, before subscribing.
pub fn create(brokers: &str, group: &str, topic: &str) -> anyhow::Result<DurableConsumer> {
    ensure!(
        !group.trim().is_empty() && !topic.trim().is_empty(),
        "group/topic required"
    );
    let consumer: StreamConsumer<StrictContext> = ClientConfig::new()
        .set("bootstrap.servers", brokers)
        .set("group.id", group)
        .set("enable.auto.commit", "false")
        .set("enable.auto.offset.store", "false")
        .set("auto.offset.reset", "error")
        .set("allow.auto.create.topics", "false")
        .set("isolation.level", "read_committed")
        .set("partition.assignment.strategy", "range")
        .set("max.poll.interval.ms", "30000")
        .set("session.timeout.ms", "10000")
        .set("socket.timeout.ms", "3000")
        .create_with_context(StrictContext::default())?;
    let deadline = Instant::now() + Duration::from_secs(5);
    let metadata = startup_query(deadline, |limit| {
        consumer.fetch_metadata(Some(topic), limit)
    })?;
    let topic_meta = metadata
        .topics()
        .iter()
        .find(|t| t.name() == topic)
        .context("topic absent")?;
    ensure!(topic_meta.error().is_none(), "topic metadata error");
    ensure!(
        !topic_meta.partitions().is_empty() && topic_meta.partitions().len() <= 64,
        "expected1..64 partitions for bounded startup audit"
    );
    let mut requested = TopicPartitionList::new();
    for partition in topic_meta.partitions() {
        ensure!(partition.error().is_none(), "partition metadata error");
        requested.add_partition(topic, partition.id());
    }
    let offsets = startup_query(deadline, |limit| {
        consumer.committed_offsets(requested.clone(), limit)
    })?;
    for partition in offsets.elements() {
        partition.error()?;
        let (low, high) = startup_query(deadline, |limit| {
            consumer.fetch_watermarks(topic, partition.partition(), limit)
        })?;
        let start = validate_start(low, high, partition.offset()).with_context(|| {
            format!(
                "topic={topic} partition={} low={low} high={high}",
                partition.partition()
            )
        })?;
        if start == Some(0) {
            consumer
                .context()
                .initial_zero
                .lock()
                .unwrap()
                .insert((topic.to_owned(), partition.partition()));
        }
    }
    consumer.subscribe(&[topic])?;
    Ok(Arc::new(consumer))
}
/// Rebalance assignment failures must wake the worker rather than leave it silently idle.
pub async fn recv(consumer: &DurableConsumer) -> anyhow::Result<BorrowedMessage<'_>> {
    loop {
        if let Some(error) = consumer.context().fatal.lock().unwrap().clone() {
            anyhow::bail!("durable consumer stopped: {error}");
        }
        match tokio::time::timeout(Duration::from_secs(1), consumer.recv()).await {
            Ok(result) => return Ok(result?),
            Err(_) => continue,
        }
    }
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn new_group_requires_untruncated_history() {
        assert_eq!(validate_start(0, 20, Offset::Invalid).unwrap(), Some(0));
        assert!(validate_start(1, 20, Offset::Invalid).is_err());
    }
    #[test]
    fn committed_next_offset_must_be_inclusive_watermark_range() {
        for next in [4, 5, 20] {
            assert_eq!(validate_start(4, 20, Offset::Offset(next)).unwrap(), None);
        }
        for next in [-1, 0, 3, 21] {
            assert!(validate_start(4, 20, Offset::Offset(next)).is_err());
        }
    }
    #[test]
    fn empty_retained_log_and_invalid_ranges_are_explicit() {
        assert!(validate_start(9, 9, Offset::Invalid).is_err());
        assert!(validate_start(9, 9, Offset::Offset(9)).is_ok());
        assert!(validate_start(10, 9, Offset::Offset(10)).is_err());
        assert!(validate_start(-1, 9, Offset::Offset(1)).is_err());
        assert!(validate_start(0, 9, Offset::Beginning).is_err());
    }
    #[test]
    fn a_coordinator_transition_retries_instead_of_becoming_a_missing_offset() {
        let mut calls = 0;
        let result = startup_query(Instant::now() + Duration::from_secs(1), |_| {
            calls += 1;
            if calls == 1 {
                Err(KafkaError::MetadataFetch(RDKafkaErrorCode::NotCoordinator))
            } else {
                Ok(42)
            }
        })
        .unwrap();
        assert_eq!(result, 42);
        assert_eq!(calls, 2);
    }
    #[test]
    fn authorization_failure_is_reported_without_retry_or_zero_bootstrap() {
        let mut calls = 0;
        let result: anyhow::Result<()> =
            startup_query(Instant::now() + Duration::from_secs(1), |_| {
                calls += 1;
                Err(KafkaError::MetadataFetch(
                    RDKafkaErrorCode::GroupAuthorizationFailed,
                ))
            });
        assert!(result.is_err());
        assert_eq!(calls, 1);
    }
    #[test]
    fn an_expired_startup_budget_never_sends_a_new_query() {
        let result = startup_query(Instant::now(), |_| -> Result<(), KafkaError> {
            panic!("expired budget must not invoke remote operation")
        });
        assert!(result.unwrap_err().to_string().contains("budget exhausted"));
    }
}
