use crate::event::Envelope;
use anyhow::Context;
use rdkafka::{
    ClientConfig, Message, Offset, TopicPartitionList,
    consumer::{CommitMode, Consumer, ConsumerContext, DefaultConsumerContext, StreamConsumer},
    producer::{FutureProducer, FutureRecord},
};
use std::{sync::Arc, time::Duration};

pub fn producer(brokers: &str) -> anyhow::Result<FutureProducer> {
    Ok(ClientConfig::new()
        .set("bootstrap.servers", brokers)
        .set("enable.idempotence", "true")
        .set("acks", "all")
        .set("delivery.timeout.ms", "5000")
        .set("request.timeout.ms", "3000")
        .set("linger.ms", "5")
        .set("queue.buffering.max.kbytes", "10240")
        .create()?)
}
pub async fn send(producer: &FutureProducer, topic: &str, event: &Envelope) -> anyhow::Result<()> {
    let payload = event.encode()?;
    let key = event.aggregate_id.to_string();
    tokio::time::timeout(
        Duration::from_secs(8),
        producer.send(
            FutureRecord::to(topic).key(&key).payload(&payload),
            Duration::from_millis(250),
        ),
    )
    .await
    .context("producer await budget exhausted; delivery may still happen")?
    .map_err(|(error, _)| anyhow::anyhow!("Kafka delivery failed: {error}"))?;
    Ok(())
}
pub fn consumer(brokers: &str, group: &str, topic: &str) -> anyhow::Result<Arc<StreamConsumer>> {
    let consumer: StreamConsumer = ClientConfig::new()
        .set("bootstrap.servers", brokers)
        .set("group.id", group)
        .set("enable.auto.commit", "false")
        .set("enable.auto.offset.store", "false")
        .set("auto.offset.reset", "earliest")
        .set("isolation.level", "read_committed")
        .set("max.poll.interval.ms", "30000")
        .set("session.timeout.ms", "10000")
        .set("socket.timeout.ms", "3000")
        .create()?;
    consumer.subscribe(&[topic])?;
    Ok(Arc::new(consumer))
}
pub fn decode_message(message: &impl Message) -> anyhow::Result<Envelope> {
    let event = Envelope::decode(message.payload().context("empty Kafka payload")?)?;
    let key = std::str::from_utf8(message.key().context("missing aggregate key")?)?;
    anyhow::ensure!(
        key == event.aggregate_id.to_string(),
        "Kafka key does not match event aggregate"
    );
    Ok(event)
}
/// Called only after a processed position is synchronously acknowledged by Kafka.
/// A rebalance alone must not retire an empty partition's validated zero bootstrap.
pub trait CommitProgress: ConsumerContext {
    fn processed_commit(&self, _topic: &str, _partition: i32) {}
}
impl CommitProgress for DefaultConsumerContext {}

pub async fn commit_processed<C: CommitProgress + 'static>(
    consumer: Arc<StreamConsumer<C>>,
    topic: String,
    partition: i32,
    offset: i64,
) -> anyhow::Result<()> {
    let mut positions = TopicPartitionList::new();
    positions.add_partition_offset(
        &topic,
        partition,
        Offset::Offset(offset.checked_add(1).context("offset overflow")?),
    )?;
    tokio::time::timeout(
        Duration::from_secs(5),
        tokio::task::spawn_blocking(move || {
            consumer.commit(&positions, CommitMode::Sync)?;
            consumer.context().processed_commit(&topic, partition);
            Ok::<_, rdkafka::error::KafkaError>(())
        }),
    )
    .await
    .context("offset commit wait budget exhausted")???;
    Ok(())
}
