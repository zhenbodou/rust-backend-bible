pub mod event;
#[cfg(feature = "kafka")]
pub mod kafka;

pub async fn signal() {
    #[cfg(unix)]
    {
        let mut term = tokio::signal::unix::signal(tokio::signal::unix::SignalKind::terminate())
            .expect("SIGTERM handler");
        tokio::select! {_=term.recv()=>{},_=tokio::signal::ctrl_c()=>{}}
    }
    #[cfg(not(unix))]
    {
        tokio::signal::ctrl_c().await.expect("ctrl-c handler");
    }
}

pub mod projection;
pub mod store;

#[cfg(feature = "kafka")]
pub mod strict_consumer;
