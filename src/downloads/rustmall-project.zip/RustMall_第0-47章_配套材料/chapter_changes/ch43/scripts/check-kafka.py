"""Isolated Kafka43 protocol lab:3 controllers +3 brokers, actual relay/projection.

No existing cluster URL is accepted. No host ports are published. All fixture
credentials and cluster IDs are new; only this randomly named Compose project
and its own synthetic volumes are removed. Requires several GB of Docker memory.
"""
from pathlib import Path
import argparse, base64, json, os, re, secrets, subprocess, tempfile, time, uuid
ROOT=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--image',default='rustmall/book:ch43-candidate')
p.add_argument('--report-dir',type=Path,required=True)
a=p.parse_args();a.report_dir.mkdir(parents=True,exist_ok=False)
project='rustmall-kafka43-'+secrets.token_hex(6)
group='catalog-view43-'+secrets.token_hex(8)
report={'success':False,'checks':[],'scope':'single host, Kafka4.0.0, three separate controllers and three brokers; synthetic dataset; no multi-host/TLS/power-loss proof'}
private=[];logs=[];owned=False;compose=None

def run(args,allowed=False,input=None,timeout=60):
 r=subprocess.run(args,cwd=ROOT,text=True,input=input,capture_output=True,timeout=timeout)
 output=r.stdout+'\n'+r.stderr
 for s in private:output=output.replace(s,'[REDACTED]')
 logs.append(output[-12000:])
 if r.returncode and not allowed:raise RuntimeError('Kafka43 command failed; inspect lab.log (credentials redacted)')
 return r

def call(*args,**kwargs):return run(compose+list(args),**kwargs)
def until(test,label,seconds=120):
 end=time.monotonic()+seconds
 while True:
  if test():return
  if time.monotonic()>end:raise RuntimeError('timeout: '+label)
  time.sleep(.3)
def kafka(script,*args,allowed=False,input=None):
 return call('exec','-T','b1','/opt/kafka/bin/'+script,'--bootstrap-server','b1:9092',*map(str,args),allowed=allowed,input=input)
def sql(db,statement):
 return call('exec','-T','postgres','psql','-U','rustmall','-d',db,'-X','-v','ON_ERROR_STOP=1','-Atc',statement).stdout.strip()
def tool(command,*args,env=None,allowed=False):
 options=[]
 for key,value in (env or {}).items():options+=['-e',key+'='+value]
 return call('run','--rm','--no-deps',*options,'tool','/app/kafka-lab',command,*args,allowed=allowed)
def enqueue():
 result=tool('enqueue','--isolated-lab')
 lines=[line for line in result.stdout.splitlines() if line.startswith('{')]
 return json.loads(lines[-1])
def describe(topic):
 result=kafka('kafka-topics.sh','--describe','--topic',topic,allowed=True)
 found=[]
 for line in result.stdout.splitlines():
  match=re.search(r'Partition:\s*(\d+).*Leader:\s*(-?\d+).*Replicas:\s*([\d,]+).*Isr:\s*([\d,]*)',line)
  if match:found.append({'partition':int(match[1]),'leader':int(match[2]),'replicas':[int(v) for v in match[3].split(',')], 'isr':[int(v) for v in match[4].split(',') if v]})
 return found

def members():
 result=kafka('kafka-consumer-groups.sh','--describe','--group',group,'--members','--verbose',allowed=True)
 counts=[]
 for line in result.stdout.splitlines():
  parts=line.split()
  if len(parts)>=6 and parts[0]==group and parts[4].isdigit():counts.append(int(parts[4]))
 return counts

def offsets(topic,selected_group):
 result=kafka('kafka-consumer-groups.sh','--describe','--group',selected_group,allowed=True)
 positions={}
 for line in result.stdout.splitlines():
  parts=line.split()
  if len(parts)>=6 and parts[0]==selected_group and parts[1]==topic and parts[2].isdigit():
   positions[int(parts[2])]=int(parts[3]) if parts[3].isdigit() else None
 return positions

def ends(topic,when='latest'):
 result=kafka('kafka-get-offsets.sh','--topic',topic,'--time',when,allowed=True)
 found={}
 for line in result.stdout.splitlines():
  parts=line.strip().split(':')
  if len(parts)==3 and parts[0]==topic:found[int(parts[1])]=int(parts[2])
 return found

def caught_up():
 current=offsets(TOPIC,group);high=ends(TOPIC)
 return bool(high) and all(current.get(p)==end or (end==0 and current.get(p) is None) for p,end in high.items())
def create_topic(topic,partitions=1):
 kafka('kafka-topics.sh','--create','--topic',topic,'--partitions',partitions,'--replication-factor',3,
       '--config','min.insync.replicas=2','--config','cleanup.policy=delete','--config','retention.ms=604800000','--config','unclean.leader.election.enable=false')
 until(lambda:len(describe(topic))==partitions and all(len(x['isr'])==3 for x in describe(topic)),'full ISR '+topic)
def produce(topic,lines):
 kafka('kafka-console-producer.sh','--topic',topic,'--property','parse.key=true','--property','key.separator=|',
       '--producer-property','enable.idempotence=true','--producer-property','acks=all',
       '--producer-property','request.timeout.ms=3000','--producer-property','delivery.timeout.ms=5000',input='\n'.join(lines)+'\n')
TOPIC='rustmall.catalog.snapshots.v1'
work=tempfile.TemporaryDirectory(prefix=project+'-')
try:
 tmp=work.name
 private_dir=Path(tmp);secret_dir=private_dir/'secrets';secret_dir.mkdir(mode=0o700)
 password=secrets.token_urlsafe(48);private.append(password)
 def secret(name,value):
  path=secret_dir/name;path.write_text(value+'\n');path.chmod(0o444);private.append(value)
 secret('pg_password',password)
 for name,db in [('catalog_url','catalog'),('projection_url','projection'),('poison_url','poison')]:
  secret(name,f'postgres://rustmall:{password}@postgres:5432/{db}?sslmode=disable')
 env=private_dir/'compose.env';env.write_text('RUSTMALL_IMAGE='+a.image+'\nKAFKA_LAB_CLUSTER_ID='+base64.urlsafe_b64encode(uuid.uuid4().bytes).decode().rstrip('=')+'\nKAFKA_LAB_GROUP='+group+'\nKAFKA_LAB_SECRET_DIR='+str(secret_dir)+'\n');env.chmod(0o600)
 compose=['docker','compose','-p',project,'--env-file',str(env),'-f',str(ROOT/'ops/kafka43/compose.json')]
 assert not call('ps','-aq').stdout.strip(),'project unexpectedly exists'
 image=json.loads(run(['docker','image','inspect',a.image]).stdout)[0]
 report['image_id']=image['Id'];report['architecture']=image['Architecture']
 owned=True
 call('up','-d','c1','c2','c3','b1','b2','b3','postgres')
 until(lambda:call('exec','-T','postgres','pg_isready','-U','rustmall','-d','postgres',allowed=True).returncode==0,'PostgreSQL ready')
 until(lambda:kafka('kafka-topics.sh','--list',allowed=True).returncode==0,'Kafka ready',180)
 # Listing can succeed before all brokers have registered with the quorum.
 until(lambda:all(call('exec','-T',name,'/opt/kafka/bin/kafka-broker-api-versions.sh','--bootstrap-server',name+':9092',allowed=True).returncode==0 for name in ['b1','b2','b3']),'three brokers ready',180)
 for db in ['catalog','projection','poison']:sql('postgres','CREATE DATABASE '+db)
 call('run','--rm','--no-deps','-e','DATABASE_URL_FILE=/run/secrets/catalog_url','tool','/app/catalog-migrate')
 call('run','--rm','--no-deps','tool','/app/projection-migrate')
 call('run','--rm','--no-deps','-e','PROJECTION_DATABASE_URL_FILE=/run/secrets/poison_url','tool','/app/projection-migrate')
 create_topic(TOPIC,3)
 report['checks'].append('three-controller quorum and three distinct brokers; RF3/minISR2/delete topic, actual catalog and two projection migrations')
 first=enqueue();enqueue();enqueue()
 call('up','-d','relay')
 until(lambda:sql('catalog','SELECT count(*) FROM product_outbox WHERE delivered_at IS NULL')=='0','initial relay drain')
 call('up','-d','worker1')
 until(lambda:sql('projection','SELECT count(*) FROM catalog_view')=='3','initial durable consumer',120)
 until(caught_up,'initial committed offsets')
 report['checks'].append('actual Rust store transaction -> Outbox -> actual relay -> RF3 Kafka -> strict projection and committed offsets')
 quorum=kafka('kafka-metadata-quorum.sh','describe','--status').stdout
 assert re.search(r'LeaderId:\s*\d+',quorum),quorum
 call('stop','b2','b3')
 until(lambda:len(describe(TOPIC))==3 and all(x['leader']==11 and x['isr']==[11] for x in describe(TOPIC)),'one ISR survivor',120)
 quorum=kafka('kafka-metadata-quorum.sh','describe','--status').stdout
 assert re.search(r'LeaderId:\s*\d+',quorum)
 blocked=enqueue();blocked_id=str(uuid.UUID(blocked['event_id']))
 until(lambda:sql('catalog',f"SELECT count(*) FROM product_outbox WHERE event_id='{blocked_id}' AND delivered_at IS NULL AND attempts>0 AND last_error IS NOT NULL")=='1','ISR rejection retained in Outbox',90)
 report['checks'].append('stop two brokers with controller quorum intact: acksall/minISR2 rejects delivery, actual relay keeps same event pending with retry state')
 call('start','b2','b3')
 until(lambda:len(describe(TOPIC))==3 and all(len(x['isr'])==3 for x in describe(TOPIC)),'ISR recovered',180)
 until(lambda:sql('catalog',f"SELECT count(*) FROM product_outbox WHERE event_id='{blocked_id}' AND delivered_at IS NOT NULL")=='1','same event delivered after ISR recovery',180)
 call('up','-d','worker1')
 until(lambda:sql('projection','SELECT count(*) FROM catalog_view')=='4','projection after recovery',120)
 until(caught_up,'post-recovery offsets')
 report['checks'].append('restored brokers rejoin ISR; original Outbox event delivered and projection converges without changing event identity')
 call('stop','worker1')
 before=offsets(TOPIC,group)
 late=enqueue();late_id=str(uuid.UUID(late['event_id']))
 until(lambda:sql('catalog',f"SELECT count(*) FROM product_outbox WHERE event_id='{late_id}' AND delivered_at IS NOT NULL")=='1','crash-window fixture published')
 applied=tool('apply-without-offset','--isolated-lab').stdout
 assert 'database committed event='+late_id in applied and 'NO offset commit' in applied
 assert sql('projection',f"SELECT count(*) FROM consumer_inbox WHERE event_id='{late_id}'")=='1'
 assert offsets(TOPIC,group)==before,'lab branch must not advance Kafka position'
 call('up','-d','worker1')
 until(caught_up,'duplicate redelivery commits next offset')
 assert sql('projection','SELECT count(*) FROM consumer_inbox')=='5'
 assert sql('projection','SELECT count(*) FROM catalog_view')=='5'
 report['checks'].append('actual shared apply commits DB then lab exits without offset: broker positions unchanged; production worker replays through Inbox with exactly5 facts')
 call('up','-d','worker2')
 until(lambda:sorted(members())==[1,2],'two eager members own three partitions',120)
 for _ in range(12):enqueue()
 until(lambda:sql('projection','SELECT count(*) FROM catalog_view')=='17','two consumers apply',180)
 call('stop','worker2')
 until(lambda:members()==[3],'remaining eager member owns all partitions',120)
 for _ in range(3):enqueue()
 until(lambda:sql('projection','SELECT count(*) FROM catalog_view')=='20','remaining consumer applies',180)
 until(caught_up,'final current offsets')
 call('stop','worker1','relay')
 call('run','--rm','--no-deps','tool','/app/projection-audit','--writers-stopped')
 report['checks'].append('actual eager rebalance2 members/3 partitions then1 member/3; all20 source products fully audited against projection after writers stopped')
 poison='rustmall.poison43';create_topic(poison)
 marker='DO_NOT_EXPORT_POISON_PAYLOAD_43';private.append(marker)
 produce(poison,['1|'+marker, '1|'+json.dumps(first,separators=(',',':'))])
 call('up','-d','poison-worker')
 def poison_exited():
  cid=call('ps','-aq','poison-worker').stdout.strip()
  state=json.loads(run(['docker','inspect',cid]).stdout)[0]['State']
  return state['Status']=='exited' and state['ExitCode']!=0
 until(poison_exited,'poison fail-stop',90)
 poison_logs=call('logs','--no-color','poison-worker').stdout
 assert 'offset=0' in poison_logs and 'no offset commit' in poison_logs
 assert marker not in poison_logs
 assert sql('poison','SELECT count(*) FROM consumer_inbox')=='0'
 assert all(v is None for v in offsets(poison,group+'-poison').values())
 report['checks'].append('malformed offset0 before a valid event: production worker exits nonzero, no Inbox/offset advancement, log contains location but no payload sentinel')
 gap='rustmall.gap43';gap_group=group+'-gap';create_topic(gap)
 record='1|'+json.dumps(first,separators=(',',':'));produce(gap,[record,record])
 kafka('kafka-consumer-groups.sh','--group',gap_group,'--topic',gap,'--reset-offsets','--to-offset',0,'--execute')
 assert offsets(gap,gap_group)=={0:0}
 delete=json.dumps({'partitions':[{'topic':gap,'partition':0,'offset':2}],'version':1})
 call('exec','-T','b1','sh','-ec','cat > /tmp/rustmall-delete43.json',input=delete)
 kafka('kafka-delete-records.sh','--offset-json-file','/tmp/rustmall-delete43.json')
 until(lambda:ends(gap,'earliest')=={0:2},'retained start advanced')
 for selected_group,reason in [(gap_group,'outside retained history'),(group+'-newgap','no baseline')]:
  failure=tool('start-check',env={'KAFKA_TOPIC':gap,'CONSUMER_NAME':selected_group},allowed=True)
  assert failure.returncode and reason in failure.stdout+failure.stderr
 assert offsets(gap,gap_group)=={0:0},'preflight must not repair offsets silently'
 report['checks'].append('controlled DeleteRecords advances low to2: existing commit0 and new group both fail actual strict preflight; original commit remains0')
 report['success']=True
finally:
 if owned and compose:
  runtime=subprocess.run(compose+['logs','--no-color','relay','worker1','worker2','poison-worker'],capture_output=True,text=True).stdout
  for s in private:runtime=runtime.replace(s,'[REDACTED]')
  (a.report_dir/'runtime.log').write_text(runtime)
  report['cleanup_exit']=subprocess.run(compose+['down','--volumes','--remove-orphans'],capture_output=True).returncode
  if report['cleanup_exit']:report['success']=False
 (a.report_dir/'lab.log').write_text('\n'.join(logs))
 (a.report_dir/'result.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
 work.cleanup()
if not report['success']:raise SystemExit('Kafka43 verification failed')
print(json.dumps(report,ensure_ascii=False,indent=2))
