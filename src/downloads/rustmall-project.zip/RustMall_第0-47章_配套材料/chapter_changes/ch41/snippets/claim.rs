/// Exact production statement, also used for EXPLAIN in the isolated chapter41 lab.
pub const CLAIM_SQL: &str = include_str!("sql/claim_order.sql");

pub async fn claim(pool: &PgPool) -> anyhow::Result<Option<(Order, Uuid)>> {
    let token = Uuid::new_v4();
    let row = sqlx::query_as::<_, Order>(CLAIM_SQL)
        .bind(token)
        .fetch_optional(pool)
        .await?;
    if let Some(row) = &row {
        anyhow::ensure!(row.valid(), "invalid stored order");
    }
    Ok(row.map(|row| (row, token)))
}
