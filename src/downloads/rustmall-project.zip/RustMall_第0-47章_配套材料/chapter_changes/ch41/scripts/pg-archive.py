"""Logical backups and NEW verification-database restores for the book's PostgreSQL17 lab.

Uses trusted container-local PostgreSQL admin access. Does not switch applications,
restore global roles, or claim cross-database consistency. Python3.11+ and Docker.
"""
import argparse,hashlib,json,os,re,subprocess,tempfile
from pathlib import Path

def digest(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def run(container,command,**kwargs):
    result=subprocess.run(['docker','exec','-i',container,*command],stderr=subprocess.PIPE,timeout=900,**kwargs)
    if result.returncode:raise RuntimeError(f'{command[0]} failed with exit {result.returncode}; database response values suppressed')
def validate(container,path):
    # Raw IO keeps the OS descriptor position aligned when handing it to Docker.
    with path.open('rb',buffering=0) as stream:
        if stream.read(5)!=b'PGDMP':raise ValueError('not a custom-format archive')
        stream.seek(0);run(container,['pg_restore','--list'],stdin=stream,stdout=subprocess.DEVNULL)
def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('operation',choices=['backup','restore']);p.add_argument('--container',required=True)
    p.add_argument('--database',choices=['rustmall_'+x for x in ['catalog','users','payments','orders','projection','rebuild']])
    p.add_argument('--output',type=Path);p.add_argument('--archive',type=Path)
    p.add_argument('--target');p.add_argument('--expected-sha256');a=p.parse_args()
    if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]{0,127}',a.container):p.error('invalid container identity')
    if a.operation=='backup':
        if not a.database or not a.output or a.archive or a.target or a.expected_sha256:p.error('backup requires only database and output')
        partial=None
        try:
            with tempfile.NamedTemporaryFile(prefix='.rustmall-backup-',dir=a.output.parent,delete=False) as stream:
                partial=Path(stream.name)
                run(a.container,['pg_dump','-U','postgres','--format=custom','--no-owner','--no-acl','--dbname',a.database],stdout=stream)
                stream.flush();os.fsync(stream.fileno())
            validate(a.container,partial)
            # Same-filesystem link atomically refuses to overwrite any existing target.
            os.link(partial,a.output)
            report={'operation':'backup','database':a.database,'file':str(a.output),'bytes':a.output.stat().st_size,'sha256':digest(a.output)}
        finally:
            if partial is not None:partial.unlink(missing_ok=True)
    else:
        if not a.archive or not a.target or not a.expected_sha256 or a.output or a.database:p.error('restore requires only archive, target and expected-sha256')
        if not re.fullmatch(r'rustmall_restore_[a-z0-9_]{1,40}',a.target):p.error('target must be a new rustmall_restore_* verification database')
        if not re.fullmatch(r'[0-9a-f]{64}',a.expected_sha256) or digest(a.archive)!=a.expected_sha256:raise ValueError('archive checksum mismatch')
        validate(a.container,a.archive)
        # No --clean, DROP DATABASE, or reuse-existing behavior.
        run(a.container,['createdb','-U','postgres','--template=template0',a.target],stdout=subprocess.DEVNULL)
        with a.archive.open('rb') as stream:
            run(a.container,['pg_restore','-U','postgres','--exit-on-error','--single-transaction','--no-owner','--no-acl','--dbname',a.target],stdin=stream,stdout=subprocess.DEVNULL)
        report={'operation':'restore','target':a.target,'sha256':a.expected_sha256,'scope':'new verification DB only; owner/ACL/global-role and cross-service cutover not restored'}
    print(json.dumps(report,ensure_ascii=False))
if __name__=='__main__':
    try:main()
    except (OSError,ValueError,RuntimeError,subprocess.TimeoutExpired) as error:
        detail=str(error) if not isinstance(error,subprocess.TimeoutExpired) else 'archive subprocess timeout'
        raise SystemExit('Archive operation failed: '+detail+'. No success is claimed; original databases are not dropped.')
