"""Real plans and logical restore on isolated actual project schemas; no production target.

Build the current chapter image first. The report directory must not exist.
"""
from pathlib import Path
import argparse,hashlib,json,os,re,secrets,stat,subprocess,tempfile,time,uuid
ROOT=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--image',default='rustmall/book:ch41-candidate');p.add_argument('--report-dir',required=True,type=Path);a=p.parse_args()
if not re.fullmatch(r'[a-zA-Z0-9][a-zA-Z0-9_./:@-]*',a.image):p.error('invalid image reference')
a.report_dir.mkdir(mode=0o700)
work=tempfile.TemporaryDirectory(prefix='rustmall-postgres41-');private=Path(work.name);label='rustmall-pg41-'+uuid.uuid4().hex[:10];container=label+'-pg';network=label+'-net';owned=[];checks=[];report={};logs=[];password=secrets.token_urlsafe(48);success=False

def run(command,ok=True,**kwargs):
 r=subprocess.run([str(x) for x in command],cwd=ROOT,capture_output=True,timeout=180,text=True,**kwargs)
 text=(r.stdout+'\n'+r.stderr).replace(password,'[REDACTED]');logs.append(text)
 if ok and r.returncode:raise RuntimeError('PostgreSQL lab command failed; inspect redacted commands.log')
 return r

def sql(db,text):return run(['docker','exec','-i',container,'psql','-X','-U','postgres','-d',db,'-v','ON_ERROR_STOP=1','-Atq'],input=text).stdout.strip()
def nodes(plan):
 yield plan
 for child in plan.get('Plans',[]):yield from nodes(child)
def explain(db,query):return json.loads(sql(db,'EXPLAIN (ANALYZE,BUFFERS,FORMAT JSON) '+query))[0]
def archive(*args,ok=True):return run(['python3','scripts/pg-archive.py',*args,'--container',container],ok=ok)
try:
 for name,value in [('postgres_password',password),('catalog_url',f'postgres://postgres:{password}@postgres:5432/rustmall_catalog?sslmode=disable'),('orders_url',f'postgres://postgres:{password}@postgres:5432/rustmall_orders?sslmode=disable')]:
  (private/name).write_text(value+'\n');(private/name).chmod(0o444)
 run(['docker','network','create',network]);owned.append(('network',network))
 run(['docker','run','-d','--name',container,'--network',network,'--network-alias','postgres','--mount',f'type=bind,src={private/"postgres_password"},dst=/run/secrets/password,readonly','-e','POSTGRES_PASSWORD_FILE=/run/secrets/password','postgres:17-bookworm','postgres','-c','shared_preload_libraries=pg_stat_statements','-c','track_io_timing=on']);owned.append(('container',container))
 deadline=time.monotonic()+45
 while run(['docker','exec',container,'pg_isready','-q','-h','127.0.0.1','-U','postgres'],ok=False).returncode:
  if time.monotonic()>deadline:raise RuntimeError('isolated PostgreSQL timeout')
  time.sleep(.2)
 for db,command,key in [('catalog',['/app/catalog-migrate'],'catalog_url'),('orders',['/app/rustmall-service','migrate-orders'],'orders_url')]:
  run(['docker','exec',container,'createdb','-U','postgres','rustmall_'+db])
  run(['docker','run','--rm','--network',network,'--mount',f'type=bind,src={private/key},dst=/run/secrets/database_url,readonly','-e','DATABASE_URL_FILE=/run/secrets/database_url',a.image,*command])
  sql('rustmall_'+db,'CREATE EXTENSION pg_stat_statements;')
 assert sql('rustmall_orders','SELECT count(*) FROM _sqlx_migrations')=='1'
 assert sql('rustmall_catalog','SELECT count(*) FROM _sqlx_migrations')=='4'
 report['postgres_version']=sql('postgres','SHOW server_version')
 checks.append('actual image migration programs create catalog/orders schemas and SQLx migration ledgers in fresh isolated DBs')
 sql('rustmall_orders',"""INSERT INTO orders(id,actor_id,request_key,product_id,quantity,unit_price,amount,state,next_attempt)
 SELECT ('00000000-0000-0000-0000-'||lpad(to_hex(g),12,'0'))::uuid,1,
 ('20000000-0000-0000-0000-'||lpad(to_hex(g),12,'0'))::uuid,1,1,100,100,'charging',now()+interval '1 day'
 FROM generate_series(1,200000) AS g;
 ANALYZE orders;""")
 current=(ROOT/'services/commerce/src/sql/claim_order.sql').read_text().strip().rstrip(';')
 plans={}
 for name,query in [('old_volatile',current.replace('statement_timestamp()','clock_timestamp()')),('statement_cutoff',current)]:
  plan=json.loads(sql('rustmall_orders',f"PREPARE claim_plan(uuid) AS {query}; EXPLAIN (ANALYZE,BUFFERS,FORMAT JSON) EXECUTE claim_plan('30000000-0000-0000-0000-000000000001');"))[0]
  plans[name]=plan;(a.report_dir/(name+'.json')).write_text(json.dumps(plan,indent=2)+'\n')
 old=list(nodes(plans['old_volatile']['Plan']));new=list(nodes(plans['statement_cutoff']['Plan']))
 assert sum(n.get('Rows Removed by Filter',0) for n in old)>=200000
 assert any('next_attempt' in n.get('Index Cond','') and 'statement_timestamp' in n.get('Index Cond','') for n in new)
 assert sum(n.get('Rows Removed by Filter',0) for n in new)==0
 assert sql('rustmall_orders','SELECT count(*) FROM orders WHERE lease_token IS NOT NULL')=='0'
 report['claim_plans']={key:{'execution_ms':value['Execution Time'],'shared_hit_blocks':value['Plan'].get('Shared Hit Blocks',0),'shared_read_blocks':value['Plan'].get('Shared Read Blocks',0),'removed_by_filter':sum(n.get('Rows Removed by Filter',0) for n in nodes(value['Plan']))} for key,value in plans.items()}
 checks.append('exact worker SQL: 200000 not-yet-due orders; old volatile predicate filters them, statement cutoff has index range condition and filters zero; neither claims a row')
 sql('rustmall_catalog',"""INSERT INTO products(name,price_cents,stock,created_at,delisted_at)
 SELECT '计划实验-'||g,100,100,TIMESTAMPTZ '2020-01-01'+(g/5)*interval '1 second',CASE WHEN g%11=0 THEN now() ELSE NULL END
 FROM generate_series(1,200000) AS g;
 INSERT INTO inventory_reservations(saga_id,product_id,quantity,unit_price_cents,state)
 SELECT ('40000000-0000-0000-0000-'||lpad(to_hex(g),12,'0'))::uuid,(g%1000)+1,2,100,CASE WHEN g%10=0 THEN 'held' ELSE 'confirmed' END
 FROM generate_series(1,200000) AS g;
 ANALYZE products;""")
 sql('rustmall_catalog','VACUUM (ANALYZE) inventory_reservations;')
 boundary=json.loads(sql('rustmall_catalog',"SELECT json_build_object('time',created_at,'id',id) FROM products WHERE delisted_at IS NULL ORDER BY created_at DESC,id DESC LIMIT 1 OFFSET 99999"))
 quoted="'"+boundary['time'].replace("'","''")+"'::timestamptz"
 base='SELECT id,name,price_cents,stock FROM products WHERE delisted_at IS NULL'
 offset=base+' ORDER BY created_at DESC,id DESC LIMIT 20 OFFSET 100000'
 keyset=base+f" AND (created_at,id)<({quoted},{int(boundary['id'])}) ORDER BY created_at DESC,id DESC LIMIT 20"
 ids=lambda query:sql('rustmall_catalog','SELECT json_agg(id) FROM ('+query+') AS page')
 assert ids(offset)==ids(keyset)
 op,kp=explain('rustmall_catalog',offset),explain('rustmall_catalog',keyset)
 assert max(n.get('Actual Rows',0) for n in nodes(op['Plan']))>=100020
 assert max(n.get('Actual Rows',0) for n in nodes(kp['Plan']))<=20
 for name,plan in [('offset_page',op),('keyset_page',kp)]: (a.report_dir/(name+'.json')).write_text(json.dumps(plan,indent=2)+'\n')
 held=explain('rustmall_catalog',"SELECT COALESCE(sum(quantity),0)::bigint FROM inventory_reservations WHERE product_id=11 AND state='held'")
 assert any(n.get('Index Name')=='inventory_reservations_product_held_idx' for n in nodes(held['Plan']))
 (a.report_dir/'held_covering_index.json').write_text(json.dumps(held,indent=2)+'\n')
 checks.append('actual catalog schema: offset100000 and keyset return identical IDs with tied timestamps; scans100020 versus20; existing product-held partial INCLUDE index is selected after VACUUM')
 diagnostics=(ROOT/'ops/postgres41/diagnostics.sql').read_text();sql('rustmall_orders',diagnostics)
 checks.append('read-only operator diagnostics run with pg_stat_statements, activity/blocker/tuple/index statistics; no session secrets or raw SQL text exported')
 oid='10000000-0000-0000-0000-000000000001'
 sql('rustmall_orders',f"""INSERT INTO orders(id,actor_id,request_key,product_id,quantity,unit_price,amount,state) VALUES('{oid}',7,'50000000-0000-0000-0000-000000000001',1,2,25,50,'completed');
 INSERT INTO order_transitions(order_id,from_state,to_state,reason) VALUES
 ('{oid}','reserving','charging','lab'),('{oid}','charging','confirming','lab'),('{oid}','confirming','completed','lab');""")
 backup=a.report_dir/'orders.dump';saved=json.loads(archive('backup','--database','rustmall_orders','--output',str(backup.resolve())).stdout)
 assert stat.S_IMODE(backup.stat().st_mode)==0o600
 before=backup.read_bytes();assert archive('backup','--database','rustmall_orders','--output',str(backup.resolve()),ok=False).returncode and backup.read_bytes()==before
 target='rustmall_restore_'+uuid.uuid4().hex[:12]
 archive('restore','--archive',str(backup.resolve()),'--target',target,'--expected-sha256',saved['sha256'])
 facts="SELECT json_build_object('orders',(SELECT count(*) FROM orders),'amount',(SELECT sum(amount) FROM orders),'transitions',(SELECT count(*) FROM order_transitions),'migrations',(SELECT count(*) FROM _sqlx_migrations),'constraints',(SELECT count(*) FROM pg_constraint WHERE conrelid='orders'::regclass))"
 assert sql('rustmall_orders',facts)==sql(target,facts)
 assert archive('restore','--archive',str(backup.resolve()),'--target',target,'--expected-sha256',saved['sha256'],ok=False).returncode
 bad=run(['docker','exec','-i',container,'psql','-X','-U','postgres','-d',target,'-v','ON_ERROR_STOP=1'],input="UPDATE orders SET amount=0 WHERE id='"+oid+"';",ok=False)
 assert bad.returncode and 'check constraint' in bad.stderr
 verification_order='60000000-0000-0000-0000-000000000001'
 sql(target,f"INSERT INTO orders(id,actor_id,request_key,product_id,quantity,unit_price,amount,state) VALUES('{verification_order}',7,'70000000-0000-0000-0000-000000000001',1,1,100,100,'charging')")
 next_id=sql(target,f"INSERT INTO order_transitions(order_id,from_state,to_state,reason) VALUES('{verification_order}','reserving','charging','sequence-check') RETURNING id")
 assert int(next_id)>3
 assert sql('rustmall_orders','SELECT count(*) FROM order_transitions')=='3'
 corrupt=a.report_dir/'corrupt.dump';corrupt.write_bytes(before[:64]);corrupt.chmod(0o600)
 rejected='rustmall_restore_checksum_rejected'
 assert archive('restore','--archive',str(corrupt.resolve()),'--target',rejected,'--expected-sha256',saved['sha256'],ok=False).returncode
 assert sql('postgres',f"SELECT count(*) FROM pg_database WHERE datname='{rejected}'")=='0'
 report['backup']={k:v for k,v in saved.items() if k!='file'}
 checks.append('real custom pg_dump/pg_restore: fresh DB preserves 200001 rows, amount total, transitions, migration ledger, constraints and sequence; existing outputs/DB and wrong checksum refused; source unchanged')
 success=True
finally:
 report['cleanup']=[]
 for kind,name in reversed(owned):
  command=['docker','rm','-f','-v',name] if kind=='container' else ['docker','network','rm',name]
  report['cleanup'].append(subprocess.run(command,capture_output=True).returncode)
 work.cleanup()
 (a.report_dir/'commands.log').write_text('\n'.join(logs))
 report.update(success=success and all(x==0 for x in report['cleanup']),checks=checks,passed=len(checks),scope='isolated PostgreSQL17 actual project schemas, measured plans and one-DB logical verification restore; not production benchmarking or coordinated six-DB PITR')
 (a.report_dir/'result.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(report,ensure_ascii=False,indent=2))
if not report['success']:raise SystemExit(1)
