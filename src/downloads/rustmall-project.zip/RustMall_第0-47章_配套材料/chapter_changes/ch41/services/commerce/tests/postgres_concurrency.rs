use commerce::orders::{self, Order};
use sqlx::{PgPool, postgres::PgPoolOptions};
use std::time::Duration;
use uuid::Uuid;

async fn seed(pool: &PgPool, id: u128) -> Uuid {
    let uuid = Uuid::from_u128(id);
    sqlx::query("INSERT INTO orders(id,actor_id,request_key,product_id,quantity,unit_price,amount,next_attempt) VALUES($1,1,$2,1,1,100,100,'2020-01-01')")
        .bind(uuid).bind(Uuid::from_u128(id+100)).execute(pool).await.unwrap();
    uuid
}
fn sqlstate(error: &sqlx::Error) -> Option<String> {
    error
        .as_database_error()
        .and_then(|e| e.code())
        .map(|s| s.into_owned())
}

#[sqlx::test(migrations = "./migrations/orders")]
async fn repeatable_read_holds_a_snapshot_but_read_committed_refreshes(pool: PgPool) {
    seed(&pool, 1).await;
    let mut rr = pool.begin().await.unwrap();
    sqlx::query("SET TRANSACTION ISOLATION LEVEL REPEATABLE READ READ ONLY")
        .execute(&mut *rr)
        .await
        .unwrap();
    let a: i64 = sqlx::query_scalar("SELECT count(*) FROM orders")
        .fetch_one(&mut *rr)
        .await
        .unwrap();
    seed(&pool, 2).await;
    let b: i64 = sqlx::query_scalar("SELECT count(*) FROM orders")
        .fetch_one(&mut *rr)
        .await
        .unwrap();
    assert_eq!((a, b), (1, 1));
    rr.rollback().await.unwrap();
    let mut rc = pool.begin().await.unwrap();
    sqlx::query("SET TRANSACTION ISOLATION LEVEL READ COMMITTED")
        .execute(&mut *rc)
        .await
        .unwrap();
    let a: i64 = sqlx::query_scalar("SELECT count(*) FROM orders")
        .fetch_one(&mut *rc)
        .await
        .unwrap();
    seed(&pool, 3).await;
    let b: i64 = sqlx::query_scalar("SELECT count(*) FROM orders")
        .fetch_one(&mut *rc)
        .await
        .unwrap();
    assert_eq!((a, b), (2, 3));
    rc.rollback().await.unwrap();
}

#[sqlx::test(migrations = "./migrations/orders")]
async fn actual_claim_skips_locked_head_and_respects_fresh_leases(pool: PgPool) {
    let first = seed(&pool, 1).await;
    let second = seed(&pool, 2).await;
    let mut lock = pool.begin().await.unwrap();
    sqlx::query("SELECT id FROM orders WHERE id=$1 FOR UPDATE")
        .bind(first)
        .execute(&mut *lock)
        .await
        .unwrap();
    let (row, key) = orders::claim(&pool).await.unwrap().unwrap();
    assert_eq!(row.id, second);
    assert_eq!(row.attempts, 1);
    assert!(orders::claim(&pool).await.unwrap().is_none());
    lock.rollback().await.unwrap();
    let (row, other) = orders::claim(&pool).await.unwrap().unwrap();
    assert_eq!(row.id, first);
    assert_eq!(row.attempts, 1);
    assert_ne!(key, other);
}

#[sqlx::test(migrations = "./migrations/orders")]
async fn claim_uses_current_statement_cutoff_even_inside_an_older_transaction(pool: PgPool) {
    let mut old = pool.begin().await.unwrap();
    sqlx::query("SELECT transaction_timestamp()")
        .execute(&mut *old)
        .await
        .unwrap();
    sqlx::query("SELECT pg_sleep(0.02)")
        .execute(&mut *old)
        .await
        .unwrap();
    let id = seed(&pool, 1).await;
    sqlx::query("UPDATE orders SET next_attempt=clock_timestamp() WHERE id=$1")
        .bind(id)
        .execute(&pool)
        .await
        .unwrap();
    let after_begin: bool =
        sqlx::query_scalar("SELECT next_attempt>transaction_timestamp() FROM orders WHERE id=$1")
            .bind(id)
            .fetch_one(&mut *old)
            .await
            .unwrap();
    assert!(after_begin);
    let row = sqlx::query_as::<_, Order>(orders::CLAIM_SQL)
        .bind(Uuid::new_v4())
        .fetch_optional(&mut *old)
        .await
        .unwrap()
        .unwrap();
    assert_eq!(row.id, id);
    let valid:bool=sqlx::query_scalar("SELECT leased_until>statement_timestamp() AND lease_token IS NOT NULL FROM orders WHERE id=$1").bind(id).fetch_one(&mut *old).await.unwrap();
    assert!(valid);
    old.rollback().await.unwrap();
}

#[sqlx::test(migrations = "./migrations/orders")]
async fn lock_timeout_aborts_transaction_and_rollback_restores_connection(pool: PgPool) {
    let id = seed(&pool, 1).await;
    let mut held = pool.begin().await.unwrap();
    sqlx::query("SELECT id FROM orders WHERE id=$1 FOR UPDATE")
        .bind(id)
        .execute(&mut *held)
        .await
        .unwrap();
    let mut waiting = pool.begin().await.unwrap();
    sqlx::query("SET LOCAL lock_timeout='40ms'")
        .execute(&mut *waiting)
        .await
        .unwrap();
    let error = sqlx::query("UPDATE orders SET last_error='lab' WHERE id=$1")
        .bind(id)
        .execute(&mut *waiting)
        .await
        .unwrap_err();
    assert_eq!(sqlstate(&error).as_deref(), Some("55P03"));
    let aborted = sqlx::query("SELECT 1")
        .execute(&mut *waiting)
        .await
        .unwrap_err();
    assert_eq!(sqlstate(&aborted).as_deref(), Some("25P02"));
    waiting.rollback().await.unwrap();
    held.rollback().await.unwrap();
    sqlx::query("SELECT 1").execute(&pool).await.unwrap();
}

#[sqlx::test(migrations = "./migrations/orders")]
async fn statement_timeout_is_distinct_and_local_setting_does_not_leak(pool: PgPool) {
    let mut tx = pool.begin().await.unwrap();
    sqlx::query("SET LOCAL statement_timeout='40ms'")
        .execute(&mut *tx)
        .await
        .unwrap();
    let error = sqlx::query("SELECT pg_sleep(1)")
        .execute(&mut *tx)
        .await
        .unwrap_err();
    assert_eq!(sqlstate(&error).as_deref(), Some("57014"));
    tx.rollback().await.unwrap();
    // A separate one-connection pool lets us inspect reuse of the same session.
    let one = PgPoolOptions::new()
        .max_connections(1)
        .connect_with(pool.connect_options().as_ref().clone())
        .await
        .unwrap();
    let before: String = sqlx::query_scalar("SHOW statement_timeout")
        .fetch_one(&one)
        .await
        .unwrap();
    let mut tx = one.begin().await.unwrap();
    sqlx::query("SET LOCAL statement_timeout='17ms'")
        .execute(&mut *tx)
        .await
        .unwrap();
    tx.commit().await.unwrap();
    let after: String = sqlx::query_scalar("SHOW statement_timeout")
        .fetch_one(&one)
        .await
        .unwrap();
    assert_eq!(before, after);
    one.close().await;
}

#[sqlx::test(migrations = "./migrations/orders")]
async fn opposite_lock_order_produces_one_deadlock_victim(pool: PgPool) {
    let first = seed(&pool, 1).await;
    let second = seed(&pool, 2).await;
    let mut a = pool.begin().await.unwrap();
    let mut b = pool.begin().await.unwrap();
    for tx in [&mut a, &mut b] {
        sqlx::raw_sql("SET LOCAL deadlock_timeout='50ms'; SET LOCAL lock_timeout='3s'")
            .execute(&mut **tx)
            .await
            .unwrap();
    }
    sqlx::query("SELECT id FROM orders WHERE id=$1 FOR UPDATE")
        .bind(first)
        .execute(&mut *a)
        .await
        .unwrap();
    sqlx::query("SELECT id FROM orders WHERE id=$1 FOR UPDATE")
        .bind(second)
        .execute(&mut *b)
        .await
        .unwrap();
    let (x, y) = tokio::join!(
        sqlx::query("SELECT id FROM orders WHERE id=$1 FOR UPDATE")
            .bind(second)
            .execute(&mut *a),
        sqlx::query("SELECT id FROM orders WHERE id=$1 FOR UPDATE")
            .bind(first)
            .execute(&mut *b)
    );
    assert_eq!(usize::from(x.is_err()) + usize::from(y.is_err()), 1);
    let error = x.err().or_else(|| y.err()).unwrap();
    assert_eq!(sqlstate(&error).as_deref(), Some("40P01"));
    a.rollback().await.unwrap();
    b.rollback().await.unwrap();
}

#[sqlx::test(migrations = "./migrations/orders")]
async fn serializable_write_skew_requires_whole_transaction_retry(pool: PgPool) {
    // Independent teaching invariant: at least one operator remains on duty.
    sqlx::raw_sql("CREATE TABLE lab_duty(id int PRIMARY KEY,on_duty bool NOT NULL); INSERT INTO lab_duty VALUES(1,true),(2,true)").execute(&pool).await.unwrap();
    let mut a = pool.begin().await.unwrap();
    let mut b = pool.begin().await.unwrap();
    for tx in [&mut a, &mut b] {
        sqlx::query("SET TRANSACTION ISOLATION LEVEL SERIALIZABLE")
            .execute(&mut **tx)
            .await
            .unwrap();
        let count: i64 = sqlx::query_scalar("SELECT count(*) FROM lab_duty WHERE on_duty")
            .fetch_one(&mut **tx)
            .await
            .unwrap();
        assert_eq!(count, 2);
    }
    sqlx::query("UPDATE lab_duty SET on_duty=false WHERE id=1")
        .execute(&mut *a)
        .await
        .unwrap();
    sqlx::query("UPDATE lab_duty SET on_duty=false WHERE id=2")
        .execute(&mut *b)
        .await
        .unwrap();
    let (x, y) = tokio::join!(a.commit(), b.commit());
    assert_eq!(usize::from(x.is_ok()) + usize::from(y.is_ok()), 1);
    assert_eq!(
        sqlstate(&x.err().or_else(|| y.err()).unwrap()).as_deref(),
        Some("40001")
    );
    let count: i64 = sqlx::query_scalar("SELECT count(*) FROM lab_duty WHERE on_duty")
        .fetch_one(&pool)
        .await
        .unwrap();
    assert_eq!(count, 1);
}

#[sqlx::test(migrations = "./migrations/orders")]
async fn waiting_for_pool_capacity_has_no_server_sqlstate(pool: PgPool) {
    let one = PgPoolOptions::new()
        .max_connections(1)
        .acquire_timeout(Duration::from_millis(80))
        .connect_with(pool.connect_options().as_ref().clone())
        .await
        .unwrap();
    let held = one.acquire().await.unwrap();
    let error = one.acquire().await.unwrap_err();
    assert!(matches!(error, sqlx::Error::PoolTimedOut));
    assert!(sqlstate(&error).is_none());
    drop(held);
    sqlx::query("SELECT 1").execute(&one).await.unwrap();
    one.close().await;
}
