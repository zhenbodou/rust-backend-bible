WITH picked AS (
    SELECT id FROM orders
    WHERE state NOT IN ('completed','cancelled','manual')
      AND next_attempt <= statement_timestamp()
      AND (leased_until IS NULL OR leased_until <= statement_timestamp())
    ORDER BY next_attempt,id
    FOR UPDATE SKIP LOCKED
    LIMIT 1
)
UPDATE orders AS o
SET lease_token=$1,
    leased_until=clock_timestamp()+interval '15 seconds',
    attempts=LEAST(o.attempts::bigint+1,1000000)::integer
FROM picked AS p WHERE o.id=p.id
RETURNING o.id,o.actor_id,o.request_key,o.product_id,o.quantity,
          o.unit_price,o.amount,o.state,o.attempts
