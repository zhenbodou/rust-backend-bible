\set ON_ERROR_STOP on
BEGIN READ ONLY;
SET LOCAL statement_timeout='3s';
SELECT current_database(),version(),current_setting('max_connections') AS max_connections;
SELECT state,wait_event_type,wait_event,count(*) AS sessions
FROM pg_stat_activity WHERE datname=current_database()
GROUP BY state,wait_event_type,wait_event ORDER BY sessions DESC;
SELECT pid,application_name,state,wait_event_type,wait_event,
       clock_timestamp()-xact_start AS transaction_age,
       backend_xmin,pg_blocking_pids(pid) AS blockers
FROM pg_stat_activity WHERE datname=current_database() AND pid<>pg_backend_pid()
ORDER BY xact_start NULLS LAST LIMIT 20;
SELECT relname,n_live_tup,n_dead_tup,last_autovacuum,last_autoanalyze,
       pg_size_pretty(pg_total_relation_size(relid)) AS total_size
FROM pg_stat_user_tables ORDER BY pg_total_relation_size(relid) DESC LIMIT 20;
SELECT indexrelname,idx_scan,idx_tup_read,idx_tup_fetch
FROM pg_stat_user_indexes ORDER BY indexrelname;
SELECT to_regclass('public.pg_stat_statements') IS NOT NULL AS has_statements \gset
\if :has_statements
SELECT queryid,calls,round(mean_exec_time::numeric,3) AS mean_ms,
       rows,shared_blks_hit,shared_blks_read,temp_blks_written
FROM pg_stat_statements
WHERE dbid=(SELECT oid FROM pg_database WHERE datname=current_database())
ORDER BY total_exec_time DESC LIMIT 20;
\endif
COMMIT;
