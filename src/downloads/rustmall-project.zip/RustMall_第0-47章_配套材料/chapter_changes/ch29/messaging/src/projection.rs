use crate::event::{Envelope, Snapshot};
use sqlx::{PgPool, types::Json};

#[derive(Debug, PartialEq, Eq)]
pub enum Applied {
    Duplicate,
    Stale,
    Updated,
}
pub async fn apply(pool: &PgPool, consumer: &str, event: &Envelope) -> anyhow::Result<Applied> {
    event.validate()?;
    let hash = event.digest()?;
    let mut tx = pool.begin().await?;
    let inserted=sqlx::query("INSERT INTO consumer_inbox(consumer_name,event_id,payload_hash) VALUES($1,$2,$3) ON CONFLICT DO NOTHING")
        .bind(consumer).bind(event.event_id).bind(&hash).execute(&mut *tx).await?.rows_affected();
    if inserted == 0 {
        let stored: Vec<u8> = sqlx::query_scalar(
            "SELECT payload_hash FROM consumer_inbox WHERE consumer_name=$1 AND event_id=$2",
        )
        .bind(consumer)
        .bind(event.event_id)
        .fetch_one(&mut *tx)
        .await?;
        anyhow::ensure!(stored == hash, "event ID reused with different payload");
        tx.commit().await?;
        return Ok(Applied::Duplicate);
    }
    let changed=sqlx::query("INSERT INTO catalog_view(product_id,revision,payload) VALUES($1,$2,$3) ON CONFLICT(product_id) DO UPDATE SET revision=EXCLUDED.revision,payload=EXCLUDED.payload,updated_at=now() WHERE catalog_view.revision<EXCLUDED.revision")
        .bind(event.aggregate_id).bind(event.revision).bind(Json::<&Snapshot>(&event.payload))
        .execute(&mut *tx).await?.rows_affected();
    if changed == 0 {
        let (revision, payload): (i64, Json<Snapshot>) =
            sqlx::query_as("SELECT revision,payload FROM catalog_view WHERE product_id=$1")
                .bind(event.aggregate_id)
                .fetch_one(&mut *tx)
                .await?;
        anyhow::ensure!(
            revision != event.revision || payload.0 == event.payload,
            "same revision has conflicting snapshot"
        );
    }
    tx.commit().await?;
    Ok(if changed == 1 {
        Applied::Updated
    } else {
        Applied::Stale
    })
}
