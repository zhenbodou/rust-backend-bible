CREATE TABLE consumer_inbox (
   consumer_name TEXT NOT NULL,
   event_id UUID NOT NULL,
   payload_hash BYTEA NOT NULL,
   processed_at TIMESTAMPTZ NOT NULL DEFAULT now(),
   PRIMARY KEY(consumer_name,event_id)
);
CREATE TABLE catalog_view (
   product_id BIGINT PRIMARY KEY,
   revision BIGINT NOT NULL,
   payload JSONB NOT NULL,
   updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
