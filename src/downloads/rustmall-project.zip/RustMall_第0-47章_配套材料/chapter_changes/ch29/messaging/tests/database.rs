use messaging::{
    event::{Envelope, Snapshot},
    projection::{self, Applied},
    store::{self, CommandError, Draft},
};
use sqlx::PgPool;
use uuid::Uuid;

async fn schema(pool: &PgPool) {
    for sql in [
        include_str!("../../services/catalog/migrations/0001_catalog.sql"),
        include_str!("../../services/catalog/migrations/0002_product_outbox.sql"),
        include_str!("../migrations/0001_projection.sql"),
    ] {
        sqlx::raw_sql(sql).execute(pool).await.unwrap();
    }
}
fn draft() -> Draft {
    Draft {
        name: "Rust 键盘".into(),
        price_cents: 19900,
        stock: 10,
    }
}
fn event(revision: i64, listed: bool) -> Envelope {
    Envelope::new(
        Snapshot {
            id: 1,
            name: "Rust 键盘".into(),
            price_cents: 19900,
            stock: 10,
            listed,
        },
        revision,
    )
}

#[sqlx::test(migrations = false)]
async fn failed_outbox_insert_rolls_back_product(pool: PgPool) {
    schema(&pool).await;
    sqlx::raw_sql("ALTER TABLE product_outbox ADD CONSTRAINT reject_events CHECK (revision < 0)")
        .execute(&pool)
        .await
        .unwrap();
    assert!(store::create(&pool, &draft()).await.is_err());
    let count: i64 = sqlx::query_scalar("SELECT count(*) FROM products")
        .fetch_one(&pool)
        .await
        .unwrap();
    assert_eq!(count, 0);
}

#[sqlx::test(migrations = false)]
async fn concurrent_command_replays_one_result(pool: PgPool) {
    schema(&pool).await;
    let key = Uuid::new_v4();
    let input = draft();
    let (a, b) = tokio::join!(
        store::create_once(&pool, 42, key, &input),
        store::create_once(&pool, 42, key, &input)
    );
    let a = a.unwrap();
    let b = b.unwrap();
    assert_eq!(a.event_id, b.event_id);
    let count: i64 = sqlx::query_scalar("SELECT count(*) FROM products")
        .fetch_one(&pool)
        .await
        .unwrap();
    let events: i64 = sqlx::query_scalar("SELECT count(*) FROM product_outbox")
        .fetch_one(&pool)
        .await
        .unwrap();
    assert_eq!((count, events), (1, 1));
    let changed = Draft { stock: 11, ..input };
    assert!(matches!(
        store::create_once(&pool, 42, key, &changed).await,
        Err(CommandError::Conflict)
    ));
}

#[sqlx::test(migrations = false)]
async fn stale_lease_cannot_ack_new_owner(pool: PgPool) {
    schema(&pool).await;
    store::create(&pool, &draft()).await.unwrap();
    let old = store::claim_one(&pool).await.unwrap().unwrap();
    sqlx::query("UPDATE product_outbox SET leased_until=now()-interval '1 second'")
        .execute(&pool)
        .await
        .unwrap();
    let new = store::claim_one(&pool).await.unwrap().unwrap();
    assert_ne!(old.lease_token, new.lease_token);
    assert!(!store::delivered(&pool, &old).await.unwrap());
    assert!(
        store::failed(&pool, &new, "broker unavailable")
            .await
            .unwrap()
    );
    let next: bool = sqlx::query_scalar("SELECT next_attempt_at>now() FROM product_outbox")
        .fetch_one(&pool)
        .await
        .unwrap();
    assert!(next);
}

#[sqlx::test(migrations = false)]
async fn tombstone_and_hash_reject_corruption(pool: PgPool) {
    schema(&pool).await;
    let latest = event(3, false);
    assert_eq!(
        projection::apply(&pool, "view-v1", &latest).await.unwrap(),
        Applied::Updated
    );
    assert_eq!(
        projection::apply(&pool, "view-v1", &latest).await.unwrap(),
        Applied::Duplicate
    );
    assert_eq!(
        projection::apply(&pool, "view-v1", &event(2, true))
            .await
            .unwrap(),
        Applied::Stale
    );
    let mut reused = latest.clone();
    reused.payload.stock = 12;
    assert!(projection::apply(&pool, "view-v1", &reused).await.is_err());
    let conflicting = event(3, true);
    assert!(
        projection::apply(&pool, "view-v1", &conflicting)
            .await
            .is_err()
    );
    let count: i64 = sqlx::query_scalar("SELECT count(*) FROM consumer_inbox")
        .fetch_one(&pool)
        .await
        .unwrap();
    assert_eq!(count, 2); // Conflicting events rolled back their Inbox rows.
    let revision: i64 = sqlx::query_scalar("SELECT revision FROM catalog_view WHERE product_id=1")
        .fetch_one(&pool)
        .await
        .unwrap();
    assert_eq!(revision, 3);
}

#[sqlx::test(migrations = false)]
async fn bootstrap_identity_matches_payload(pool: PgPool) {
    sqlx::raw_sql(include_str!(
        "../../services/catalog/migrations/0001_catalog.sql"
    ))
    .execute(&pool)
    .await
    .unwrap();
    sqlx::raw_sql(
        "INSERT INTO products(name,price_cents,stock) VALUES('旧商品',100,1),('另一件',200,2)",
    )
    .execute(&pool)
    .await
    .unwrap();
    sqlx::raw_sql(include_str!(
        "../../services/catalog/migrations/0002_product_outbox.sql"
    ))
    .execute(&pool)
    .await
    .unwrap();
    let valid:i64=sqlx::query_scalar("SELECT count(*) FROM product_outbox WHERE event_id::text=payload->>'event_id' AND aggregate_id=(payload->>'aggregate_id')::bigint").fetch_one(&pool).await.unwrap();
    assert_eq!(valid, 2);
}
