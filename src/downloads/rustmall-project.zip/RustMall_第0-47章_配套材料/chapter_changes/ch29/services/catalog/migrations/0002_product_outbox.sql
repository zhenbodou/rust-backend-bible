ALTER TABLE products ADD COLUMN revision BIGINT NOT NULL DEFAULT 1 CHECK(revision>0);
CREATE TABLE product_outbox (
   event_id UUID PRIMARY KEY,
   aggregate_id BIGINT NOT NULL,
   revision BIGINT NOT NULL,
   payload JSONB NOT NULL,
   occurred_at TIMESTAMPTZ NOT NULL DEFAULT now(),
   attempts INT NOT NULL DEFAULT 0,
   next_attempt_at TIMESTAMPTZ NOT NULL DEFAULT now(),
   lease_token UUID,
   leased_until TIMESTAMPTZ,
   delivered_at TIMESTAMPTZ,
   last_error TEXT,
   UNIQUE(aggregate_id,revision)
);
CREATE INDEX product_outbox_pending_idx ON product_outbox(next_attempt_at,occurred_at)
   WHERE delivered_at IS NULL;
CREATE TABLE product_create_receipts (
   actor_id BIGINT NOT NULL,
   command_id UUID NOT NULL,
   request_hash BYTEA NOT NULL,
   response JSONB,
   PRIMARY KEY(actor_id,command_id)
);
-- Bootstrap unchanged legacy products from the same transaction as this migration.
INSERT INTO product_outbox(event_id,aggregate_id,revision,payload)
SELECT event_id,id,revision,
       jsonb_build_object('schema_version',1,'kind','product.snapshot.v1',
         'event_id',event_id,'aggregate_id',id,'revision',revision,
         'occurred_at_unix_ms',(extract(epoch FROM now())*1000)::bigint,
         'payload',jsonb_build_object('id',id,'name',name,'price_cents',price_cents,
           'stock',stock,'listed',delisted_at IS NULL))
FROM (SELECT p.*,gen_random_uuid() AS event_id FROM products p) AS snapshots;
