use anyhow::{Context, ensure};
use contracts::catalog::{catalog_client::CatalogClient, *};
use std::time::Duration;
use tonic::metadata::{Ascii, MetadataValue};
use tonic::transport::Endpoint;
use tonic::{Code, Request};

fn request<T>(value: T, key: &MetadataValue<Ascii>) -> Request<T> {
    let mut request = Request::new(value);
    request.set_timeout(Duration::from_secs(1));
    request
        .metadata_mut()
        .insert("x-rustmall-service-token", key.clone());
    request
}

#[tokio::main]
async fn main() -> anyhow::Result<()> {
    let arguments: Vec<String> = std::env::args().skip(1).collect();
    let expect_unauthenticated = match arguments.as_slice() {
        [] => false,
        [flag] if flag == "--expect-unauthenticated" => true,
        _ => anyhow::bail!("usage: smoke [--expect-unauthenticated]"),
    };
    let endpoint = std::env::var("RUSTMALL_CATALOG_ENDPOINT")
        .unwrap_or_else(|_| "http://127.0.0.1:50051".into());
    let key: MetadataValue<Ascii> = std::env::var("RUSTMALL_CATALOG_TOKEN")
        .context("catalog token missing")?
        .parse()
        .context("token is not valid metadata")?;
    let channel = Endpoint::from_shared(endpoint)?
        .connect_timeout(Duration::from_secs(2))
        .timeout(Duration::from_secs(2))
        .connect()
        .await?;
    let mut health = tonic_health::pb::health_client::HealthClient::new(channel.clone());
    tokio::time::timeout(Duration::from_secs(3), async {
        loop {
            let reply = health
                .check(Request::new(tonic_health::pb::HealthCheckRequest {
                    service: "readiness".into(),
                }))
                .await?
                .into_inner();
            if reply.status
                == tonic_health::pb::health_check_response::ServingStatus::Serving as i32
            {
                break;
            }
            tokio::time::sleep(Duration::from_millis(100)).await;
        }
        Ok::<_, tonic::Status>(())
    })
    .await
    .context("readiness did not become serving")??;
    let mut client = CatalogClient::new(channel);
    if expect_unauthenticated {
        let error = client
            .get_product(request(GetProductRequest { id: 1 }, &key))
            .await
            .expect_err("wrong identity must not succeed");
        ensure!(error.code() == Code::Unauthenticated);
        println!("PASS identity rejection code={}", error.code() as i32);
        return Ok(());
    }
    let created = client
        .create_product(request(
            CreateProductRequest {
                name: "  章节验证键盘  ".into(),
                price_cents: 19_900,
                stock: 10,

                idempotency_key: String::new(),
                actor_id: 0,
            },
            &key,
        ))
        .await?
        .into_inner();
    ensure!(created.id > 0 && created.name == "章节验证键盘");
    ensure!(created.price_cents == 19_900 && created.stock == 10);
    let found = client
        .get_product(request(GetProductRequest { id: created.id }, &key))
        .await?
        .into_inner();
    ensure!(found == created);
    let page = client
        .list_products(request(
            ListProductsRequest {
                limit: 2,
                offset: 0,
            },
            &key,
        ))
        .await?
        .into_inner();
    ensure!(page.total >= 1 && page.items.len() <= 2);
    let updated = client
        .update_product(request(
            UpdateProductRequest {
                id: created.id,
                name: "静音章节键盘".into(),
                price_cents: 20_000,
                stock: 8,
            },
            &key,
        ))
        .await?
        .into_inner();
    ensure!(updated.name == "静音章节键盘" && updated.price_cents == 20_000 && updated.stock == 8);
    client
        .delist_product(request(GetProductRequest { id: created.id }, &key))
        .await?;
    let error = client
        .get_product(request(GetProductRequest { id: created.id }, &key))
        .await
        .expect_err("delisted product must be invisible");
    ensure!(error.code() == Code::NotFound);
    println!("PASS catalog create/get/list/update/delist; integer money and status preserved");
    Ok(())
}
