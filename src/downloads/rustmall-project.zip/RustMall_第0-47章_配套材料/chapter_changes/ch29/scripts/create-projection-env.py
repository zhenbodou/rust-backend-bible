"""本地投影库配置；只创建新文件，不打印秘密。"""
import os
import secrets

password = secrets.token_urlsafe(36)
values = {
    "POSTGRES_PASSWORD": password,
    "PROJECTION_DATABASE_URL": f"postgres://rustmall:{password}@127.0.0.1:55435/rustmall_projection",
    "CONSUMER_NAME": "catalog-view-v1",
}
fd = os.open(".env.projection.local", os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
with os.fdopen(fd, "w") as output:
    for key, value in values.items():
        output.write(f"{key}={value}\n")
print("已生成 .env.projection.local；未输出秘密。")
