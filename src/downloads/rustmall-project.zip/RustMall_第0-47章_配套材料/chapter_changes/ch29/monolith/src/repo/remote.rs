use super::ProductRepository;
use common::error::{DomainError, DomainResult, ValidationError};
use common::ids::ProductId;
use common::product::{NewProduct, Product};
use contracts::catalog::{self as wire, catalog_client::CatalogClient};
use std::time::Duration;
use tonic::{
    Code, Request, Status,
    metadata::MetadataValue,
    transport::{Channel, Endpoint},
};

#[derive(Clone)]
pub struct RemoteProductRepo {
    client: CatalogClient<Channel>,
    health: tonic_health::pb::health_client::HealthClient<Channel>,
    key: MetadataValue<tonic::metadata::Ascii>,
}
impl RemoteProductRepo {
    pub async fn connect(endpoint: &str, key: &str) -> anyhow::Result<Self> {
        anyhow::ensure!(
            key.len() >= 32 && key.bytes().all(|byte| byte.is_ascii_graphic()),
            "catalog token must be >=32 visible ASCII bytes"
        );
        let channel = Endpoint::from_shared(endpoint.to_string())?
            .connect_timeout(Duration::from_secs(2))
            .timeout(Duration::from_secs(1))
            .connect()
            .await?;
        Ok(Self {
            client: CatalogClient::new(channel.clone()),
            health: tonic_health::pb::health_client::HealthClient::new(channel),
            key: key.parse()?,
        })
    }
    pub async fn insert_once(
        &self,
        actor: i64,
        key: uuid::Uuid,
        draft: &NewProduct,
    ) -> DomainResult<Product> {
        let response = self
            .client
            .clone()
            .create_product(self.request(wire::CreateProductRequest {
                name: draft.name().into(),
                price_cents: draft.price_cents(),
                stock: draft.stock(),
                actor_id: actor,
                idempotency_key: key.to_string(),
            }))
            .await
            .map_err(|e| map_status(e, None))?;
        decode(response.into_inner())
    }
    pub async fn is_ready(&self) -> bool {
        let result = self
            .health
            .clone()
            .check(self.request(tonic_health::pb::HealthCheckRequest {
                service: "readiness".into(),
            }))
            .await;
        matches!(result, Ok(reply) if reply.get_ref().status ==
            tonic_health::pb::health_check_response::ServingStatus::Serving as i32)
    }
    fn request<T>(&self, value: T) -> Request<T> {
        let mut request = Request::new(value);
        request.set_timeout(Duration::from_secs(1));
        request
            .metadata_mut()
            .insert("x-rustmall-service-token", self.key.clone());
        request
    }
}
fn decode(value: wire::Product) -> DomainResult<Product> {
    Product::try_new(
        ProductId::new(value.id),
        &value.name,
        value.price_cents,
        value.stock,
    )
    .map_err(|_| DomainError::Internal("catalog returned invalid product".into()))
}
fn map_status(error: Status, id: Option<ProductId>) -> DomainError {
    match error.code() {
        Code::NotFound => match id {
            Some(id) => DomainError::not_found("商品", id),
            None => DomainError::Internal("unexpected catalog NotFound".into()),
        },
        Code::InvalidArgument => ValidationError::Format {
            field: "product",
            reason: error.message().to_string(),
        }
        .into(),
        Code::AlreadyExists | Code::FailedPrecondition => {
            DomainError::Conflict(error.message().to_string())
        }
        _ => DomainError::Internal(format!("catalog RPC failed: {}", error.code())),
    }
}
impl ProductRepository for RemoteProductRepo {
    async fn insert(&self, draft: &NewProduct) -> DomainResult<Product> {
        let response = self
            .client
            .clone()
            .create_product(self.request(wire::CreateProductRequest {
                name: draft.name().into(),
                price_cents: draft.price_cents(),
                stock: draft.stock(),
                idempotency_key: String::new(),
                actor_id: 0,
            }))
            .await
            .map_err(|e| map_status(e, None))?;
        decode(response.into_inner())
    }
    async fn get(&self, id: ProductId) -> DomainResult<Product> {
        let response = self
            .client
            .clone()
            .get_product(self.request(wire::GetProductRequest { id: id.get() }))
            .await
            .map_err(|e| map_status(e, Some(id)))?;
        decode(response.into_inner())
    }
    async fn list(&self, limit: i64, offset: i64) -> DomainResult<(Vec<Product>, i64)> {
        let page = self
            .client
            .clone()
            .list_products(self.request(wire::ListProductsRequest { limit, offset }))
            .await
            .map_err(|e| map_status(e, None))?
            .into_inner();
        if page.total < 0 {
            return Err(DomainError::Internal("invalid catalog total".into()));
        }
        let items = page
            .items
            .into_iter()
            .map(decode)
            .collect::<DomainResult<_>>()?;
        Ok((items, page.total))
    }
    async fn update(&self, product: &Product) -> DomainResult<Product> {
        let response = self
            .client
            .clone()
            .update_product(self.request(wire::UpdateProductRequest {
                id: product.id().get(),
                name: product.name().into(),
                price_cents: product.price_cents(),
                stock: product.stock(),
            }))
            .await
            .map_err(|e| map_status(e, Some(product.id())))?;
        decode(response.into_inner())
    }
    async fn delist(&self, id: ProductId) -> DomainResult<()> {
        self.client
            .clone()
            .delist_product(self.request(wire::GetProductRequest { id: id.get() }))
            .await
            .map_err(|e| map_status(e, Some(id)))?;
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    #![allow(clippy::unwrap_used)]
    use super::*;
    use common::error::ErrorKind;
    #[test]
    fn not_found_retains_the_public_id() {
        let error = map_status(
            Status::not_found("different internal text"),
            Some(ProductId::new(42)),
        );
        assert_eq!(error.kind(), ErrorKind::NotFound);
        assert_eq!(error.to_string(), "商品 42 不存在");
    }
    #[test]
    fn service_auth_failure_is_not_end_user_unauthorized() {
        let error = map_status(Status::unauthenticated("wrong internal token"), None);
        assert_eq!(error.kind(), ErrorKind::Internal);
    }
    #[test]
    fn invalid_remote_data_is_never_a_valid_product() {
        assert!(
            decode(wire::Product {
                id: 1,
                name: "键盘".into(),
                price_cents: -1,
                stock: 1
            })
            .is_err()
        );
    }
}
