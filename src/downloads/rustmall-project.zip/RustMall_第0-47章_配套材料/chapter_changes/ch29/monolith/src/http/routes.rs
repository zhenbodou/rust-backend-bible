//! 路由表与全局中间件。

use axum::extract::{DefaultBodyLimit, Request};
use axum::http::{HeaderName, HeaderValue, Method, StatusCode, header};
use axum::routing::{get, post};
use axum::{Json, Router};
use tower::ServiceBuilder;
use tower_http::cors::{AllowOrigin, CorsLayer};
use tower_http::request_id::{MakeRequestUuid, PropagateRequestIdLayer, SetRequestIdLayer};
use tower_http::trace::{DefaultOnResponse, TraceLayer};
use tracing::Level;

use crate::http::error::ErrorBody;
use crate::http::{auth, health, product_commands, products};
use crate::settings::CorsSettings;
use crate::state::AppState;

/// 请求体大小上限：64 KB。商品、订单等 JSON 请求远小于这个值。
pub const MAX_BODY_BYTES: usize = 64 * 1024;

/// 请求 ID 所在的请求头 / 响应头。
const REQUEST_ID: HeaderName = HeaderName::from_static("x-request-id");

/// 构建完整的应用路由。测试与 main 共用同一个函数，保证测试的就是线上的路由。
pub fn router(state: AppState, cors: &CorsSettings) -> Router {
    let products_route = if state.catalog_commands.is_some() {
        get(products::list).post(product_commands::create)
    } else {
        get(products::list).post(products::create)
    };
    let api = Router::new()
        .route("/auth/register", post(auth::register))
        .route("/auth/login", post(auth::login))
        .route("/users/me", get(auth::me))
        .route("/products", products_route)
        .route(
            "/products/{id}",
            get(products::get_one)
                .put(products::update)
                .delete(products::remove),
        );

    // ServiceBuilder 中写在上面的层在外层，请求按从上到下的顺序经过
    let middleware = ServiceBuilder::new()
        // 1. 生成请求 ID（请求已带 x-request-id 时保留原值）
        .layer(SetRequestIdLayer::new(REQUEST_ID, MakeRequestUuid))
        // 2. 为每个请求创建 span，并记录响应状态与耗时
        .layer(
            TraceLayer::new_for_http()
                .make_span_with(make_span)
                .on_response(DefaultOnResponse::new().level(Level::INFO)),
        )
        // 3. 把请求 ID 写回响应头
        .layer(PropagateRequestIdLayer::new(REQUEST_ID))
        // 4. 跨域
        .layer(cors_layer(cors))
        // 5. 请求体大小限制
        .layer(DefaultBodyLimit::max(MAX_BODY_BYTES));

    Router::new()
        .route("/health/live", get(health::live))
        .route("/health/ready", get(health::ready))
        .nest("/api/v1", api)
        .fallback(not_found)
        .layer(middleware)
        .with_state(state)
}

/// 请求 span：方法、路径与请求 ID。之后该请求内产生的所有日志都带有这些字段。
fn make_span(request: &Request) -> tracing::Span {
    let request_id = request
        .headers()
        .get(&REQUEST_ID)
        .and_then(|v| v.to_str().ok())
        .unwrap_or("-");
    tracing::info_span!("http", method = %request.method(), uri = %request.uri(), request_id)
}

/// 按配置构造 CORS 中间件：只允许列出的来源。
fn cors_layer(settings: &CorsSettings) -> CorsLayer {
    let origins: Vec<HeaderValue> = settings
        .allowed_origins
        .iter()
        .filter_map(|origin| match origin.parse() {
            Ok(value) => Some(value),
            Err(_) => {
                tracing::warn!(%origin, "忽略无法解析的 CORS 来源");
                None
            }
        })
        .collect();

    CorsLayer::new()
        .allow_origin(AllowOrigin::list(origins))
        .allow_methods([Method::GET, Method::POST, Method::PUT, Method::DELETE])
        .allow_headers([
            header::CONTENT_TYPE,
            header::AUTHORIZATION,
            HeaderName::from_static("idempotency-key"),
        ])
        // 让前端 JavaScript 能读取这两个响应头
        .expose_headers([REQUEST_ID, header::LOCATION])
}

/// 未匹配任何路由时，也返回统一格式的错误。
async fn not_found() -> (StatusCode, Json<ErrorBody>) {
    let body = ErrorBody {
        code: "NOT_FOUND",
        message: "接口不存在".to_string(),
    };
    (StatusCode::NOT_FOUND, Json(body))
}
