use crate::{
    http::{auth::AdminUser, error::ApiError, extract::AppJson},
    state::AppState,
};
use axum::{
    extract::State,
    http::{HeaderMap, HeaderName, StatusCode},
};
use common::{
    error::{DomainError, ValidationError},
    product::{NewProduct, Product},
};
use serde::Deserialize;
use uuid::Uuid;

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
pub struct CreateInput {
    name: String,
    price_cents: i64,
    stock: i32,
}
pub async fn create(
    State(state): State<AppState>,
    admin: AdminUser,
    headers: HeaderMap,
    AppJson(input): AppJson<CreateInput>,
) -> Result<(StatusCode, [(HeaderName, String); 1], AppJson<Product>), ApiError> {
    if headers.get_all("idempotency-key").iter().count() != 1 {
        return Err(ApiError::BadRequest(
            "必须提供一个 Idempotency-Key 请求头".into(),
        ));
    }
    let key = headers
        .get("idempotency-key")
        .and_then(|v| v.to_str().ok())
        .and_then(|v| Uuid::parse_str(v).ok())
        .ok_or_else(|| ApiError::BadRequest("Idempotency-Key 必须为 UUID".into()))?;
    let draft =
        NewProduct::try_new(&input.name, input.price_cents, input.stock).map_err(|reason| {
            DomainError::from(ValidationError::Format {
                field: "product",
                reason,
            })
        })?;
    let catalog = state
        .catalog_commands
        .as_ref()
        .ok_or_else(|| DomainError::Internal("幂等商品命令要求远程 catalog 模式".into()))?;
    let product = catalog.insert_once(admin.0.id.get(), key, &draft).await?;
    let location = format!("/api/v1/products/{}", product.id());
    Ok((
        StatusCode::CREATED,
        [(HeaderName::from_static("location"), location)],
        AppJson(product),
    ))
}
