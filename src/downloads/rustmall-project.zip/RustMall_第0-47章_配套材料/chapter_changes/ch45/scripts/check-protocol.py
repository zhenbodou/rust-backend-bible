"""Run the finite protocol explorer in the actual delivered image, without network.

These are bounded model results/negative controls, not a SQL or liveness proof.
No database URL, user credential, host socket or volume is given to the process.
"""
from pathlib import Path
import argparse,json,subprocess
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--image',default='rustmall/book:ch45-candidate')
p.add_argument('--report-dir',type=Path,required=True)
a=p.parse_args();a.report_dir.mkdir(parents=True,exist_ok=False)
report={'success':False,'checks':[],'scope':'one-order finite model with production pure decisions; normal bounds18steps/5claims/2workers, not database/network/restore/liveness proof'}
try:
 image=subprocess.run(['docker','image','inspect',a.image],capture_output=True,text=True,check=True)
 report['image_id']=json.loads(image.stdout)[0]['Id']
 for mode in ['normal','declined','empty','new-payment-identity','missing-lease-guard','missing-token-guard']:
  command=['docker','run','--rm','--network','none','--read-only','--user','10001:10001','--cap-drop','ALL','--security-opt','no-new-privileges:true','--memory','128m','--pids-limit','32','--entrypoint','/app/protocol-lab',a.image]
  if mode!='normal':command.append(mode)
  result=subprocess.run(command,capture_output=True,text=True,timeout=30,check=True)
  value=json.loads(result.stdout)
  expected=mode in ['normal','declined','empty']
  assert value['safe_within_bounds']==expected
  if expected:
   assert not value['counterexample'] and value['checked_states']==value['discovered_states']
   if mode=='normal':assert value['completed_states']>0 and value['refunded_cancelled_states']>0
   else:assert value['cancelled_states']>0 and value['completed_states']==0
  else:assert value['counterexample'] and value['violation']
  (a.report_dir/(mode+'.json')).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
  report['checks'].append({'mode':mode,'discovered':value['discovered_states'],'checked':value['checked_states'],'safe_within_bounds':value['safe_within_bounds'],'counterexample_length':len(value['counterexample'])})
 report['success']=True
finally:(a.report_dir/'result.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(report,ensure_ascii=False,indent=2))
