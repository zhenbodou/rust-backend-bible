//! Bounded teaching explorer, not a database/network simulator or a formal proof.
//! Calls production participant/coordinator decision functions. SQL atomicity,
//! immutable request binding and stable storage are assumptions checked separately.
use crate::{orders, payments};
use inventory::model::{self, Action as StockAction, State as StockState, Step};
use serde::Serialize;
use std::collections::{HashMap, VecDeque};

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize)]
#[serde(rename_all = "snake_case")]
pub enum Mutation {
    None,
    NewPaymentIdentity,
    MissingLeaseGuard,
    MissingTokenGuard,
}
#[derive(Debug, Clone, Copy)]
pub struct Limits {
    pub depth: usize,
    pub claims: u8,
    pub states: usize,
}
#[derive(Debug, Clone, Copy)]
pub struct Scenario {
    pub initial_stock: i8,
    pub amount: i64,
}
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
struct Flight {
    token: u8,
    step: &'static str,
    reply: Option<&'static str>,
}
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
struct World {
    coordinator: &'static str,
    stock: i8,
    inventory: u8,
    payment: u8,
    paid_effects: u8,
    refund_effects: u8,
    lease: Option<u8>,
    lease_live: bool,
    claims: u8,
    flights: [Option<Flight>; 2],
    external_release_used: bool,
    accepted_stale_write: bool,
}
#[derive(Debug, Serialize)]
pub struct Report {
    pub mutation: Mutation,
    pub max_depth: usize,
    pub max_claims: u8,
    pub discovered_states: usize,
    pub checked_states: usize,
    pub claim_frontier: usize,
    pub explored_edges: usize,
    pub depth_frontier: usize,
    pub completed_states: usize,
    pub cancelled_states: usize,
    pub refunded_cancelled_states: usize,
    pub safe_within_bounds: bool,
    pub violation: Option<String>,
    pub counterexample: Vec<String>,
    pub scope: &'static str,
}
fn inventory(code: u8) -> StockState {
    match code {
        0 => StockState::Pending,
        1 => StockState::Held,
        2 => StockState::Confirmed,
        3 => StockState::Released,
        4 => StockState::Rejected,
        _ => unreachable!(),
    }
}
fn stock_code(state: StockState) -> u8 {
    match state {
        StockState::Pending => 0,
        StockState::Held => 1,
        StockState::Confirmed => 2,
        StockState::Released => 3,
        StockState::Rejected => 4,
    }
}
fn payment(code: u8) -> payments::State {
    match code {
        1 => payments::State::Paid,
        2 => payments::State::Declined,
        3 => payments::State::Refunded,
        _ => unreachable!(),
    }
}
fn pay_code(state: payments::State) -> u8 {
    match state {
        payments::State::Paid => 1,
        payments::State::Declined => 2,
        payments::State::Refunded => 3,
    }
}
impl World {
    fn initial(s: Scenario) -> Self {
        Self {
            coordinator: "reserving",
            stock: s.initial_stock,
            inventory: 0,
            payment: 0,
            paid_effects: 0,
            refund_effects: 0,
            lease: None,
            lease_live: false,
            claims: 0,
            flights: [None, None],
            external_release_used: false,
            accepted_stale_write: false,
        }
    }
    fn terminal(&self) -> bool {
        matches!(self.coordinator, "completed" | "cancelled" | "manual")
    }
    fn owned(&self, f: Flight) -> bool {
        self.lease == Some(f.token) && self.lease_live && self.coordinator == f.step
    }
    fn stock_action(&mut self, action: StockAction) {
        self.inventory = match model::decide(inventory(self.inventory), action) {
            Step::TryHold if self.stock >= 1 => {
                self.stock -= 1;
                stock_code(StockState::Held)
            }
            Step::TryHold => stock_code(StockState::Rejected),
            Step::GiveBack => {
                self.stock += 1;
                stock_code(StockState::Released)
            }
            Step::Store(state) => stock_code(state),
        };
    }
    fn invoke(&mut self, f: Flight, s: Scenario, m: Mutation) -> &'static str {
        let outcome = match f.step {
            "reserving" | "confirming" | "releasing" => {
                let action = match f.step {
                    "reserving" => StockAction::Reserve,
                    "confirming" => StockAction::Confirm,
                    _ => StockAction::Release,
                };
                self.stock_action(action);
                orders::inventory_outcome(f.step, inventory(self.inventory))
            }
            "charging" | "refunding" => {
                let action = if f.step == "charging" {
                    payments::Action::Charge
                } else {
                    payments::Action::Refund
                };
                let first = self.payment == 0
                    || (m == Mutation::NewPaymentIdentity && action == payments::Action::Charge);
                let next = if first {
                    payments::initial(s.amount, action)
                } else {
                    payments::next(payment(self.payment), action)
                };
                if first && action == payments::Action::Charge && next == payments::State::Paid {
                    self.paid_effects += 1;
                }
                if !first && self.payment == 1 && next == payments::State::Refunded {
                    self.refund_effects += 1;
                }
                self.payment = pay_code(next);
                orders::payment_outcome(f.step, next)
            }
            _ => unreachable!(),
        };
        match outcome {
            orders::Outcome::Advance(next, _) => next,
            orders::Outcome::Retry(_) => unreachable!(),
        }
    }
    fn violation(&self, s: Scenario) -> Option<&'static str> {
        if self.accepted_stale_write {
            return Some("stale or expired coordinator write accepted");
        }
        if self.paid_effects > 1 {
            return Some("more than one paid effect for one logical order");
        }
        if self.refund_effects > self.paid_effects {
            return Some("refund effect without prior paid effect");
        }
        let held = i8::from(matches!(self.inventory, 1 | 2));
        if self.stock < 0 || self.stock + held != s.initial_stock {
            return Some("inventory conservation violated");
        }
        if self.coordinator == "completed"
            && !(self.inventory == 2
                && self.payment == 1
                && self.paid_effects == 1
                && self.refund_effects == 0)
        {
            return Some("completed order lacks paid and confirmed participants");
        }
        if self.coordinator == "cancelled" && (self.payment == 1 || self.inventory == 1) {
            return Some("cancelled order retains payment or held inventory");
        }
        None
    }
    fn successors(self, s: Scenario, m: Mutation, limit: Limits) -> Vec<(String, Self)> {
        let mut result = Vec::new();
        if self.lease.is_some() && self.lease_live {
            let mut n = self;
            n.lease_live = false;
            result.push(("lease expires; old process is NOT killed".into(), n));
        }
        if !self.external_release_used {
            let mut n = self;
            n.external_release_used = true;
            n.stock_action(StockAction::Release);
            result.push((
                "one authorized external release (environment action)".into(),
                n,
            ));
        }
        for worker in 0..2 {
            match self.flights[worker] {
                None if !self.terminal()
                    && (!self.lease_live || self.lease.is_none())
                    && self.claims < limit.claims =>
                {
                    let mut n = self;
                    n.claims += 1;
                    n.lease = Some(n.claims);
                    n.lease_live = true;
                    n.flights[worker] = Some(Flight {
                        token: n.claims,
                        step: n.coordinator,
                        reply: None,
                    });
                    result.push((
                        format!("worker{worker} claims {} token{}", n.coordinator, n.claims),
                        n,
                    ));
                }
                Some(f) => {
                    let mut crash = self;
                    crash.flights[worker] = None;
                    result.push((
                        format!("worker{worker} crashes; participant commits are retained"),
                        crash,
                    ));
                    let mut n = self;
                    let next = n.invoke(f, s, m);
                    if f.reply.is_none() {
                        n.flights[worker] = Some(Flight {
                            reply: Some(next),
                            ..f
                        });
                    }
                    result.push((
                        format!(
                            "worker{worker} invokes {} (same reply retained on duplicate)",
                            f.step
                        ),
                        n,
                    ));
                    if let Some(next) = f.reply {
                        let mut n = self;
                        n.flights[worker] = None;
                        if n.owned(f)
                            || (m == Mutation::MissingLeaseGuard && n.coordinator == f.step)
                            || (m == Mutation::MissingTokenGuard
                                && n.lease_live
                                && n.coordinator == f.step)
                        {
                            if !n.owned(f) {
                                n.accepted_stale_write = true;
                            }
                            if orders::allowed(f.step, next) {
                                n.coordinator = next;
                                n.lease = None;
                                n.lease_live = false;
                            }
                        }
                        result.push((
                            format!("worker{worker} delivers reply: {} -> {next}", f.step),
                            n,
                        ));
                        let mut lost = self;
                        lost.flights[worker] = None;
                        if lost.owned(f) {
                            lost.lease = None;
                            lost.lease_live = false;
                        }
                        result.push((
                            format!(
                                "worker{worker} loses reply; owned attempt defers, no rollback"
                            ),
                            lost,
                        ));
                    }
                }
                _ => {}
            }
        }
        result
    }
}
/// Complete exploration only of the explicitly bounded graph. Node-budget exhaustion
/// returns an error; it is never reported as a successful safety result.
pub fn explore(s: Scenario, m: Mutation, limit: Limits) -> anyhow::Result<Report> {
    anyhow::ensure!(
        (0..=1).contains(&s.initial_stock) && (1..=100_000_000).contains(&s.amount),
        "invalid model scenario"
    );
    anyhow::ensure!(
        (1..=32).contains(&limit.depth)
            && (1..=6).contains(&limit.claims)
            && (1..=1_000_000).contains(&limit.states),
        "invalid bounded model limits"
    );
    let initial = World::initial(s);
    let mut nodes = vec![(initial, 0_usize, None::<(usize, String)>)];
    let mut seen = HashMap::from([(initial, 0)]);
    let mut queue = VecDeque::from([0]);
    let mut report = Report {
        mutation: m,
        max_depth: limit.depth,
        max_claims: limit.claims,
        discovered_states: 0,
        checked_states: 0,
        claim_frontier: 0,
        explored_edges: 0,
        depth_frontier: 0,
        completed_states: 0,
        cancelled_states: 0,
        refunded_cancelled_states: 0,
        safe_within_bounds: true,
        violation: None,
        counterexample: Vec::new(),
        scope: "one logical order, one product0/1stock, two workers, bounded unique leases/RPCs, atomic durable participant steps, optional one external release; no clock rollback, unbounded delayed copies, multiple products/orders, SQL/network/restore proof or liveness proof",
    };
    while let Some(index) = queue.pop_front() {
        report.checked_states += 1;
        let (world, depth, _) = &nodes[index];
        let world = *world;
        let depth = *depth;
        if let Some(error) = world.violation(s) {
            report.safe_within_bounds = false;
            report.violation = Some(error.into());
            let mut cursor = index;
            while let Some((parent, label)) = &nodes[cursor].2 {
                report.counterexample.push(label.clone());
                cursor = *parent;
            }
            report.counterexample.reverse();
            break;
        }
        if world.coordinator == "completed" {
            report.completed_states += 1;
        }
        if world.coordinator == "cancelled" {
            report.cancelled_states += 1;
            if world.payment == 3 {
                report.refunded_cancelled_states += 1;
            }
        }
        if world.claims == limit.claims
            && !world.terminal()
            && (!world.lease_live || world.lease.is_none())
            && world.flights.iter().any(Option::is_none)
        {
            report.claim_frontier += 1;
        }
        if depth == limit.depth {
            report.depth_frontier += 1;
            continue;
        }
        for (label, next) in world.successors(s, m, limit) {
            report.explored_edges += 1;
            if seen.contains_key(&next) {
                continue;
            }
            anyhow::ensure!(
                nodes.len() < limit.states,
                "model node budget exhausted; no safety conclusion"
            );
            let next_index = nodes.len();
            seen.insert(next, next_index);
            nodes.push((next, depth + 1, Some((index, label))));
            queue.push_back(next_index);
        }
    }
    report.discovered_states = nodes.len();
    Ok(report)
}
#[cfg(test)]
mod tests {
    use super::*;
    fn limits() -> Limits {
        Limits {
            depth: 18,
            claims: 5,
            states: 250_000,
        }
    }
    #[test]
    fn production_decisions_preserve_safety_and_reach_both_settlements() {
        let r = explore(
            Scenario {
                initial_stock: 1,
                amount: 100,
            },
            Mutation::None,
            limits(),
        )
        .unwrap();
        assert!(r.safe_within_bounds);
        assert!(r.completed_states > 0);
        assert!(r.refunded_cancelled_states > 0);
    }
    #[test]
    fn out_of_stock_and_payment_decline_can_cancel_safely() {
        for s in [
            Scenario {
                initial_stock: 0,
                amount: 100,
            },
            Scenario {
                initial_stock: 1,
                amount: 600_000,
            },
        ] {
            let r = explore(s, Mutation::None, limits()).unwrap();
            assert!(r.safe_within_bounds);
            assert!(r.cancelled_states > 0);
            assert_eq!(r.completed_states, 0);
        }
    }
    #[test]
    fn a_new_payment_identity_on_retry_has_a_short_counterexample() {
        let r = explore(
            Scenario {
                initial_stock: 1,
                amount: 100,
            },
            Mutation::NewPaymentIdentity,
            limits(),
        )
        .unwrap();
        assert!(!r.safe_within_bounds);
        assert!(r.violation.unwrap().contains("paid effect"));
        assert!(!r.counterexample.is_empty());
    }
    #[test]
    fn removing_the_coordinator_guard_accepts_a_stale_write() {
        let r = explore(
            Scenario {
                initial_stock: 1,
                amount: 100,
            },
            Mutation::MissingLeaseGuard,
            limits(),
        )
        .unwrap();
        assert!(!r.safe_within_bounds);
        assert!(r.violation.unwrap().contains("stale"));
    }
    #[test]
    fn insufficient_node_budget_is_an_error_not_a_green_report() {
        assert!(
            explore(
                Scenario {
                    initial_stock: 1,
                    amount: 100
                },
                Mutation::None,
                Limits {
                    states: 1,
                    ..limits()
                }
            )
            .is_err()
        );
    }
    #[test]
    fn keeping_expiry_but_ignoring_owner_still_accepts_a_replaced_token() {
        let r = explore(
            Scenario {
                initial_stock: 1,
                amount: 100,
            },
            Mutation::MissingTokenGuard,
            limits(),
        )
        .unwrap();
        assert!(!r.safe_within_bounds);
        assert!(r.violation.unwrap().contains("stale"));
        assert!(
            r.counterexample
                .iter()
                .filter(|line| line.contains("claims"))
                .count()
                >= 2
        );
    }
}
