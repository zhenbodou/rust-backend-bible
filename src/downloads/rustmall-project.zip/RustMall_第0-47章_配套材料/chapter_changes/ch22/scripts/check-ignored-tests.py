"""拒绝把没有选中任何 ignored 测试的执行计划当作通过。"""
import re
import subprocess
import sys

for target in ["pg_container", "product_cache"]:
    result = subprocess.run(
        ["cargo", "test", "--locked", "-p", "monolith", "--test", target,
         "--", "--ignored", "--list"],
        text=True, capture_output=True, check=False,
    )
    if result.returncode:
        # 编译器原始诊断保留到 CI 日志；不读取或输出环境变量。
        sys.stdout.write(result.stdout)
        sys.stderr.write(result.stderr)
        raise SystemExit(result.returncode)
    tests = [line for line in result.stdout.splitlines()
             if re.fullmatch(r".+: test", line)]
    if not tests:
        print(f"FAIL {target}: 没有选中 ignored 测试", file=sys.stderr)
        raise SystemExit(1)
    print(f"PASS {target}: 已发现 {len(tests)} 个 ignored 测试")
