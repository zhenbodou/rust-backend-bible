#!/usr/bin/env bash
set -euo pipefail

# 这个脚本只用于一次性 GitHub 托管 runner；不用它清理个人开发环境。
[[ "${CI:-}" == true && "${GITHUB_ACTIONS:-}" == true ]] || {
  echo '请在 GitHub Actions 的临时 runner 中执行。' >&2
  exit 2
}
[[ "${GITHUB_RUN_ID:-}" =~ ^[0-9]+$ && "${GITHUB_RUN_ATTEMPT:-}" =~ ^[0-9]+$ ]] || {
  echo '缺少有效的运行编号。' >&2
  exit 2
}
[[ -n "${GITHUB_OUTPUT:-}" ]] || { echo '缺少步骤输出文件。' >&2; exit 2; }
project="rustmall-ci-${GITHUB_RUN_ID}-${GITHUB_RUN_ATTEMPT}"
compose=(docker compose -p "$project" --env-file compose.dev.env)

# 生成失败时不接管已有文件，也不对已有项目执行清理。
python3 scripts/create-compose-env.py
cleanup() {
  local result=$?
  trap - EXIT
  "${compose[@]}" ps --all || true
  if ! "${compose[@]}" down --volumes --remove-orphans; then
    echo '临时 Compose 资源清理失败。' >&2
    if [[ "$result" == 0 ]]; then result=1; fi
  fi
  if ! rm -f compose.dev.env; then
    echo '临时凭据文件清理失败。' >&2
    if [[ "$result" == 0 ]]; then result=1; fi
  fi
  exit "$result"
}
trap cleanup EXIT

"${compose[@]}" config --quiet
"${compose[@]}" up -d --wait --wait-timeout 90 postgres redis
"${compose[@]}" build app
tested_id=$(docker image inspect rustmall-monolith:ch21 --format '{{.Id}}')
[[ "$tested_id" =~ ^sha256:[0-9a-f]{64}$ ]]
"${compose[@]}" up -d --no-deps --no-build --pull never --wait --wait-timeout 90 app
container_id=$("${compose[@]}" ps -q app)
[[ -n "$container_id" ]]
running_id=$(docker inspect "$container_id" --format '{{.Image}}')
[[ "$running_id" == "$tested_id" ]]
python3 scripts/check-ch21-http.py --base http://127.0.0.1:58080
printf 'tested_image_id=%s\n' "$tested_id" >> "$GITHUB_OUTPUT"
