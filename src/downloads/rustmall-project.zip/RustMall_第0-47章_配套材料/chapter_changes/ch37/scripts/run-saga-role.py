"""Load one generated role, remove inherited profile settings, and exec a built binary."""
import argparse
import importlib.util
import json
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ROLES = ['catalog', 'users', 'payments', 'orders', 'worker', 'catalog-http', 'edge', 'relay', 'projection', 'projection-rebuild']
def read(path):
    values = {}
    for line in path.read_text().splitlines():
        if line.strip() and not line.lstrip().startswith('#'):
            key, value = line.split('=', 1)
            if not key or not all(c.isascii() and (c.isalnum() or c == '_') for c in key):
                raise ValueError('invalid profile variable name')
            values[key] = value
    return values

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('role', choices=ROLES)
    parser.add_argument('--migrate', action='store_true')
    parser.add_argument('--check', action='store_true')
    parser.add_argument('--profile-dir', type=Path, default=Path('.saga.local'))
    parser.add_argument('--bin-dir', type=Path)
    args = parser.parse_args()
    ledger = json.loads((ROOT/'docs/runtime-boundaries.json').read_text())
    environment = dict(os.environ)
    # Each generated role gets only its own settings, even in a previously loaded shell.
    for path in args.profile_dir.glob('*.env'):
        for name in read(path): environment.pop(name, None)
    environment.update(read(args.profile_dir/(args.role+'.env')))
    spec = importlib.util.spec_from_file_location('checkpoint', ROOT/'scripts/check-checkpoint.py')
    check = importlib.util.module_from_spec(spec); spec.loader.exec_module(check)
    errors = check.check_environment('projection' if args.role == 'projection-rebuild' else args.role, ledger['roles']['projection' if args.role == 'projection-rebuild' else args.role], environment)
    if errors: raise SystemExit('\n'.join(errors))
    if args.check:
        print('PASS isolated role profile: ' + args.role); return
    binaries = args.bin_dir or Path(environment.get('CARGO_TARGET_DIR', str(ROOT/'target')))/'debug'
    if args.role in ('relay', 'projection', 'projection-rebuild'):
        if args.migrate and args.role == 'relay':
            parser.error('relay does not own a migration')
        binary = 'outbox-relay' if args.role == 'relay' else ('projection-migrate' if args.migrate else 'projection-worker')
        command = [str((binaries/binary).resolve())]
    elif args.role == 'catalog':
        command = [str((binaries/('catalog-migrate' if args.migrate else 'catalog')).resolve())]
    else:
        if args.migrate and args.role not in ('users', 'payments', 'orders'):
            parser.error('this role does not own a migration')
        command = [str((binaries/'rustmall-service').resolve()),
                   'migrate-'+args.role if args.migrate else args.role]
    if not Path(command[0]).is_file():
        raise SystemExit('Build first: cargo build --locked --workspace --all-features --bins')
    os.chdir(ROOT)
    os.execve(command[0], command, environment)
if __name__ == '__main__': main()
