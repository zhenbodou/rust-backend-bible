"""Add chapter-37 local read-model databases and private role files to chapter 36.

Existing business databases and volumes are preserved. Requires the chapter-36
PostgreSQL container to be running. No secret values are printed.
"""
import argparse
import importlib.util
import os
from pathlib import Path
import stat
import subprocess
import uuid

ROOT = Path(__file__).resolve().parents[1]

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--profile-dir', type=Path, default=Path('.saga.local'))
    parser.add_argument('--project', default='rustmall-saga36')
    args = parser.parse_args()
    if not args.project.startswith('rustmall-saga36') or not all(c.isalnum() or c == '-' for c in args.project):
        parser.error('use a rustmall-saga36 local project name')
    profile = args.profile_dir.resolve()
    if stat.S_IMODE(profile.stat().st_mode) & 0o077:
        raise SystemExit('profile directory must be private (chmod 700)')
    spec = importlib.util.spec_from_file_location('runner', ROOT/'scripts/run-saga-role.py')
    runner = importlib.util.module_from_spec(spec); spec.loader.exec_module(runner)
    catalog = runner.read(profile/'catalog.env')['DATABASE_URL']
    if not catalog.endswith('/rustmall_saga_catalog'):
        raise SystemExit('expected the isolated chapter-36 catalog dataset')
    paths = [profile/(role+'.env') for role in ('relay', 'projection', 'projection-rebuild')]
    existing = sum(p.exists() for p in paths)
    if existing not in (0, 3):
        raise SystemExit('partial event profile: inspect it before retrying; no files changed')
    compose = ['docker','compose','-p',args.project,'--env-file',str(profile/'infra.env'),
               '-f',str(ROOT/'deploy/saga36/compose.yaml')]
    def sql(query):
        result = subprocess.run(compose+['exec','-T','postgres','psql','-X','-v','ON_ERROR_STOP=1',
            '-U','rustmall','-d','postgres','-Atc',query],capture_output=True,text=True)
        if result.returncode:
            raise SystemExit('local database provisioning failed; inspect PostgreSQL readiness')
        return result.stdout.strip()
    for name in ('rustmall_saga_projection','rustmall_saga_projection_rebuild'):
        if sql(f"SELECT 1 FROM pg_database WHERE datname='{name}'") != '1':
            sql(f'CREATE DATABASE {name}')
    if not existing:
        generation = 'catalog-view-' + uuid.uuid4().hex
        common = {'KAFKA_BROKERS':'127.0.0.1:59093','KAFKA_TOPIC':'rustmall.catalog.snapshots.v1'}
        values = [
            {'CATALOG_DATABASE_URL':catalog, **common},
            {'PROJECTION_DATABASE_URL':catalog.removesuffix('catalog')+'projection',
             'CONSUMER_NAME':generation, **common},
            {'PROJECTION_DATABASE_URL':catalog.removesuffix('catalog')+'projection_rebuild',
             'CONSUMER_NAME':generation+'-rebuild', **common},
        ]
        for path, env in zip(paths, values):
            fd = os.open(path, os.O_WRONLY|os.O_CREAT|os.O_EXCL, 0o600)
            with os.fdopen(fd,'w') as out:
                for key,value in env.items(): out.write(f'{key}={value}\n')
    print('Local projection databases ready; event profiles preserved or created. Run both projection migrations next.')

if __name__ == '__main__': main()
