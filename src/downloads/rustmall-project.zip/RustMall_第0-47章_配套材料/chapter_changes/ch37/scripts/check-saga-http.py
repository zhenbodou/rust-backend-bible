"""Run the local reader exercise with explicit isolated-DB admin-fixture authority."""
import argparse
import ipaddress
import json
from pathlib import Path
import re
import secrets
import subprocess
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid

ROOT=Path(__file__).resolve().parents[1]
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--local-admin-fixture',action='store_true')
parser.add_argument('--delist-after-order',action='store_true',help='chapter-37 tombstone exercise')
parser.add_argument('--project',default='rustmall-saga36')
parser.add_argument('--profile-dir',type=Path,default=Path('.saga.local'))
a=parser.parse_args()
if not a.local_admin_fixture:parser.error('explicit --local-admin-fixture is required')
if not re.fullmatch(r'rustmall-saga36[a-z0-9_-]*',a.project):parser.error('isolated saga36 project name required')
profile=a.profile_dir.resolve()
values=dict(line.split('=',1) for line in (profile/'edge.env').read_text().splitlines())
base='http://'+values['HTTP_ADDR'];url=urllib.parse.urlsplit(base)
assert url.scheme=='http' and url.port and (url.hostname=='localhost' or ipaddress.ip_address(url.hostname).is_loopback)
def call(path,method='GET',body=None,token=None,key=None):
 headers={'Content-Type':'application/json'}
 if token:headers['Authorization']='Bearer '+token
 if key:headers['Idempotency-Key']=key
 request=urllib.request.Request(base+path,method=method,headers=headers,data=None if body is None else json.dumps(body).encode())
 try:reply=urllib.request.urlopen(request,timeout=7)
 except urllib.error.HTTPError as e:reply=e
 with reply:
  raw=reply.read();return reply.status,json.loads(raw) if raw else None
c={'username':'saga_'+secrets.token_hex(4),'password':secrets.token_urlsafe(24)}
assert call('/readyz')[0]==200
assert call('/api/v1/auth/register','POST',c)[0]==201
status,r=call('/api/v1/auth/login','POST',c);assert status==200;token=r['access_token']
status,identity=call('/api/v1/auth/me',token=token);assert status==200;actor=int(identity['id']);assert actor>0
compose=['docker','compose','-p',a.project,'--env-file',str(profile/'infra.env'),'-f',str(ROOT/'deploy/saga36/compose.yaml')]
# Only this explicit local fixture grants admin; there is no self-promotion HTTP route.
r=subprocess.run(compose+['exec','-T','postgres','psql','-U','rustmall','-d','rustmall_saga_users','-v','ON_ERROR_STOP=1','-c',f"UPDATE users SET role='admin' WHERE id={actor}"],capture_output=True)
assert r.returncode==0,'local admin fixture failed'
product={'name':'Saga教材键盘','price_cents':19900,'stock':10}
status,p=call('/api/v1/products','POST',product,token=token,key=str(uuid.uuid4()));assert status==201
key=str(uuid.uuid4());draft={'product_id':p['id'],'quantity':2}
status,order=call('/api/v1/orders','POST',draft,token=token,key=key);assert status==202
assert call('/api/v1/orders','POST',draft,token=token,key=key)[1]['id']==order['id']
assert call('/api/v1/orders','POST',{**draft,'quantity':3},token=token,key=key)[0]==409
deadline=time.monotonic()+40
while True:
 status,current=call('/api/v1/orders/'+order['id'],token=token);assert status==200
 if current['state']=='completed':break
 assert current['state'] not in ('manual','cancelled'),'unexpected terminal state'
 assert time.monotonic()<deadline,'order completion timeout';time.sleep(.2)
assert current['amount']==39800
if a.delist_after_order:
 assert call('/api/v1/products/'+str(p['id']),'DELETE',token=token)[0]==204
 assert call('/api/v1/products/'+str(p['id']),token=token)[0]==404
print('PASS new users -> admin product -> idempotent order -> inventory/payment -> completed; fixtures retained, credentials not printed')
