"""Compare one read-model generation with authority, after writers have stopped."""
import argparse
import importlib.util
import os
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parents[1]
def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--writers-stopped', action='store_true', required=True)
    parser.add_argument('--rebuild', action='store_true')
    parser.add_argument('--profile-dir', type=Path, default=Path('.saga.local'))
    parser.add_argument('--bin-dir', type=Path)
    args = parser.parse_args()
    spec = importlib.util.spec_from_file_location('runner', ROOT/'scripts/run-saga-role.py')
    runner = importlib.util.module_from_spec(spec); spec.loader.exec_module(runner)
    environment = dict(os.environ)
    for path in args.profile_dir.glob('*.env'):
        for name in runner.read(path): environment.pop(name, None)
    environment.update(runner.read(args.profile_dir/'relay.env'))
    environment.update(runner.read(args.profile_dir/('projection-rebuild.env' if args.rebuild else 'projection.env')))
    binaries = args.bin_dir or Path(environment.get('CARGO_TARGET_DIR', str(ROOT/'target')))/'debug'
    result = subprocess.run([str((binaries/'projection-audit').resolve()), '--writers-stopped'],
        env=environment, cwd=ROOT)
    raise SystemExit(result.returncode)
if __name__ == '__main__': main()
