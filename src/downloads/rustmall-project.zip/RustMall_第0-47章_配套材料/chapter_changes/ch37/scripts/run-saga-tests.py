"""Run workspace tests using isolated local PostgreSQL and Redis from the profile."""
import argparse
import importlib.util
import ipaddress
import os
from pathlib import Path
import subprocess
from urllib.parse import urlsplit

ROOT = Path(__file__).resolve().parents[1]
def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--profile-dir', type=Path, default=Path('.saga.local'))
    args = parser.parse_args()
    spec = importlib.util.spec_from_file_location('runner', ROOT/'scripts/run-saga-role.py')
    runner = importlib.util.module_from_spec(spec); spec.loader.exec_module(runner)
    users = runner.read(args.profile_dir/'users.env')
    url = urlsplit(users['DATABASE_URL'])
    if url.path != '/rustmall_saga_users' or not url.hostname or not (
        url.hostname == 'localhost' or ipaddress.ip_address(url.hostname).is_loopback
    ):
        raise SystemExit('expected the isolated local chapter-36 test profile')
    environment = dict(os.environ)
    for path in args.profile_dir.glob('*.env'):
        for name in runner.read(path): environment.pop(name, None)
    # sqlx::test creates independent databases; it must not use the users schema.
    environment['DATABASE_URL'] = users['DATABASE_URL'].rsplit('/',1)[0]+'/postgres'
    environment['REDIS_URL'] = users['REDIS_URL']
    result = subprocess.run([environment.get('CARGO','cargo'),'+1.92.0','test','--locked',
        '--offline','--workspace','--all-features'],cwd=ROOT,env=environment)
    raise SystemExit(result.returncode)
if __name__ == '__main__': main()
