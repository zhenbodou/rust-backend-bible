-- One physical read model belongs to one logical consumer generation.
-- Preserve an existing unambiguous Inbox identity during the upgrade.
DO $$ BEGIN
    IF (SELECT count(DISTINCT consumer_name) FROM consumer_inbox) > 1 THEN
        RAISE EXCEPTION 'multiple Inbox identities: audit before binding this read model';
    END IF;
END $$;
CREATE TABLE projection_identity (
    singleton BOOLEAN PRIMARY KEY DEFAULT true CHECK(singleton),
    consumer_name TEXT NOT NULL CHECK(length(consumer_name) BETWEEN 1 AND 128)
);
INSERT INTO projection_identity(singleton,consumer_name)
SELECT true,min(consumer_name) FROM consumer_inbox
HAVING count(DISTINCT consumer_name)=1;
