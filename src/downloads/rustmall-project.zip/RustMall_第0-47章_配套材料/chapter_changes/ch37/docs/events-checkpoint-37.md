# Chapter 37: persistent event projection and independent rebuild

This checkpoint extends the repaired chapter-36 business workspace. It preserves
metadata updates, absolute-stock write rejection, new user sessions, payment
receipts, persistent Saga leases, CORS idempotency headers and bounded clients.

## Local upgrade

Keep the chapter-36 `.saga.local` profile and `rustmall-saga36` Compose project.
Do not regenerate its credentials or delete its existing volume. If starting
fresh, complete the chapter-36 setup and four business migrations first.

```sh
cargo +1.92.0 build --locked --workspace --all-features --bins
python3 scripts/extend-saga-events.py
docker compose -p rustmall-saga36 --env-file .saga.local/infra.env \
  -f deploy/saga36/compose.yaml -f deploy/saga37/compose.yaml \
  up -d --wait --wait-timeout 150
docker compose -p rustmall-saga36 --env-file .saga.local/infra.env \
  -f deploy/saga36/compose.yaml -f deploy/saga37/compose.yaml \
  exec -T kafka /opt/kafka/bin/kafka-topics.sh --bootstrap-server kafka:19092 \
  --create --if-not-exists --topic rustmall.catalog.snapshots.v1 \
  --partitions 3 --replication-factor 1
python3 scripts/run-saga-role.py projection --migrate
python3 scripts/run-saga-role.py projection-rebuild --migrate
```

The extension explicitly creates two databases in the running PostgreSQL
instance. Editing `init.sql` would not upgrade an existing initialized volume.
It creates three private role files once and preserves them on repeated runs.
A partial profile requires manual inspection, rather than automatic deletion.

The broker is local plaintext on 59093. The generated clients and broker's
advertised external listener must agree if changing that port. Single broker,
replication factor one, and the shared local PostgreSQL administrator do not
prove production HA or least-privilege database grants.

## Business and consumer experiment

Run all seven chapter-36 business roles in their own terminals, then:

```sh
python3 scripts/check-saga-http.py --local-admin-fixture --delist-after-order
```

This explicit local admin fixture creates a real authenticated order, waits for
completion and delists its product. Initial stock10 becomes8; the product stays
in the authority table as a delisted record. Stop the business roles normally
before quiescent audits. Do not stop the infrastructure.

Run each of these consumers in a separate terminal:

```sh
python3 scripts/run-saga-role.py relay
python3 scripts/run-saga-role.py projection
python3 scripts/run-saga-role.py projection-rebuild
```

The primary and rebuild use independent databases and persistent group/Inbox
names. The database identity migration rejects accidental mixing of logical
consumer generations in one physical read model. Existing unambiguous Inbox
identity is preserved during migration; multiple historical names block upgrade.
This guard cannot prevent reusing an old Kafka group with an entirely empty
new database. New rebuilds still require both a new group and a new database.

After pending Outbox rows drain and consumers catch up:

```sh
python3 scripts/check-saga-projection.py --writers-stopped
python3 scripts/check-saga-projection.py --writers-stopped --rebuild
python3 scripts/run-saga-tests.py
```

The audit compares every product snapshot and revision, including delisted
products, using separate read-only repeatable-read transactions. Writers must
actually be stopped: the flag acknowledges that prerequisite; it cannot enforce
it. The local comparison deliberately caps each side at100000 rows. Continuous
production reconciliation needs a defined snapshot/incremental boundary and
pagination. Kafka lag zero alone is not a completeness proof.

The test wrapper loads local PostgreSQL and Redis from the private profile,
uses the PostgreSQL maintenance database for `sqlx::test` to create independent
test databases, and does not print credentials. Build once to fetch dependencies
before its offline test run. It does not select ignored container tests.

## Duplicate and poison handling

`outbox-replay --local-lab EVENT_UUID`, with relay profile loaded, deliberately
resends an existing immutable Outbox envelope. It preserves UUID, revision,
time and payload; it does not edit source rows or delivered markers. Observe
Duplicate, unchanged Inbox count, and no resurrection of delisted products.

Projection errors include topic/partition/offset and stop without explicitly
committing the failed record. Stable-group restart encounters the unresolved
poison again. There is no automatic DLQ or skip API in this checkpoint. Test
poison only in a disposable topic/project with a defined cleanup procedure.

The authority remains catalog. Product HTTP does not switch to the projection,
and order/payment events are not invented inside the product snapshot schema.
Rebuilding from earliest is valid only for history still retained by Kafka;
missing historical final snapshots require validated archive/authority snapshot
recovery with an explicit incremental boundary.
