#[derive(sqlx::FromRow)]
pub struct Lease {
    pub event_id: Uuid,
    pub payload: Json<Envelope>,
    pub attempts: i32,
    pub lease_token: Uuid,
}
pub async fn claim_one(pool: &PgPool) -> Result<Option<Lease>, sqlx::Error> {
    let token = Uuid::new_v4();
    sqlx::query_as::<_,Lease>(
        "WITH candidate AS (SELECT event_id FROM product_outbox WHERE delivered_at IS NULL AND next_attempt_at<=now() AND (leased_until IS NULL OR leased_until<now()) ORDER BY occurred_at,event_id FOR UPDATE SKIP LOCKED LIMIT 1) UPDATE product_outbox AS o SET lease_token=$1,leased_until=now()+interval '30 seconds',attempts=LEAST(o.attempts::bigint+1,2147483647)::int FROM candidate AS c WHERE o.event_id=c.event_id RETURNING o.event_id,o.payload,o.attempts,o.lease_token"
    ).bind(token).fetch_optional(pool).await
}
pub async fn delivered(pool: &PgPool, lease: &Lease) -> Result<bool, sqlx::Error> {
    Ok(sqlx::query("UPDATE product_outbox SET delivered_at=now(),lease_token=NULL,leased_until=NULL,last_error=NULL WHERE event_id=$1 AND lease_token=$2 AND delivered_at IS NULL")
        .bind(lease.event_id).bind(lease.lease_token).execute(pool).await?.rows_affected()==1)
}
pub async fn failed(pool: &PgPool, lease: &Lease, error: &str) -> Result<bool, sqlx::Error> {
    let bounded: String = error.chars().take(500).collect();
    Ok(sqlx::query("UPDATE product_outbox SET next_attempt_at=now()+($3::bigint*interval '1 second'),lease_token=NULL,leased_until=NULL,last_error=$4 WHERE event_id=$1 AND lease_token=$2 AND delivered_at IS NULL")
        .bind(lease.event_id).bind(lease.lease_token).bind(retry_delay_secs(lease.attempts)).bind(bounded)
        .execute(pool).await?.rows_affected()==1)
}
