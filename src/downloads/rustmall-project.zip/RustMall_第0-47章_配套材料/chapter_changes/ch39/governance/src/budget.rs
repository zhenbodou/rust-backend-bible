//! Monotonic local budget plus a bounded relative hint for the next hop.
use std::{future::Future, time::Duration};
use tokio::time::Instant;
tokio::task_local! {static DEADLINE:Instant;}
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Expired;
pub async fn scope<T>(duration: Duration, future: impl Future<Output = T>) -> T {
    let end = Instant::now() + duration;
    let end = DEADLINE.try_with(|old| (*old).min(end)).unwrap_or(end);
    DEADLINE.scope(end, future).await
}
pub fn remaining(cap: Duration, reserve: Duration) -> Result<Duration, Expired> {
    match DEADLINE.try_with(|end| end.saturating_duration_since(Instant::now())) {
        Ok(left) => left
            .checked_sub(reserve)
            .filter(|d| !d.is_zero())
            .map(|d| d.min(cap))
            .ok_or(Expired),
        Err(_) => {
            if cap.is_zero() {
                Err(Expired)
            } else {
                Ok(cap)
            }
        }
    }
}
pub fn milliseconds(duration: Duration) -> Result<u64, Expired> {
    let ms = duration.as_millis().min(5000) as u64;
    if ms == 0 { Err(Expired) } else { Ok(ms) }
}
#[cfg(test)]
mod tests {
    use super::*;
    #[tokio::test(start_paused = true)]
    async fn sequential_calls_consume_one_budget_and_nested_scopes_cannot_extend_it() {
        scope(Duration::from_secs(5), async {
            tokio::time::advance(Duration::from_secs(2)).await;
            assert_eq!(
                remaining(Duration::from_secs(4), Duration::from_millis(100)).unwrap(),
                Duration::from_millis(2900)
            );
            scope(Duration::from_secs(30), async {
                tokio::time::advance(Duration::from_secs(3)).await;
                assert_eq!(
                    remaining(Duration::from_secs(2), Duration::ZERO),
                    Err(Expired)
                );
            })
            .await;
        })
        .await;
    }
    #[test]
    fn unscoped_clients_keep_their_cap_and_wire_rounding_never_adds_time() {
        assert_eq!(
            remaining(Duration::from_secs(2), Duration::from_millis(50)).unwrap(),
            Duration::from_secs(2)
        );
        assert_eq!(milliseconds(Duration::from_micros(1999)).unwrap(), 1);
        assert_eq!(milliseconds(Duration::from_micros(999)), Err(Expired));
    }
}
