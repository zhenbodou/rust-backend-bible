//! Process-local token bucket; admission tokens are not concurrency permits.
use std::{
    sync::{Arc, Mutex},
    time::Duration,
};
use tokio::time::Instant;
const UNIT: u128 = 1_000_000_000;
#[derive(Clone)]
pub struct Bucket {
    state: Arc<Mutex<State>>,
    burst: u32,
    per_second: u32,
}
struct State {
    credit: u128,
    at: Instant,
}
impl Bucket {
    pub fn new(burst: u32, per_second: u32) -> Result<Self, &'static str> {
        if burst == 0 || per_second == 0 {
            return Err("rate and burst must be positive");
        }
        Ok(Self {
            state: Arc::new(Mutex::new(State {
                credit: u128::from(burst) * UNIT,
                at: Instant::now(),
            })),
            burst,
            per_second,
        })
    }
    pub fn acquire(&self) -> Result<(), Duration> {
        let mut state = self.state.lock().unwrap_or_else(|p| p.into_inner());
        let now = Instant::now();
        let refill = now
            .saturating_duration_since(state.at)
            .as_nanos()
            .saturating_mul(u128::from(self.per_second));
        state.credit = state
            .credit
            .saturating_add(refill)
            .min(u128::from(self.burst) * UNIT);
        state.at = now;
        if state.credit >= UNIT {
            state.credit -= UNIT;
            Ok(())
        } else {
            let nanos = (UNIT - state.credit).div_ceil(u128::from(self.per_second));
            Err(Duration::from_nanos(nanos as u64))
        }
    }
}
#[cfg(test)]
mod tests {
    use super::*;
    #[tokio::test(start_paused = true)]
    async fn burst_and_fractional_refill_are_shared_by_clones() {
        let b = Bucket::new(2, 2).unwrap();
        b.acquire().unwrap();
        b.clone().acquire().unwrap();
        assert_eq!(b.acquire().unwrap_err(), Duration::from_millis(500));
        tokio::time::advance(Duration::from_millis(250)).await;
        assert!(b.acquire().is_err());
        tokio::time::advance(Duration::from_millis(250)).await;
        b.acquire().unwrap();
        assert!(b.acquire().is_err());
        tokio::time::advance(Duration::from_secs(100)).await;
        b.acquire().unwrap();
        b.acquire().unwrap();
        assert!(b.acquire().is_err());
    }
    #[test]
    fn invalid_rates_are_rejected() {
        assert!(Bucket::new(0, 1).is_err());
        assert!(Bucket::new(1, 0).is_err());
    }
}
