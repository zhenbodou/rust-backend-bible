//! One process-local dependency circuit. All clones share state.
use std::sync::{Arc, Mutex};
use std::time::Duration;
use tokio::time::Instant;
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Outcome {
    Healthy,
    Failure,
    Ignore,
}
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Phase {
    Closed,
    Open,
    HalfOpen,
}
#[derive(Debug, Clone, Copy)]
pub struct Policy {
    pub minimum: u32,
    pub failure_percent: u32,
    pub window: Duration,
    pub cooldown: Duration,
    pub probe_budget: Duration,
}
impl Default for Policy {
    fn default() -> Self {
        Self {
            minimum: 5,
            failure_percent: 60,
            window: Duration::from_secs(30),
            cooldown: Duration::from_secs(5),
            probe_budget: Duration::from_secs(3),
        }
    }
}
struct Inner {
    phase: Phase,
    generation: Arc<()>,
    since: Instant,
    total: u32,
    failed: u32,
}
#[derive(Clone)]
pub struct Breaker {
    inner: Arc<Mutex<Inner>>,
    policy: Policy,
    name: &'static str,
}
#[derive(Debug, Clone, Copy)]
pub struct Rejected {
    pub phase: Phase,
    pub retry_after: Duration,
}
pub struct Permit {
    breaker: Breaker,
    generation: Arc<()>,
    probe: bool,
    finished: bool,
}
impl Breaker {
    pub fn new(name: &'static str, policy: Policy) -> Result<Self, &'static str> {
        if policy.minimum == 0
            || policy.failure_percent == 0
            || policy.failure_percent > 100
            || [policy.window, policy.cooldown, policy.probe_budget]
                .iter()
                .any(Duration::is_zero)
        {
            return Err("invalid circuit policy");
        }
        Ok(Self {
            inner: Arc::new(Mutex::new(Inner {
                phase: Phase::Closed,
                generation: Arc::new(()),
                since: Instant::now(),
                total: 0,
                failed: 0,
            })),
            policy,
            name,
        })
    }
    fn change(&self, state: &mut Inner, phase: Phase, now: Instant) {
        let previous = state.phase;
        state.phase = phase;
        state.generation = Arc::new(());
        state.since = now;
        state.total = 0;
        state.failed = 0;
        tracing::info!(
            dependency = self.name,
            ?previous,
            ?phase,
            "circuit transition"
        );
    }
    pub fn phase(&self) -> Phase {
        self.inner.lock().unwrap_or_else(|p| p.into_inner()).phase
    }
    pub fn acquire(&self) -> Result<Permit, Rejected> {
        let now = Instant::now();
        let mut state = self.inner.lock().unwrap_or_else(|p| p.into_inner());
        let elapsed = now.saturating_duration_since(state.since);
        match state.phase {
            Phase::Closed if elapsed >= self.policy.window => {
                self.change(&mut state, Phase::Closed, now)
            }
            Phase::Open if elapsed >= self.policy.cooldown => {
                self.change(&mut state, Phase::HalfOpen, now)
            }
            Phase::Open => {
                return Err(Rejected {
                    phase: Phase::Open,
                    retry_after: self.policy.cooldown - elapsed,
                });
            }
            Phase::HalfOpen => {
                if elapsed >= self.policy.probe_budget {
                    self.change(&mut state, Phase::Open, now);
                }
                return Err(Rejected {
                    phase: state.phase,
                    retry_after: if state.phase == Phase::Open {
                        self.policy.cooldown
                    } else {
                        self.policy.probe_budget - elapsed
                    },
                });
            }
            _ => {}
        }
        Ok(Permit {
            breaker: self.clone(),
            generation: state.generation.clone(),
            probe: state.phase == Phase::HalfOpen,
            finished: false,
        })
    }
}
impl Permit {
    pub fn finish(mut self, outcome: Outcome) {
        self.settle(outcome);
        self.finished = true;
    }
    fn settle(&self, outcome: Outcome) {
        let now = Instant::now();
        let mut state = self.breaker.inner.lock().unwrap_or_else(|p| p.into_inner());
        if !Arc::ptr_eq(&state.generation, &self.generation) {
            return;
        }
        if !self.probe
            && state.phase == Phase::Closed
            && now.saturating_duration_since(state.since) >= self.breaker.policy.window
        {
            self.breaker.change(&mut state, Phase::Closed, now);
            return;
        }
        if self.probe {
            let healthy = now.saturating_duration_since(state.since)
                < self.breaker.policy.probe_budget
                && outcome == Outcome::Healthy;
            self.breaker.change(
                &mut state,
                if healthy { Phase::Closed } else { Phase::Open },
                now,
            );
        } else if state.phase == Phase::Closed && outcome != Outcome::Ignore {
            state.total = state.total.saturating_add(1);
            state.failed = state
                .failed
                .saturating_add(u32::from(outcome == Outcome::Failure));
            if state.total >= self.breaker.policy.minimum
                && u64::from(state.failed) * 100
                    >= u64::from(state.total) * u64::from(self.breaker.policy.failure_percent)
            {
                self.breaker.change(&mut state, Phase::Open, now);
            }
        }
    }
}
impl Drop for Permit {
    fn drop(&mut self) {
        if !self.finished && self.probe {
            self.settle(Outcome::Ignore);
        }
    }
}
#[cfg(test)]
mod tests {
    use super::*;
    fn breaker() -> Breaker {
        Breaker::new("test", Policy::default()).unwrap()
    }
    fn trip(b: &Breaker) {
        for _ in 0..5 {
            b.acquire().unwrap().finish(Outcome::Failure);
        }
        assert_eq!(b.phase(), Phase::Open);
    }
    #[tokio::test(start_paused = true)]
    async fn minimum_samples_and_failure_ratio_apply_to_a_fixed_window() {
        let b = breaker();
        for _ in 0..4 {
            b.acquire().unwrap().finish(Outcome::Failure);
        }
        assert_eq!(b.phase(), Phase::Closed);
        b.acquire().unwrap().finish(Outcome::Healthy);
        assert_eq!(b.phase(), Phase::Open);
        let c = breaker();
        for _ in 0..5 {
            c.acquire().unwrap().finish(Outcome::Healthy);
        }
        for _ in 0..4 {
            c.acquire().unwrap().finish(Outcome::Failure);
        }
        assert_eq!(c.phase(), Phase::Closed);
    }
    #[tokio::test(start_paused = true)]
    async fn ignored_business_errors_do_not_trip_the_circuit() {
        let b = breaker();
        for _ in 0..100 {
            b.acquire().unwrap().finish(Outcome::Ignore);
        }
        assert_eq!(b.phase(), Phase::Closed);
    }
    #[tokio::test(start_paused = true)]
    async fn a_single_half_open_probe_is_shared_by_clones() {
        let b = breaker();
        trip(&b);
        assert!(b.clone().acquire().is_err());
        tokio::time::advance(Duration::from_secs(5)).await;
        let permit = b.acquire().unwrap();
        assert_eq!(b.phase(), Phase::HalfOpen);
        assert!(b.clone().acquire().is_err());
        permit.finish(Outcome::Healthy);
        assert_eq!(b.phase(), Phase::Closed);
    }
    #[tokio::test(start_paused = true)]
    async fn cancelled_probe_reopens_and_later_probe_can_recover() {
        let b = breaker();
        trip(&b);
        tokio::time::advance(Duration::from_secs(5)).await;
        let permit = b.acquire().unwrap();
        drop(permit);
        assert_eq!(b.phase(), Phase::Open);
        assert!(b.acquire().is_err());
        tokio::time::advance(Duration::from_secs(5)).await;
        b.acquire().unwrap().finish(Outcome::Healthy);
        assert_eq!(b.phase(), Phase::Closed);
    }
    #[tokio::test(start_paused = true)]
    async fn late_success_cannot_close_a_new_generation() {
        let b = breaker();
        let old = b.acquire().unwrap();
        trip(&b);
        old.finish(Outcome::Healthy);
        assert_eq!(b.phase(), Phase::Open);
        tokio::time::advance(Duration::from_secs(5)).await;
        let old_probe = b.acquire().unwrap();
        tokio::time::advance(Duration::from_secs(3)).await;
        assert!(b.acquire().is_err());
        assert_eq!(b.phase(), Phase::Open);
        old_probe.finish(Outcome::Healthy);
        assert_eq!(b.phase(), Phase::Open);
    }
    #[tokio::test(start_paused = true)]
    async fn window_reset_does_not_count_old_in_flight_results() {
        let b = breaker();
        let old = b.acquire().unwrap();
        tokio::time::advance(Duration::from_secs(30)).await;
        b.acquire().unwrap().finish(Outcome::Healthy);
        old.finish(Outcome::Failure);
        for _ in 0..3 {
            b.acquire().unwrap().finish(Outcome::Failure);
        }
        assert_eq!(b.phase(), Phase::Closed);
    }
    #[tokio::test(start_paused = true)]
    async fn expired_probe_cannot_report_success_without_another_acquirer() {
        let b = breaker();
        trip(&b);
        tokio::time::advance(Duration::from_secs(5)).await;
        let permit = b.acquire().unwrap();
        tokio::time::advance(Duration::from_secs(3)).await;
        permit.finish(Outcome::Healthy);
        assert_eq!(b.phase(), Phase::Open);
    }
    #[tokio::test(start_paused = true)]
    async fn simultaneous_recovery_attempts_allow_only_one_probe() {
        let b = breaker();
        trip(&b);
        tokio::time::advance(Duration::from_secs(5)).await;
        let tasks: Vec<_> = (0..32)
            .map(|_| {
                let b = b.clone();
                tokio::spawn(async move { b.acquire() })
            })
            .collect();
        let mut probes = Vec::new();
        for task in tasks {
            if let Ok(permit) = task.await.unwrap() {
                probes.push(permit);
            }
        }
        assert_eq!(probes.len(), 1);
        probes.pop().unwrap().finish(Outcome::Healthy);
        assert_eq!(b.phase(), Phase::Closed);
    }
    #[tokio::test(start_paused = true)]
    async fn expired_window_results_are_ignored_even_without_a_new_acquirer() {
        let b = breaker();
        let pending: Vec<_> = (0..5).map(|_| b.acquire().unwrap()).collect();
        tokio::time::advance(Duration::from_secs(30)).await;
        for permit in pending {
            permit.finish(Outcome::Failure);
        }
        for _ in 0..4 {
            b.acquire().unwrap().finish(Outcome::Failure);
        }
        assert_eq!(b.phase(), Phase::Closed);
        b.acquire().unwrap().finish(Outcome::Failure);
        assert_eq!(b.phase(), Phase::Open);
    }
    #[test]
    fn bad_policies_are_rejected() {
        assert!(
            Breaker::new(
                "x",
                Policy {
                    minimum: 0,
                    ..Policy::default()
                }
            )
            .is_err()
        );
    }
}
