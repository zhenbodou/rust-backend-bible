//! Stable equal jitter: a replay of the same identity/attempt keeps its delay.
use sha2::{Digest, Sha256};
use uuid::Uuid;
pub fn jitter_seconds(base: u64, id: Uuid, attempt: i32) -> u64 {
    let low = (base / 2).max(1);
    let high = base.max(1);
    let mut hash = Sha256::new();
    hash.update(id.as_bytes());
    hash.update(attempt.to_be_bytes());
    let digest = hash.finalize();
    let mut seed = [0_u8; 8];
    seed.copy_from_slice(&digest[..8]);
    low + u64::from_be_bytes(seed) % (high - low + 1)
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn jitter_is_reproducible_bounded_and_spreads_a_batch() {
        let mut delays = std::collections::HashSet::new();
        for n in 1..100 {
            let id = Uuid::from_u128(n);
            let delay = jitter_seconds(32, id, 8);
            assert!((16..=32).contains(&delay));
            assert_eq!(delay, jitter_seconds(32, id, 8));
            delays.insert(delay);
        }
        assert!(delays.len() > 8);
        assert_eq!(jitter_seconds(0, Uuid::nil(), 0), 1);
    }
}
