"""Prepare eight durable test orders and verify payments-outage/recovery checkpoints.

Stop/restart payments in its own terminal. This script never kills application
processes and never deletes business data. The private receipt contains generated
lab credentials and request keys, and must stay outside source archives.
"""
import argparse,hashlib,json,os,re,secrets,stat,subprocess,time,urllib.error,urllib.request,uuid
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('mode',choices=['prepare','outage','recovered'])
p.add_argument('--local-admin-fixture',action='store_true')
p.add_argument('--project',default='rustmall-saga36')
p.add_argument('--profile-dir',type=Path,default=Path('.saga.local'))
a=p.parse_args()
if not a.local_admin_fixture:p.error('explicit --local-admin-fixture is required')
if not re.fullmatch(r'rustmall-saga36[a-z0-9_-]*',a.project):p.error('isolated saga36 project required')
profile=a.profile_dir.resolve()
if stat.S_IMODE(profile.stat().st_mode)&0o077:raise SystemExit('profile directory must be private')
edge=dict(line.split('=',1) for line in (profile/'edge.env').read_text().splitlines())
if edge.get('HTTP_ADDR')!='127.0.0.1:18086':raise SystemExit('expected isolated loopback edge profile')
path=profile/'governance39.json';binding=hashlib.sha256((profile/'infra.env').read_bytes()).hexdigest()
def save(value):
    temporary=path.with_suffix('.json.tmp')
    fd=os.open(temporary,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    with os.fdopen(fd,'w') as f:json.dump(value,f,ensure_ascii=False,indent=2)
    os.replace(temporary,path)
def call(route,method='GET',body=None,key=None,token=None):
    h={'Content-Type':'application/json'}
    if token:h['Authorization']='Bearer '+token
    if key:h['Idempotency-Key']=key
    req=urllib.request.Request('http://127.0.0.1:18086'+route,method=method,headers=h,data=None if body is None else json.dumps(body).encode())
    try:r=urllib.request.urlopen(req,timeout=7)
    except urllib.error.HTTPError as error:r=error
    with r:
        raw=r.read();return r.status,json.loads(raw) if raw else None
compose=['docker','compose','-p',a.project,'--env-file',str(profile/'infra.env'),'-f',str(ROOT/'deploy/saga36/compose.yaml')]
def sql(db,query):
    r=subprocess.run(compose+['exec','-T','postgres','psql','-X','-v','ON_ERROR_STOP=1','-U','rustmall','-d','rustmall_saga_'+db,'-Atc',query],capture_output=True,text=True)
    if r.returncode:raise SystemExit('local fixture query failed; check database readiness')
    return r.stdout.strip()
if path.exists():
    if stat.S_IMODE(path.stat().st_mode)&0o077:raise SystemExit('private receipt must have mode0600')
    state=json.loads(path.read_text())
    if state['project']!=a.project or state['profile_sha256']!=binding:raise SystemExit('receipt belongs to a different local dataset')
elif a.mode=='prepare':
    state={'project':a.project,'profile_sha256':binding,'username':'gov_'+secrets.token_hex(5),
        'password':secrets.token_urlsafe(24),'product_key':str(uuid.uuid4()),
        'orders':[{'key':str(uuid.uuid4()),'id':None} for _ in range(8)]}
    save(state)  # Persist command identities before the first HTTP write.
else:raise SystemExit('run prepare first, with payments stopped')
if a.mode=='prepare':
    credentials={k:state[k] for k in ('username','password')}
    if 'actor_id' not in state:
        code,_=call('/api/v1/auth/register','POST',credentials)
        assert code in (201,409),'registration failed; no new request keys generated'
    code,reply=call('/api/v1/auth/login','POST',credentials);assert code==200,'login failed'
    token=reply['access_token'];code,identity=call('/api/v1/auth/me',token=token);assert code==200
    actor=int(identity['id']);assert actor>0 and state.get('actor_id',actor)==actor
    state.update(actor_id=actor,access_token=token);save(state)
    sql('users',f"UPDATE users SET role='admin' WHERE id={actor}")
    code,product=call('/api/v1/products','POST',{'name':'治理故障键盘','price_cents':19900,'stock':20},key=state['product_key'],token=token)
    assert code==201 and int(product['id'])>0
    assert state.get('product_id',int(product['id']))==int(product['id'])
    state['product_id']=int(product['id']);save(state)
    for command in state['orders']:
        code,order=call('/api/v1/orders','POST',{'product_id':state['product_id'],'quantity':1},key=command['key'],token=token)
        assert code==202,'order creation failed; rerun prepare with the saved identities'
        identity=str(uuid.UUID(order['id']));assert command['id'] in (None,identity)
        command['id']=identity;save(state)
    print('Prepared eight orders; private identities saved. Run outage before restarting payments.')
else:
    ids=[str(uuid.UUID(c['id'])) for c in state['orders']];assert len(ids)==8
    where=','.join("'"+identity+"'" for identity in ids)
    target='charging' if a.mode=='outage' else 'completed';deadline=time.monotonic()+(45 if a.mode=='outage' else 90)
    while sql('orders',f"SELECT count(*) FROM orders WHERE id IN ({where}) AND state='{target}'")!='8':
        if time.monotonic()>deadline:raise SystemExit('checkpoint not reached; inspect durable states and process readiness; data retained')
        time.sleep(.2)
    expected='held' if a.mode=='outage' else 'confirmed'
    assert sql('catalog',f"SELECT count(*) FROM inventory_reservations WHERE saga_id IN ({where}) AND state='{expected}'")=='8'
    assert sql('catalog',f"SELECT stock FROM products WHERE id={int(state['product_id'])}")=='12'
    if a.mode=='outage':
        assert sql('payments',f"SELECT count(*) FROM payments WHERE saga_id IN ({where})")=='0'
        while sql('orders',f"SELECT count(*) FROM orders WHERE id IN ({where}) AND last_error='payment-circuit-open'")=='0':
            if time.monotonic()>deadline:raise SystemExit('circuit checkpoint not observed; confirm payments is stopped')
            time.sleep(.2)
    else:
        assert sql('payments',f"SELECT count(*) FROM payment_effects WHERE saga_id IN ({where}) AND kind='paid'")=='8'
        assert sql('payments',f"SELECT count(*) FROM payment_effects WHERE saga_id IN ({where}) AND kind!='paid'")=='0'
    print('PASS '+a.mode+': all eight durable orders, inventory receipts and payment effects match the checkpoint.')
