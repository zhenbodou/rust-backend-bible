pub const BUDGET_HEADER: &str = "x-rustmall-budget-ms";
pub fn call_duration(cap: Duration) -> ApiResult<Duration> {
    governance::budget::remaining(cap, Duration::from_millis(100)).map_err(|_| {
        ApiError(
            StatusCode::GATEWAY_TIMEOUT,
            "local budget exhausted; result may be unknown",
        )
    })
}
pub fn outbound(
    request: reqwest::RequestBuilder,
    cap: Duration,
) -> ApiResult<reqwest::RequestBuilder> {
    let duration = call_duration(cap)?;
    let ms = governance::budget::milliseconds(duration)
        .map_err(|_| ApiError(StatusCode::GATEWAY_TIMEOUT, "local budget exhausted"))?;
    Ok(request
        .timeout(duration)
        .header(BUDGET_HEADER, ms.to_string()))
}
pub fn client() -> anyhow::Result<reqwest::Client> {
    client_with_limit(Duration::from_secs(2))
}
pub fn client_with_limit(duration: Duration) -> anyhow::Result<reqwest::Client> {
    Ok(reqwest::Client::builder()
        .no_proxy()
        .connect_timeout(Duration::from_millis(300))
        .timeout(duration)
        .redirect(reqwest::redirect::Policy::none())
        .build()?)
}
fn request_budget(headers: &HeaderMap, accept_hint: bool) -> ApiResult<Duration> {
    if !accept_hint || !headers.contains_key(BUDGET_HEADER) {
        return Ok(Duration::from_secs(5));
    }
    if headers.get_all(BUDGET_HEADER).iter().count() != 1 {
        return Err(invalid());
    }
    let ms = headers
        .get(BUDGET_HEADER)
        .and_then(|v| v.to_str().ok())
        .and_then(|v| v.parse::<u64>().ok())
        .filter(|v| (1..=5000).contains(v))
        .ok_or_else(invalid)?;
    Ok(Duration::from_millis(ms))
}
