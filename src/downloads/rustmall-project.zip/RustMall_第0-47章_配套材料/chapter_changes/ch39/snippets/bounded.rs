pub fn bounded(router: Router) -> Router {
    bounded_impl(router, true)
}
pub fn bounded_edge(router: Router) -> Router {
    bounded_impl(router, false)
}
fn bounded_impl(router: Router, accept_hint: bool) -> Router {
    use axum::{
        extract::{MatchedPath, Request},
        middleware::{self, Next},
        routing::get,
    };
    use tracing::Instrument;
    let capacity = capacity();
    let rate = governance::rate::Bucket::new(64, 32).expect("fixed valid rate policy");
    let metrics = Arc::new(observability::metrics::HttpMetrics::default());
    let scrape = metrics.clone();
    router.route("/metrics",get(move||{let m=scrape.clone();async move{
        ([("content-type","text/plain; version=0.0.4; charset=utf-8")],m.encode()+&observability::metrics::process_metrics())
    }})).layer(middleware::from_fn(move|mut request:Request,next:Next|{
        let capacity=capacity.clone();let rate=rate.clone();let metrics=metrics.clone();
        async move {
            let id=if request.headers().get_all("x-request-id").iter().count()==1 {
                request.headers().get("x-request-id").and_then(|v|v.to_str().ok()).and_then(|v|uuid::Uuid::parse_str(v).ok()).filter(|v|!v.is_nil())
            }else{None}.unwrap_or_else(uuid::Uuid::new_v4);
            request.headers_mut().insert("x-request-id",id.to_string().parse().expect("UUID header"));
            let control=matches!(request.uri().path(),"/healthz"|"/readyz"|"/metrics");
            let budget=request_budget(request.headers(),accept_hint);
            let method=request.method().to_string();
            let route=request.extensions().get::<MatchedPath>().map_or("<unmatched>",MatchedPath::as_str);
            let span=if control{tracing::Span::none()}else{observability::http_span(request.headers(),&method,route)};
            async move {
                let start=std::time::Instant::now();
                let mut response=if control{next.run(request).await}else{
                    match (rate.acquire(),budget){
                        (Err(wait),_)=>{
                            tracing::warn!(category="rate",retry_after_ms=wait.as_millis(),"HTTP admission rejected");
                            let mut response=ApiError(StatusCode::TOO_MANY_REQUESTS,"process request rate exhausted").into_response();
                            let seconds=wait.as_secs().saturating_add(u64::from(wait.subsec_nanos()>0)).max(1);
                            response.headers_mut().insert("retry-after",seconds.to_string().parse().expect("integer header"));response
                        },
                        (_,Err(error))=>error.into_response(),
                        (Ok(()),Ok(duration))=>match enter(&capacity){
                            Err(error)=>{tracing::warn!(category="capacity","HTTP admission rejected");error.into_response()},
                            Ok(_permit)=>governance::budget::scope(duration,async{
                                match tokio::time::timeout(duration,next.run(request)).await{
                                    Ok(response)=>response,
                                    Err(_)=>ApiError(StatusCode::GATEWAY_TIMEOUT,"request budget exhausted; result may be unknown").into_response(),
                                }
                            }).await,
                        }
                    }
                };
                let status=response.status().as_u16();let elapsed=start.elapsed();if !control{metrics.observe(elapsed,status);}
                if response.status().is_server_error(){tracing::Span::current().record("otel.status_code","ERROR");}
                response.headers_mut().insert("x-request-id",id.to_string().parse().expect("UUID header"));
                response.headers_mut().insert("cache-control","no-store".parse().expect("static header"));
                response.headers_mut().insert("pragma","no-cache".parse().expect("static header"));
                if !control{let(trace_id,span_id)=observability::ids();tracing::info!(request_id=%id,%trace_id,%span_id,%method,status,duration_seconds=elapsed.as_secs_f64(),"request completed");}
                response
            }.instrument(span).await
        }
    }))
}
