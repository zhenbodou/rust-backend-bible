#[derive(Debug, thiserror::Error, PartialEq, Eq)]
pub enum RemoteError {
    #[error("invalid payment input")]
    InvalidInput,
    #[error("payment identity conflict")]
    IdentityConflict,
    #[error("payment service identity rejected")]
    Unauthenticated,
    #[error("payment deadline; result may be unknown")]
    Deadline,
    #[error("payment dependency unavailable; result may be unknown")]
    Unavailable,
    #[error("invalid payment response")]
    Protocol,
    #[error("payment circuit open; preserve original command identity")]
    CircuitOpen,
    #[error("caller budget exhausted; preserve original command identity")]
    LocalBudget,
}
#[derive(Clone)]
pub struct PaymentRemote {
    client: reqwest::Client,
    base: String,
    key: String,
    breaker: governance::breaker::Breaker,
}
impl PaymentRemote {
    pub fn new(base: &str, key: String) -> anyhow::Result<Self> {
        let url = reqwest::Url::parse(base)?;
        anyhow::ensure!(
            matches!(url.scheme(), "http" | "https")
                && url.host_str().is_some()
                && url.username().is_empty()
                && url.password().is_none()
                && url.path() == "/"
                && url.query().is_none()
                && url.fragment().is_none(),
            "payment endpoint must be an HTTP(S) origin without credentials"
        );
        ServiceKey::parse(&key)?;
        Ok(Self {
            client: client()?,
            base: base.trim_end_matches('/').into(),
            key,
            breaker: governance::breaker::Breaker::new(
                "payments",
                governance::breaker::Policy::default(),
            )
            .map_err(anyhow::Error::msg)?,
        })
    }
    #[tracing::instrument(name="http.client",skip_all,fields(otel.kind="client",peer.service="payments"))]
    async fn request(
        &self,
        c: &Charge,
        action: Option<Action>,
    ) -> Result<Option<Payment>, RemoteError> {
        if !c.valid() {
            return Err(RemoteError::InvalidInput);
        }
        let request = match action {
            Some(Action::Charge) => self
                .client
                .post(format!("{}/internal/payments", self.base))
                .json(c),
            Some(Action::Refund) => self
                .client
                .post(format!("{}/internal/payments/refund", self.base))
                .json(c),
            None => self
                .client
                .get(format!("{}/internal/payments/{}", self.base, c.saga_id)),
        }
        .bearer_auth(&self.key);
        let request =
            outbound(request, Duration::from_secs(2)).map_err(|_| RemoteError::LocalBudget)?;
        let mut response = observability::http(request).send().await.map_err(|e| {
            if e.is_timeout() {
                RemoteError::Deadline
            } else {
                RemoteError::Unavailable
            }
        })?;
        match response.status().as_u16() {
            200 => {}
            404 if action.is_none() => return Ok(None),
            400 | 422 => return Err(RemoteError::InvalidInput),
            409 => return Err(RemoteError::IdentityConflict),
            401 | 403 => return Err(RemoteError::Unauthenticated),
            504 => return Err(RemoteError::Deadline),
            429 | 500 | 502 | 503 => return Err(RemoteError::Unavailable),
            _ => return Err(RemoteError::Protocol),
        }
        let mut bytes = Vec::new();
        while let Some(chunk) = response.chunk().await.map_err(|e| {
            if e.is_timeout() {
                RemoteError::Deadline
            } else {
                RemoteError::Unavailable
            }
        })? {
            if bytes.len().saturating_add(chunk.len()) > 4096 {
                return Err(RemoteError::Protocol);
            }
            bytes.extend_from_slice(&chunk);
        }
        let row: Payment = serde_json::from_slice(&bytes).map_err(|_| RemoteError::Protocol)?;
        if (row.saga_id, row.actor_id, row.amount) != (c.saga_id, c.actor_id, c.amount) {
            return Err(RemoteError::Protocol);
        }
        Ok(Some(row))
    }
    async fn guarded(
        &self,
        c: &Charge,
        action: Option<Action>,
    ) -> Result<Option<Payment>, RemoteError> {
        if !c.valid() {
            return Err(RemoteError::InvalidInput);
        }
        let duration =
            call_duration(Duration::from_secs(2)).map_err(|_| RemoteError::LocalBudget)?;
        let permit=self.breaker.acquire().map_err(|rejection|{
            tracing::warn!(dependency="payments",phase=?rejection.phase,retry_after_ms=rejection.retry_after.as_millis(),"circuit rejected call; no payment request sent");
            RemoteError::CircuitOpen
        })?;
        let result = tokio::time::timeout(duration, self.request(c, action))
            .await
            .unwrap_or(Err(RemoteError::Deadline));
        use governance::breaker::Outcome;
        let outcome = match &result {
            Ok(_) => Outcome::Healthy,
            Err(RemoteError::Unavailable) => Outcome::Failure,
            Err(RemoteError::Deadline) if duration >= Duration::from_secs(2) => Outcome::Failure,
            Err(_) => Outcome::Ignore,
        };
        permit.finish(outcome);
        result
    }
    pub async fn apply(&self, c: &Charge, action: Action) -> Result<Payment, RemoteError> {
        self.guarded(c, Some(action))
            .await?
            .ok_or(RemoteError::Protocol)
    }
    pub async fn query(&self, c: &Charge) -> Result<Option<Payment>, RemoteError> {
        self.guarded(c, None).await
    }
}

