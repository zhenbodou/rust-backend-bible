use crate::runtime::*;
use axum::http::StatusCode;
use contracts::catalog::{catalog_client::CatalogClient, *};
use inventory::rpc::ServiceKey;
use std::time::Duration;
use tonic::transport::{Channel, Endpoint};
use tonic_health::pb::{
    HealthCheckRequest, health_check_response::ServingStatus, health_client::HealthClient,
};
#[derive(Clone)]
pub struct CatalogRemote {
    client: CatalogClient<Channel>,
    health: HealthClient<Channel>,
    key: ServiceKey,
}
fn error(e: tonic::Status) -> ApiError {
    match e.code() {
        tonic::Code::NotFound => ApiError(StatusCode::NOT_FOUND, "product not found"),
        tonic::Code::InvalidArgument => invalid(),
        tonic::Code::AlreadyExists | tonic::Code::FailedPrecondition => {
            ApiError(StatusCode::CONFLICT, "product command conflict")
        }
        _ => unavailable(),
    }
}
fn check(p: &Product) -> ApiResult<()> {
    if p.id <= 0 || p.price_cents < 0 || p.stock < 0 || p.name.trim().is_empty() {
        return Err(unavailable());
    }
    Ok(())
}
impl CatalogRemote {
    pub async fn connect(address: &str, key: ServiceKey) -> anyhow::Result<Self> {
        let endpoint = Endpoint::from_shared(address.to_owned())?
            .connect_timeout(Duration::from_millis(300))
            .timeout(Duration::from_millis(900));
        let channel = tokio::time::timeout(Duration::from_secs(1), endpoint.connect()).await??;
        Ok(Self {
            client: CatalogClient::new(channel.clone())
                .max_decoding_message_size(64 * 1024)
                .max_encoding_message_size(64 * 1024),
            health: HealthClient::new(channel),
            key,
        })
    }
    fn request<T>(&self, value: T) -> ApiResult<tonic::Request<T>> {
        let mut r = tonic::Request::new(value);
        self.key.attach(&mut r);
        observability::rpc(&mut r);
        r.set_timeout(call_duration(Duration::from_millis(700))?);
        Ok(r)
    }
    #[tracing::instrument(name="rpc.client",skip_all,fields(otel.kind="client",peer.service="catalog",rpc.method="get"))]
    pub async fn get(&self, id: i64) -> ApiResult<Product> {
        if id <= 0 {
            return Err(invalid());
        }
        let p = tokio::time::timeout(
            call_duration(Duration::from_secs(1))?,
            self.client
                .clone()
                .get_product(self.request(GetProductRequest { id })?),
        )
        .await
        .map_err(|_| unavailable())?
        .map_err(error)?
        .into_inner();
        check(&p)?;
        if p.id != id {
            return Err(unavailable());
        }
        Ok(p)
    }
    #[tracing::instrument(name="rpc.client",skip_all,fields(otel.kind="client",peer.service="catalog",rpc.method="list"))]
    pub async fn list(&self, limit: i64, offset: i64) -> ApiResult<ListProductsResponse> {
        if !(1..=100).contains(&limit) || offset < 0 {
            return Err(invalid());
        }
        let p = tokio::time::timeout(
            call_duration(Duration::from_secs(1))?,
            self.client
                .clone()
                .list_products(self.request(ListProductsRequest { limit, offset })?),
        )
        .await
        .map_err(|_| unavailable())?
        .map_err(error)?
        .into_inner();
        if p.total < 0 || p.items.len() > limit as usize {
            return Err(unavailable());
        }
        for row in &p.items {
            check(row)?;
        }
        Ok(p)
    }
    #[tracing::instrument(name="rpc.client",skip_all,fields(otel.kind="client",peer.service="catalog",rpc.method="create"))]
    pub async fn create(&self, value: CreateProductRequest) -> ApiResult<Product> {
        let p = tokio::time::timeout(
            call_duration(Duration::from_secs(1))?,
            self.client.clone().create_product(self.request(value)?),
        )
        .await
        .map_err(|_| unavailable())?
        .map_err(error)?
        .into_inner();
        check(&p)?;
        Ok(p)
    }
    #[tracing::instrument(name="rpc.client",skip_all,fields(otel.kind="client",peer.service="catalog",rpc.method="update"))]
    pub async fn update(&self, value: UpdateProductRequest) -> ApiResult<Product> {
        if value.id <= 0 {
            return Err(invalid());
        }
        let id = value.id;
        let p = tokio::time::timeout(
            call_duration(Duration::from_secs(1))?,
            self.client.clone().update_product(self.request(value)?),
        )
        .await
        .map_err(|_| unavailable())?
        .map_err(error)?
        .into_inner();
        check(&p)?;
        if p.id != id {
            return Err(unavailable());
        }
        Ok(p)
    }
    #[tracing::instrument(name="rpc.client",skip_all,fields(otel.kind="client",peer.service="catalog",rpc.method="delist"))]
    pub async fn delist(&self, id: i64) -> ApiResult<()> {
        if id <= 0 {
            return Err(invalid());
        }
        tokio::time::timeout(
            call_duration(Duration::from_secs(1))?,
            self.client
                .clone()
                .delist_product(self.request(GetProductRequest { id })?),
        )
        .await
        .map_err(|_| unavailable())?
        .map_err(error)?;
        Ok(())
    }
    pub async fn ready(&self) -> bool {
        matches!(tokio::time::timeout(Duration::from_millis(500),self.health.clone().check(tonic::Request::new(HealthCheckRequest{service:"readiness".into()}))).await,
            Ok(Ok(r)) if r.get_ref().status==ServingStatus::Serving as i32)
    }
}
