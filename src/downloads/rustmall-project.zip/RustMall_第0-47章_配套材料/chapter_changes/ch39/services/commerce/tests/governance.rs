use axum::{
    Router,
    body::Body,
    http::{Request, StatusCode},
    routing::{get, post},
};
use commerce::{
    payments::{Action, Charge, PaymentRemote, RemoteError},
    runtime::{self, BUDGET_HEADER},
};
use http_body_util::BodyExt;
use std::{
    sync::{
        Arc,
        atomic::{AtomicU64, AtomicUsize, Ordering},
    },
    time::Duration,
};
use tokio_util::sync::CancellationToken;
use tower::ServiceExt;
use uuid::Uuid;
const KEY: &str = "chapter39-test-service-key-not-for-production";
async fn call(
    app: &Router,
    path: &str,
    header: Option<&str>,
) -> (u16, axum::http::HeaderMap, String) {
    let mut r = Request::builder().uri(path);
    if let Some(value) = header {
        r = r.header(BUDGET_HEADER, value);
    }
    let r = app
        .clone()
        .oneshot(r.body(Body::empty()).unwrap())
        .await
        .unwrap();
    let status = r.status().as_u16();
    let headers = r.headers().clone();
    (
        status,
        headers,
        String::from_utf8(r.into_body().collect().await.unwrap().to_bytes().to_vec()).unwrap(),
    )
}
async fn server(app: Router) -> (String, CancellationToken, tokio::task::JoinHandle<()>) {
    let l = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
    let base = format!("http://{}", l.local_addr().unwrap());
    let stop = CancellationToken::new();
    let token = stop.clone();
    let task = tokio::spawn(async move {
        axum::serve(l, app)
            .with_graceful_shutdown(token.cancelled_owned())
            .await
            .unwrap()
    });
    (base, stop, task)
}
async fn close(stop: CancellationToken, mut task: tokio::task::JoinHandle<()>) {
    stop.cancel();
    if tokio::time::timeout(Duration::from_secs(3), &mut task)
        .await
        .is_err()
    {
        task.abort();
        let _ = task.await;
        panic!("mock did not stop");
    }
}
#[tokio::test(start_paused = true)]
async fn rate_burst_refill_and_control_scrapes_have_separate_semantics() {
    let app = runtime::bounded(Router::new().route("/", get(|| async { "ok" })));
    for _ in 0..64 {
        assert_eq!(call(&app, "/", None).await.0, 200);
    }
    let (status, h, b) = call(&app, "/", None).await;
    assert_eq!(status, 429);
    assert_eq!(h["retry-after"], "1");
    assert_eq!(
        serde_json::from_str::<serde_json::Value>(&b).unwrap()["code"],
        "RESOURCE_EXHAUSTED"
    );
    assert_eq!(call(&app, "/metrics", None).await.0, 200);
    tokio::time::advance(Duration::from_micros(31_250)).await;
    assert_eq!(call(&app, "/", None).await.0, 200);
}
#[tokio::test]
async fn inbound_hint_shortens_an_internal_request_and_invalid_hints_are_rejected() {
    let app = runtime::bounded(Router::new().route(
        "/",
        get(|| async {
            tokio::time::sleep(Duration::from_millis(150)).await;
            "ok"
        }),
    ));
    assert_eq!(call(&app, "/", Some("20")).await.0, 504);
    for bad in ["0", "5001", "-1", "x"] {
        assert_eq!(call(&app, "/", Some(bad)).await.0, 400);
    }
}
#[tokio::test]
async fn edge_ignores_external_hint_consumes_body_time_and_allows_more_than_two_seconds() {
    let seen = Arc::new(AtomicU64::new(0));
    let observed = seen.clone();
    let (base, stop, task) = server(Router::new().route(
        "/api/v1/products",
        get(move |headers: axum::http::HeaderMap| {
            let seen = observed.clone();
            async move {
                seen.store(
                    headers[BUDGET_HEADER].to_str().unwrap().parse().unwrap(),
                    Ordering::SeqCst,
                );
                tokio::time::sleep(Duration::from_millis(2200)).await;
                "{}"
            }
        }),
    ))
    .await;
    let edge = commerce::edge::Edge::new(&base, &base, &base, "http://localhost:3000").unwrap();
    let app = runtime::bounded_edge(commerce::edge::router(edge));
    let stream = futures_util::stream::once(async {
        tokio::time::sleep(Duration::from_millis(250)).await;
        Ok::<_, std::io::Error>(axum::body::Bytes::new())
    });
    let r = app
        .oneshot(
            Request::builder()
                .uri("/api/v1/products")
                .header(BUDGET_HEADER, "1")
                .body(Body::from_stream(stream))
                .unwrap(),
        )
        .await
        .unwrap();
    assert_eq!(r.status(), StatusCode::OK);
    assert!((1..=4660).contains(&seen.load(Ordering::SeqCst)));
    close(stop, task).await;
}
#[tokio::test]
async fn breaker_blocks_new_wire_requests_recovers_and_preserves_identity() {
    let calls = Arc::new(AtomicUsize::new(0));
    let healthy = Arc::new(AtomicUsize::new(0));
    let c = Charge {
        saga_id: Uuid::new_v4(),
        actor_id: 7,
        amount: 100,
    };
    let expected = c.clone();
    let count = calls.clone();
    let mode = healthy.clone();
    let(base,stop,task)=server(Router::new().route("/internal/payments",post(move|axum::Json(body):axum::Json<Charge>|{let calls=count.clone();let mode=mode.clone();let expected=expected.clone();async move{
        assert_eq!(body,expected);calls.fetch_add(1,Ordering::SeqCst);
        if mode.load(Ordering::SeqCst)==0{(StatusCode::SERVICE_UNAVAILABLE,axum::Json(serde_json::json!({})))}else{(StatusCode::OK,axum::Json(serde_json::json!({"saga_id":body.saga_id,"actor_id":body.actor_id,"amount":body.amount,"state":"paid"})))}
    }}))).await;
    let client = PaymentRemote::new(&base, KEY.into()).unwrap();
    for _ in 0..5 {
        assert_eq!(
            client.apply(&c, Action::Charge).await.unwrap_err(),
            RemoteError::Unavailable
        );
    }
    assert_eq!(
        client.clone().apply(&c, Action::Charge).await.unwrap_err(),
        RemoteError::CircuitOpen
    );
    assert_eq!(calls.load(Ordering::SeqCst), 5);
    healthy.store(1, Ordering::SeqCst);
    tokio::time::sleep(Duration::from_millis(5050)).await;
    assert_eq!(
        client.apply(&c, Action::Charge).await.unwrap().saga_id,
        c.saga_id
    );
    assert_eq!(calls.load(Ordering::SeqCst), 6);
    close(stop, task).await;
}
#[tokio::test]
async fn authentication_failures_and_local_expiry_do_not_trip_the_dependency() {
    let count = Arc::new(AtomicUsize::new(0));
    let calls = count.clone();
    let (base, stop, task) = server(Router::new().route(
        "/internal/payments",
        post(move || {
            let c = calls.clone();
            async move {
                c.fetch_add(1, Ordering::SeqCst);
                StatusCode::UNAUTHORIZED
            }
        }),
    ))
    .await;
    let c = Charge {
        saga_id: Uuid::new_v4(),
        actor_id: 7,
        amount: 100,
    };
    let client = PaymentRemote::new(&base, KEY.into()).unwrap();
    for _ in 0..10 {
        assert_eq!(
            client.apply(&c, Action::Charge).await.unwrap_err(),
            RemoteError::Unauthenticated
        );
    }
    governance::budget::scope(Duration::from_millis(1), async {
        tokio::time::sleep(Duration::from_millis(2)).await;
        assert_eq!(
            client.apply(&c, Action::Charge).await.unwrap_err(),
            RemoteError::LocalBudget
        );
    })
    .await;
    assert_eq!(count.load(Ordering::SeqCst), 10);
    close(stop, task).await;
}
