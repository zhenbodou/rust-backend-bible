# Chapter39 governance checkpoint

Continue stage38, preserving `.saga.local`, the business/Kafka volumes and stable
consumer identities. Stop old application roles, build this checkpoint, then
restart the same ten logical roles. This chapter adds no database migration.

```sh
cargo +1.92.0 build --locked --workspace --all-features --bins
python3 scripts/check-saga-http.py --local-admin-fixture --delist-after-order
```

The active commerce HTTP roles keep32 concurrency permits and gain a per-process
token bucket: refill32/sec, burst64. Control probes and metrics bypass these
business limits.429 rate responses include a conservative integer Retry-After;
rate and capacity refusal have distinct fixed log categories. This is not a
distributed global quota, and each additional replica adds its own capacity.
Legacy teaching monolith/gateway binaries are not silently claimed to use this
new commerce limiter.

HTTP5-second budgets now use a monotonic task-local scope. External edge ignores
caller-supplied `x-rustmall-budget-ms`; internal role boundaries accept a unique
1-5000 millisecond hint that can only shorten the hard cap. Outbound clients
recompute remaining time and reserve100ms. Edge's transport cap is4.8sec, normal
internal HTTP remains2sec, Catalog gRPC has its700ms metadata cap and Inventory
900ms, all shortened by the current scope. Metadata and local awaits are both
limited. Relative wire hints do not remove network delay or prove that remote
execution stops exactly when the caller returns; SQL retains separate limits.

Catalog pool now has session statement500ms/lock200ms defaults in addition to
its acquire500ms limit. Inventory/payment transaction SET LOCAL settings remain.
A cancelled future does not prove that a transaction or remote effect rolled
back. All write recovery retains the original identity and immutable inputs.

PaymentRemote owns a clone-shared, process-local circuit: Closed fixed30s window,
minimum5 eligible completed samples,60% failure ratio; Open cooldown5s; one
HalfOpen probe with3s lifetime. Valid business replies are Healthy. Real
unavailability or an exhausted full2sec dependency budget count as Failure.
Input/auth/contract errors and caller-shortened deadline outcomes do not trip
Closed dependency statistics. HalfOpen Ignore/failure/cancellation/expiry opens
again because availability has not been proved. A generation Arc fences late
results and cancelled old probes; no mutex guard is held across network await; the owned Permit deliberately spans the call so cancellation can be observed by Drop.

CircuitOpen means this attempt did not send a new request; it says nothing about
previous same-UUID attempts. The worker persists payment-circuit-open or caller
budget categories and retries the original order. It does not auto-cancel an
unknown payment. Restarting a worker resets process-local circuit statistics,
while database order/participant receipts survive.

Orders and Outbox get deterministic equal jitter on their bounded exponential
base, with at least1second delay. Identity+attempt reproduces the same delay;
next-attempt time is saved in the owning DB rather than sleeping while holding
an order. No gateway POST retry loop or cross-process retry budget was invented.

## Exact reader payment-outage exercise

Stop payments in its own terminal, then run:

```sh
python3 scripts/check-governance-faults.py prepare --local-admin-fixture
python3 scripts/check-governance-faults.py outage --local-admin-fixture
```

The explicit isolated admin fixture creates8 durable orders, with command keys
saved before HTTP writes. A private0600 `.saga.local/governance39.json` stores
lab client credentials and request identities; exclude it from all archives.
Rerunning prepare replays the original keys. Do not delete this receipt just to
make a failed experiment look clean. Partial `.json.tmp` files require inspection.

The outage checkpoint expects8 charging orders,8 Held reservations, stock12 from
an initial20, no matching payment receipts, and a durable circuit-open category.
Resume payments in its original terminal:

```sh
python3 scripts/run-saga-role.py payments
```

In another terminal:

```sh
python3 scripts/check-governance-faults.py recovered --local-admin-fixture
```

The same UUIDs must finish with8 Confirmed reservations,8 paid effects, no extra
refund/effect, and stock12. Nothing in this script kills other processes or
deletes data. Product/order HTTP replay and participant receipts enforce the
same invariants if the script itself is interrupted and resumed.

Further isolated native verification also races2 orders for stock1, kills a
worker in leased charging while payment processing is paused, and proves the
original order completes with one paid effect after expiry/takeover. Logout
followed by clearing only that test Redis database never revives the old token.
Both Kafka projections must still fully match authority after writers stop.

```sh
cargo +1.92.0 test --locked -p governance
cargo +1.92.0 test --locked -p commerce --test governance
python3 scripts/run-saga-tests.py
```

Core tests use virtual time; HTTP tests count actual wire requests. Full native
faults use real local PostgreSQL/Redis/Kafka and Collector/Prometheus, with owned
resource cleanup. They do not prove production TLS, least-privilege DB grants,
Linux application images, CNI enforcement, real cluster drain or deployment.
Those remain required work in the later delivery chapters and final audit.
