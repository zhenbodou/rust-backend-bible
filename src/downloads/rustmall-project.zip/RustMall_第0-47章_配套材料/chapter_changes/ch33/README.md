# RustMall 第0—33章累积工程

固定Rust1.92.0。当前组件：common、platform、contracts、monolith（过渡HTTP/用户认证）、catalog（独立商品gRPC与数据库）、gateway（HTTP边界）、messaging（Outbox/Inbox/Kafka投影）、inventory（商品库内预留事务与可信CLI）。

请按合订教材第26—33章顺序运行。scripts/create-catalog-env.py、create-facade-env.py、create-projection-env.py分别创建商品、身份、投影数据库的本地配置，均拒绝覆盖且不打印秘密。不要交换迁移入口，不要把新服务迁移应用到旧库。

## 运行顺序

1. 准备Rust1.92.0、Docker/Compose、C/C++工具链与CMake。核对本机端口55433/55434/55435和50051/8080/8081/9092。
2. 第26章创建商品数据库并运行catalog-migrate，加载商品配置后启动catalog。
3. 第27章创建独立身份数据库、执行rustmall-migrate。接口层终端先加载catalog配置再加载facade配置，启用RUSTMALL_CATALOG_ENDPOINT，最后启动monolith。网关使用GATEWAY_UPSTREAM指向接口层，再启动gateway。
4. 第28章启动deploy/messaging/compose.yaml内单节点Kafka，显式创建各实验主题。text-lab、demo与snapshots主题不能混用格式。
5. 第29章初始化独立投影库，运行projection-migrate；outbox-relay用CATALOG_DATABASE_URL，projection-worker用PROJECTION_DATABASE_URL，业务主题rustmall.catalog.snapshots.v1。
6. 第30章执行catalog第三次迁移。可信inventory-command直接访问商品库，只供本地实验/受控管理，本章保留该本地工具。

7. 第31章运行scripts/create-inventory-env.py生成独立库存凭据。catalog终端另加载.env.inventory.local；商品与库存令牌必须不同。可信调用方只加载库存令牌和RUSTMALL_CATALOG_ENDPOINT，用inventory-rpc跨网络操作，不授予它DATABASE_URL。第31章详细命令和独立小实验见书稿。

8. 第32章执行catalog-migrate新增第四次商品迁移。inventory-adjust apply/query UUID PRODUCT_ID DELTA ACTOR_ID REASON --local-admin只供持有商品库写凭据的受控管理终端；actor参数不是认证证明。重复同一操作保留UUID及全部输入。补货/盘亏不会绕开预留与释放空间约束。

Remote模式公共POST /api/v1/products要求一个UUID Idempotency-Key。最终用户权限仍由JWT/AdminUser验证，内部服务令牌不替代用户身份。商品PUT不能直接改库存：请求stock须等于锁定后的当前值，违反返回409；通过库存预留/释放改变可售量。初始创建库存可指定，补货/盘亏使用第32章专门调整命令。

## 检查

专用测试PostgreSQL的DATABASE_URL账号需能创建测试数据库，绝不能指向生产。

```bash
cargo +1.92.0 fmt --all --check
cargo +1.92.0 clippy --locked --workspace --all-targets --all-features -- -D warnings
cargo +1.92.0 test --locked --workspace --all-features -- --test-threads=2
cargo +1.92.0 test --locked -p monolith --test pg_container -- --ignored --test-threads=1
cargo +1.92.0 test --locked -p monolith --test product_cache -- --ignored --test-threads=1
```

不同章节同名包应使用独立CARGO_TARGET_DIR，避免检查时混入另一检查点的旧产物。需要自定义CMake路径时设置CMAKE指向实际可执行文件，不复制作者机器的绝对路径。

现有Dockerfile/compose/Helm是前面单体交付练习，并非全部微服务的最终部署。完整微服务镜像、TLS、集群与高可用交付将继续在后续章节实现；当前验证范围见随包的verification记录。不要将原生进程测试等同于Linux镜像或远端CI已运行。

第33章工程检查：python3 scripts/check-checkpoint.py 检查角色/二进制/迁移结构；加 --role catalog 等参数检查当前进程环境（仅本地回环HTTP实验）。cargo test --locked -p contracts --test compatibility 检查已审阅v1描述符账本。检查不等于实际账号权限、生产TLS或部署证明。详见docs/checkpoint-33.md。
