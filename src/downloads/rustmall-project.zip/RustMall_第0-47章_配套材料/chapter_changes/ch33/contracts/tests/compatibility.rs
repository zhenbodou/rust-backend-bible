use contracts::FILE_DESCRIPTOR_SET;
use prost::Message;
use prost_types::{
    FileDescriptorSet,
    field_descriptor_proto::{Label, Type},
};
use serde_json::{Map, Value, json};

fn describe(bytes: &[u8]) -> Value {
    let descriptor = FileDescriptorSet::decode(bytes).expect("valid protoc descriptor");
    let file = descriptor
        .file
        .iter()
        .find(|f| f.package.as_deref() == Some("rustmall.catalog.v1"))
        .expect("catalog v1 package");
    let mut messages = Map::new();
    for message in &file.message_type {
        let mut fields = Map::new();
        for field in &message.field {
            let kind = Type::try_from(field.r#type.unwrap())
                .unwrap()
                .as_str_name()
                .trim_start_matches("TYPE_")
                .to_lowercase();
            let label = Label::try_from(field.label.unwrap())
                .unwrap()
                .as_str_name()
                .trim_start_matches("LABEL_")
                .to_lowercase();
            fields.insert(
                field.name.clone().unwrap(),
                json!({
                    "number":field.number, "type":kind, "label":label,
                    "type_name":field.type_name.as_deref().unwrap_or(""),
                    "oneof_index":field.oneof_index,
                    "proto3_optional":field.proto3_optional.unwrap_or(false)
                }),
            );
        }
        messages.insert(message.name.clone().unwrap(), Value::Object(fields));
    }
    let mut enums = Map::new();
    for enumeration in &file.enum_type {
        let values: Map<String, Value> = enumeration
            .value
            .iter()
            .map(|v| (v.name.clone().unwrap(), json!(v.number)))
            .collect();
        enums.insert(enumeration.name.clone().unwrap(), Value::Object(values));
    }
    let mut methods = Map::new();
    for service in &file.service {
        for method in &service.method {
            methods.insert(
                format!(
                    "{}.{}",
                    service.name.as_deref().unwrap(),
                    method.name.as_deref().unwrap()
                ),
                json!({
                    "input":method.input_type, "output":method.output_type,
                    "client_streaming":method.client_streaming.unwrap_or(false),
                    "server_streaming":method.server_streaming.unwrap_or(false)
                }),
            );
        }
    }
    json!({"package":file.package,"syntax":file.syntax,"messages":messages,"enums":enums,"methods":methods})
}

// Existing entries are immutable; new fields/types/methods may be added.
// This is the book's conservative v1 rule, not a complete Protobuf compatibility checker.
fn preserves(expected: &Value, actual: &Value, path: &str) -> Result<(), String> {
    if let Value::Object(entries) = expected {
        for (key, value) in entries {
            let next = actual
                .get(key)
                .ok_or_else(|| format!("removed: {path}/{key}"))?;
            preserves(value, next, &format!("{path}/{key}"))?;
        }
        return Ok(());
    }
    if expected == actual {
        Ok(())
    } else {
        Err(format!("changed: {path}"))
    }
}

fn baseline() -> Value {
    serde_json::from_str(include_str!("../compat/catalog-v1.json")).unwrap()
}

#[test]
fn generated_descriptor_preserves_the_reviewed_v1_contract() {
    preserves(&baseline(), &describe(FILE_DESCRIPTOR_SET), "v1").unwrap();
}

#[test]
fn rejects_changed_money_type_even_when_the_wire_type_is_compatible() {
    let expected = baseline();
    let mut changed = expected.clone();
    changed["messages"]["Product"]["price_cents"]["type"] = json!("uint64");
    assert!(
        preserves(&expected, &changed, "v1")
            .unwrap_err()
            .contains("price_cents/type")
    );
}

#[test]
fn rejects_field_renumbering_or_removal() {
    let expected = baseline();
    let mut changed = expected.clone();
    changed["messages"]["ReservationCommand"]["quantity"]["number"] = json!(9);
    assert!(preserves(&expected, &changed, "v1").is_err());
    changed = expected.clone();
    changed["messages"]["CreateProductRequest"]
        .as_object_mut()
        .unwrap()
        .remove("idempotency_key");
    assert!(preserves(&expected, &changed, "v1").is_err());
}

#[test]
fn rejects_changed_enum_or_rpc_shape() {
    let expected = baseline();
    let mut changed = expected.clone();
    changed["enums"]["ReservationState"]["RESERVATION_STATE_HELD"] = json!(2);
    assert!(preserves(&expected, &changed, "v1").is_err());
    changed = expected.clone();
    changed["methods"]["Inventory.Reserve"]["server_streaming"] = json!(true);
    assert!(preserves(&expected, &changed, "v1").is_err());
}

#[test]
fn additive_fields_are_allowed_without_erasing_the_old_ledger() {
    let expected = baseline();
    let mut changed = expected.clone();
    changed["messages"]["Product"]["future_field"] = json!({"number":50,"type":"string"});
    assert!(preserves(&expected, &changed, "v1").is_ok());
}
