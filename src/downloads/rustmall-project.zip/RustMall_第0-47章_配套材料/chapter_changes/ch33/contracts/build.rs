fn main() -> Result<(), Box<dyn std::error::Error>> {
    let mut config = prost_build::Config::new();
    config.file_descriptor_set_path(
        std::path::PathBuf::from(std::env::var("OUT_DIR")?).join("catalog_descriptor.bin"),
    );
    config.protoc_executable(protoc_bin_vendored::protoc_bin_path()?);
    tonic_prost_build::configure().compile_with_config(
        config,
        &["proto/catalog.proto"],
        &["proto"],
    )?;
    println!("cargo:rerun-if-changed=proto/catalog.proto");
    Ok(())
}
