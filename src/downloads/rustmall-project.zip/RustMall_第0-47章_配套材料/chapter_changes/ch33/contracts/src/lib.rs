pub const FILE_DESCRIPTOR_SET: &[u8] = tonic::include_file_descriptor_set!("catalog_descriptor");

pub mod catalog {
    tonic::include_proto!("rustmall.catalog.v1");
}

#[cfg(test)]
mod tests {
    use super::catalog::Product;
    use prost::Message;
    #[test]
    fn integer_money_and_unicode_round_trip() {
        let value = Product {
            id: 7,
            name: "机械键盘".into(),
            price_cents: 19900,
            stock: 10,
        };
        assert_eq!(
            Product::decode(value.encode_to_vec().as_slice()).unwrap(),
            value
        );
    }
    #[test]
    fn empty_wire_message_does_not_validate_business_rules() {
        let decoded = Product::decode(&[][..]).unwrap();
        assert_eq!((decoded.id, decoded.price_cents, decoded.stock), (0, 0, 0));
        assert!(decoded.name.is_empty());
    }
    #[test]
    fn unknown_field_is_ignored_by_current_decoder() {
        let mut data = Product {
            id: 7,
            ..Default::default()
        }
        .encode_to_vec();
        data.extend_from_slice(&[0x28, 0x01]); // field 5, varint 1
        let decoded = Product::decode(data.as_slice()).unwrap();
        assert_eq!(decoded.id, 7);
        assert_eq!(decoded.encode_to_vec(), [0x08, 0x07]);
    }
}
