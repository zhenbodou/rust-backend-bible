# 第33章运行检查点

当前仍使用过渡monolith HTTP/身份入口、独立catalog、gateway、messaging与inventory；users/payments/orders后续引入。普通商品元数据PUT保留，库存覆盖拒绝。

运行角色与变量见runtime-boundaries.json；python3 scripts/check-checkpoint.py核对Cargo目标/迁移目录，带--role检查当前环境（仅回环HTTP实验）。它不证明服务连通或实际数据库授权。角色数据库标签用于说明所有权，不是可直接创建的数据库名。

catalog服务终端加载.env.catalog.local和.env.inventory.local；facade终端先商品配置再.env.facade.local，使DATABASE_URL归身份库。RPC库存客户端不接收DATABASE_URL。库存调整CLI仅限受控管理终端；actor参数不是认证证明。

cargo test --locked -p contracts --test compatibility核对已审阅的v1账本。不要随修改后的协议自动重写账本。新增字段可通过，不等于旧客户端理解新业务值；当前检查器只覆盖本协议顶层类型，扩展语法时要扩展检查。

CI增加结构检查，原完整workspace测试继续运行。真实数据库需要隔离测试账号，ignored容器测试另选。构建/测试/原生进程不等于应用镜像或集群部署。
