# 第47章当前公共HTTP接口

本文件描述最终十角色工程的Edge入口。Docker Compose默认只向本机发布 `http://127.0.0.1:18086`；合并第44章TLS覆盖后，仅发布 `https://localhost:18443`，原18086端口关闭。原gateway8081、facade8080及分散的原生实验端口属于历史检查点，不能混用身份库、JWT和凭据。

## 入口、身份与商品

| 方法与路径 | 权限与当前语义 |
| --- | --- |
| GET /healthz | Edge进程存活；不能代替依赖或业务检查 |
| GET /readyz | Edge检查Users、Orders和Catalog HTTP的就绪，失败503 |
| POST /api/v1/auth/register | username/password；只注册普通用户，201，不接受自选role |
| POST /api/v1/auth/login | 原密码验证与登录限流；200含access_token、token_type、expires_in；没有刷新令牌接口 |
| GET /api/v1/auth/me | 当前Bearer身份，id与role；兼容GET /api/v1/users/me |
| POST /api/v1/auth/logout | 持久撤销；成功及重复204；依赖故障可能503，保留重试责任 |
| GET /api/v1/products | 公开分页；page默认1，page_size默认20且范围1..100，返回items/total/page/page_size |
| GET /api/v1/products/{id} | 公开详情；不存在或下架404 |
| POST /api/v1/products | 管理员；单个非nil UUID Idempotency-Key；name/price_cents/stock；201，同键同输入重放、改参数409 |
| PUT /api/v1/products/{id} | 管理员；name/price_cents/stock；名称价格可改，stock必须等于加锁后的可售数量，覆盖库存409 |
| DELETE /api/v1/products/{id} | 管理员软下架，204；重复删除当前404 |

金额单位是整数分；商品JSON为id/name/price_cents/stock。运行接口没有公共任意库存覆盖、用户自升管理员或批量改订单步骤入口。受限inventory-adjust是独立管理员工具，不能用用户JWT调用内部库存RPC。

## 新Saga订单

| 方法与路径 | 权限与当前语义 |
| --- | --- |
| POST /api/v1/orders | 用户Bearer与单个非nil UUID Idempotency-Key；仅product_id/quantity；202返回持久订单及当前步骤，受理不等于已付款 |
| GET /api/v1/orders/{uuid} | 所属actor才可查，其余404；无公网任意改状态或manual恢复接口 |

创建时按actor/request key重放，数量范围1..999，冻结单价与总额受当前订单约束。相同actor同键改输入409；导入历史的同actor旧请求键也409，指向历史查询。新步骤为reserving/charging/confirming/refunding/releasing/completed/cancelled/manual。新completed表示付款与库存协调完成，不表示物流发货完成。

## 第47章历史读取

| 方法与路径 | 权限与当前语义 |
| --- | --- |
| GET /api/v1/orders/legacy/{old_bigint_id} | 当前actor归属过滤；返回legacy_id/public_id/source_id/legacy_status/source_payload，保留旧冻结价与物流字段；其他actor404 |
| GET /api/v1/orders/legacy-cart?page=1 | 当前actor只读历史购物车；每页最多100条，page范围1..10000；错误类型、未知参数、零或溢出返回JSON400 INVALID_INPUT |

历史表独立于新Saga和实验付款账本。迁移只接已结清completed和未付cancelled；未结清状态或旧表缺少退款证明的已付取消需要先在旧流程处理。历史购物车不会自动结算；稳定UUID映射不代表新Saga存在，也不提供访问权限。

## 内部调用和验证边界

内部Payments仅在私有网络使用专用服务Bearer：POST /internal/payments、POST /internal/payments/refund、GET /internal/payments/{uuid}；字段saga_id/actor_id/amount必须绑定。它是教学模拟器，不是真实银行或复式账本。Catalog/Inventory使用各自gRPC凭据；它们不接受用户JWT，也没有经Edge公开内部端点。

标准业务错误使用code/message JSON；依赖故障503、未知结果或预算到期按路径504，身份冲突409。代理413/502/504另按第44章映射。源码与真实路由是最终依据，默认Axum未匹配路径或方法的处理不能被本表扩大成全部响应格式保证。

复现本章完整链路：从工程根运行 `scripts/check-delivery.py --legacy --recovery-cutover`，选择实际构建的镜像和私有实验证书；这只操作自动创建的本机实验项目。最终同镜像TLS25组与无TLS21组、403项常规及另选五项Docker检查记录随交付保存；远端发布及生产容量需独立证据。
