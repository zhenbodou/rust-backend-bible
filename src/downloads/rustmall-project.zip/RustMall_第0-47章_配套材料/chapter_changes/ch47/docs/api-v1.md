历史设计说明：本文件保存早期接口设计练习，刷新令牌、物流及购物车写操作并非最终工程已实现清单。当前公开入口、状态与权限以docs/current-http-api.md和第47章为准；不要把设计中的24小时窗口当作已有自动清理策略。

> 本文件保留第9章的目标设计，部分订单和会话能力属于后续章节。当前已实现接口以根README和docs/current-http-api.md为准。

# RustMall API v1 设计文档

## 1. 通用约定

| 项目 | 约定 |
| --- | --- |
| 基础路径 | `/api/v1` |
| 数据格式 | 请求与响应正文均为 JSON，`Content-Type: application/json; charset=utf-8` |
| 字段命名 | snake_case |
| 金额 | 整数，单位为分，字段名以 `_cents` 结尾 |
| 时间 | RFC 3339 字符串，UTC，例如 `2026-10-10T08:30:00Z` |
| ID | 整数（JSON number） |
| 枚举 | 小写字符串，例如订单状态 `pending` |
| 认证 | `Authorization: Bearer <access_token>`；标注“登录”的接口必须携带 |
| 请求编号 | 每个响应都带 `X-Request-Id` 头；客戶端传入时沿用，否则由服务端生成 |
| 幂等 | 创建类 POST 接口接受 `Idempotency-Key` 头（UUID），24 小时内同一个键返回同一结果 |
| 分页 | 查询参数 `page`（默认 1）与 `page_size`（默认 20，最大 100） |

## 2. 错误响应

所有错误的响应体：

```json
{ "code": "CONFLICT", "message": "商品 42 库存不足：需要 3，剩余 1", "request_id": "0f8c2a1e7d" }
```

| HTTP 状态码 | code | 含义 |
| --- | --- | --- |
| 400 | `BAD_REQUEST` | 请求无法解析（JSON 语法错误、类型错误、缺少必填字段） |
| 401 | `UNAUTHORIZED` | 未登录或令牌无效、过期 |
| 403 | `FORBIDDEN` | 无权限 |
| 404 | `NOT_FOUND` | 资源不存在 |
| 409 | `CONFLICT` | 状态冲突：用户名已存在、库存不足、订单状态不允许 |
| 422 | `INVALID_INPUT` | 业务校验失败 |
| 429 | `TOO_MANY_REQUESTS` | 请求过于频繁，见 `Retry-After` |
| 500 | `INTERNAL` | 服务器内部错误，message 固定为“服务器内部错误” |
| 503 | `UNAVAILABLE` | 服务暂时不可用 |

客戶端只能依据 `code` 做程序判断，`message` 仅用于展示。
## 3. 分页响应

```json
{ "items": [], "page": 1, "page_size": 20, "total": 0 }
```

## 4. 接口清单

| 方法 | 路径 | 说明 | 认证 | 成功状态码 |
| --- | --- | --- | --- | --- |
| GET | `/health/live` | 存活检查 | 否 | 200 |
| GET | `/health/ready` | 就绪检查（依赖可用） | 否 | 200 / 503 |
| POST | `/api/v1/auth/register` | 注册 | 否 | 201 |
| POST | `/api/v1/auth/login` | 登录，返回令牌 | 否 | 200 |
| POST | `/api/v1/auth/refresh` | 刷新访问令牌 | 否（携带刷新令牌） | 200 |
| POST | `/api/v1/auth/logout` | 注销刷新令牌 | 登录 | 204 |
| GET | `/api/v1/users/me` | 当前用户信息 | 登录 | 200 |
| GET | `/api/v1/products` | 商品列表（分页、搜索） | 否 | 200 |
| GET | `/api/v1/products/{id}` | 商品详情 | 否 | 200 |
| POST | `/api/v1/products` | 新增商品 | 管理员 | 201 |
| PUT | `/api/v1/products/{id}` | 修改商品（整体） | 管理员 | 200 |
| DELETE | `/api/v1/products/{id}` | 下架商品 | 管理员 | 204 |
| GET | `/api/v1/cart` | 查看购物车与结算预览 | 登录 | 200 |
| PUT | `/api/v1/cart/items/{product_id}` | 设置某商品的购买数量（不存在则加入） | 登录 | 200 |
| DELETE | `/api/v1/cart/items/{product_id}` | 移出购物车 | 登录 | 204 |
| POST | `/api/v1/orders` | 下单 | 登录 | 201 |
| GET | `/api/v1/orders` | 我的订单（分页，可按状态过滤） | 登录 | 200 |
| GET | `/api/v1/orders/{id}` | 订单详情（只能看自己的） | 登录 | 200 |
| POST | `/api/v1/orders/{id}/pay` | 支付 | 登录 | 200 |
| POST | `/api/v1/orders/{id}/cancel` | 取消 | 登录 | 200 |
| POST | `/api/v1/orders/{id}/ship` | 发货 | 管理员 | 200 |
| POST | `/api/v1/orders/{id}/complete` | 确认收货 | 登录 | 200 |

## 5. 接口详情

### 5.1 注册 `POST /api/v1/auth/register`

请求：

```json
{ "username": "alice_01", "password": "S3cure-Passw0rd" }
```
- `username`：3~20 个字符，字母、数字、下划线，不区分大小写（规范化为小写）
- `password`：8~64 个字符

响应 201：
```json
{ "id": 7, "username": "alice_01", "role": "user", "created_at": "2026-10-10T08:30:00Z" }```

错误：用户名格式不合法 422；用户名已存在 409。

### 5.2 登录 `POST /api/v1/auth/login`

请求：`{ "username": "alice_01", "password": "S3cure-Passw0rd" }`

响应 200：

```json
{ "access_token": "eyJ...", "token_type": "Bearer", "expires_in": 900 }
```

错误：用户名或密码错误统一返回 401（不区分“用户不存在”与“密码错误”，防止探测用户名）。

### 5.3 商品列表 `GET /api/v1/products`

查询参数：`q`（搜索词，支持 `分类:关键词`）、`min_price_cents`、`max_price_cents`、`sort`（`price`、`-price`、`-created_at`，默认 `-created_at`）、`page`、`page_size`。

响应 200：

```json
{
  "items": [
    { "id": 42, "name": "机械键盘", "price_cents": 19900, "stock": 10, "created_at": "2026-10-01T02:00:00Z" }
  ],
  "page": 1,
  "page_size": 20,
  "total": 1
}
```

### 5.4 新增商品 `POST /api/v1/products`（管理员）

请求：`{ "name": "机械键盘", "price_cents": 19900, "stock": 10 }`

响应 201，`Location: /api/v1/products/42`，正文为商品详情。

错误：名称为空或超过 100 字、价格或库存为负 422；非管理员 403。

### 5.5 设置购物车商品数量 `PUT /api/v1/cart/items/{product_id}`

请求：`{ "quantity": 2 }`（1~99）

响应 200：返回整个购物车（同 5.6）。商品不存在 404；数量超限 422。

### 5.6 查看购物车 `GET /api/v1/cart`
响应 200：

```json
{
  "lines": [
    { "product_id": 42, "name": "机械键盘", "unit_price_cents": 19900, "quantity": 2, 
        "subtotal_cents": 39800 }
  ],
  "item_count": 2,
  "subtotal_cents": 39800,
  "discount_cents": 5000,
  "payable_cents": 34800,
  "applied_promotion": { "type": "full_reduction", "threshold_cents": 30000, "off_cents": 5000 
      }
}
```

### 5.7 下单 `POST /api/v1/orders`

请求头：`Idempotency-Key: <UUID>`（必填）

请求：`{ "product_id": 42, "quantity": 2 }`

响应 201，`Location: /api/v1/orders/1001`：
```json
{
  "id": 1001,
  "product_id": 42,
  "quantity": 2,
  "unit_price_cents": 19900,
  "total_cents": 39800,
  "status": "pending",
  "created_at": "2026-10-10T08:30:00Z"
}
```

错误：商品不存在 404；库存不足 409；数量超限 422；缺少 Idempotency-Key 400。使用同一个 Idempotency- Key 重复提交，返回第一次的结果，不会重复下单。

### 5.8 订单状态操作

| 接口 | 允许的当前状态 | 结果状态 | 请求体 |
| --- | --- | --- | --- |
| `POST /orders/{id}/pay` | pending | paid | 无 |
| `POST /orders/{id}/cancel` | pending、paid | cancelled | `{ "reason": "不想要了" }` |
| `POST /orders/{id}/ship` | paid | shipped | `{ "tracking_no": "SF1234567890" }` |
| `POST /orders/{id}/complete` | shipped | completed | 无 |

状态不允许时返回 409，message 示例：“订单当前为 pending 状态，不允许执行 ship”。成功时返回订单详情；状态为 shipped 与 completed 的订单详情中包含 `tracking_no`，已取消的订单包含 `cancel_reason`。

访问他人的订单一律返回 404（而不是 403），不暴露订单是否存在。

## 6. 版本与兼容

- v1 内只做向后兼容的修改：新增接口、新增响应字段、新增可选参数。
- 客戶端必须忽略不认识的响应字段。
- 不兼容的修改发布为 v2，v1 至少保留 6 个月。
