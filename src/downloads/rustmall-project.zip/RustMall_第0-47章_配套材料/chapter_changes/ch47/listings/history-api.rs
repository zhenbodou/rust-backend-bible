#[derive(Serialize, sqlx::FromRow)]
struct LegacyView {
    legacy_id: i64,
    public_id: Uuid,
    source_id: Uuid,
    legacy_status: String,
    source_payload: sqlx::types::Json<serde_json::Value>,
}
async fn legacy_query(
    State(s): State<Orders>,
    Extension(Actor(actor)): Extension<Actor>,
    Path(raw): Path<String>,
) -> ApiResult<Json<LegacyView>> {
    let id = raw
        .parse::<i64>()
        .ok()
        .filter(|id| *id > 0)
        .ok_or_else(invalid)?;
    let row=sqlx::query_as("SELECT legacy_id,public_id,source_id,legacy_status,source_payload FROM legacy_orders WHERE legacy_id=$1 AND actor_id=$2")
        .bind(id).bind(actor).fetch_optional(&s.pool).await?.ok_or(ApiError(StatusCode::NOT_FOUND,"legacy order not found"))?;
    Ok(Json(row))
}
#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct LegacyCartPage {
    #[serde(default = "first_page")]
    page: u32,
}
fn first_page() -> u32 {
    1
}
async fn legacy_cart(
    State(s): State<Orders>,
    Extension(Actor(actor)): Extension<Actor>,
    page: Result<axum::extract::Query<LegacyCartPage>, axum::extract::rejection::QueryRejection>,
) -> ApiResult<Json<Vec<serde_json::Value>>> {
    let axum::extract::Query(page) = page.map_err(|_| invalid())?;
    if !(1..=10_000).contains(&page.page) {
        return Err(invalid());
    }
    let rows:Vec<sqlx::types::Json<serde_json::Value>>=sqlx::query_scalar("SELECT source_payload FROM legacy_cart_items WHERE actor_id=$1 ORDER BY product_id LIMIT 100 OFFSET $2")
        .bind(actor).bind(i64::from(page.page-1)*100).fetch_all(&s.pool).await?;
    Ok(Json(rows.into_iter().map(|r| r.0).collect()))
}
