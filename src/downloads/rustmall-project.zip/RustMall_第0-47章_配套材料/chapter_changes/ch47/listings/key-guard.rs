async fn reject_legacy_key(pool: &PgPool, actor: i64, key: Uuid) -> ApiResult<()> {
    let archived: bool = sqlx::query_scalar(
        "SELECT EXISTS(SELECT 1 FROM legacy_orders WHERE actor_id=$1 AND request_key=$2)",
    )
    .bind(actor)
    .bind(key)
    .fetch_one(pool)
    .await?;
    if archived {
        return Err(ApiError(
            StatusCode::CONFLICT,
            "legacy order key archived; use history endpoint",
        ));
    }
    Ok(())
}
