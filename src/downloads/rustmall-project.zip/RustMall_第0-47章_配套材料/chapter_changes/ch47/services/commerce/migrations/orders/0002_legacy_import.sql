-- Offline legacy import metadata. Runtime roles do not own this table.
CREATE TABLE legacy_import_checkpoint (
 singleton BOOLEAN PRIMARY KEY DEFAULT true CHECK(singleton),
 source_id UUID NOT NULL CHECK(source_id<>'00000000-0000-0000-0000-000000000000'),
 snapshot_sha256 BYTEA NOT NULL CHECK(octet_length(snapshot_sha256)=32),
 imported_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Historical shipping completion is NOT a new Saga completion or payment effect.
CREATE TABLE legacy_orders (
 legacy_id BIGINT PRIMARY KEY CHECK(legacy_id>0),
 public_id UUID NOT NULL UNIQUE,
 source_id UUID NOT NULL,
 actor_id BIGINT NOT NULL CHECK(actor_id>0),
 request_key UUID NOT NULL CHECK(request_key<>'00000000-0000-0000-0000-000000000000'),
 product_id BIGINT NOT NULL CHECK(product_id>0),
 quantity INTEGER NOT NULL CHECK(quantity BETWEEN 1 AND 99),
 unit_price BIGINT NOT NULL CHECK(unit_price>=0),
 amount BIGINT NOT NULL CHECK(amount>=0 AND amount=unit_price*quantity),
 legacy_status TEXT NOT NULL CHECK(legacy_status IN ('completed','cancelled')),
 source_payload JSONB NOT NULL,
 UNIQUE(actor_id,request_key)
);
CREATE TABLE legacy_cart_items (
 actor_id BIGINT NOT NULL CHECK(actor_id>0),
 product_id BIGINT NOT NULL CHECK(product_id>0),
 quantity INTEGER NOT NULL CHECK(quantity BETWEEN 1 AND 99),
 source_payload JSONB NOT NULL,
 PRIMARY KEY(actor_id,product_id)
);
-- Defence in depth: runtime INSERT cannot reuse an archived actor/key either.
CREATE FUNCTION reject_archived_request_key() RETURNS trigger LANGUAGE plpgsql
SET search_path = pg_catalog, public AS $$
BEGIN
 IF EXISTS (SELECT 1 FROM public.legacy_orders WHERE actor_id=NEW.actor_id AND request_key=NEW.request_key) THEN
  RAISE EXCEPTION USING ERRCODE='23505', MESSAGE='legacy request key already archived';
 END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER orders_reject_archived_key BEFORE INSERT OR UPDATE OF actor_id,request_key ON orders
FOR EACH ROW EXECUTE FUNCTION reject_archived_request_key();
