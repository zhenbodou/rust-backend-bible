//! Offline bridge from the exact two-migration monolith schema.
//! History remains history: no legacy order enters the Saga or payment ledger.
use anyhow::{Context, ensure};
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use sqlx::{PgPool, Postgres, Transaction, types::Json};
use std::collections::HashSet;
use uuid::Uuid;

#[derive(Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct User {
    pub id: i64,
    pub username: String,
    pub password_hash: String,
    pub role: String,
    pub created_at: String,
}
#[derive(Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Product {
    pub id: i64,
    pub name: String,
    pub price_cents: i64,
    pub stock: i32,
    pub created_at: String,
    pub updated_at: String,
    pub delisted_at: Option<String>,
}
#[derive(Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct HistoricalOrder {
    pub id: i64,
    pub user_id: i64,
    pub product_id: i64,
    pub quantity: i32,
    pub unit_price_cents: i64,
    pub total_cents: i64,
    pub status: String,
    pub paid_at: Option<String>,
    pub tracking_no: Option<String>,
    pub cancel_reason: Option<String>,
    pub idempotency_key: Uuid,
    pub created_at: String,
    pub updated_at: String,
}
#[derive(Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct CartItem {
    pub user_id: i64,
    pub product_id: i64,
    pub quantity: i32,
    pub updated_at: String,
}
#[derive(Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Snapshot {
    pub format: u32,
    pub source_id: Uuid,
    pub users: Vec<User>,
    pub products: Vec<Product>,
    pub orders: Vec<HistoricalOrder>,
    pub cart_items: Vec<CartItem>,
}
/// Custom version-8 UUID, domain separated and independent of retry timestamps.
/// This is an identity mapping, not an authorization credential.
pub fn mapped_id(source: Uuid, kind: &str, id: i64) -> Uuid {
    let mut h = Sha256::new();
    h.update(b"rustmall/legacy-bridge/v1\0");
    h.update(source.as_bytes());
    h.update(kind.as_bytes());
    h.update([0]);
    h.update(id.to_be_bytes());
    let digest = h.finalize();
    let mut bytes = [0; 16];
    bytes.copy_from_slice(&digest[..16]);
    bytes[6] = (bytes[6] & 15) | 128;
    bytes[8] = (bytes[8] & 63) | 128;
    Uuid::from_bytes(bytes)
}
impl Snapshot {
    pub fn digest(&self) -> anyhow::Result<[u8; 32]> {
        Ok(Sha256::digest(serde_json::to_vec(self)?).into())
    }
    pub fn validate(&self) -> anyhow::Result<()> {
        ensure!(
            self.format == 1 && !self.source_id.is_nil(),
            "invalid source identity"
        );
        ensure!(
            self.users.len() <= 10_000
                && self.products.len() <= 10_000
                && self.orders.len() <= 100_000
                && self.cart_items.len() <= 100_000,
            "lab import size exceeded"
        );
        let mut users = HashSet::new();
        let mut names = HashSet::new();
        for u in &self.users {
            ensure!(
                u.id > 0 && u.id < i64::MAX && users.insert(u.id),
                "invalid or duplicate user ID"
            );
            ensure!(
                common::text::normalize_username(&u.username).ok().as_ref() == Some(&u.username)
                    && names.insert(&u.username),
                "noncanonical or colliding username"
            );
            let hash = argon2::password_hash::PasswordHash::new(&u.password_hash)
                .map_err(|_| anyhow::anyhow!("unsupported password hash"))?;
            ensure!(
                u.password_hash.len() <= 512 && crate::users::supported_phc(&hash),
                "unsupported password hash policy"
            );
            ensure!(
                matches!(u.role.as_str(), "user" | "admin"),
                "unknown user role"
            );
        }
        let mut products = HashSet::new();
        for p in &self.products {
            ensure!(
                p.id > 0 && p.id < i64::MAX && products.insert(p.id),
                "invalid or duplicate product ID"
            );
            ensure!(
                (1..=100).contains(&p.name.chars().count())
                    && !p.name.trim().is_empty()
                    && (0..=100_000_000).contains(&p.price_cents)
                    && p.stock >= 0,
                "unsupported product values"
            );
        }
        let mut ids = HashSet::new();
        let mut keys = HashSet::new();
        for o in &self.orders {
            ensure!(
                o.id > 0
                    && ids.insert(o.id)
                    && users.contains(&o.user_id)
                    && products.contains(&o.product_id),
                "invalid order references"
            );
            ensure!(
                !o.idempotency_key.is_nil() && keys.insert((o.user_id, o.idempotency_key)),
                "invalid order request identity"
            );
            ensure!(
                (1..=99).contains(&o.quantity)
                    && o.unit_price_cents >= 0
                    && o.unit_price_cents.checked_mul(i64::from(o.quantity)) == Some(o.total_cents),
                "invalid frozen amount"
            );
            let closed = match o.status.as_str() {
                "completed" => {
                    o.paid_at.is_some()
                        && o.tracking_no.as_ref().is_some_and(|s| !s.is_empty())
                        && o.cancel_reason.is_none()
                }
                // A paid cancellation needs refund evidence absent from the old
                // schema. Refuse it instead of inventing a refunded payment.
                "cancelled" => {
                    o.paid_at.is_none()
                        && o.tracking_no.is_none()
                        && o.cancel_reason.as_ref().is_some_and(|s| !s.is_empty())
                }
                _ => false,
            };
            ensure!(closed, "legacy order still has unresolved responsibility");
        }
        let mut carts = HashSet::new();
        for c in &self.cart_items {
            ensure!(
                users.contains(&c.user_id)
                    && products.contains(&c.product_id)
                    && (1..=99).contains(&c.quantity)
                    && carts.insert((c.user_id, c.product_id)),
                "invalid historical cart"
            );
        }
        Ok(())
    }
}

pub async fn capture(pool: &PgPool, source_id: Uuid) -> anyhow::Result<Snapshot> {
    let mut tx = pool.begin().await?;
    sqlx::query("SET TRANSACTION ISOLATION LEVEL REPEATABLE READ READ ONLY")
        .execute(&mut *tx)
        .await?;
    sqlx::query("SET LOCAL statement_timeout='30s'")
        .execute(&mut *tx)
        .await?;
    sqlx::query("SET LOCAL timezone='UTC'")
        .execute(&mut *tx)
        .await?;
    let actual: Vec<(i64, Vec<u8>, bool)> =
        sqlx::query_as("SELECT version,checksum,success FROM _sqlx_migrations ORDER BY version")
            .fetch_all(&mut *tx)
            .await?;
    let migrator = sqlx::migrate!("../../monolith/migrations");
    let expected: Vec<_> = migrator
        .iter()
        .map(|m| (m.version, m.checksum.to_vec(), true))
        .collect();
    ensure!(
        actual == expected,
        "source migration lineage differs from this bridge"
    );
    // Size checks precede materializing PHC strings and JSON rows.
    for (table, limit) in [
        ("users", 10_000),
        ("products", 10_000),
        ("orders", 100_000),
        ("cart_items", 100_000),
    ] {
        let count: i64 = sqlx::query_scalar(&format!("SELECT count(*) FROM {table}"))
            .fetch_one(&mut *tx)
            .await?;
        ensure!(count <= limit, "source exceeds bounded lab size");
    }
    let oversized: bool = sqlx::query_scalar(
        "SELECT EXISTS(SELECT 1 FROM users WHERE octet_length(password_hash)>512)",
    )
    .fetch_one(&mut *tx)
    .await?;
    ensure!(!oversized, "oversized password hash");
    let users: Vec<Json<User>> = sqlx::query_scalar("SELECT row_to_json(r) FROM (SELECT id,username,password_hash,role,created_at::text FROM users ORDER BY id) r")
        .fetch_all(&mut *tx).await?;
    let products: Vec<Json<Product>> = sqlx::query_scalar("SELECT row_to_json(r) FROM (SELECT id,name,price_cents,stock,created_at::text,updated_at::text,delisted_at::text FROM products ORDER BY id) r")
        .fetch_all(&mut *tx).await?;
    let orders: Vec<Json<HistoricalOrder>> = sqlx::query_scalar("SELECT row_to_json(r) FROM (SELECT id,user_id,product_id,quantity,unit_price_cents,total_cents,status,paid_at::text,tracking_no,cancel_reason,idempotency_key,created_at::text,updated_at::text FROM orders ORDER BY id) r")
        .fetch_all(&mut *tx).await?;
    let carts: Vec<Json<CartItem>> = sqlx::query_scalar("SELECT row_to_json(r) FROM (SELECT user_id,product_id,quantity,updated_at::text FROM cart_items ORDER BY user_id,product_id) r")
        .fetch_all(&mut *tx).await?;
    tx.commit().await?;
    let snapshot = Snapshot {
        format: 1,
        source_id,
        users: users.into_iter().map(|x| x.0).collect(),
        products: products.into_iter().map(|x| x.0).collect(),
        orders: orders.into_iter().map(|x| x.0).collect(),
        cart_items: carts.into_iter().map(|x| x.0).collect(),
    };
    snapshot.validate()?;
    Ok(snapshot)
}

#[derive(Clone, Copy)]
pub enum Phase {
    Users,
    Catalog,
    Orders,
}
impl Phase {
    fn tables(self) -> &'static [&'static str] {
        match self {
            Self::Users => &["users", "sessions"],
            Self::Catalog => &[
                "products",
                "product_outbox",
                "product_create_receipts",
                "inventory_reservations",
                "inventory_adjustments",
            ],
            Self::Orders => &[
                "orders",
                "order_transitions",
                "legacy_orders",
                "legacy_cart_items",
            ],
        }
    }
}
async fn target_lineage(pool: &PgPool, phase: Phase) -> anyhow::Result<()> {
    let migrator = match phase {
        Phase::Users => sqlx::migrate!("./migrations/users"),
        Phase::Catalog => sqlx::migrate!("../catalog/migrations"),
        Phase::Orders => sqlx::migrate!("./migrations/orders"),
    };
    let actual: Vec<(i64, Vec<u8>, bool)> =
        sqlx::query_as("SELECT version,checksum,success FROM _sqlx_migrations ORDER BY version")
            .fetch_all(pool)
            .await?;
    let expected: Vec<_> = migrator
        .iter()
        .map(|m| (m.version, m.checksum.to_vec(), true))
        .collect();
    ensure!(
        actual == expected,
        "target migration lineage differs from requested phase"
    );
    Ok(())
}
async fn checkpoint(
    tx: &mut Transaction<'_, Postgres>,
    s: &Snapshot,
    lock: bool,
) -> anyhow::Result<bool> {
    if lock {
        sqlx::query("LOCK TABLE legacy_import_checkpoint IN EXCLUSIVE MODE")
            .execute(&mut **tx)
            .await?;
    }
    let row: Option<(Uuid, Vec<u8>)> = sqlx::query_as(
        "SELECT source_id,snapshot_sha256 FROM legacy_import_checkpoint WHERE singleton",
    )
    .fetch_optional(&mut **tx)
    .await?;
    if let Some((source, hash)) = row {
        ensure!(
            source == s.source_id && hash == s.digest()?,
            "target belongs to a different source snapshot"
        );
        return Ok(true);
    }
    Ok(false)
}
async fn require_empty(tx: &mut Transaction<'_, Postgres>, phase: Phase) -> anyhow::Result<()> {
    for table in phase.tables() {
        let count: i64 = sqlx::query_scalar(&format!("SELECT count(*) FROM {table}"))
            .fetch_one(&mut **tx)
            .await?;
        ensure!(
            count == 0,
            "target contains business data without this import checkpoint"
        );
    }
    Ok(())
}
pub async fn preflight(pool: &PgPool, s: &Snapshot, phase: Phase) -> anyhow::Result<()> {
    target_lineage(pool, phase).await?;
    let mut tx = pool.begin().await?;
    sqlx::query("SET TRANSACTION READ ONLY")
        .execute(&mut *tx)
        .await?;
    if !checkpoint(&mut tx, s, false).await? {
        require_empty(&mut tx, phase).await?;
    }
    tx.commit().await?;
    Ok(())
}
pub async fn import_phase(pool: &PgPool, s: &Snapshot, phase: Phase) -> anyhow::Result<bool> {
    s.validate()?;
    target_lineage(pool, phase).await?;
    let mut tx = pool.begin().await?;
    sqlx::query("SET LOCAL lock_timeout='5s'")
        .execute(&mut *tx)
        .await?;
    sqlx::query("SET LOCAL statement_timeout='30s'")
        .execute(&mut *tx)
        .await?;
    if checkpoint(&mut tx, s, true).await? {
        tx.commit().await?;
        return Ok(false);
    }
    require_empty(&mut tx, phase).await?;
    match phase {
        Phase::Users => {
            for u in &s.users {
                sqlx::query("INSERT INTO users(id,username,password_hash,role,created_at) OVERRIDING SYSTEM VALUE VALUES($1,$2,$3,$4,$5::text::timestamptz)")
                    .bind(u.id).bind(&u.username).bind(&u.password_hash).bind(&u.role).bind(&u.created_at).execute(&mut *tx).await?;
            }
            let next = s.users.iter().map(|u| u.id).max().unwrap_or(0) + 1;
            sqlx::query(&format!(
                "ALTER TABLE users ALTER COLUMN id RESTART WITH {next}"
            ))
            .execute(&mut *tx)
            .await?;
        }
        Phase::Catalog => {
            for p in &s.products {
                sqlx::query("INSERT INTO products(id,name,price_cents,stock,created_at,updated_at,delisted_at,revision) OVERRIDING SYSTEM VALUE VALUES($1,$2,$3,$4,$5::text::timestamptz,$6::text::timestamptz,$7::text::timestamptz,1)")
                    .bind(p.id).bind(&p.name).bind(p.price_cents).bind(p.stock).bind(&p.created_at).bind(&p.updated_at).bind(&p.delisted_at).execute(&mut *tx).await?;
                let mut event = messaging::event::Envelope::new(
                    messaging::event::Snapshot {
                        id: p.id,
                        name: p.name.clone(),
                        price_cents: p.price_cents,
                        stock: p.stock,
                        listed: p.delisted_at.is_none(),
                    },
                    1,
                );
                event.event_id = mapped_id(s.source_id, "product-snapshot", p.id);
                event.validate()?;
                sqlx::query("INSERT INTO product_outbox(event_id,aggregate_id,revision,payload) VALUES($1,$2,1,$3)")
                    .bind(event.event_id).bind(p.id).bind(Json(event)).execute(&mut *tx).await?;
            }
            let next = s.products.iter().map(|p| p.id).max().unwrap_or(0) + 1;
            sqlx::query(&format!(
                "ALTER TABLE products ALTER COLUMN id RESTART WITH {next}"
            ))
            .execute(&mut *tx)
            .await?;
        }
        Phase::Orders => {
            for o in &s.orders {
                sqlx::query("INSERT INTO legacy_orders(legacy_id,public_id,source_id,actor_id,request_key,product_id,quantity,unit_price,amount,legacy_status,source_payload) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)")
                    .bind(o.id).bind(mapped_id(s.source_id,"order",o.id)).bind(s.source_id).bind(o.user_id)
                    .bind(o.idempotency_key).bind(o.product_id).bind(o.quantity).bind(o.unit_price_cents).bind(o.total_cents)
                    .bind(&o.status).bind(Json(o)).execute(&mut *tx).await?;
            }
            for c in &s.cart_items {
                sqlx::query("INSERT INTO legacy_cart_items(actor_id,product_id,quantity,source_payload) VALUES($1,$2,$3,$4)")
                    .bind(c.user_id).bind(c.product_id).bind(c.quantity).bind(Json(c)).execute(&mut *tx).await?;
            }
        }
    }
    sqlx::query("INSERT INTO legacy_import_checkpoint(singleton,source_id,snapshot_sha256) VALUES(true,$1,$2)")
        .bind(s.source_id).bind(s.digest()?.as_slice()).execute(&mut *tx).await?;
    tx.commit()
        .await
        .context("import phase commit may be unknown; reuse source identity")?;
    Ok(true)
}
/// Cross-DB completion is a rollout barrier, never a cross-DB atomic transaction.
pub async fn apply(
    s: &Snapshot,
    users: &PgPool,
    catalog: &PgPool,
    orders: &PgPool,
    stop_after_users: bool,
) -> anyhow::Result<()> {
    s.validate()?;
    let mut databases = HashSet::new();
    for pool in [users, catalog, orders] {
        let name: String = sqlx::query_scalar("SELECT current_database()")
            .fetch_one(pool)
            .await?;
        ensure!(
            databases.insert(name),
            "three distinct target database names required"
        );
    }
    for (pool, phase) in [
        (users, Phase::Users),
        (catalog, Phase::Catalog),
        (orders, Phase::Orders),
    ] {
        preflight(pool, s, phase).await?;
    }
    import_phase(users, s, Phase::Users).await?;
    ensure!(
        !stop_after_users,
        "lab stop after committed users phase; keep applications stopped"
    );
    import_phase(catalog, s, Phase::Catalog).await?;
    import_phase(orders, s, Phase::Orders).await?;
    Ok(())
}
