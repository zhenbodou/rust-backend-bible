use commerce::{
    legacy::{self, CartItem, HistoricalOrder, Phase, Product, Snapshot, User},
    orders,
};
use sqlx::PgPool;
use uuid::Uuid;
async fn snapshot() -> Snapshot {
    let hash = commerce::users::hash("Legacy-Test-Pass-2026".into())
        .await
        .unwrap();
    let source = Uuid::parse_str("829ff5a1-2e02-48c4-a14b-fc27051cdfb1").unwrap();
    let when = "2025-01-01 00:00:00+00".to_string();
    Snapshot {
        format: 1,
        source_id: source,
        users: vec![
            User {
                id: 7,
                username: "legacy_admin".into(),
                password_hash: hash.clone(),
                role: "admin".into(),
                created_at: when.clone(),
            },
            User {
                id: 11,
                username: "legacy_other".into(),
                password_hash: hash,
                role: "user".into(),
                created_at: when.clone(),
            },
        ],
        products: vec![Product {
            id: 41,
            name: "Historical Keyboard".into(),
            price_cents: 599,
            stock: 8,
            created_at: when.clone(),
            updated_at: when.clone(),
            delisted_at: None,
        }],
        orders: vec![HistoricalOrder {
            id: 101,
            user_id: 7,
            product_id: 41,
            quantity: 2,
            unit_price_cents: 199,
            total_cents: 398,
            status: "completed".into(),
            paid_at: Some(when.clone()),
            tracking_no: Some("legacy-track".into()),
            cancel_reason: None,
            idempotency_key: Uuid::parse_str("da65a670-e8ed-410c-aa36-12720eff68d1").unwrap(),
            created_at: when.clone(),
            updated_at: when.clone(),
        }],
        cart_items: vec![CartItem {
            user_id: 7,
            product_id: 41,
            quantity: 1,
            updated_at: when,
        }],
    }
}
#[tokio::test]
async fn identity_domains_and_source_namespaces_are_stable_and_distinct() {
    let s = snapshot().await;
    let a = legacy::mapped_id(s.source_id, "order", 101);
    assert_eq!(a, legacy::mapped_id(s.source_id, "order", 101));
    assert_ne!(a, legacy::mapped_id(s.source_id, "product-snapshot", 101));
    assert_ne!(a, legacy::mapped_id(Uuid::new_v4(), "order", 101));
    assert_eq!(a.get_version_num(), 8);
    assert!(!a.is_nil());
}
#[tokio::test]
async fn pending_paid_shipped_and_paid_cancelled_cannot_silently_close() {
    let original = snapshot().await;
    for status in ["pending", "paid", "shipped", "cancelled"] {
        let mut s = original.clone();
        s.orders[0].status = status.into();
        if status == "cancelled" {
            s.orders[0].tracking_no = None;
            s.orders[0].cancel_reason = Some("unknown refund".into());
        }
        assert!(s.validate().is_err(), "{status}");
    }
}
#[tokio::test]
async fn invalid_canonical_name_hash_or_frozen_amount_is_rejected() {
    let original = snapshot().await;
    let mut s = original.clone();
    s.users[0].username = " Legacy_Admin ".into();
    assert!(s.validate().is_err());
    let mut s = original.clone();
    s.users[0].password_hash = "$argon2id$v=19$m=19456,t=2,p=1".into();
    assert!(s.validate().is_err());
    let mut s = original.clone();
    s.orders[0].total_cents = 399;
    assert!(s.validate().is_err());
    let mut s = original.clone();
    s.orders[0].product_id = 999;
    assert!(s.validate().is_err());
    let mut s = original;
    s.users.push(s.users[0].clone());
    assert!(s.validate().is_err());
}
#[sqlx::test(migrations = "./migrations/users")]
async fn users_resume_does_not_overwrite_live_changes_or_rewind_sequence(pool: PgPool) {
    let s = snapshot().await;
    assert!(legacy::import_phase(&pool, &s, Phase::Users).await.unwrap());
    let stored: String = sqlx::query_scalar("SELECT password_hash FROM users WHERE id=7")
        .fetch_one(&pool)
        .await
        .unwrap();
    assert_eq!(stored, s.users[0].password_hash);
    sqlx::query("UPDATE users SET username='edited_after_cutover' WHERE id=7")
        .execute(&pool)
        .await
        .unwrap();
    let first: i64 = sqlx::query_scalar(
        "INSERT INTO users(username,password_hash) VALUES('new_user_1','fixture') RETURNING id",
    )
    .fetch_one(&pool)
    .await
    .unwrap();
    assert_eq!(first, 12);
    assert!(!legacy::import_phase(&pool, &s, Phase::Users).await.unwrap());
    let second: i64 = sqlx::query_scalar(
        "INSERT INTO users(username,password_hash) VALUES('new_user_2','fixture') RETURNING id",
    )
    .fetch_one(&pool)
    .await
    .unwrap();
    assert_eq!(second, 13);
    let name: String = sqlx::query_scalar("SELECT username FROM users WHERE id=7")
        .fetch_one(&pool)
        .await
        .unwrap();
    assert_eq!(name, "edited_after_cutover");
}
#[sqlx::test(migrations = "./migrations/users")]
async fn different_snapshot_cannot_take_over_existing_phase(pool: PgPool) {
    let mut s = snapshot().await;
    legacy::import_phase(&pool, &s, Phase::Users).await.unwrap();
    s.products[0].stock += 1;
    assert!(legacy::import_phase(&pool, &s, Phase::Users).await.is_err());
    let count: i64 = sqlx::query_scalar("SELECT count(*) FROM users")
        .fetch_one(&pool)
        .await
        .unwrap();
    assert_eq!(count, 2);
}
#[sqlx::test(migrations = "./migrations/users")]
async fn failed_phase_rolls_back_partial_rows_and_checkpoint(pool: PgPool) {
    let mut s = snapshot().await;
    s.users[1].created_at = "invalid timestamp".into();
    assert!(legacy::import_phase(&pool, &s, Phase::Users).await.is_err());
    let counts: (i64, i64) = sqlx::query_as(
        "SELECT (SELECT count(*) FROM users),(SELECT count(*) FROM legacy_import_checkpoint)",
    )
    .fetch_one(&pool)
    .await
    .unwrap();
    assert_eq!(counts, (0, 0));
    let next: i64 = sqlx::query_scalar(
        "INSERT INTO users(username,password_hash) VALUES('after_failure','fixture') RETURNING id",
    )
    .fetch_one(&pool)
    .await
    .unwrap();
    assert_eq!(next, 1);
}
#[sqlx::test(migrations = "./migrations/users")]
async fn populated_target_without_checkpoint_is_never_merged_or_erased(pool: PgPool) {
    sqlx::query("INSERT INTO users(username,password_hash) VALUES('already_here','fixture')")
        .execute(&pool)
        .await
        .unwrap();
    let s = snapshot().await;
    assert!(legacy::preflight(&pool, &s, Phase::Users).await.is_err());
    assert!(legacy::import_phase(&pool, &s, Phase::Users).await.is_err());
    let name: String = sqlx::query_scalar("SELECT username FROM users")
        .fetch_one(&pool)
        .await
        .unwrap();
    assert_eq!(name, "already_here");
}
#[sqlx::test(migrations = "../catalog/migrations")]
async fn product_import_preserves_available_stock_and_emits_once_without_reservations(
    pool: PgPool,
) {
    let s = snapshot().await;
    legacy::import_phase(&pool, &s, Phase::Catalog)
        .await
        .unwrap();
    assert!(
        !legacy::import_phase(&pool, &s, Phase::Catalog)
            .await
            .unwrap()
    );
    let values:(i32,i64,i64)=sqlx::query_as("SELECT stock,(SELECT count(*) FROM product_outbox),(SELECT count(*) FROM inventory_reservations) FROM products WHERE id=41")
        .fetch_one(&pool).await.unwrap();
    assert_eq!(values, (8, 1, 0));
    let id: Uuid = sqlx::query_scalar("SELECT event_id FROM product_outbox")
        .fetch_one(&pool)
        .await
        .unwrap();
    assert_eq!(id, legacy::mapped_id(s.source_id, "product-snapshot", 41));
    let next: i64 = sqlx::query_scalar(
        "INSERT INTO products(name,price_cents,stock) VALUES('new',100,1) RETURNING id",
    )
    .fetch_one(&pool)
    .await
    .unwrap();
    assert_eq!(next, 42);
    assert!(legacy::preflight(&pool, &s, Phase::Users).await.is_err());
}
#[sqlx::test(migrations = "./migrations/orders")]
async fn history_remains_outside_saga_and_blocks_actor_scoped_key_at_api_and_sql(pool: PgPool) {
    let s = snapshot().await;
    legacy::import_phase(&pool, &s, Phase::Orders)
        .await
        .unwrap();
    assert!(
        !legacy::import_phase(&pool, &s, Phase::Orders)
            .await
            .unwrap()
    );
    let values:(i64,i64,i64)=sqlx::query_as("SELECT (SELECT count(*) FROM legacy_orders),(SELECT count(*) FROM orders),(SELECT count(*) FROM legacy_cart_items)")
        .fetch_one(&pool).await.unwrap();
    assert_eq!(values, (1, 0, 1));
    let key = s.orders[0].idempotency_key;
    let draft = orders::Draft {
        product_id: 41,
        quantity: 2,
    };
    let error = orders::insert(&pool, 7, key, &draft, 599)
        .await
        .unwrap_err();
    assert_eq!(error.0, 409);
    let raw=sqlx::query("INSERT INTO orders(id,actor_id,request_key,product_id,quantity,unit_price,amount) VALUES($1,7,$2,41,2,599,1198)")
        .bind(Uuid::new_v4()).bind(key).execute(&pool).await.unwrap_err();
    assert_eq!(
        raw.as_database_error().unwrap().code().as_deref(),
        Some("23505")
    );
    assert!(orders::insert(&pool, 11, key, &draft, 599).await.is_ok());
    let frozen: (i64, i64) =
        sqlx::query_as("SELECT unit_price,amount FROM legacy_orders WHERE legacy_id=101")
            .fetch_one(&pool)
            .await
            .unwrap();
    assert_eq!(frozen, (199, 398));
}

#[sqlx::test(migrations = "./migrations/users")]
async fn checkpoint_failure_also_rolls_back_identity_restart(pool: PgPool) {
    sqlx::query("CREATE FUNCTION abort_import_marker() RETURNS trigger LANGUAGE plpgsql AS $$ BEGIN RAISE EXCEPTION 'fixture checkpoint failure'; END $$")
        .execute(&pool).await.unwrap();
    sqlx::query("CREATE TRIGGER abort_marker BEFORE INSERT ON legacy_import_checkpoint FOR EACH ROW EXECUTE FUNCTION abort_import_marker()")
        .execute(&pool).await.unwrap();
    let s = snapshot().await;
    assert!(legacy::import_phase(&pool, &s, Phase::Users).await.is_err());
    let rows: i64 = sqlx::query_scalar("SELECT count(*) FROM users")
        .fetch_one(&pool)
        .await
        .unwrap();
    assert_eq!(rows, 0);
    let next:i64=sqlx::query_scalar("INSERT INTO users(username,password_hash) VALUES('after_marker_fail','fixture') RETURNING id").fetch_one(&pool).await.unwrap();
    assert_eq!(next, 1);
}
