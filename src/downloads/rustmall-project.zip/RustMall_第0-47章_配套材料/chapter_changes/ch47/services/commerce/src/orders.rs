use crate::{
    catalog_link::CatalogRemote,
    payments::{Action as PayAction, Charge, PaymentRemote, RemoteError, State as PayState},
    runtime::*,
    users::UserRemote,
};
use axum::{
    Json, Router,
    extract::{Extension, Path, Request, State},
    http::{HeaderMap, StatusCode},
    middleware::{self, Next},
    response::Response,
    routing::{get, post},
};
use inventory::{
    model::{Action, Command, State as StockState},
    remote::InventoryRemote,
};
use serde::{Deserialize, Serialize};
use sqlx::PgPool;
use std::time::Duration;
use tokio_util::sync::CancellationToken;
use uuid::Uuid;
#[derive(Clone)]
pub struct Orders {
    pub pool: PgPool,
    pub users: UserRemote,
    pub catalog: CatalogRemote,
}
#[derive(Clone)]
pub struct Worker {
    pub pool: PgPool,
    pub inventory: InventoryRemote,
    pub payments: PaymentRemote,
}
#[derive(Serialize, Deserialize, Clone, Debug)]
#[serde(deny_unknown_fields)]
pub struct Draft {
    pub product_id: i64,
    pub quantity: i32,
}
#[derive(Serialize, Deserialize, sqlx::FromRow, Debug, Clone, PartialEq, Eq)]
pub struct Order {
    pub id: Uuid,
    pub actor_id: i64,
    pub request_key: Uuid,
    pub product_id: i64,
    pub quantity: i32,
    pub unit_price: i64,
    pub amount: i64,
    pub state: String,
    pub attempts: i32,
}
const FIELDS: &str = "id,actor_id,request_key,product_id,quantity,unit_price,amount,state,attempts";
impl Order {
    pub fn reservation(&self) -> Command {
        Command {
            saga_id: self.id,
            product_id: self.product_id,
            quantity: self.quantity,
            unit_price_cents: self.unit_price,
        }
    }
    pub fn charge(&self) -> Charge {
        Charge {
            saga_id: self.id,
            actor_id: self.actor_id,
            amount: self.amount,
        }
    }
    fn valid(&self) -> bool {
        !self.id.is_nil()
            && !self.request_key.is_nil()
            && self.actor_id > 0
            && self.product_id > 0
            && (1..=999).contains(&self.quantity)
            && (1..=100_000_000).contains(&self.amount)
            && self.unit_price > 0
            && self.unit_price.checked_mul(i64::from(self.quantity)) == Some(self.amount)
            && (0..=1_000_000).contains(&self.attempts)
            && matches!(
                self.state.as_str(),
                "reserving"
                    | "charging"
                    | "confirming"
                    | "refunding"
                    | "releasing"
                    | "completed"
                    | "cancelled"
                    | "manual"
            )
    }
}
fn same(row: &Order, d: &Draft) -> ApiResult<()> {
    if !row.valid() {
        return Err(unavailable());
    }
    if (row.product_id, row.quantity) != (d.product_id, d.quantity) {
        return Err(ApiError(
            StatusCode::CONFLICT,
            "idempotency key input conflict",
        ));
    }
    Ok(())
}
pub async fn existing(pool: &PgPool, actor: i64, key: Uuid) -> Result<Option<Order>, sqlx::Error> {
    sqlx::query_as(&format!(
        "SELECT {FIELDS} FROM orders WHERE actor_id=$1 AND request_key=$2"
    ))
    .bind(actor)
    .bind(key)
    .fetch_optional(pool)
    .await
}
async fn reject_legacy_key(pool: &PgPool, actor: i64, key: Uuid) -> ApiResult<()> {
    let archived: bool = sqlx::query_scalar(
        "SELECT EXISTS(SELECT 1 FROM legacy_orders WHERE actor_id=$1 AND request_key=$2)",
    )
    .bind(actor)
    .bind(key)
    .fetch_one(pool)
    .await?;
    if archived {
        return Err(ApiError(
            StatusCode::CONFLICT,
            "legacy order key archived; use history endpoint",
        ));
    }
    Ok(())
}
pub async fn insert(
    pool: &PgPool,
    actor: i64,
    key: Uuid,
    d: &Draft,
    unit_price: i64,
) -> ApiResult<Order> {
    if actor <= 0 || key.is_nil() || d.product_id <= 0 || !(1..=999).contains(&d.quantity) {
        return Err(invalid());
    }
    reject_legacy_key(pool, actor, key).await?;
    let amount = unit_price
        .checked_mul(i64::from(d.quantity))
        .filter(|n| (1..=100_000_000).contains(n))
        .ok_or_else(invalid)?;
    sqlx::query(
        "INSERT INTO orders(id,actor_id,request_key,product_id,quantity,unit_price,amount)
        VALUES($1,$2,$3,$4,$5,$6,$7) ON CONFLICT(actor_id,request_key) DO NOTHING",
    )
    .bind(Uuid::new_v4())
    .bind(actor)
    .bind(key)
    .bind(d.product_id)
    .bind(d.quantity)
    .bind(unit_price)
    .bind(amount)
    .execute(pool)
    .await?;
    let row = existing(pool, actor, key).await?.ok_or_else(unavailable)?;
    same(&row, d)?;
    Ok(row)
}
#[derive(Clone, Copy)]
struct Actor(i64);
async fn authenticate(
    State(users): State<UserRemote>,
    mut request: Request,
    next: Next,
) -> ApiResult<Response> {
    let actor = users.authenticate(request.headers()).await?;
    request.extensions_mut().insert(Actor(actor));
    Ok(next.run(request).await)
}
pub fn router(s: Orders) -> Router {
    let ready = s.clone();
    Router::new()
        .route("/api/v1/orders", post(create))
        .route("/api/v1/orders/{id}", get(query))
        .route("/api/v1/orders/legacy/{id}", get(legacy_query))
        .route("/api/v1/orders/legacy-cart", get(legacy_cart))
        .route_layer(middleware::from_fn_with_state(
            s.users.clone(),
            authenticate,
        ))
        .route("/healthz", get(|| async { StatusCode::OK }))
        .route(
            "/readyz",
            get(move || {
                let s = ready.clone();
                async move {
                    let (db, users, catalog) =
                        tokio::join!(readiness(s.pool), s.users.ready(), s.catalog.ready());
                    if db == StatusCode::OK && users && catalog {
                        StatusCode::OK
                    } else {
                        StatusCode::SERVICE_UNAVAILABLE
                    }
                }
            }),
        )
        .layer(axum::extract::DefaultBodyLimit::max(4096))
        .with_state(s)
}
fn request_key(h: &HeaderMap) -> ApiResult<Uuid> {
    if h.get_all("idempotency-key").iter().count() != 1 {
        return Err(invalid());
    }
    h.get("idempotency-key")
        .and_then(|s| s.to_str().ok())
        .and_then(|s| Uuid::parse_str(s).ok())
        .filter(|s| !s.is_nil())
        .ok_or_else(invalid)
}
async fn create(
    State(s): State<Orders>,
    Extension(Actor(actor)): Extension<Actor>,
    h: HeaderMap,
    BodyJson(d): BodyJson<Draft>,
) -> ApiResult<(StatusCode, Json<Order>)> {
    let key = request_key(&h)?;
    reject_legacy_key(&s.pool, actor, key).await?;
    if let Some(row) = existing(&s.pool, actor, key).await? {
        same(&row, &d)?;
        return Ok((StatusCode::ACCEPTED, Json(row)));
    }
    if d.product_id <= 0 || !(1..=999).contains(&d.quantity) {
        return Err(invalid());
    }
    let product = s.catalog.get(d.product_id).await?;
    Ok((
        StatusCode::ACCEPTED,
        Json(insert(&s.pool, actor, key, &d, product.price_cents).await?),
    ))
}
async fn query(
    State(s): State<Orders>,
    Extension(Actor(actor)): Extension<Actor>,
    Path(raw): Path<String>,
) -> ApiResult<Json<Order>> {
    let id = Uuid::parse_str(&raw)
        .ok()
        .filter(|s| !s.is_nil())
        .ok_or_else(invalid)?;
    let row: Order = sqlx::query_as(&format!(
        "SELECT {FIELDS} FROM orders WHERE id=$1 AND actor_id=$2"
    ))
    .bind(id)
    .bind(actor)
    .fetch_optional(&s.pool)
    .await?
    .ok_or(ApiError(StatusCode::NOT_FOUND, "order not found"))?;
    if !row.valid() {
        return Err(unavailable());
    }
    Ok(Json(row))
}
/// Exact production statement, also used for EXPLAIN in the isolated chapter41 lab.
pub const CLAIM_SQL: &str = include_str!("sql/claim_order.sql");

pub async fn claim(pool: &PgPool) -> anyhow::Result<Option<(Order, Uuid)>> {
    let token = Uuid::new_v4();
    let row = sqlx::query_as::<_, Order>(CLAIM_SQL)
        .bind(token)
        .fetch_optional(pool)
        .await?;
    if let Some(row) = &row {
        anyhow::ensure!(row.valid(), "invalid stored order");
    }
    Ok(row.map(|row| (row, token)))
}
pub fn allowed(from: &str, to: &str) -> bool {
    match from {
        "reserving" => matches!(to, "charging" | "cancelled" | "manual"),
        "charging" => matches!(to, "confirming" | "releasing" | "manual"),
        "confirming" => matches!(to, "completed" | "refunding" | "manual"),
        "refunding" => matches!(to, "releasing" | "manual"),
        "releasing" => matches!(to, "cancelled" | "manual"),
        _ => false,
    }
}
pub async fn advance(
    pool: &PgPool,
    row: &Order,
    token: Uuid,
    next: &str,
    reason: &str,
) -> anyhow::Result<bool> {
    anyhow::ensure!(
        row.valid() && allowed(&row.state, next) && !reason.is_empty() && reason.len() <= 64,
        "invalid order transition"
    );
    let mut tx = pool.begin().await?;
    let count=sqlx::query("UPDATE orders SET state=$4,lease_token=NULL,leased_until=NULL,next_attempt=clock_timestamp(),last_error=NULL,updated_at=now()
        WHERE id=$1 AND lease_token=$2 AND state=$3 AND leased_until>clock_timestamp()")
        .bind(row.id).bind(token).bind(&row.state).bind(next).execute(&mut *tx).await?.rows_affected();
    if count == 1 {
        sqlx::query("INSERT INTO order_transitions(order_id,from_state,to_state,reason) VALUES($1,$2,$3,$4)")
        .bind(row.id).bind(&row.state).bind(next).bind(reason).execute(&mut *tx).await?;
    }
    tx.commit().await?;
    Ok(count == 1)
}
pub async fn defer(pool: &PgPool, row: &Order, token: Uuid, reason: &str) -> anyhow::Result<bool> {
    anyhow::ensure!(
        !reason.is_empty() && reason.len() <= 64,
        "invalid retry category"
    );
    let base = 1_u64 << row.attempts.clamp(0, 5);
    let delay = governance::retry::jitter_seconds(base, row.id, row.attempts) as i64;
    Ok(sqlx::query("UPDATE orders SET lease_token=NULL,leased_until=NULL,next_attempt=clock_timestamp()+$4*interval '1 second',last_error=$5,updated_at=now()
        WHERE id=$1 AND lease_token=$2 AND state=$3 AND leased_until>clock_timestamp()")
        .bind(row.id).bind(token).bind(&row.state).bind(delay).bind(reason).execute(pool).await?.rows_affected()==1)
}
#[derive(Debug, PartialEq, Eq)]
pub enum Outcome {
    Advance(&'static str, &'static str),
    Retry(&'static str),
}
pub fn inventory_outcome(step: &str, state: StockState) -> Outcome {
    use Outcome::Advance;
    match (step, state) {
        ("reserving", StockState::Held) => Advance("charging", "inventory-held"),
        ("reserving", StockState::Rejected | StockState::Released) => {
            Advance("cancelled", "inventory-closed")
        }
        ("confirming", StockState::Confirmed) => Advance("completed", "inventory-confirmed"),
        ("confirming", StockState::Released | StockState::Rejected) => {
            Advance("refunding", "inventory-unconfirmable")
        }
        ("releasing", StockState::Released | StockState::Rejected) => {
            Advance("cancelled", "inventory-released")
        }
        _ => Advance("manual", "inconsistent-inventory"),
    }
}
pub fn payment_outcome(step: &str, state: PayState) -> Outcome {
    use Outcome::Advance;
    match (step, state) {
        ("charging", PayState::Paid) => Advance("confirming", "payment-paid"),
        ("charging", PayState::Declined | PayState::Refunded) => {
            Advance("releasing", "payment-closed")
        }
        ("refunding", PayState::Refunded | PayState::Declined) => {
            Advance("releasing", "payment-refunded")
        }
        _ => Advance("manual", "inconsistent-payment"),
    }
}
fn inventory_error(error: tonic::Status) -> Outcome {
    match error.code() {
        tonic::Code::InvalidArgument | tonic::Code::FailedPrecondition | tonic::Code::DataLoss => {
            Outcome::Advance("manual", "inventory-contract")
        }
        tonic::Code::Unauthenticated | tonic::Code::PermissionDenied => {
            Outcome::Retry("inventory-auth-unavailable")
        }
        _ => Outcome::Retry("inventory-result-unknown"),
    }
}
fn payment_error(error: RemoteError) -> Outcome {
    match error {
        RemoteError::InvalidInput | RemoteError::IdentityConflict | RemoteError::Protocol => {
            Outcome::Advance("manual", "payment-contract")
        }
        RemoteError::Unauthenticated => Outcome::Retry("payment-auth-unavailable"),
        RemoteError::CircuitOpen => Outcome::Retry("payment-circuit-open"),
        RemoteError::LocalBudget => Outcome::Retry("caller-budget-exhausted"),
        _ => Outcome::Retry("payment-result-unknown"),
    }
}
pub async fn step(s: &Worker, row: &Order) -> anyhow::Result<Outcome> {
    anyhow::ensure!(row.valid(), "invalid stored order");
    match row.state.as_str() {
        "reserving" | "confirming" | "releasing" => {
            let action = match row.state.as_str() {
                "reserving" => Action::Reserve,
                "confirming" => Action::Confirm,
                _ => Action::Release,
            };
            Ok(match s.inventory.apply(&row.reservation(), action).await {
                Ok(state) => inventory_outcome(&row.state, state),
                Err(e) => inventory_error(e),
            })
        }
        "charging" | "refunding" => {
            let action = if row.state == "charging" {
                PayAction::Charge
            } else {
                PayAction::Refund
            };
            Ok(match s.payments.apply(&row.charge(), action).await {
                Ok(p) => payment_outcome(&row.state, p.state),
                Err(e) => payment_error(e),
            })
        }
        _ => anyhow::bail!("no automatic work for terminal state"),
    }
}
#[tracing::instrument(name="saga.attempt",skip_all,fields(order_id=%row.id,state=%row.state,attempt=row.attempts))]
async fn attempt(s: &Worker, row: &Order, token: Uuid) -> anyhow::Result<()> {
    let result = governance::budget::scope(
        Duration::from_secs(5),
        tokio::time::timeout(Duration::from_secs(5), step(s, row)),
    )
    .await;
    match result {
        Ok(Ok(Outcome::Advance(next, reason))) => {
            let owned = advance(&s.pool, row, token, next, reason).await?;
            tracing::info!(order_id=%row.id,from=%row.state,to=next,owned,"saga transition attempted");
        }
        Ok(Ok(Outcome::Retry(reason))) => {
            defer(&s.pool, row, token, reason).await?;
        }
        Ok(Err(error)) => {
            tracing::error!(order_id=%row.id,%error,"invalid saga work");
            return Err(error);
        }
        Err(_) => {
            defer(&s.pool, row, token, "step-budget-unknown").await?;
        }
    }
    Ok(())
}
async fn sample_queue(pool: &PgPool) {
    use observability::metrics::{self, Gauge};
    let query = sqlx::query_as::<_, (i64, i64, f64)>(
        "SELECT count(*) FILTER(WHERE state NOT IN ('completed','cancelled','manual')),count(*) FILTER(WHERE state='manual'),GREATEST(COALESCE(EXTRACT(EPOCH FROM clock_timestamp()-min(created_at) FILTER(WHERE state NOT IN ('completed','cancelled','manual'))),0),0)::float8 FROM orders",
    );
    if let Ok(Ok((pending, manual, oldest))) =
        tokio::time::timeout(Duration::from_millis(250), query.fetch_one(pool)).await
    {
        metrics::set_gauges(&[
            (Gauge::OrdersPending, pending as f64),
            (Gauge::OrdersManual, manual as f64),
            (Gauge::OrdersOldestSeconds, oldest),
            (Gauge::OrdersSampleUnix, metrics::unix_seconds()),
        ]);
    }
}
pub async fn run(s: Worker, stop: CancellationToken) -> anyhow::Result<()> {
    let mut sampled = std::time::Instant::now() - Duration::from_secs(5);
    loop {
        if sampled.elapsed() >= Duration::from_secs(5) {
            sample_queue(&s.pool).await;
            sampled = std::time::Instant::now();
        }
        if stop.is_cancelled() {
            return Ok(());
        }
        match claim(&s.pool).await {
            Ok(Some((row, token))) => {
                attempt(&s, &row, token).await?;
            }
            Ok(None) => {
                tokio::select! {_=stop.cancelled()=>return Ok(()),_=tokio::time::sleep(Duration::from_millis(200))=>{}}
            }
            Err(error) => {
                tracing::error!(%error,"order claim failed");
                tokio::select! {_=stop.cancelled()=>return Ok(()),_=tokio::time::sleep(Duration::from_secs(1))=>{}}
            }
        }
    }
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn only_legal_acyclic_transitions_are_accepted() {
        assert!(allowed("reserving", "charging"));
        assert!(allowed("confirming", "refunding"));
        assert!(!allowed("reserving", "completed"));
        for s in ["completed", "cancelled", "manual"] {
            assert!(!allowed(s, "reserving"));
        }
    }
    #[test]
    fn inconsistent_participants_never_become_false_success() {
        assert_eq!(
            inventory_outcome("releasing", StockState::Confirmed),
            Outcome::Advance("manual", "inconsistent-inventory")
        );
        assert_eq!(
            payment_outcome("refunding", PayState::Paid),
            Outcome::Advance("manual", "inconsistent-payment")
        );
    }
    #[test]
    fn lost_results_are_retried_and_contract_failures_are_manual() {
        assert!(matches!(
            payment_error(RemoteError::Deadline),
            Outcome::Retry(_)
        ));
        assert!(matches!(
            payment_error(RemoteError::IdentityConflict),
            Outcome::Advance("manual", _)
        ));
        assert!(matches!(
            inventory_error(tonic::Status::unavailable("offline")),
            Outcome::Retry(_)
        ));
    }
}

#[derive(Serialize, sqlx::FromRow)]
struct LegacyView {
    legacy_id: i64,
    public_id: Uuid,
    source_id: Uuid,
    legacy_status: String,
    source_payload: sqlx::types::Json<serde_json::Value>,
}
async fn legacy_query(
    State(s): State<Orders>,
    Extension(Actor(actor)): Extension<Actor>,
    Path(raw): Path<String>,
) -> ApiResult<Json<LegacyView>> {
    let id = raw
        .parse::<i64>()
        .ok()
        .filter(|id| *id > 0)
        .ok_or_else(invalid)?;
    let row=sqlx::query_as("SELECT legacy_id,public_id,source_id,legacy_status,source_payload FROM legacy_orders WHERE legacy_id=$1 AND actor_id=$2")
        .bind(id).bind(actor).fetch_optional(&s.pool).await?.ok_or(ApiError(StatusCode::NOT_FOUND,"legacy order not found"))?;
    Ok(Json(row))
}
#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct LegacyCartPage {
    #[serde(default = "first_page")]
    page: u32,
}
fn first_page() -> u32 {
    1
}
async fn legacy_cart(
    State(s): State<Orders>,
    Extension(Actor(actor)): Extension<Actor>,
    page: Result<axum::extract::Query<LegacyCartPage>, axum::extract::rejection::QueryRejection>,
) -> ApiResult<Json<Vec<serde_json::Value>>> {
    let axum::extract::Query(page) = page.map_err(|_| invalid())?;
    if !(1..=10_000).contains(&page.page) {
        return Err(invalid());
    }
    let rows:Vec<sqlx::types::Json<serde_json::Value>>=sqlx::query_scalar("SELECT source_payload FROM legacy_cart_items WHERE actor_id=$1 ORDER BY product_id LIMIT 100 OFFSET $2")
        .bind(actor).bind(i64::from(page.page-1)*100).fetch_all(&s.pool).await?;
    Ok(Json(rows.into_iter().map(|r| r.0).collect()))
}
