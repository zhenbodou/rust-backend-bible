-- Offline legacy import metadata. Runtime roles do not own this table.
CREATE TABLE legacy_import_checkpoint (
 singleton BOOLEAN PRIMARY KEY DEFAULT true CHECK(singleton),
 source_id UUID NOT NULL CHECK(source_id<>'00000000-0000-0000-0000-000000000000'),
 snapshot_sha256 BYTEA NOT NULL CHECK(octet_length(snapshot_sha256)=32),
 imported_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
