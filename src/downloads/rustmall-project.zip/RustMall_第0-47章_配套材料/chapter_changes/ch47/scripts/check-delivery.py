"""Verify the actual Linux image and complete role-scoped container deployment."""
from pathlib import Path
import argparse,json,os,re,secrets,stat,subprocess,tempfile,time,urllib.request,urllib.error,uuid,sys
stage=Path(__file__).resolve().parents[1]
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--image',default='rustmall/book:ch47-candidate')
parser.add_argument('--report-dir',type=Path,required=True)
parser.add_argument('--tls-dir',type=Path,help='existing local44 certificate directory; enables TLS override')
parser.add_argument('--rotate-local-cert',action='store_true')
parser.add_argument('--benchmark',action='store_true')
parser.add_argument('--recovery',action='store_true',help='quiesced six-DB logical restore and read-only reconciliation lab')
parser.add_argument('--legacy',action='store_true',help='migrate exact old monolith historical fixture before new business checks')
parser.add_argument('--recovery-cutover',action='store_true',help='also recover to new local PostgreSQL and route this owned lab there; Kafka/Redis retained')
args=parser.parse_args()
if args.recovery_cutover:args.recovery=True
if (args.rotate_local_cert or args.benchmark) and not args.tls_dir:parser.error('TLS required')
tls_context=None
if args.tls_dir:
 import ssl
 args.tls_dir=args.tls_dir.resolve()
 for name in ['ca.pem','server.pem','server.key']:
  if not (args.tls_dir/name).is_file():parser.error('TLS directory missing required file')
 os.environ['RUSTMALL_TLS_DIR']=str(args.tls_dir)
 tls_context=ssl.create_default_context(cafile=str(args.tls_dir/'ca.pem'))
if not re.fullmatch(r'[a-zA-Z0-9][a-zA-Z0-9_./:@-]*',args.image):parser.error('invalid image reference')
args.report_dir.mkdir(parents=True,exist_ok=True)
project='rustmall-delivery40-'+uuid.uuid4().hex[:12]
owned=False
success=False
work=tempfile.TemporaryDirectory(prefix='rustmall-delivery40-');checks=[];report={};compose=None;private=[];output=[]
def run(command,ok=True,input=None):
 r=subprocess.run(command,cwd=stage,capture_output=True,text=True,input=input)
 text=r.stdout+'\n'+r.stderr
 for value in private:text=text.replace(value,'[REDACTED]')
 output.append(text)
 if ok and r.returncode:raise RuntimeError('container delivery command failed; inspect container.log in the selected report directory')
 return r
def until(test,label,seconds=90):
 deadline=time.monotonic()+seconds
 while True:
  try:
   if test():return
  except (urllib.error.URLError,ConnectionError,TimeoutError):pass
  if time.monotonic()>deadline:raise RuntimeError('timeout: '+label)
  time.sleep(.25)
try:
 profile=Path(work.name)/'.delivery.local'
 run(['python3',str(stage/'scripts/create-delivery-env.py'),'--output-dir',str(profile),'--image',args.image])
 values={p.name:p.read_text().strip() for p in (profile/'secrets').iterdir()}
 private.extend(v for v in values.values() if len(v)>20)
 assert stat.S_IMODE(profile.stat().st_mode)==0o700 and stat.S_IMODE((profile/'secrets').stat().st_mode)==0o700
 before={p.name:p.read_bytes() for p in (profile/'secrets').iterdir()}
 r=run(['python3',str(stage/'scripts/create-delivery-env.py'),'--output-dir',str(profile),'--image',args.image],ok=False);assert r.returncode
 assert before=={p.name:p.read_bytes() for p in (profile/'secrets').iterdir()}
 compose=['docker','compose','-p',project,'--env-file',str(profile/'compose.env'),'-f',str(stage/'deploy/delivery40/compose.yaml')]
 if args.tls_dir:compose+=['-f',str(stage/'deploy/tls44/compose.yaml')]
 assert not run(compose+['ps','-a','-q']).stdout.strip(),'test project already exists'
 owned=True
 config=json.loads(run(compose+['config','--format','json']).stdout)
 assert all(secret not in json.dumps(config) for secret in private)
 published=[name for name,spec in config['services'].items() if spec.get('ports')];assert published==(['tls'] if args.tls_dir else ['edge']),published
 checks.append('private profile refuses overwrite; Compose contains no credential values and publishes only the selected HTTP or TLS entry')
 run(compose+['up','-d','--wait','--wait-timeout','120','postgres','redis'])
 def admin(db,query):return run(compose+['exec','-T','postgres','psql','-X','-v','ON_ERROR_STOP=1','-U','postgres','-d','rustmall_'+db,'-Atc',query]).stdout.strip()
 assert admin('catalog',"SELECT count(*) FROM pg_database WHERE datname IN ('rustmall_catalog','rustmall_users','rustmall_payments','rustmall_orders','rustmall_projection','rustmall_rebuild')")=='6'
 def as_role(role,db,query,ok=True):
  assert re.fullmatch('[a-z_]+',role) and re.fullmatch('[a-z_]+',db)
  command='export PGPASSWORD="$(cat /run/secrets/'+role+'_password)"; exec psql -h 127.0.0.1 -U '+role+' -d rustmall_'+db+' -X -v ON_ERROR_STOP=1 -At'
  return run(compose+['exec','-T','postgres','sh','-ec',command],input=query+'\n',ok=ok)
 denied=as_role('app_users','catalog','SELECT 1',ok=False);assert denied.returncode and 'permission denied for database' in denied.stderr
 checks.append('empty-volume bootstrap creates six isolated DBs; users runtime cannot connect to catalog')
 # The named build process is observed by the caller; image availability is only a dependency here.
 until(lambda:run(['docker','image','inspect',args.image],ok=False).returncode==0,'Linux image build',seconds=1200)
 image=json.loads(run(['docker','image','inspect',args.image]).stdout)[0]
 report['image_id']=image['Id'];report['image_os']=image['Os'];report['image_architecture']=image['Architecture']
 assert image['Os']=='linux' and image['Config']['User']=='10001:10001'
 run(compose+['up','-d','--wait','--wait-timeout','240'])
 roles=['catalog','users','payments','orders','worker','catalog-http','edge','relay','projection','projection-rebuild']
 for role in roles:
  cid=run(compose+['ps','-q',role]).stdout.strip();container=json.loads(run(['docker','inspect',cid]).stdout)[0]
  assert container['Image']==image['Id'] and container['Config']['User']=='10001:10001'
  assert container['HostConfig']['ReadonlyRootfs'] and 'ALL' in container['HostConfig']['CapDrop']
 checks.append('all ten logical roles use the same actually built Linux image, UID10001, read-only rootfs and dropped capabilities; six migrations and grants precede startup')
 base='https://localhost:18443' if args.tls_dir else 'http://127.0.0.1:18086'
 def api(path,method='GET',body=None,token=None,key=None):
  h={'Content-Type':'application/json'}
  if token:h['Authorization']='Bearer '+token
  if key:h['Idempotency-Key']=str(key)
  r=urllib.request.Request(base+path,headers=h,method=method,data=None if body is None else json.dumps(body).encode())
  try:reply=urllib.request.urlopen(r,timeout=8,context=tls_context)
  except urllib.error.HTTPError as error:reply=error
  with reply:
   raw=reply.read();return reply.status,json.loads(raw) if raw else None
 assert api('/readyz')[0]==200
 if args.legacy:
  import importlib.util
  spec=importlib.util.spec_from_file_location('legacy47_checker',stage/'scripts/check-legacy47.py')
  legacy_checker=importlib.util.module_from_spec(spec);spec.loader.exec_module(legacy_checker)
  legacy_checker.exercise(stage,compose,config,profile,work,args,run,until,api,roles,report,checks,private,admin,as_role)
 c={'username':'delivery_'+secrets.token_hex(4),'password':secrets.token_urlsafe(24)};private.append(c['password'])
 assert api('/api/v1/auth/register','POST',c)[0]==201
 status,reply=api('/api/v1/auth/login','POST',c);assert status==200;token=reply['access_token'];private.append(token)
 status,identity=api('/api/v1/auth/me',token=token);assert status==200;actor=int(identity['id']);assert actor>0
 admin('users',f"UPDATE users SET role='admin' WHERE id={actor}")
 draft={'name':'容器交付键盘','price_cents':19900,'stock':10};create_key=uuid.uuid4()
 status,p=api('/api/v1/products','POST',draft,token,create_key);assert status==201;pid=int(p['id'])
 assert api('/api/v1/products','POST',draft,token,create_key)[1]['id']==pid
 request={'product_id':pid,'quantity':2};key=uuid.uuid4();status,o=api('/api/v1/orders','POST',request,token,key);assert status==202;oid=str(uuid.UUID(o['id']))
 until(lambda:admin('orders',f"SELECT state FROM orders WHERE id='{oid}'")=='completed','container Saga complete')
 assert admin('payments',f"SELECT count(*) FROM payment_effects WHERE saga_id='{oid}' AND kind='paid'")=='1'
 assert admin('catalog',f'SELECT stock FROM products WHERE id={pid}')=='8'
 assert api('/api/v1/orders','POST',request,token,key)[1]['id']==oid
 assert api(f'/api/v1/products/{pid}','PUT',{**draft,'stock':999},token)[0]==409
 assert api(f'/api/v1/products/{pid}','PUT',{**draft,'name':'容器键盘资料修订','stock':8},token)[0]==200
 checks.append('real container HTTP auth/product/idempotent order/Saga completes with one paid effect, stock8, preserved metadata edits and rejected stock overwrite')
 adjust_id=uuid.uuid4()
 run(compose+['run','--rm','--no-deps','inventory-admin','/app/inventory-adjust','apply',str(adjust_id),str(pid),'3',str(actor),'container-check','--local-admin'])
 assert admin('catalog',f'SELECT stock FROM products WHERE id={pid}')=='11'
 assert api(f'/api/v1/products/{pid}','DELETE',token=token)[0]==204
 def projection_ok(db):return admin(db,f"SELECT count(*) FROM catalog_view WHERE product_id={pid} AND (payload->>'stock')::int=11 AND NOT (payload->>'listed')::boolean")=='1'
 until(lambda:projection_ok('projection') and projection_ok('rebuild'),'independent container projections')
 assert admin('catalog','SELECT count(*) FROM product_outbox WHERE delivered_at IS NULL')=='0'
 checks.append('least-privilege inventory-admin adjusts stock and records audit; relay and both independent projections converge to the stock11 tombstone')
 refusals=[
  ('app_users','users',"UPDATE users SET role='admin' WHERE false"),
  ('app_users','users','CREATE TABLE should_not_exist(id int)'),
  ('app_orders','orders',"UPDATE orders SET state='completed' WHERE false"),
  ('worker_orders','orders','INSERT INTO orders(id,actor_id,request_key,product_id,quantity,unit_price,amount) SELECT gen_random_uuid(),1,gen_random_uuid(),1,1,1,1 WHERE false'),
  ('relay_catalog','catalog',"UPDATE product_outbox SET payload='{}'::jsonb WHERE false"),
  ('relay_catalog','catalog','UPDATE products SET stock=0 WHERE false'),
  ('app_payments','payments','DELETE FROM payment_effects WHERE false'),
  ('app_projection','projection','DELETE FROM catalog_view WHERE false'),
  ('app_projection','projection',"UPDATE projection_identity SET consumer_name='different' WHERE false"),
 ]
 for role,db,query in refusals:
  r=as_role(role,db,query,ok=False);assert r.returncode and 'permission denied' in r.stderr,(role,db)
 checks.append('nine actual SQL privilege denials protect user promotion/DDL, order state, worker creation, event content, product stock, payment audit and projection identity/tombstones')
 redis='export REDISCLI_AUTH="$(awk \'$1=="user" && $2=="app_users" {print substr($4,2)}\' /run/secrets/redis_acl)"; exec redis-cli -e --user app_users FLUSHDB'
 r=run(compose+['exec','-T','redis','sh','-ec',redis],ok=False);assert r.returncode and 'NOPERM' in (r.stdout+r.stderr)
 assert api('/api/v1/auth/logout','POST',token=token)[0]==204
 assert api('/api/v1/auth/me',token=token)[0]==401
 checks.append('Redis ACL supports login/Lua/session revocation but denies application FLUSHDB; logout remains effective')
 fresh=[]
 for _ in range(2):
  status,reply=api('/api/v1/auth/login','POST',c);assert status==200
  fresh.append(reply['access_token']);private.append(fresh[-1])
 live_token,revoke_token=fresh
 run(compose+['stop','redis'])
 started=time.monotonic()
 assert api('/api/v1/auth/me',token=live_token)[0]==503
 assert time.monotonic()-started<3
 assert api('/api/v1/auth/login','POST',c)[0]==503
 assert api('/api/v1/auth/logout','POST',token=revoke_token)[0]==503
 assert admin('users',f'SELECT count(*) FROM sessions WHERE user_id={actor} AND revoked_at IS NOT NULL')=='2'
 run(compose+['start','redis'])
 until(lambda:api('/api/v1/auth/me',token=live_token)[0]==200,'users Redis reconnection')
 assert api('/api/v1/auth/me',token=revoke_token)[0]==401
 assert api('/api/v1/auth/logout','POST',token=revoke_token)[0]==204
 checks.append('real Redis outage: me/login return503, logout commits DB revocation before503; empty restart reconnects and never revives revoked session, retry logout204')

 # Health probes and metrics are executed in their real namespaces, not merely rendered.
 run(compose+['exec','-T','edge','/app/rustmall-probe','http','http://127.0.0.1:8080/readyz'])
 run(compose+['exec','-T','catalog','/app/rustmall-probe','grpc','http://127.0.0.1:50051','readiness'])
 if args.tls_dir:
  import ssl,socket
  for context,target in [(ssl.create_default_context(),'localhost'),(tls_context,'127.0.0.1')]:
   try:
    with urllib.request.urlopen('https://'+target+':18443/readyz',context=context,timeout=2):pass
   except urllib.error.URLError as error:
    assert isinstance(error.reason,ssl.SSLCertVerificationError),type(error.reason)
   else:raise AssertionError('invalid TLS trust/identity accepted')
  for version in [ssl.TLSVersion.TLSv1_2,ssl.TLSVersion.TLSv1_3]:
   context=ssl.create_default_context(cafile=str(args.tls_dir/'ca.pem'))
   context.minimum_version=version;context.maximum_version=version
   with socket.create_connection(('127.0.0.1',18443),timeout=2) as tcp:
    with context.wrap_socket(tcp,server_hostname='localhost') as channel:
     assert channel.version()==('TLSv1.2' if version==ssl.TLSVersion.TLSv1_2 else 'TLSv1.3')
  try:
   with socket.create_connection(('127.0.0.1',18086),timeout=.5):pass
  except OSError:pass
  else:raise AssertionError('plaintext edge bypass remains reachable')
  assert api('/api/v1/auth/register','POST',{'payload':'x'*5000})[0]==413
  tls_id=run(compose+['ps','-q','tls']).stdout.strip()
  proxy=json.loads(run(['docker','inspect',tls_id]).stdout)[0]
  assert proxy['Config']['User']=='101:101' and proxy['HostConfig']['ReadonlyRootfs']
  report['tls_image_id']=proxy['Image']
  checks.append('real Nginx TLS1.2/1.3, localhost CA accepted; untrusted root/IP name rejected; plaintext18086 unreachable; oversized body413; nonroot readonly proxy')
  run(compose+['stop','edge'])
  started=time.monotonic();status,error=api('/readyz')
  assert status in [503,504] and error['code']=={503:'UNAVAILABLE',504:'DEADLINE_EXCEEDED'}[status]
  assert time.monotonic()-started<8
  report['tls_stopped_upstream_status']=status
  run(compose+['start','edge'])
  until(lambda:api('/readyz')[0]==200,'edge recovered behind TLS')
  checks.append('actual upstream edge outage returns bounded JSON503/504 matching error class; recovery restores HTTPS readiness')
  for role in ['edge','tls']:
   snapshot=run(compose+['exec','-T',role,'sh','-s'],input=(stage/'ops/linux44/snapshot.sh').read_text()).stdout
   assert '/sys/fs/cgroup/memory.max' in snapshot and 'pid1_fd_count' in snapshot
   (args.report_dir/('linux-'+role+'.txt')).write_text(snapshot)
  assert proxy['HostConfig']['Memory']==128*1024*1024 and proxy['HostConfig']['PidsLimit']==32
  checks.append('real Linux container cgroup/FD read-only snapshots captured; TLS memory128MiB/pids32 verified')
  edge_id=run(compose+['ps','-q','edge']).stdout.strip()
  run(['docker','kill','--signal','STOP',edge_id])
  try:
   started=time.monotonic();status,error=api('/readyz')
   assert status==504 and error['code']=='DEADLINE_EXCEEDED' and time.monotonic()-started<8
  finally:run(['docker','kill','--signal','CONT',edge_id])
  until(lambda:api('/readyz')[0]==200,'edge after CONT')
  checks.append('actual SIGSTOP keeps edge process alive but proxy read timeout gives JSON504; CONT restores readiness')

  if args.rotate_local_cert:
   import hashlib
   def certificate_hash():
    with socket.create_connection(('127.0.0.1',18443),timeout=2) as tcp:
     with tls_context.wrap_socket(tcp,server_hostname='localhost') as connection:
      return hashlib.sha256(connection.getpeercert(binary_form=True)).hexdigest()
   before=certificate_hash()
   ca_before={name:(args.tls_dir/name).read_bytes() for name in ['ca.pem','ca.key']}
   rotated=Path(work.name)/'rotated'
   run(['python3',str(stage/'scripts/rotate-tls-lab.py'),'--ca-dir',str(args.tls_dir),'--output-dir',str(rotated)])
   assert ca_before=={name:(args.tls_dir/name).read_bytes() for name in ca_before}
   assert not (rotated/'ca.key').exists()
   os.environ['RUSTMALL_TLS_DIR']=str(rotated)
   run(compose+['up','-d','--no-deps','--force-recreate','tls'])
   until(lambda:api('/readyz')[0]==200,'rotated TLS readiness')
   after=certificate_hash();assert before!=after
   assert api('/api/v1/auth/me',token=live_token)[0]==200
   report['leaf_sha256_before']=before;report['leaf_sha256_after']=after
   checks.append('actual leaf rotation under unchanged CA changes wire fingerprint; recreate only TLS, existing user session still valid; no zero-downtime claim')
  if args.benchmark:
   assert api('/api/v1/products','POST',{'name':'TLS基准商品','price_cents':19900,'stock':10},live_token,uuid.uuid4())[0]==201
   token_path=Path(work.name)/'benchmark.token'
   token_path.write_text(live_token);token_path.chmod(0o600)
   for concurrency in [1,8,32]:
    time.sleep(2)
    report_path=args.report_dir.resolve()/('https-c'+str(concurrency)+'.json')
    run(['python3',str(stage/'scripts/bench-https.py'),'--url',base,'--ca',str(args.tls_dir/'ca.pem'),'--token-file',str(token_path),'--output',str(report_path),'--concurrency',str(concurrency)])
    observation=json.loads(report_path.read_text())
    assert sum(observation['status_counts'].values())==120 and observation['status_counts'].get('200',0)>0
   checks.append('three bounded HTTPS GET observations retain all status/error counts and separate200 throughput; per-worker connection reuse, not order capacity proof')

 if args.recovery:
  import recovery46
  for database in ('orders','catalog','payments'):
   diagnostic=(stage/'ops/recovery46'/(database+'-health.sql')).read_text()
   run(compose+['exec','-T','postgres','psql','-X','-q','-v','ON_ERROR_STOP=1','-U','postgres','-d','rustmall_'+database],input=diagnostic)
  # This project is freshly owned by this checker, with a private backend network.
  # Stop ALL application DB clients before taking a six-database cut. No live
  # production deployment is stopped and no application URL is switched.
  stopped=roles+(['tls'] if args.tls_dir else [])
  run(compose+['stop',*stopped])
  container=run(compose+['ps','-q','postgres']).stdout.strip()
  bundle=Path(work.name)/'recovery-set'
  metadata=recovery46.backup(container,bundle)
  prefix='rustmall_restore_'+uuid.uuid4().hex[:12]
  restored=recovery46.restore(container,bundle,metadata['manifest_sha256'],prefix)
  assert restored['matches'] and len(restored['databases'])==6
  original={x:'rustmall_'+x for x in recovery46.DATABASES}
  baseline=recovery46.reconcile(recovery46.collect(container,original))
  recovered=recovery46.reconcile(recovery46.collect(container,restored['databases']))
  assert baseline['clean'] and recovered['clean'],(baseline,recovered)
  report['recovery']={'backup':metadata,'restore':restored,'baseline':baseline,'restored_audit':recovered}
  checks.append('quiesced owned lab: six custom archives restored to six NEW offline databases; every public table, SQLx ledger, sequence state and constraint flag matches; read-only reconciliation clean')
  # Verify restored constraints and identity allocation, on OFFLINE copies only.
  targets=restored['databases']
  try:recovery46.sql(container,targets['catalog'],f'UPDATE products SET stock=-1 WHERE id={pid};')
  except RuntimeError:pass
  else:raise AssertionError('restored stock CHECK did not reject negative value')
  assert recovery46.sql(container,targets['catalog'],f'SELECT stock FROM products WHERE id={pid};')=='11'
  for logical,table in [('catalog','products'),('users','users'),('orders','order_transitions')]:
   query=f"SELECT nextval(pg_get_serial_sequence('public.{table}','id'))>COALESCE((SELECT max(id) FROM public.{table}),0);"
   assert recovery46.sql(container,targets[logical],query)=='t'
  checks.append('three diagnostic SQL scripts execute; restored stock CHECK rejects invalid update and all three identity sequences allocate beyond existing IDs on offline copies')
  # Refuse an existing target and a damaged archive BEFORE any database creation.
  def database_count():
   return recovery46.sql(container,'rustmall_orders',"SELECT count(*) FROM pg_database WHERE datname LIKE 'rustmall_restore_%';")
  count_before=database_count()
  try:recovery46.restore(container,bundle,metadata['manifest_sha256'],prefix)
  except ValueError:pass
  else:raise AssertionError('existing target accepted')
  assert database_count()==count_before
  archive=bundle/'orders.dump'
  with archive.open('ab') as stream:stream.write(b'integrity-negative-control')
  try:recovery46.restore(container,bundle,metadata['manifest_sha256'],prefix+'x')
  except ValueError:pass
  else:raise AssertionError('damaged archive accepted')
  assert database_count()==count_before
  with archive.open('r+b') as stream:stream.truncate(archive.stat().st_size-len(b'integrity-negative-control'))
  checks.append('existing verification targets and archive corruption refused before creation; original databases untouched')
  # Damage ONLY offline verification copies, modeling a lost participant receipt.
  targets=restored['databases']
  recovery46.sql(container,targets['payments'],f"DELETE FROM payment_effects WHERE saga_id='{oid}'; DELETE FROM payments WHERE saga_id='{oid}';")
  lost=recovery46.reconcile(recovery46.collect(container,targets))
  assert any(x['code']=='completed_participants_mismatch' and x['identity']==oid for x in lost['findings'])
  assert recovery46.reconcile(recovery46.collect(container,original))['clean']
  report['recovery']['lost_receipt_negative_control']=lost
  checks.append('offline lost-payment-receipt negative control detected completed-order mismatch; production cut remains clean; no automatic repair')
  # Resuming the ORIGINAL deployment proves no cutover occurred. Redis caches
  # remain empty after the earlier fault; durable sessions are still authoritative.
  run(compose+['up','-d','--no-deps','--wait','--wait-timeout','120',*stopped])
  assert api('/api/v1/auth/me',token=live_token)[0]==200
  assert api('/api/v1/orders','POST',request,live_token,key)[1]['id']==oid
  assert admin('payments',f"SELECT count(*) FROM payment_effects WHERE saga_id='{oid}' AND kind='paid'")=='1'
  checks.append('original deployment resumes with existing session and idempotent order; one paid effect remains; offline verification DBs were never routed into apps')
  if args.recovery_cutover:
   from recovery_cutover46 import exercise_cutover
   compose=exercise_cutover(stage,compose,config,profile,work,args,run,until,api,roles,report,checks,private,container,bundle,metadata,actor,live_token,revoke_token,request,key,oid,pid)


 report['containers_verified']=roles
 success=True
finally:
 if compose and owned:
  logs=subprocess.run(compose+['logs','--no-color'],capture_output=True,text=True).stdout
  for value in private:logs=logs.replace(value,'[REDACTED]')
  (args.report_dir/'container-runtime.log').write_text(logs)
  report['cleanup_exit']=subprocess.run(compose+['down','--volumes','--remove-orphans'],capture_output=True).returncode
 work.cleanup()
 text='\n'.join(output)
 for value in private:text=text.replace(value,'[REDACTED]')
 (args.report_dir/'container.log').write_text(text)
 report.update(success=success and report.get('cleanup_exit')==0,checks=checks,passed=len(checks),scope=('actual Nginx external TLS and local ten-role deployment; backend links remain plaintext' if args.tls_dir else 'actual single-architecture Linux image and complete local Docker Compose with DB/Redis privileges; no remote CI/cluster proof'))
 (args.report_dir/'container.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(report,ensure_ascii=False,indent=2))

if not report['success']:sys.exit(1)
