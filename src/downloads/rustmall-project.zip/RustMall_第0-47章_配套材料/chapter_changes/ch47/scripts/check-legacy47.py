"""Hook for an OWNED empty-volume check-delivery deployment, never a live importer.
The actual data bridge is the Rust binary. This driver creates historical fixtures,
checks negative cases, then exercises real authenticated HTTP and the Saga.
"""
import copy
import json
from pathlib import Path
import secrets
import uuid


def exercise(stage, compose, config, profile, work, args, run, until, api,
             roles, report, checks, private, admin, as_role):
    stopped = roles + (['tls'] if args.tls_dir else [])
    run(compose + ['stop', *stopped])
    source_name = 'rustmall_legacy_lab_' + uuid.uuid4().hex[:12]
    source_id = str(uuid.uuid4())
    password = secrets.token_urlsafe(24)
    admin_password = (profile/'secrets/postgres_admin_password').read_text().strip()
    source_url = f'postgresql://postgres:{admin_password}@postgres:5432/{source_name}'
    private.extend([password, source_url])
    for name, value in [('legacy_source_url', source_url), ('legacy_fixture_password', password)]:
        path = profile/'secrets'/name
        with path.open('x') as stream:stream.write(value)
        path.chmod(0o444)
    run(compose + ['exec','-T','postgres','createdb','-U','postgres',source_name])
    spec = copy.deepcopy(config['services']['users'])
    spec.pop('depends_on',None);spec.pop('healthcheck',None)
    spec['command'] = ['/app/legacy-bridge','--help']
    spec['environment'] = {'TOKIO_WORKER_THREADS':'2',
        'LEGACY_SOURCE_URL_FILE':'/run/secrets/legacy_source_url',
        'LEGACY_USERS_URL_FILE':'/run/secrets/migrate_users_url',
        'LEGACY_CATALOG_URL_FILE':'/run/secrets/migrate_catalog_url',
        'LEGACY_ORDERS_URL_FILE':'/run/secrets/migrate_orders_url'}
    names=['legacy_source_url','legacy_fixture_password','migrate_users_url','migrate_catalog_url','migrate_orders_url']
    spec['secrets']=[{'source':name} for name in names]
    overlay=Path(work.name)/'legacy47-overlay.json'
    overlay.write_text(json.dumps({'services':{'legacy-bridge':spec},'secrets':{
        name:{'file':str(profile/'secrets'/name)} for name in names[:2]}}))
    # Register with the parent's cleanup command before the first tool container.
    compose.extend(['-f',str(overlay)])
    def tool(*arguments,ok=True):
        return run(compose+['run','--rm','--no-deps','legacy-bridge','/app/legacy-bridge',*arguments],ok=ok)
    def source(query):
        return run(compose+['exec','-T','postgres','psql','-X','-qAt','-v','ON_ERROR_STOP=1','-U','postgres','-d',source_name],input=query+'\n').stdout.strip()
    tool('lab-init','/run/secrets/legacy_fixture_password','--ack-owned-empty-lab')
    plan=json.loads(tool('plan',source_id).stdout);digest=plan['sha256']
    assert (plan['users'],plan['products'],plan['historical_orders'],plan['historical_cart_items'])==(2,2,2,2)
    def empty_targets():
        return admin('users','SELECT count(*) FROM users')=='0' and admin('catalog','SELECT count(*) FROM products')=='0' and admin('orders','SELECT count(*) FROM legacy_orders')=='0'
    assert empty_targets()
    # A pending order cannot be silently transformed into a fresh Saga.
    source("INSERT INTO orders(id,user_id,product_id,quantity,unit_price_cents,total_cents,idempotency_key) OVERRIDING SYSTEM VALUE VALUES(999,7,41,1,100,100,'5abc27ad-1fea-471e-9694-a6116dba0459')")
    assert tool('plan',source_id,ok=False).returncode
    assert tool('apply',source_id,digest,'--ack-offline',ok=False).returncode
    assert empty_targets()
    source('DELETE FROM orders WHERE id=999')
    source("INSERT INTO orders(id,user_id,product_id,quantity,unit_price_cents,total_cents,status,paid_at,cancel_reason,idempotency_key) OVERRIDING SYSTEM VALUE VALUES(998,7,41,1,100,100,'cancelled','2025-01-01','refund unknown','107ba865-cacc-4ee9-842c-c95e1bf7b5c9')")
    assert tool('plan',source_id,ok=False).returncode
    source('DELETE FROM orders WHERE id=998')
    source("UPDATE users SET username=' Legacy_Admin ' WHERE id=7")
    assert tool('plan',source_id,ok=False).returncode
    source("UPDATE users SET username='legacy_admin' WHERE id=7")
    assert json.loads(tool('plan',source_id).stdout)['sha256']==digest
    checks.append('exact old monolith migrations and historical fixture: pending/paid-cancelled/noncanonical-name negatives rejected; no target writes')
    admin('users',"INSERT INTO users(username,password_hash) VALUES('conflict_fixture','fixture')")
    assert tool('apply',source_id,digest,'--ack-offline',ok=False).returncode
    assert admin('users','SELECT count(*) FROM users')=='1'
    admin('users',"DELETE FROM users WHERE username='conflict_fixture'")
    checks.append('populated destination without matching checkpoint is refused without merge or deletion')
    assert tool('apply',source_id,digest,'--ack-offline','--stop-after-users',ok=False).returncode
    assert admin('users','SELECT count(*) FROM users')=='2'
    assert admin('catalog','SELECT count(*) FROM products')=='0'
    assert admin('orders','SELECT count(*) FROM legacy_orders')=='0'
    source('UPDATE products SET stock=9 WHERE id=41')
    changed=json.loads(tool('plan',source_id).stdout)['sha256'];assert changed!=digest
    assert tool('apply',source_id,digest,'--ack-offline',ok=False).returncode
    assert tool('apply',source_id,changed,'--ack-offline',ok=False).returncode
    assert admin('catalog','SELECT count(*) FROM products')=='0'
    source('UPDATE products SET stock=8 WHERE id=41')
    completed=json.loads(tool('apply',source_id,digest,'--ack-offline').stdout)
    assert completed['all_three_phases_complete']
    for db in ['users','catalog','orders']:
        assert admin(db,'SELECT count(*) FROM legacy_import_checkpoint')=='1'
    assert admin('orders','SELECT count(*) FROM orders')=='0'
    assert admin('payments','SELECT count(*) FROM payment_effects')=='0'
    assert admin('catalog','SELECT stock FROM products WHERE id=41')=='8'
    checks.append('real committed users-phase interruption resumes by SAME source hash; changed source or reviewed hash cannot hijack checkpoint; imported stock unchanged and zero fake payment effects')
    run(compose+['up','-d','--no-deps','--wait','--wait-timeout','120',*stopped])
    def login(name):
        status,reply=api('/api/v1/auth/login','POST',{'username':name,'password':password})
        assert status==200
        token=reply['access_token'];private.append(token)
        return token
    token=login('legacy_admin');other=login('legacy_other')
    assert api('/api/v1/auth/me',token=token)[1]['id']==7
    status,history=api('/api/v1/orders/legacy/101',token=token)
    assert status==200 and history['legacy_status']=='completed'
    assert history['source_id']==source_id and uuid.UUID(history['public_id']).version==8
    assert history['source_payload']['unit_price_cents']==199 and history['source_payload']['total_cents']==398
    assert history['source_payload']['tracking_no']=='legacy-track-101'
    assert api('/api/v1/orders/legacy/101',token=other)[0]==404
    assert api('/api/v1/orders/legacy/101')[0]==401
    assert api('/api/v1/orders/legacy/0',token=token)[0]==400
    status,cart=api('/api/v1/orders/legacy-cart',token=token);assert status==200 and len(cart)==1 and cart[0]['user_id']==7
    status,cart=api('/api/v1/orders/legacy-cart',token=other);assert status==200 and len(cart)==1 and cart[0]['user_id']==11
    for query in ['page=0','page=bad','page=4294967296','other=1']:
        status,error=api('/api/v1/orders/legacy-cart?'+query,token=token)
        assert status==400 and error['code']=='INVALID_INPUT'
    checks.append('real imported PHC login keeps user IDs and roles; authenticated historical order preserves price/shipping data, other actor404/anonymous401; historical carts paginated and actor isolated')
    for key,pid,quantity in [('da65a670-e8ed-410c-aa36-12720eff68d1',41,2),('e1cc88c2-25fb-4082-97ee-575058e07027',43,1)]:
        assert api('/api/v1/orders','POST',{'product_id':pid,'quantity':quantity},token,uuid.UUID(key))[0]==409
    assert admin('orders','SELECT count(*) FROM orders')=='0'
    assert admin('payments','SELECT count(*) FROM payment_effects')=='0'
    denied=as_role('app_orders','orders','DELETE FROM legacy_orders WHERE false',ok=False)
    assert denied.returncode and 'permission denied' in denied.stderr
    checks.append('both old request keys return409 before re-reservation or payment; zero new Saga/effects; runtime Orders cannot delete historical records')
    request={'product_id':41,'quantity':1};key=uuid.uuid4()
    status,order=api('/api/v1/orders','POST',request,token,key);assert status==202
    new_id=str(uuid.UUID(order['id']))
    until(lambda:admin('orders',f"SELECT state FROM orders WHERE id='{new_id}'")=='completed','migrated user new Saga')
    assert admin('catalog','SELECT stock FROM products WHERE id=41')=='7'
    assert admin('payments',f"SELECT count(*) FROM payment_effects WHERE saga_id='{new_id}' AND kind='paid'")=='1'
    run(compose+['stop',*stopped])
    assert json.loads(tool('apply',source_id,digest,'--ack-offline').stdout)['all_three_phases_complete']
    assert admin('catalog','SELECT stock FROM products WHERE id=41')=='7'
    assert admin('users','SELECT count(*) FROM sessions')=='2'
    run(compose+['up','-d','--no-deps','--wait','--wait-timeout','120',*stopped])
    assert api('/api/v1/orders','POST',request,token,key)[1]['id']==new_id
    def projected(db):
        return admin(db,"SELECT count(*) FROM catalog_view WHERE product_id=41 AND (payload->>'stock')::int=7")=='1' and admin(db,"SELECT count(*) FROM catalog_view WHERE product_id=43 AND NOT (payload->>'listed')::boolean")=='1'
    until(lambda:projected('projection') and projected('rebuild'),'legacy snapshots and new stock projections')
    assert source('SELECT stock FROM products WHERE id=41')=='8'
    assert source('SELECT count(*) FROM orders')=='2'
    checks.append('migrated actor completes NEW Saga once; offline rerun preserves post-cutover stock7/session rows; same-key replay and both projections including tombstone succeed; old source remains stock8/history2')
    report['legacy_import']={'source_id':source_id,'reviewed_sha256':digest,'users':2,'products':2,'historical_orders':2,'historical_cart_items':2,
        'checkpoint_resume':True,'historical_replays_blocked':True,'legacy_payment_effects_created':0,
        'new_saga_after_import':True,'rerun_preserves_new_data':True,
        'scope':'owned frozen monolith fixture; terminal settled history only, read-only historical carts; no unresolved-order or payment-channel migration'}
