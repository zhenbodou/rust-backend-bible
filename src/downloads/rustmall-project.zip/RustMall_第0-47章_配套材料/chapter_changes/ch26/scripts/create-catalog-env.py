"""仅生成本地商品服务实验配置；拒绝覆盖，不输出秘密。"""
import os
import secrets

password = secrets.token_urlsafe(36)
values = {
    "POSTGRES_PASSWORD": password,
    "DATABASE_URL": f"postgres://rustmall:{password}@127.0.0.1:55433/rustmall_catalog",
    "RUSTMALL_CATALOG_TOKEN": secrets.token_urlsafe(48),
    "CATALOG_ADDR": "127.0.0.1:50051",
    "RUSTMALL_CATALOG_ENDPOINT": "http://127.0.0.1:50051",
}
fd = os.open(".env.catalog.local", os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
with os.fdopen(fd, "w") as output:
    for key, value in values.items():
        output.write(f"{key}={value}\n")
print("已生成 .env.catalog.local；未输出秘密。")
