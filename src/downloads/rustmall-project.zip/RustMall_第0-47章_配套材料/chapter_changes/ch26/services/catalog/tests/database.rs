use catalog::CatalogApi;
use contracts::catalog::catalog_server::Catalog;
use contracts::catalog::*;
use sqlx::PgPool;
use tonic::{Code, Request};

async fn create(api: &CatalogApi, name: &str) -> Product {
    api.create_product(Request::new(CreateProductRequest {
        name: name.into(),
        price_cents: 19_900,
        stock: 10,
    }))
    .await
    .unwrap()
    .into_inner()
}

#[sqlx::test]
async fn methods_preserve_values_and_delisting_is_persistent(pool: PgPool) {
    let api = CatalogApi::new(pool.clone());
    let created = create(&api, "  机械键盘  ").await;
    assert!(created.id > 0);
    assert_eq!(
        (created.name.as_str(), created.price_cents, created.stock),
        ("机械键盘", 19_900, 10)
    );
    let read = api
        .get_product(Request::new(GetProductRequest { id: created.id }))
        .await
        .unwrap()
        .into_inner();
    assert_eq!(read, created);
    let changed = api
        .update_product(Request::new(UpdateProductRequest {
            id: created.id,
            name: "静音键盘".into(),
            price_cents: 20_000,
            stock: 0,
        }))
        .await
        .unwrap()
        .into_inner();
    assert_eq!((changed.price_cents, changed.stock), (20_000, 0));
    api.delist_product(Request::new(GetProductRequest { id: created.id }))
        .await
        .unwrap();
    assert_eq!(
        api.get_product(Request::new(GetProductRequest { id: created.id }))
            .await
            .unwrap_err()
            .code(),
        Code::NotFound
    );
    assert_eq!(
        api.delist_product(Request::new(GetProductRequest { id: created.id }))
            .await
            .unwrap_err()
            .code(),
        Code::NotFound
    );
    let kept: i64 =
        sqlx::query_scalar("SELECT count(*) FROM products WHERE id=$1 AND delisted_at IS NOT NULL")
            .bind(created.id)
            .fetch_one(&pool)
            .await
            .unwrap();
    assert_eq!(kept, 1);
}

#[sqlx::test]
async fn invalid_inputs_and_missing_rows_have_different_statuses(pool: PgPool) {
    let api = CatalogApi::new(pool);
    assert_eq!(
        api.get_product(Request::new(GetProductRequest { id: 0 }))
            .await
            .unwrap_err()
            .code(),
        Code::InvalidArgument
    );
    assert_eq!(
        api.get_product(Request::new(GetProductRequest { id: 999 }))
            .await
            .unwrap_err()
            .code(),
        Code::NotFound
    );
    assert_eq!(
        api.list_products(Request::new(ListProductsRequest {
            limit: 0,
            offset: 0
        }))
        .await
        .unwrap_err()
        .code(),
        Code::InvalidArgument
    );
    assert_eq!(
        api.create_product(Request::new(CreateProductRequest {
            name: "键盘".into(),
            price_cents: -1,
            stock: 10,
        }))
        .await
        .unwrap_err()
        .code(),
        Code::InvalidArgument
    );
    assert_eq!(
        api.update_product(Request::new(UpdateProductRequest {
            id: -1,
            name: "键盘".into(),
            price_cents: 100,
            stock: 10,
        }))
        .await
        .unwrap_err()
        .code(),
        Code::InvalidArgument
    );
    assert_eq!(
        api.delist_product(Request::new(GetProductRequest { id: -1 }))
            .await
            .unwrap_err()
            .code(),
        Code::InvalidArgument
    );
}

#[sqlx::test]
async fn list_uses_stable_tie_order_and_excludes_delisted_rows(pool: PgPool) {
    sqlx::query(
        "INSERT INTO products(name,price_cents,stock,created_at,delisted_at) VALUES
        ('A',100,1,'2020-01-01T00:00:00Z',NULL),
        ('B',100,1,'2020-01-02T00:00:00Z',NULL),
        ('C',100,1,'2020-01-02T00:00:00Z',NULL),
        ('D',100,1,'2020-01-03T00:00:00Z','2020-01-04T00:00:00Z')",
    )
    .execute(&pool)
    .await
    .unwrap();
    let api = CatalogApi::new(pool);
    let first = api
        .list_products(Request::new(ListProductsRequest {
            limit: 2,
            offset: 0,
        }))
        .await
        .unwrap()
        .into_inner();
    assert_eq!(first.items.iter().map(|p| p.id).collect::<Vec<_>>(), [3, 2]);
    assert_eq!(first.total, 3);
    let second = api
        .list_products(Request::new(ListProductsRequest {
            limit: 2,
            offset: 2,
        }))
        .await
        .unwrap()
        .into_inner();
    assert_eq!(second.items.iter().map(|p| p.id).collect::<Vec<_>>(), [1]);
    assert_eq!(second.total, 3);
}

#[sqlx::test]
async fn locked_query_exhausts_budget_and_pool_recovers(pool: PgPool) {
    let mut lock = pool.begin().await.unwrap();
    sqlx::query("LOCK TABLE products IN ACCESS EXCLUSIVE MODE")
        .execute(&mut *lock)
        .await
        .unwrap();
    let api = CatalogApi::new(pool.clone());
    let result = tokio::time::timeout(
        std::time::Duration::from_secs(2),
        api.get_product(Request::new(GetProductRequest { id: 1 })),
    )
    .await
    .expect("catalog's 700ms budget must finish before the outer guard");
    assert_eq!(result.unwrap_err().code(), Code::DeadlineExceeded);
    lock.rollback().await.unwrap();
    assert_eq!(
        api.get_product(Request::new(GetProductRequest { id: 1 }))
            .await
            .unwrap_err()
            .code(),
        Code::NotFound
    );
}

#[sqlx::test]
async fn invalid_stored_domain_value_is_not_returned_as_a_product(pool: PgPool) {
    // PostgreSQL's default btrim and Rust's Unicode trim are not identical.
    // Model malformed legacy data written outside the application boundary.
    let id: i64 = sqlx::query_scalar(
        "INSERT INTO products(name,price_cents,stock) VALUES($1,100,1) RETURNING id",
    )
    .bind("\u{2003}")
    .fetch_one(&pool)
    .await
    .unwrap();
    let api = CatalogApi::new(pool);
    let error = api
        .get_product(Request::new(GetProductRequest { id }))
        .await
        .unwrap_err();
    assert_eq!(error.code(), Code::Internal);
    assert_eq!(error.message(), "stored product violates domain rules");
}
