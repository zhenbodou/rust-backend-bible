-- Fresh catalog database only. Never run against monolith migration history.
CREATE TABLE products (
   id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
   name VARCHAR(100) NOT NULL CHECK (char_length(btrim(name)) BETWEEN 1 AND 100),
   price_cents BIGINT NOT NULL CHECK (price_cents >= 0),
   stock INT NOT NULL CHECK (stock >= 0),
   created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
   updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
   delisted_at TIMESTAMPTZ
);
CREATE INDEX products_listed_created_idx ON products(created_at DESC,id DESC)
   WHERE delisted_at IS NULL;
