use common::ids::ProductId;
use common::product::{NewProduct, Product as DomainProduct};
use contracts::catalog::catalog_server::Catalog;
use contracts::catalog::*;
use sqlx::PgPool;
use std::future::Future;
use std::time::Duration;
use tonic::{Request, Response, Status};

#[derive(Clone)]
pub struct CatalogApi {
    pool: PgPool,
}
impl CatalogApi {
    pub fn new(pool: PgPool) -> Self {
        Self { pool }
    }
}
#[derive(sqlx::FromRow)]
struct Row {
    id: i64,
    name: String,
    price_cents: i64,
    stock: i32,
}
impl Row {
    fn wire(self) -> Result<Product, Status> {
        let product = DomainProduct::try_new(
            ProductId::new(self.id),
            &self.name,
            self.price_cents,
            self.stock,
        )
        .map_err(|_| Status::internal("stored product violates domain rules"))?;
        Ok(Product {
            id: product.id().get(),
            name: product.name().into(),
            price_cents: product.price_cents(),
            stock: product.stock(),
        })
    }
}
fn database_error(error: sqlx::Error) -> Status {
    if let Some(db) = error.as_database_error()
        && matches!(db.code().as_deref(), Some("23505" | "23503"))
    {
        return Status::failed_precondition("product conflicts with stored data");
    }
    tracing::error!(%error, "catalog database failure");
    Status::internal("catalog database failure")
}
async fn bounded<T>(future: impl Future<Output = Result<T, sqlx::Error>>) -> Result<T, Status> {
    tokio::time::timeout(Duration::from_millis(700), future)
        .await
        .map_err(|_| Status::deadline_exceeded("catalog query budget exhausted"))?
        .map_err(database_error)
}
pub fn validate_draft(name: &str, price: i64, stock: i32) -> Result<NewProduct, Status> {
    NewProduct::try_new(name, price, stock).map_err(Status::invalid_argument)
}
pub fn validate_id(id: i64) -> Result<i64, Status> {
    if id <= 0 {
        return Err(Status::invalid_argument("id must be positive"));
    }
    Ok(id)
}
pub fn validate_page(limit: i64, offset: i64) -> Result<(), Status> {
    if !(1..=100).contains(&limit) || offset < 0 {
        return Err(Status::invalid_argument(
            "limit must be 1..100 and offset nonnegative",
        ));
    }
    Ok(())
}

#[tonic::async_trait]
impl Catalog for CatalogApi {
    async fn get_product(
        &self,
        request: Request<GetProductRequest>,
    ) -> Result<Response<Product>, Status> {
        let id = validate_id(request.into_inner().id)?;
        let row = bounded(sqlx::query_as::<_, Row>(
             "SELECT id,name,price_cents,stock FROM products WHERE id=$1 AND delisted_at IS NULL"
         ).bind(id).fetch_optional(&self.pool)).await?
             .ok_or_else(|| Status::not_found("product not found"))?;
        Ok(Response::new(row.wire()?))
    }
    async fn list_products(
        &self,
        request: Request<ListProductsRequest>,
    ) -> Result<Response<ListProductsResponse>, Status> {
        let page = request.into_inner();
        validate_page(page.limit, page.offset)?;
        // One repeatable-read snapshot keeps count and items coherent.
        let result = async {
            let mut tx = self.pool.begin().await?;
            sqlx::query("SET TRANSACTION ISOLATION LEVEL REPEATABLE READ READ ONLY")
                .execute(&mut *tx)
                .await?;
            let items = sqlx::query_as::<_, Row>(
                 "SELECT id,name,price_cents,stock FROM products WHERE delisted_at IS NULL ORDER BY created_at DESC,id DESC LIMIT $1 OFFSET $2"
             ).bind(page.limit).bind(page.offset).fetch_all(&mut *tx).await?;
            let total: i64 =
                sqlx::query_scalar("SELECT count(*) FROM products WHERE delisted_at IS NULL")
                    .fetch_one(&mut *tx)
                    .await?;
            tx.commit().await?;
            Ok::<_, sqlx::Error>((items, total))
        };
        let (rows, total) = bounded(result).await?;
        let items = rows.into_iter().map(Row::wire).collect::<Result<_, _>>()?;
        Ok(Response::new(ListProductsResponse { items, total }))
    }
    async fn create_product(
        &self,
        request: Request<CreateProductRequest>,
    ) -> Result<Response<Product>, Status> {
        let input = request.into_inner();
        let draft = validate_draft(&input.name, input.price_cents, input.stock)?;
        let row = bounded(sqlx::query_as::<_, Row>(
             "INSERT INTO products(name,price_cents,stock) VALUES($1,$2,$3) RETURNING id,name,price_cents,stock"
         ).bind(draft.name()).bind(draft.price_cents()).bind(draft.stock()).fetch_one(&self.pool)).await?;
        Ok(Response::new(row.wire()?))
    }
    async fn update_product(
        &self,
        request: Request<UpdateProductRequest>,
    ) -> Result<Response<Product>, Status> {
        let input = request.into_inner();
        validate_id(input.id)?;
        let draft = validate_draft(&input.name, input.price_cents, input.stock)?;
        let row = bounded(sqlx::query_as::<_, Row>(
             "UPDATE products SET name=$2,price_cents=$3,stock=$4,updated_at=now() WHERE id=$1 AND delisted_at IS NULL RETURNING id,name,price_cents,stock"
         ).bind(input.id).bind(draft.name()).bind(draft.price_cents()).bind(draft.stock()).fetch_optional(&self.pool)).await?
             .ok_or_else(|| Status::not_found("product not found"))?;
        Ok(Response::new(row.wire()?))
    }
    async fn delist_product(
        &self,
        request: Request<GetProductRequest>,
    ) -> Result<Response<DelistProductResponse>, Status> {
        let id = validate_id(request.into_inner().id)?;
        let result = bounded(sqlx::query(
             "UPDATE products SET delisted_at=now(),updated_at=now() WHERE id=$1 AND delisted_at IS NULL"
         ).bind(id).execute(&self.pool)).await?;
        if result.rows_affected() == 0 {
            return Err(Status::not_found("product not found"));
        }
        Ok(Response::new(DelistProductResponse {}))
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn ids_are_positive_at_the_protocol_boundary() {
        assert!(validate_id(1).is_ok());
        assert_eq!(
            validate_id(0).unwrap_err().code(),
            tonic::Code::InvalidArgument
        );
        assert!(validate_id(-1).is_err());
    }
    #[test]
    fn pagination_has_a_transport_boundary() {
        assert!(validate_page(100, 0).is_ok());
        assert!(validate_page(101, 0).is_err());
        assert!(validate_page(1, -1).is_err());
    }
    #[test]
    fn validation_reuses_the_book_domain() {
        assert_eq!(validate_draft(" 键盘 ", 19900, 10).unwrap().name(), "键盘");
        assert!(validate_draft(" ", 19900, 10).is_err());
        assert!(validate_draft("键盘", -1, 10).is_err());
        assert!(validate_draft("键盘", 19900, -1).is_err());
    }
}
