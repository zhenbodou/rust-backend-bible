use super::{
    ProductRepository, cached::CachedProductRepo, products::PgProductRepo,
    remote::RemoteProductRepo,
};
use common::error::DomainResult;
use common::ids::ProductId;
use common::product::{NewProduct, Product};

#[derive(Clone)]
pub enum SelectedProductRepo {
    Local(CachedProductRepo<PgProductRepo>),
    Remote(Box<RemoteProductRepo>),
}
impl ProductRepository for SelectedProductRepo {
    async fn insert(&self, draft: &NewProduct) -> DomainResult<Product> {
        match self {
            Self::Local(r) => r.insert(draft).await,
            Self::Remote(r) => r.insert(draft).await,
        }
    }
    async fn get(&self, id: ProductId) -> DomainResult<Product> {
        match self {
            Self::Local(r) => r.get(id).await,
            Self::Remote(r) => r.get(id).await,
        }
    }
    async fn list(&self, limit: i64, offset: i64) -> DomainResult<(Vec<Product>, i64)> {
        match self {
            Self::Local(r) => r.list(limit, offset).await,
            Self::Remote(r) => r.list(limit, offset).await,
        }
    }
    async fn update(&self, product: &Product) -> DomainResult<Product> {
        match self {
            Self::Local(r) => r.update(product).await,
            Self::Remote(r) => r.update(product).await,
        }
    }
    async fn delist(&self, id: ProductId) -> DomainResult<()> {
        match self {
            Self::Local(r) => r.delist(id).await,
            Self::Remote(r) => r.delist(id).await,
        }
    }
}
