use anyhow::Context;
use monolith::auth::jwt::JwtKeys;
use monolith::cache::{ProductCache, connect_redis};
use monolith::settings::Settings;
use monolith::state::AppState;
use monolith::{background, db, http, shutdown, telemetry};
use platform::{ShutdownBudget, migration_enabled};
use std::future::IntoFuture;
use std::time::Duration;
use tokio_util::sync::CancellationToken;

#[tokio::main]
async fn main() -> anyhow::Result<()> {
    dotenvy::dotenv().ok();
    let settings = Settings::load().context("load settings")?;
    telemetry::init(&settings.log).context("init logging")?;
    let run_migrations =
        migration_enabled(std::env::var("RUSTMALL_RUN_MIGRATIONS").ok().as_deref())?;
    let pool = db::connect(&settings.database)
        .await
        .context("connect database")?;
    if run_migrations {
        db::MIGRATOR.run(&pool).await.context("run migrations")?;
    }
    let jwt = JwtKeys::new(
        &settings.auth.jwt_secret,
        &settings.auth.issuer,
        settings.auth.access_token_ttl_secs,
    );
    let redis = connect_redis(&settings.redis).await;
    let cache = ProductCache::new(
        &settings.cache,
        redis,
        Duration::from_millis(settings.redis.op_timeout_ms),
    );
    let mut state = AppState::new(pool.clone(), jwt, cache);
    // Chapter 27: only enable this after the catalog cutover procedure.
    if let Ok(endpoint) = std::env::var("RUSTMALL_CATALOG_ENDPOINT") {
        let key = std::env::var("RUSTMALL_CATALOG_TOKEN").context("catalog token missing")?;
        state.use_remote_catalog(&endpoint, &key).await?;
    }
    let app = http::routes::router(state, &settings.cors);
    let listener = tokio::net::TcpListener::bind(settings.server.addr()).await?;
    let token = CancellationToken::new();
    tokio::spawn(shutdown::wait_for_signal(token.clone()));
    let mut cleaner = tokio::spawn(background::run_periodic(
        Duration::from_secs(60),
        token.clone(),
        || async { tracing::debug!("cart cleanup tick") },
    ));
    let server = axum::serve(listener, app)
        .with_graceful_shutdown(token.clone().cancelled_owned())
        .into_future();
    tokio::pin!(server);
    let (server_result, budget) = tokio::select! {
        result = &mut server => {
            token.cancel();
            (result.context("HTTP server failed"),
                ShutdownBudget::new(settings.server.shutdown_grace()))
        }
        () = token.cancelled() => {
            let budget = ShutdownBudget::new(settings.server.shutdown_grace());
            let result = budget.wait("HTTP", &mut server).await;
            let result = match result {
                Ok(result) => result.context("HTTP server failed"),
                Err(error) => {
                    cleaner.abort();
                    return Err(error);
                }
            };
            (result, budget)
        }
    };
    token.cancel();
    match budget.wait("background", &mut cleaner).await {
        Ok(result) => {
            result.context("background task failed")?;
        }
        Err(error) => {
            cleaner.abort();
            return Err(error);
        }
    }
    budget.wait("database", pool.close()).await?;
    server_result
}
