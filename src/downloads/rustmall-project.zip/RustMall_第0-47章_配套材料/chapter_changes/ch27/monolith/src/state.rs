use crate::auth::jwt::JwtKeys;
use crate::cache::ProductCache;
use crate::repo::{cached::CachedProductRepo, products::PgProductRepo, users::PgUserRepo};
use crate::repo::{remote::RemoteProductRepo, selected::SelectedProductRepo};
use crate::service::{auth::AuthService, products::ProductService};
use sqlx::PgPool;

pub type ProductRepo = SelectedProductRepo;
#[derive(Clone)]
pub struct AppState {
    pub pool: PgPool,
    catalog_health: Option<RemoteProductRepo>,
    pub products: ProductService<ProductRepo>,
    pub auth: AuthService<PgUserRepo>,
}
impl AppState {
    pub fn new(pool: PgPool, jwt: JwtKeys, cache: ProductCache) -> Self {
        let repo = CachedProductRepo::new(PgProductRepo::new(pool.clone()), cache);
        Self {
            catalog_health: None,
            products: ProductService::new(SelectedProductRepo::Local(repo)),
            auth: AuthService::new(PgUserRepo::new(pool.clone()), jwt),
            pool,
        }
    }
    pub async fn catalog_is_ready(&self) -> bool {
        match &self.catalog_health {
            Some(repo) => repo.is_ready().await,
            None => true,
        }
    }
    pub async fn use_remote_catalog(&mut self, endpoint: &str, key: &str) -> anyhow::Result<()> {
        let repo = RemoteProductRepo::connect(endpoint, key).await?;
        self.catalog_health = Some(repo.clone());
        self.products = ProductService::new(SelectedProductRepo::Remote(Box::new(repo)));
        Ok(())
    }
}
