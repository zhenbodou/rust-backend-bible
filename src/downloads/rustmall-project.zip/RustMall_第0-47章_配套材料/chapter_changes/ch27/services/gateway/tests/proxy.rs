use axum::{
    Router,
    body::{Body, to_bytes},
    extract::Request,
    http::{HeaderValue, StatusCode},
    response::IntoResponse,
};
use tower::ServiceExt;
async fn upstream() -> (String, tokio::task::JoinHandle<()>) {
    let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
    let addr = listener.local_addr().unwrap();
    let app = Router::new().fallback(|request: Request| async move {
        if request.uri().path() == "/api/v1/redirect" {
            let mut response = StatusCode::FOUND.into_response();
            response.headers_mut().insert(
                "location",
                HeaderValue::from_static("http://127.0.0.1:1/should-not-follow"),
            );
            return response;
        }
        let value = serde_json::json!({"path":request.uri().path(),"query":request.uri().query(),
            "authorization":request.headers().get("authorization").and_then(|v|v.to_str().ok()),
            "forged_role":request.headers().contains_key("x-user-role"),
            "request_id":request.headers().get("x-request-id").and_then(|v|v.to_str().ok())});
        axum::Json(value).into_response()
    });
    let task = tokio::spawn(async move {
        axum::serve(listener, app).await.unwrap();
    });
    (format!("http://{addr}"), task)
}
#[tokio::test]
async fn forwarding_keeps_api_path_query_and_bearer_but_drops_forged_role() {
    let (url, task) = upstream().await;
    let app = gateway::Gateway::new(&url).unwrap().router();
    let request = axum::http::Request::get("/api/v1/products?x=one%20two")
        .header("authorization", "Bearer test-only")
        .header("x-user-role", "admin")
        .header("x-request-id", "untrusted")
        .body(Body::empty())
        .unwrap();
    let response = app.oneshot(request).await.unwrap();
    assert_eq!(response.status(), StatusCode::OK);
    let id = response.headers()["x-request-id"]
        .to_str()
        .unwrap()
        .to_owned();
    let bytes = to_bytes(response.into_body(), 1024 * 1024).await.unwrap();
    let value: serde_json::Value = serde_json::from_slice(&bytes).unwrap();
    assert_eq!(value["path"], "/api/v1/products");
    assert_eq!(value["query"], "x=one%20two");
    assert_eq!(value["authorization"], "Bearer test-only");
    assert_eq!(value["forged_role"], false);
    assert_eq!(value["request_id"], id);
    assert_ne!(id, "untrusted");
    task.abort();
}
#[tokio::test]
async fn redirects_are_rejected_without_following_the_target() {
    let (url, task) = upstream().await;
    let response = gateway::Gateway::new(&url)
        .unwrap()
        .router()
        .oneshot(
            axum::http::Request::get("/api/v1/redirect")
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();
    assert_eq!(response.status(), StatusCode::BAD_GATEWAY);
    task.abort();
}
#[tokio::test]
async fn oversized_request_is_rejected_before_forwarding() {
    let response = gateway::Gateway::new("http://127.0.0.1:1")
        .unwrap()
        .router()
        .oneshot(
            axum::http::Request::post("/api/v1/products")
                .body(Body::from(vec![0; 64 * 1024 + 1]))
                .unwrap(),
        )
        .await
        .unwrap();
    assert_eq!(response.status(), StatusCode::PAYLOAD_TOO_LARGE);
}
