use axum::{
    Router,
    body::{Body, to_bytes},
    extract::{Request, State},
    http::{HeaderMap, HeaderName, HeaderValue, StatusCode},
    response::{IntoResponse, Response},
    routing::get,
};
use reqwest::{Client, Url};
use std::{sync::Arc, time::Duration};
use uuid::Uuid;

const REQUEST_LIMIT: usize = 64 * 1024;
const RESPONSE_LIMIT: usize = 2 * 1024 * 1024;
#[derive(Clone)]
pub struct Gateway {
    client: Client,
    upstream: Url,
    permits: Arc<tokio::sync::Semaphore>,
}
impl Gateway {
    pub fn new(upstream: &str) -> anyhow::Result<Self> {
        let upstream = Url::parse(upstream)?;
        anyhow::ensure!(
            matches!(upstream.scheme(), "http" | "https"),
            "HTTP upstream required"
        );
        anyhow::ensure!(
            upstream.host_str().is_some()
                && upstream.username().is_empty()
                && upstream.password().is_none(),
            "upstream must have a host and no credentials"
        );
        anyhow::ensure!(
            upstream.path() == "/" && upstream.query().is_none() && upstream.fragment().is_none(),
            "upstream must be an origin, without path/query/fragment"
        );
        let client = Client::builder()
            .no_proxy()
            .redirect(reqwest::redirect::Policy::none())
            .connect_timeout(Duration::from_secs(1))
            .timeout(Duration::from_secs(3))
            .build()?;
        Ok(Self {
            client,
            upstream,
            permits: Arc::new(tokio::sync::Semaphore::new(32)),
        })
    }
    pub fn router(self) -> Router {
        Router::new()
            .route("/health/live", get(|| async { StatusCode::OK }))
            .route("/health/ready", get(ready))
            .fallback(forward)
            .with_state(self)
    }
}
pub fn filtered_headers(source: &HeaderMap) -> HeaderMap {
    let mut result = source.clone();
    for value in source.get_all("connection") {
        if let Ok(text) = value.to_str() {
            for token in text.split(',').map(str::trim) {
                if let Ok(name) = HeaderName::from_bytes(token.as_bytes()) {
                    result.remove(name);
                }
            }
        }
    }
    for name in [
        "connection",
        "proxy-connection",
        "keep-alive",
        "transfer-encoding",
        "te",
        "trailer",
        "upgrade",
        "proxy-authenticate",
        "proxy-authorization",
        "host",
        "content-length",
        "forwarded",
        "x-user-id",
        "x-user-role",
        "x-rustmall-service-token",
        "x-request-id",
    ] {
        result.remove(name);
    }
    let untrusted: Vec<_> = result
        .keys()
        .filter(|name| {
            name.as_str().starts_with("x-forwarded-") || name.as_str().starts_with("x-internal-")
        })
        .cloned()
        .collect();
    for name in untrusted {
        result.remove(name);
    }
    result
}
async fn ready(State(state): State<Gateway>) -> StatusCode {
    let mut target = state.upstream.clone();
    target.set_path("/health/ready");
    match state.client.get(target).send().await {
        Ok(response) if response.status() == StatusCode::OK => StatusCode::OK,
        _ => StatusCode::SERVICE_UNAVAILABLE,
    }
}
fn failure(status: StatusCode, id: &str) -> Response {
    let code = match status {
        StatusCode::NOT_FOUND => "NOT_FOUND",
        StatusCode::PAYLOAD_TOO_LARGE => "PAYLOAD_TOO_LARGE",
        StatusCode::REQUEST_TIMEOUT => "REQUEST_TIMEOUT",
        StatusCode::GATEWAY_TIMEOUT => "GATEWAY_TIMEOUT",
        StatusCode::BAD_REQUEST => "BAD_REQUEST",
        StatusCode::SERVICE_UNAVAILABLE => "UNAVAILABLE",
        _ => "BAD_GATEWAY",
    };
    let mut response = (
        status,
        axum::Json(serde_json::json!({"code":code,"message":"网关暂时无法处理请求"})),
    )
        .into_response();
    response.headers_mut().insert(
        "x-request-id",
        HeaderValue::from_str(id).expect("UUID header"),
    );
    response
}
async fn forward(State(state): State<Gateway>, request: Request) -> Response {
    let id = Uuid::new_v4().to_string();
    if !request.uri().path().starts_with("/api/v1/") {
        return failure(StatusCode::NOT_FOUND, &id);
    }
    let _permit = match state.permits.clone().try_acquire_owned() {
        Ok(permit) => permit,
        Err(_) => return failure(StatusCode::SERVICE_UNAVAILABLE, &id),
    };
    let (parts, body) = request.into_parts();
    let body =
        match tokio::time::timeout(Duration::from_secs(5), to_bytes(body, REQUEST_LIMIT)).await {
            Ok(Ok(body)) => body,
            Ok(Err(_)) => return failure(StatusCode::PAYLOAD_TOO_LARGE, &id),
            Err(_) => return failure(StatusCode::REQUEST_TIMEOUT, &id),
        };
    let mut target = state.upstream.clone();
    target.set_path(parts.uri.path());
    target.set_query(parts.uri.query());
    if !target.path().starts_with("/api/v1/") {
        return failure(StatusCode::BAD_REQUEST, &id);
    }
    let mut headers = filtered_headers(&parts.headers);
    headers.insert(
        "x-request-id",
        HeaderValue::from_str(&id).expect("UUID header"),
    );
    let mut upstream = match state
        .client
        .request(parts.method, target)
        .headers(headers)
        .body(body)
        .send()
        .await
    {
        Ok(response) => response,
        Err(error) => {
            return failure(
                if error.is_timeout() {
                    StatusCode::GATEWAY_TIMEOUT
                } else {
                    StatusCode::BAD_GATEWAY
                },
                &id,
            );
        }
    };
    if upstream.status().is_redirection() {
        return failure(StatusCode::BAD_GATEWAY, &id);
    }
    let status = upstream.status();
    let mut headers = filtered_headers(upstream.headers());
    headers.insert(
        "x-request-id",
        HeaderValue::from_str(&id).expect("UUID header"),
    );
    let mut bytes = Vec::new();
    loop {
        match upstream.chunk().await {
            Ok(Some(chunk)) if bytes.len() + chunk.len() <= RESPONSE_LIMIT => {
                bytes.extend_from_slice(&chunk)
            }
            Ok(Some(_)) => return failure(StatusCode::BAD_GATEWAY, &id),
            Ok(None) => break,
            Err(error) => {
                return failure(
                    if error.is_timeout() {
                        StatusCode::GATEWAY_TIMEOUT
                    } else {
                        StatusCode::BAD_GATEWAY
                    },
                    &id,
                );
            }
        }
    }
    let mut response = Response::new(Body::from(bytes));
    *response.status_mut() = status;
    *response.headers_mut() = headers;
    response
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn connection_named_headers_and_forged_identity_are_removed() {
        let mut input = HeaderMap::new();
        input.insert("connection", "x-private, upgrade".parse().unwrap());
        input.insert("x-private", "secret".parse().unwrap());
        input.insert("x-user-role", "admin".parse().unwrap());
        input.insert("authorization", "Bearer test-only".parse().unwrap());
        let output = filtered_headers(&input);
        assert!(!output.contains_key("x-private"));
        assert!(!output.contains_key("x-user-role"));
        assert!(output.contains_key("authorization"));
    }
    #[test]
    fn response_cookie_values_survive_filtering() {
        let mut input = HeaderMap::new();
        input.append("set-cookie", "a=1".parse().unwrap());
        input.append("set-cookie", "b=2".parse().unwrap());
        assert_eq!(
            filtered_headers(&input)
                .get_all("set-cookie")
                .iter()
                .count(),
            2
        );
    }
    #[test]
    fn upstream_is_a_fixed_origin() {
        assert!(Gateway::new("http://user:password@localhost:8080").is_err());
        assert!(Gateway::new("http://localhost:8080/api").is_err());
        assert!(Gateway::new("file:///tmp/input").is_err());
    }
}
