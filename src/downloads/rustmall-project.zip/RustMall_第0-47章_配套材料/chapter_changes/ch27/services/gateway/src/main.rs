use platform::ShutdownBudget;
use std::{future::IntoFuture, time::Duration};
async fn signal() {
    #[cfg(unix)]
    {
        let mut term = tokio::signal::unix::signal(tokio::signal::unix::SignalKind::terminate())
            .expect("SIGTERM handler");
        tokio::select! {_=term.recv()=>{},_=tokio::signal::ctrl_c()=>{}}
    }
    #[cfg(not(unix))]
    {
        tokio::signal::ctrl_c().await.expect("ctrl-c handler");
    }
}
#[tokio::main]
async fn main() -> anyhow::Result<()> {
    let upstream =
        std::env::var("GATEWAY_UPSTREAM").unwrap_or_else(|_| "http://127.0.0.1:8080".into());
    let addr = std::env::var("GATEWAY_ADDR").unwrap_or_else(|_| "127.0.0.1:8081".into());
    let listener = tokio::net::TcpListener::bind(addr).await?;
    let (send, receive) = tokio::sync::oneshot::channel::<()>();
    let server = axum::serve(listener, gateway::Gateway::new(&upstream)?.router())
        .with_graceful_shutdown(async {
            let _ = receive.await;
        })
        .into_future();
    tokio::pin!(server);
    tokio::select! {
        result=&mut server=>result?,
        ()=signal()=>{
            let _=send.send(());
            ShutdownBudget::new(Duration::from_secs(20)).wait("gateway HTTP",&mut server).await??;
        }
    }
    Ok(())
}
