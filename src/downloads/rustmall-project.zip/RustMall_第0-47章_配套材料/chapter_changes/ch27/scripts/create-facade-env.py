"""独立接口层实验配置；商品连接信息从第26章配置显式加载。"""
import os
import secrets

password = secrets.token_urlsafe(36)
values = {
    "POSTGRES_PASSWORD": password,
    "DATABASE_URL": f"postgres://rustmall:{password}@127.0.0.1:55434/rustmall_identity",
    "APP_ENV": "production",
    "APP_AUTH__JWT_SECRET": secrets.token_urlsafe(48),
    "APP_SERVER__HOST": "127.0.0.1",
    "APP_SERVER__PORT": "8080",
    "APP_REDIS__URL": "",
    "RUSTMALL_RUN_MIGRATIONS": "false",
}
fd = os.open(".env.facade.local", os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
with os.fdopen(fd, "w") as output:
    for key, value in values.items():
        output.write(f"{key}={value}\n")
print("已生成 .env.facade.local；未输出秘密。")
