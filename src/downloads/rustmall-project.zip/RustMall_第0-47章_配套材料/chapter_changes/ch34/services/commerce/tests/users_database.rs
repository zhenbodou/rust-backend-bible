use axum::{
    Router,
    body::Body,
    http::{Request, StatusCode},
};
use commerce::{
    runtime::bounded,
    users::{self, Users},
};
use http_body_util::BodyExt;
use serde_json::{Value, json};
use sqlx::PgPool;
use std::sync::Arc;
use tower::ServiceExt;
use uuid::Uuid;

const KEY: &str = "chapter34-test-key-that-is-not-a-real-service-secret";
async fn state(pool: &PgPool) -> Users {
    let redis = redis::Client::open(std::env::var("REDIS_URL").expect("isolated Redis required"))
        .unwrap()
        .get_connection_manager()
        .await
        .unwrap();
    Users {
        pool: pool.clone(),
        redis,
        key: Arc::new(KEY.into()),
        hashes: Arc::new(tokio::sync::Semaphore::new(4)),
        dummy: Arc::new(users::hash("not-a-user-password".into()).await.unwrap()),
    }
}
fn credentials() -> Value {
    json!({"username":format!("u_{}", &Uuid::new_v4().simple().to_string()[..12]),"password":"password-for-ch34-tests"})
}
async fn call(
    app: &Router,
    path: &str,
    method: &str,
    body: Option<&Value>,
    token: Option<&str>,
) -> (StatusCode, Value) {
    let mut req = Request::builder()
        .method(method)
        .uri(path)
        .header("content-type", "application/json");
    if let Some(token) = token {
        req = req.header("authorization", format!("Bearer {token}"));
    }
    let response = app
        .clone()
        .oneshot(
            req.body(
                body.map(|b| Body::from(b.to_string()))
                    .unwrap_or_else(Body::empty),
            )
            .unwrap(),
        )
        .await
        .unwrap();
    let status = response.status();
    assert_eq!(response.headers()["cache-control"], "no-store");
    assert!(response.headers().contains_key("x-request-id"));
    let bytes = response.into_body().collect().await.unwrap().to_bytes();
    (
        status,
        if bytes.is_empty() {
            Value::Null
        } else {
            serde_json::from_slice(&bytes).unwrap()
        },
    )
}
async fn token(app: &Router, c: &Value) -> String {
    assert_eq!(
        call(app, "/api/v1/auth/register", "POST", Some(c), None)
            .await
            .0,
        StatusCode::CREATED
    );
    let (status, reply) = call(app, "/api/v1/auth/login", "POST", Some(c), None).await;
    assert_eq!(status, StatusCode::OK);
    reply["access_token"].as_str().unwrap().to_owned()
}

#[sqlx::test(migrations = "./migrations/users")]
async fn normalized_registration_login_and_persisted_session(pool: PgPool) {
    let s = state(&pool).await;
    let app = bounded(users::router(s));
    let c = json!({"username":"  Alice_01  ","password":"password-for-ch34-tests"});
    let t = token(&app, &c).await;
    let (name, hash): (String, String) = sqlx::query_as("SELECT username,password_hash FROM users")
        .fetch_one(&pool)
        .await
        .unwrap();
    assert_eq!(name, "alice_01");
    assert!(hash.starts_with("$argon2id$"));
    assert_ne!(hash, c["password"]);
    let decoded = jsonwebtoken::decode::<Value>(
        &t,
        &jsonwebtoken::DecodingKey::from_secret(KEY.as_bytes()),
        &{
            let mut v = jsonwebtoken::Validation::default();
            v.set_audience(&["rustmall-api"]);
            v
        },
    )
    .unwrap()
    .claims;
    assert!(decoded["sub"].is_string());
    assert_eq!(decoded["iss"], "rustmall-users");
    let count: i64 = sqlx::query_scalar("SELECT count(*) FROM sessions WHERE revoked_at IS NULL")
        .fetch_one(&pool)
        .await
        .unwrap();
    assert_eq!(count, 1);
    let (status, id) = call(&app, "/api/v1/auth/me", "GET", None, Some(&t)).await;
    assert_eq!(status, StatusCode::OK);
    assert_eq!(id["role"], "user");
    assert_eq!(
        call(&app, "/api/v1/users/me", "GET", None, Some(&t))
            .await
            .1,
        id
    );
}

#[sqlx::test(migrations = "./migrations/users")]
async fn duplicate_name_and_self_selected_role_are_rejected(pool: PgPool) {
    let app = bounded(users::router(state(&pool).await));
    let mut c = credentials();
    assert_eq!(
        call(&app, "/api/v1/auth/register", "POST", Some(&c), None)
            .await
            .0,
        StatusCode::CREATED
    );
    c["username"] = json!(c["username"].as_str().unwrap().to_uppercase());
    assert_eq!(
        call(&app, "/api/v1/auth/register", "POST", Some(&c), None)
            .await
            .0,
        StatusCode::CONFLICT
    );
    let mut forged = credentials();
    forged["role"] = json!("admin");
    assert_eq!(
        call(&app, "/api/v1/auth/register", "POST", Some(&forged), None)
            .await
            .0,
        StatusCode::UNPROCESSABLE_ENTITY
    );
    let count: i64 = sqlx::query_scalar("SELECT count(*) FROM users")
        .fetch_one(&pool)
        .await
        .unwrap();
    assert_eq!(count, 1);
}

#[sqlx::test(migrations = "./migrations/users")]
async fn new_password_policy_and_legacy_login_are_distinct(pool: PgPool) {
    let app = bounded(users::router(state(&pool).await));
    let mut c = credentials();
    c["password"] = json!("oldpass8");
    assert_eq!(
        call(&app, "/api/v1/auth/register", "POST", Some(&c), None)
            .await
            .0,
        StatusCode::BAD_REQUEST
    );
    let hash = users::hash("oldpass8".into()).await.unwrap();
    sqlx::query("INSERT INTO users(username,password_hash) VALUES($1,$2)")
        .bind(c["username"].as_str().unwrap())
        .bind(hash)
        .execute(&pool)
        .await
        .unwrap();
    assert_eq!(
        call(&app, "/api/v1/auth/login", "POST", Some(&c), None)
            .await
            .0,
        StatusCode::OK
    );
    c["password"] = json!("汉".repeat(43));
    assert_eq!(
        call(&app, "/api/v1/auth/register", "POST", Some(&c), None)
            .await
            .0,
        StatusCode::BAD_REQUEST
    );
}

#[sqlx::test(migrations = "./migrations/users")]
async fn unknown_user_and_wrong_password_have_same_error(pool: PgPool) {
    let app = bounded(users::router(state(&pool).await));
    let mut c = credentials();
    let _ = token(&app, &c).await;
    c["password"] = json!("incorrect-password");
    let wrong = call(&app, "/api/v1/auth/login", "POST", Some(&c), None).await;
    let unknown = call(
        &app,
        "/api/v1/auth/login",
        "POST",
        Some(&credentials()),
        None,
    )
    .await;
    assert_eq!(wrong.0, StatusCode::UNAUTHORIZED);
    assert_eq!(wrong, unknown);
}

#[sqlx::test(migrations = "./migrations/users")]
async fn login_counter_has_expiry_and_enforces_limit(pool: PgPool) {
    let s = state(&pool).await;
    let mut redis = s.redis.clone();
    let app = bounded(users::router(s));
    let c = credentials();
    for _ in 0..10 {
        assert_eq!(
            call(&app, "/api/v1/auth/login", "POST", Some(&c), None)
                .await
                .0,
            StatusCode::UNAUTHORIZED
        );
    }
    assert_eq!(
        call(&app, "/api/v1/auth/login", "POST", Some(&c), None)
            .await
            .0,
        StatusCode::TOO_MANY_REQUESTS
    );
    let ttl: i64 = redis::cmd("TTL")
        .arg(format!(
            "users:v1:login:{}",
            c["username"].as_str().unwrap()
        ))
        .query_async(&mut redis)
        .await
        .unwrap();
    assert!((1..=60).contains(&ttl));
}

#[sqlx::test(migrations = "./migrations/users")]
async fn repeated_logout_is_successful_and_db_revocation_survives_key_loss(pool: PgPool) {
    let s = state(&pool).await;
    let mut redis = s.redis.clone();
    let app = bounded(users::router(s));
    let t = token(&app, &credentials()).await;
    for _ in 0..2 {
        assert_eq!(
            call(&app, "/api/v1/auth/logout", "POST", None, Some(&t))
                .await
                .0,
            StatusCode::NO_CONTENT
        );
    }
    assert_eq!(
        call(&app, "/api/v1/auth/me", "GET", None, Some(&t)).await.0,
        StatusCode::UNAUTHORIZED
    );
    let jti: Uuid = sqlx::query_scalar("SELECT jti FROM sessions")
        .fetch_one(&pool)
        .await
        .unwrap();
    let key = format!("users:v1:revoked:{jti}");
    let ttl: i64 = redis::cmd("TTL")
        .arg(&key)
        .query_async(&mut redis)
        .await
        .unwrap();
    assert!((1..=3600).contains(&ttl));
    let _: i64 = redis::cmd("DEL")
        .arg(key)
        .query_async(&mut redis)
        .await
        .unwrap();
    assert_eq!(
        call(&app, "/api/v1/auth/me", "GET", None, Some(&t)).await.0,
        StatusCode::UNAUTHORIZED
    );
    assert_eq!(
        call(&app, "/api/v1/auth/logout", "POST", None, Some(&t))
            .await
            .0,
        StatusCode::NO_CONTENT
    );
}

#[sqlx::test(migrations = "./migrations/users")]
async fn current_role_and_session_expiry_are_authoritative(pool: PgPool) {
    let app = bounded(users::router(state(&pool).await));
    let t = token(&app, &credentials()).await;
    for role in ["admin", "user"] {
        sqlx::query("UPDATE users SET role=$1")
            .bind(role)
            .execute(&pool)
            .await
            .unwrap();
        assert_eq!(
            call(&app, "/api/v1/auth/me", "GET", None, Some(&t)).await.1["role"],
            role
        );
    }
    sqlx::query("UPDATE sessions SET expires_at=now()-interval '1 second'")
        .execute(&pool)
        .await
        .unwrap();
    assert_eq!(
        call(&app, "/api/v1/auth/me", "GET", None, Some(&t)).await.0,
        StatusCode::UNAUTHORIZED
    );
}

#[sqlx::test(migrations = "./migrations/users")]
async fn signed_but_unissued_expired_or_wrong_scope_tokens_are_rejected(pool: PgPool) {
    let app = bounded(users::router(state(&pool).await));
    let now = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .unwrap()
        .as_secs();
    let issued = token(&app, &credentials()).await;
    assert_eq!(
        call(&app, "/api/v1/auth/me", "GET", None, Some(&issued))
            .await
            .0,
        StatusCode::OK
    );
    let (id, jti): (i64, Uuid) = sqlx::query_as("SELECT user_id,jti FROM sessions")
        .fetch_one(&pool)
        .await
        .unwrap();
    let original = json!({"sub":id.to_string(),"jti":jti,"exp":now+3600,"iss":"rustmall-users","aud":"rustmall-api"});
    let mut unissued = original.clone();
    unissued["jti"] = json!(Uuid::new_v4());
    let mut cases = vec![unissued];
    for (key, value) in [
        ("exp", json!(now - 10)),
        ("iss", json!("old-monolith")),
        ("aud", json!("other-api")),
        ("sub", json!("0")),
        ("jti", json!(Uuid::nil())),
    ] {
        let mut c = original.clone();
        c[key] = value;
        cases.push(c);
    }
    for (algorithm, key) in [
        (jsonwebtoken::Algorithm::HS384, KEY.as_bytes()),
        (jsonwebtoken::Algorithm::HS256, b"wrong-key".as_slice()),
    ] {
        let invalid = jsonwebtoken::encode(
            &jsonwebtoken::Header::new(algorithm),
            &original,
            &jsonwebtoken::EncodingKey::from_secret(key),
        )
        .unwrap();
        assert_eq!(
            call(&app, "/api/v1/auth/me", "GET", None, Some(&invalid))
                .await
                .0,
            StatusCode::UNAUTHORIZED
        );
    }
    for c in cases {
        let t = jsonwebtoken::encode(
            &jsonwebtoken::Header::default(),
            &c,
            &jsonwebtoken::EncodingKey::from_secret(KEY.as_bytes()),
        )
        .unwrap();
        assert_eq!(
            call(&app, "/api/v1/auth/me", "GET", None, Some(&t)).await.0,
            StatusCode::UNAUTHORIZED
        );
    }
}

#[sqlx::test(migrations = "./migrations/users")]
async fn hashing_capacity_rejects_before_creating_a_user(pool: PgPool) {
    let mut s = state(&pool).await;
    s.hashes = Arc::new(tokio::sync::Semaphore::new(0));
    let app = bounded(users::router(s));
    assert_eq!(
        call(
            &app,
            "/api/v1/auth/register",
            "POST",
            Some(&credentials()),
            None
        )
        .await
        .0,
        StatusCode::TOO_MANY_REQUESTS
    );
    let count: i64 = sqlx::query_scalar("SELECT count(*) FROM users")
        .fetch_one(&pool)
        .await
        .unwrap();
    assert_eq!(count, 0);
}

#[sqlx::test(migrations = "./migrations/users")]
async fn body_contract_and_duplicate_bearer_are_preserved(pool: PgPool) {
    let app = bounded(users::router(state(&pool).await));
    for (body, media, status) in [
        ("{", Some("application/json"), 400),
        ("{}", None, 415),
        (&"x".repeat(5000), Some("application/json"), 413),
    ] {
        let mut req = Request::builder()
            .method("POST")
            .uri("/api/v1/auth/register");
        if let Some(media) = media {
            req = req.header("content-type", media);
        }
        let response = app
            .clone()
            .oneshot(req.body(Body::from(body.to_owned())).unwrap())
            .await
            .unwrap();
        assert_eq!(response.status().as_u16(), status);
    }
    let mut req = Request::builder()
        .uri("/api/v1/auth/me")
        .body(Body::empty())
        .unwrap();
    req.headers_mut()
        .append("authorization", "Bearer a".parse().unwrap());
    req.headers_mut()
        .append("authorization", "Bearer b".parse().unwrap());
    assert_eq!(
        app.oneshot(req).await.unwrap().status(),
        StatusCode::UNAUTHORIZED
    );
}
