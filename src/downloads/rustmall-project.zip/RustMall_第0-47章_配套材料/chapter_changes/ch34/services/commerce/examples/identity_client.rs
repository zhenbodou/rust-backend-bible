use axum::http::HeaderMap;
use commerce::users::UserRemote;

#[tokio::main]
async fn main() -> anyhow::Result<()> {
    let base = std::env::var("USERS_BASE_URL").unwrap_or_else(|_| "http://127.0.0.1:8082".into());
    let token = std::env::var("ACCESS_TOKEN")?;
    let mut headers = HeaderMap::new();
    headers.insert("authorization", format!("Bearer {token}").parse()?);
    let identity = UserRemote::new(&base)?
        .identity(&headers)
        .await
        .map_err(|error| anyhow::anyhow!("users rejected request: {}", error.0))?;
    println!("{} {}", identity.id, identity.role);
    Ok(())
}
