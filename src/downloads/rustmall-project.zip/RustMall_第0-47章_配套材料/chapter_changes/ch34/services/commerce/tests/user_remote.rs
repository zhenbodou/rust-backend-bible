use axum::{
    Router,
    body::Body,
    http::{HeaderMap, StatusCode},
    routing::get,
};
use commerce::users::UserRemote;
use tokio_util::sync::CancellationToken;

async fn server(app: Router) -> (String, CancellationToken, tokio::task::JoinHandle<()>) {
    let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
    let base = format!("http://{}", listener.local_addr().unwrap());
    let stop = CancellationToken::new();
    let cancel = stop.clone();
    let task = tokio::spawn(async move {
        axum::serve(listener, app)
            .with_graceful_shutdown(cancel.cancelled_owned())
            .await
            .unwrap();
    });
    (base, stop, task)
}
fn headers() -> HeaderMap {
    let mut h = HeaderMap::new();
    h.insert("authorization", "Bearer test-only-token".parse().unwrap());
    h
}
async fn close(stop: CancellationToken, mut task: tokio::task::JoinHandle<()>) {
    stop.cancel();
    match tokio::time::timeout(std::time::Duration::from_secs(3), &mut task).await {
        Ok(result) => result.unwrap(),
        Err(_) => {
            task.abort();
            let _ = task.await;
            panic!("test server shutdown exceeded budget");
        }
    }
}
#[tokio::test]
async fn identity_comes_from_remote_not_forged_headers() {
    let (base, stop, task) = server(Router::new().route(
        "/api/v1/auth/me",
        get(|| async { axum::Json(serde_json::json!({"id":7,"role":"user"})) }),
    ))
    .await;
    let mut h = headers();
    h.insert("x-user-role", "admin".parse().unwrap());
    h.insert("x-user-id", "999".parse().unwrap());
    let id = UserRemote::new(&base).unwrap().identity(&h).await.unwrap();
    assert_eq!((id.id, id.role.as_str()), (7, "user"));
    close(stop, task).await;
}
#[tokio::test]
async fn invalid_identity_and_oversized_reply_are_unavailable() {
    for text in [
        r#"{"id":0,"role":"admin"}"#.to_owned(),
        r#"{"id":7,"role":"root"}"#.to_owned(),
        "x".repeat(4097),
    ] {
        let (base, stop, task) = server(Router::new().route(
            "/api/v1/auth/me",
            get(move || {
                let text = text.clone();
                async move { text }
            }),
        ))
        .await;
        assert_eq!(
            UserRemote::new(&base)
                .unwrap()
                .identity(&headers())
                .await
                .unwrap_err()
                .0,
            StatusCode::SERVICE_UNAVAILABLE
        );
        close(stop, task).await;
    }
}
#[tokio::test]
async fn unauthorized_is_distinct_from_dependency_failure() {
    for status in [StatusCode::UNAUTHORIZED, StatusCode::SERVICE_UNAVAILABLE] {
        let (base, stop, task) =
            server(Router::new().route("/api/v1/auth/me", get(move || async move { status })))
                .await;
        assert_eq!(
            UserRemote::new(&base)
                .unwrap()
                .identity(&headers())
                .await
                .unwrap_err()
                .0,
            status
        );
        close(stop, task).await;
    }
}
#[tokio::test]
async fn redirect_cannot_move_bearer_to_another_destination() {
    let (base, stop, task) = server(Router::new().route(
        "/api/v1/auth/me",
        get(|| async { axum::response::Redirect::temporary("http://127.0.0.1:1/steal") }),
    ))
    .await;
    assert_eq!(
        UserRemote::new(&base)
            .unwrap()
            .identity(&headers())
            .await
            .unwrap_err()
            .0,
        StatusCode::SERVICE_UNAVAILABLE
    );
    close(stop, task).await;
}
#[tokio::test]
async fn stalled_response_body_is_bounded() {
    let (base, stop, task) = server(Router::new().route(
        "/api/v1/auth/me",
        get(|| async {
            let stream =
                futures_util::stream::pending::<Result<axum::body::Bytes, std::io::Error>>();
            axum::http::Response::new(Body::from_stream(stream))
        }),
    ))
    .await;
    let start = std::time::Instant::now();
    assert_eq!(
        UserRemote::new(&base)
            .unwrap()
            .identity(&headers())
            .await
            .unwrap_err()
            .0,
        StatusCode::SERVICE_UNAVAILABLE
    );
    assert!(start.elapsed() < std::time::Duration::from_secs(3));
    close(stop, task).await;
}
#[test]
fn base_url_does_not_accept_paths_or_embedded_credentials() {
    for base in [
        "file:///tmp/users",
        "http://name:secret@localhost:8082",
        "http://localhost:8082/path",
        "http://localhost:8082?token=secret",
    ] {
        assert!(UserRemote::new(base).is_err());
    }
}
