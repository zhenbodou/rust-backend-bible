use axum::{
    Json, Router,
    http::{HeaderMap, StatusCode},
    response::{IntoResponse, Response},
};
use serde_json::json;
use sqlx::{PgPool, postgres::PgPoolOptions};
use std::{sync::Arc, time::Duration};
use tokio::sync::Semaphore;
use tokio_util::sync::CancellationToken;

#[derive(Debug)]
pub struct ApiError(pub StatusCode, pub &'static str);
impl IntoResponse for ApiError {
    fn into_response(self) -> Response {
        {
            let code = match self.0.as_u16() {
                400 | 422 => "INVALID_INPUT",
                401 => "UNAUTHORIZED",
                403 => "FORBIDDEN",
                404 => "NOT_FOUND",
                409 => "CONFLICT",
                413 => "PAYLOAD_TOO_LARGE",
                415 => "UNSUPPORTED_MEDIA_TYPE",
                429 => "RESOURCE_EXHAUSTED",
                503 => "UNAVAILABLE",
                504 => "DEADLINE_EXCEEDED",
                _ => "INTERNAL",
            };
            (self.0, Json(json!({"code":code,"message":self.1}))).into_response()
        }
    }
}
impl From<sqlx::Error> for ApiError {
    fn from(error: sqlx::Error) -> Self {
        tracing::error!(%error,"database operation failed");
        Self(StatusCode::SERVICE_UNAVAILABLE, "database unavailable")
    }
}
pub type ApiResult<T> = Result<T, ApiError>;
pub fn invalid() -> ApiError {
    ApiError(StatusCode::BAD_REQUEST, "invalid input")
}
pub fn unauthorized() -> ApiError {
    ApiError(StatusCode::UNAUTHORIZED, "authentication required")
}
pub fn unavailable() -> ApiError {
    ApiError(
        StatusCode::SERVICE_UNAVAILABLE,
        "dependency unavailable; retry with same identity",
    )
}
pub fn bearer(h: &HeaderMap) -> ApiResult<&str> {
    if h.get_all("authorization").iter().count() != 1 {
        return Err(unauthorized());
    }
    h.get("authorization")
        .and_then(|s| s.to_str().ok())
        .and_then(|s| s.split_once(' '))
        .filter(|(scheme, _)| scheme.eq_ignore_ascii_case("Bearer"))
        .map(|(_, s)| s.trim())
        .filter(|s| !s.is_empty() && s.len() < 4096)
        .ok_or_else(unauthorized)
}
pub fn env(name: &str) -> anyhow::Result<String> {
    Ok(std::env::var(name)?)
}
pub async fn pool() -> anyhow::Result<PgPool> {
    Ok(PgPoolOptions::new()
        .max_connections(10)
        .acquire_timeout(Duration::from_millis(500))
        .after_connect(|c, _| {
            Box::pin(async move {
                sqlx::query("SET statement_timeout='1500ms'")
                    .execute(&mut *c)
                    .await?;
                sqlx::query("SET lock_timeout='500ms'").execute(c).await?;
                Ok(())
            })
        })
        .connect(&env("DATABASE_URL")?)
        .await?)
}
pub fn client() -> anyhow::Result<reqwest::Client> {
    Ok(reqwest::Client::builder()
        .connect_timeout(Duration::from_millis(300))
        .timeout(Duration::from_secs(2))
        .redirect(reqwest::redirect::Policy::none())
        .build()?)
}
pub fn capacity() -> Arc<Semaphore> {
    Arc::new(Semaphore::new(32))
}
pub fn enter(s: &Arc<Semaphore>) -> ApiResult<tokio::sync::OwnedSemaphorePermit> {
    s.clone()
        .try_acquire_owned()
        .map_err(|_| ApiError(StatusCode::TOO_MANY_REQUESTS, "service capacity exhausted"))
}
pub async fn readiness(pool: PgPool) -> StatusCode {
    match tokio::time::timeout(
        Duration::from_millis(500),
        sqlx::query("SELECT 1").execute(&pool),
    )
    .await
    {
        Ok(Ok(_)) => StatusCode::OK,
        _ => StatusCode::SERVICE_UNAVAILABLE,
    }
}
pub async fn serve(
    router: Router,
    default_addr: &str,
    stop: CancellationToken,
) -> anyhow::Result<()> {
    let addr = std::env::var("HTTP_ADDR").unwrap_or_else(|_| default_addr.into());
    let listener = tokio::net::TcpListener::bind(&addr).await?;
    tracing::info!(%addr,"listening");
    let result = axum::serve(listener, router)
        .with_graceful_shutdown(stop.clone().cancelled_owned())
        .into_future();
    tokio::pin!(result);
    tokio::select! {
      v=&mut result=>v?,
      _=crate::signal()=> { stop.cancel();tokio::time::timeout(Duration::from_secs(20),&mut result).await??; }
      _=stop.cancelled()=> { tokio::time::timeout(Duration::from_secs(20),&mut result).await??; }
    }
    Ok(())
}
use std::future::IntoFuture;

/// Preserve the book's JSON error contract for request decoding failures.
pub struct BodyJson<T>(pub T);
impl<T, S> axum::extract::FromRequest<S> for BodyJson<T>
where
    T: serde::de::DeserializeOwned,
    S: Send + Sync,
{
    type Rejection = ApiError;
    async fn from_request(
        request: axum::extract::Request,
        state: &S,
    ) -> Result<Self, Self::Rejection> {
        use axum::extract::rejection::JsonRejection;
        match axum::Json::<T>::from_request(request, state).await {
            Ok(axum::Json(value)) => Ok(Self(value)),
            Err(JsonRejection::JsonDataError(_)) => Err(ApiError(
                StatusCode::UNPROCESSABLE_ENTITY,
                "JSON fields do not match contract",
            )),
            Err(JsonRejection::MissingJsonContentType(_)) => Err(ApiError(
                StatusCode::UNSUPPORTED_MEDIA_TYPE,
                "application/json required",
            )),
            Err(error) if error.status() == StatusCode::PAYLOAD_TOO_LARGE => {
                Err(ApiError(StatusCode::PAYLOAD_TOO_LARGE, "body too large"))
            }
            Err(_) => Err(invalid()),
        }
    }
}

/// Bound application requests; probes retain their own dependency budgets.
pub fn bounded(router: Router) -> Router {
    use axum::{
        extract::Request,
        middleware::{self, Next},
    };
    let capacity = capacity();
    router.layer(middleware::from_fn(move |request: Request, next: Next| {
        let capacity = capacity.clone();
        async move {
            let id = request
                .headers()
                .get("x-request-id")
                .and_then(|v| v.to_str().ok())
                .and_then(|v| uuid::Uuid::parse_str(v).ok())
                .unwrap_or_else(uuid::Uuid::new_v4);
            let probe = matches!(request.uri().path(), "/healthz" | "/readyz");
            let mut response = if probe {
                next.run(request).await
            } else {
                match enter(&capacity) {
                    Err(error) => error.into_response(),
                    Ok(_permit) => {
                        match tokio::time::timeout(Duration::from_secs(5), next.run(request)).await
                        {
                            Ok(response) => response,
                            Err(_) => ApiError(
                                StatusCode::GATEWAY_TIMEOUT,
                                "request budget exhausted; result may be unknown",
                            )
                            .into_response(),
                        }
                    }
                }
            };
            response
                .headers_mut()
                .insert("x-request-id", id.to_string().parse().expect("UUID header"));
            response
                .headers_mut()
                .insert("cache-control", "no-store".parse().expect("static header"));
            response
                .headers_mut()
                .insert("pragma", "no-cache".parse().expect("static header"));
            tracing::info!(request_id=%id,status=response.status().as_u16(),"request completed");
            response
        }
    }))
}
