use argon2::{
    Argon2, PasswordHasher, PasswordVerifier,
    password_hash::{PasswordHash, SaltString},
};
use rand_core::OsRng;

fn main() {
    // A fixed teaching fixture, never a real account credential.
    let password = b"password-only-for-this-lab";
    let algorithm = Argon2::default();
    let first = algorithm
        .hash_password(password, &SaltString::generate(&mut OsRng))
        .expect("lab hashing succeeds")
        .to_string();
    let second = algorithm
        .hash_password(password, &SaltString::generate(&mut OsRng))
        .expect("lab hashing succeeds")
        .to_string();
    assert_ne!(first, second);
    let saved = PasswordHash::new(&first).expect("generated PHC parses");
    assert!(algorithm.verify_password(password, &saved).is_ok());
    assert!(algorithm.verify_password(b"incorrect", &saved).is_err());
    println!("PASS independent salts, saved PHC verification, wrong password rejection");
}
