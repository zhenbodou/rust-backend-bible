# 第34章独立用户服务

1. password-lab是独立概念实验，用cargo run --locked --manifest-path password-lab/Cargo.toml核对盐、PHC和错误密码；它不加入业务workspace运行角色。
2. python3 scripts/create-users-env.py生成一次本地0600配置，拒绝覆盖。docker compose -p rustmall-users34 --env-file .env.users.local -f deploy/users/compose.yaml up -d --wait启动PG55436与Redis56380。
3. 专用服务终端加载.env.users.local，运行python3 scripts/check-checkpoint.py --role users；再运行cargo run --locked -p commerce --bin rustmall-service -- migrate-users，随后同命令users。默认HTTP8082。
4. 另开终端执行python3 scripts/check-users-http.py，创建一个实验账号并核对重复退出与撤销。只输出摘要，账号/会话保留供核对。
5. UserRemote::new(origin)构建两秒、禁止重定向、4KiB回复限制的身份客户端；identity_client示例只需要ACCESS_TOKEN和USERS_BASE_URL，不需要数据库或签名密钥。

旧gateway/facade身份流量本章未切换，新旧库与JWT issuer不同，不可混用用户编号；切流和账号映射仍须后续验证。原商品元数据更新与库存覆盖拒绝继续保留。

数据库会话是持久撤销屏障；logout先保存revoked_at再写Redis。Redis失败可返回503但已经撤销，重复退出可完成标记并返回204。合法令牌认证在Redis/PG不可用时503，liveness仍可200，readiness检查两个依赖。

测试需要隔离DATABASE_URL和REDIS_URL；CI增加短期Redis，真实线上凭据不能进入CI配置。应用镜像、远端CI、完整切流与集群交付尚未验证。
