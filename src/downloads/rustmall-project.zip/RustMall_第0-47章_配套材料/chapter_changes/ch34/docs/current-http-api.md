# 第34章当前公共HTTP接口与独立users实验

推荐通过gateway的127.0.0.1:8081访问，并启用接口层Remote catalog模式。用户JWT和内部服务令牌是不同凭据，外部身份头不能产生管理员权限。

| 方法与路径 | 权限和当前语义 |
| --- | --- |
| GET /health/live | 网关进程存活 |
| GET /health/ready | 接口层数据库与已选择商品依赖就绪 |
| POST /api/v1/auth/register | 普通用户注册，不允许自选管理员角色 |
| POST /api/v1/auth/login | 返回access_token、token_type与expires_in，当前没有本接口的刷新令牌字段 |
| GET /api/v1/users/me | 有效Bearer JWT |
| GET /api/v1/products | 公开分页，page与page_size参数 |
| GET /api/v1/products/{id} | 公开详情，不存在或下架404 |
| POST /api/v1/products | 管理员；Remote模式必须恰好一个UUID Idempotency-Key，输入name、price_cents、stock；同键同输入重放原结果，冲突409 |
| PUT /api/v1/products/{id} | 管理员；名称价格可改，stock须与锁定后的当前库存相同，否则409 |
| DELETE /api/v1/products/{id} | 管理员软下架；重复删除当前返回404 |

商品金额单位为分，当前商品JSON是id、name、price_cents、stock。库存预留已提供第31章内部Inventory RPC，调用方只持库存凭据；第32章inventory-adjust支持受控本地补货/盘亏，具有调整收据与查询。当前仍没有公共库存调整、持久化订单、支付和刷新会话接口。目标设计文档中的这些接口需继续后续章节，不能视为本阶段已经实现。


独立users实验监听127.0.0.1:8082：POST /api/v1/auth/register、POST /api/v1/auth/login、GET /api/v1/auth/me（兼容GET /api/v1/users/me）、POST /api/v1/auth/logout。退出重复调用204，失效会话/me返回401；依赖不可用返回503。/healthz为存活，/readyz同时检查PG和Redis。旧gateway仍转发旧facade，本章未切换公开身份流量。新旧库、JWT issuer/key、会话分别独立，不能互相冒认身份。
