"""Create local users credentials once; do not print secrets or overwrite files."""
import os
import secrets

postgres = secrets.token_urlsafe(36)
redis = secrets.token_urlsafe(36)
values = {
    "POSTGRES_PASSWORD": postgres,
    "REDIS_PASSWORD": redis,
    "DATABASE_URL": f"postgres://rustmall:{postgres}@127.0.0.1:55436/rustmall_users",
    "REDIS_URL": f"redis://:{redis}@127.0.0.1:56380/0",
    "JWT_SECRET": secrets.token_urlsafe(48),
    "HTTP_ADDR": "127.0.0.1:8082",
}
fd = os.open(".env.users.local", os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
with os.fdopen(fd, "w") as output:
    for key, value in values.items():
        output.write(f"{key}={value}\n")
print("Created .env.users.local; credentials were not printed.")
