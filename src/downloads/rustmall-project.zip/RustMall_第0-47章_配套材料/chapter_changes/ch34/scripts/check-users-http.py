"""Local chapter-34 HTTP experiment. Creates one disposable reader account.

No password or bearer token is printed. PostgreSQL session state is retained.
"""
import ipaddress
import json
import os
import secrets
import urllib.error
import urllib.parse
import urllib.request

base = os.environ.get("USERS_BASE_URL", "http://127.0.0.1:8082").rstrip("/")
url = urllib.parse.urlsplit(base)
assert (url.scheme == "http" and url.port and not url.username and not url.password
        and not url.path and not url.query and not url.fragment
        and (url.hostname == "localhost" or ipaddress.ip_address(url.hostname).is_loopback)), "loopback HTTP origin required"


def request(path, method="GET", data=None, token=None):
    headers = {"Content-Type": "application/json"}
    if token:
        headers["Authorization"] = "Bearer " + token
    req = urllib.request.Request(base + path, method=method, headers=headers,
        data=None if data is None else json.dumps(data).encode())
    try:
        response = urllib.request.urlopen(req, timeout=6)
    except urllib.error.HTTPError as error:
        response = error
    with response:
        assert response.headers.get("Cache-Control") == "no-store"
        body = response.read()
        return response.status, json.loads(body) if body else None


credentials = {"username": "reader_" + secrets.token_hex(5), "password": secrets.token_urlsafe(24)}
assert request("/readyz")[0] == 200
status, identity = request("/api/v1/auth/register", "POST", credentials)
assert status == 201 and identity["role"] == "user"
assert request("/api/v1/auth/register", "POST", credentials)[0] == 409
status, reply = request("/api/v1/auth/login", "POST", credentials)
assert status == 200
access = reply["access_token"]
assert request("/api/v1/auth/me", token=access)[1] == identity
assert request("/api/v1/auth/logout", "POST", token=access)[0] == 204
assert request("/api/v1/auth/logout", "POST", token=access)[0] == 204
assert request("/api/v1/auth/me", token=access)[0] == 401
print("PASS ready/register/duplicate/login/me/repeated logout/revocation; one reader account retained")
