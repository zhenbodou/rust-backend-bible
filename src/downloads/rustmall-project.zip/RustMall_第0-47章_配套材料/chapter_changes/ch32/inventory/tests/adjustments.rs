use inventory::adjustment::{self, Command, Error};
use inventory::model::{Action, Command as Reservation};
use sqlx::PgPool;
use uuid::Uuid;

async fn product(pool: &PgPool, stock: i32) -> i64 {
    sqlx::query_scalar(
        "INSERT INTO products(name,price_cents,stock) VALUES('调整实验',100,$1) RETURNING id",
    )
    .bind(stock)
    .fetch_one(pool)
    .await
    .unwrap()
}
fn command(id: i64, delta: i32) -> Command {
    Command {
        command_id: Uuid::new_v4(),
        product_id: id,
        delta,
        actor_id: 7,
        reason: "入库复核单 42".into(),
    }
}
async fn facts(pool: &PgPool, id: i64) -> (i32, i64, i64) {
    sqlx::query_as(
        "SELECT stock,revision,
          (SELECT count(*) FROM product_outbox WHERE aggregate_id=$1)
         FROM products WHERE id=$1",
    )
    .bind(id)
    .fetch_one(pool)
    .await
    .unwrap()
}

#[sqlx::test(migrations = "../services/catalog/migrations")]
async fn replay_does_not_apply_delta_twice(pool: PgPool) {
    let id = product(&pool, 10).await;
    let cmd = command(id, 3);
    let first = adjustment::execute(&pool, &cmd).await.unwrap();
    assert_eq!(first.outcome, "applied");
    let saved = facts(&pool, id).await;
    assert_eq!(saved, (13, 2, 1));
    assert_eq!(adjustment::execute(&pool, &cmd).await.unwrap(), first);
    assert_eq!(facts(&pool, id).await, saved);
    let changed = Command { delta: 4, ..cmd };
    assert!(matches!(
        adjustment::execute(&pool, &changed).await,
        Err(Error::IdentityConflict)
    ));
    assert_eq!(facts(&pool, id).await, saved);
}

#[sqlx::test(migrations = "../services/catalog/migrations")]
async fn rejected_attempt_stays_rejected(pool: PgPool) {
    let id = product(&pool, 1).await;
    let rejected = command(id, -2);
    let original = adjustment::execute(&pool, &rejected).await.unwrap();
    assert_eq!(original.outcome, "rejected");
    adjustment::execute(&pool, &command(id, 10)).await.unwrap();
    let saved = facts(&pool, id).await;
    assert_eq!(
        adjustment::execute(&pool, &rejected).await.unwrap(),
        original
    );
    assert_eq!(facts(&pool, id).await, saved);
}

#[sqlx::test(migrations = "../services/catalog/migrations")]
async fn independent_deltas_add_up(pool: PgPool) {
    let id = product(&pool, 10).await;
    let a = command(id, 3);
    let b = command(id, 5);
    let (a, b) = tokio::join!(
        adjustment::execute(&pool, &a),
        adjustment::execute(&pool, &b),
    );
    assert_eq!(a.unwrap().outcome, "applied");
    assert_eq!(b.unwrap().outcome, "applied");
    assert_eq!(facts(&pool, id).await, (18, 3, 2));
}

#[sqlx::test(migrations = "../services/catalog/migrations")]
async fn outbox_failure_rolls_back_everything(pool: PgPool) {
    let id = product(&pool, 10).await;
    sqlx::query(
        "ALTER TABLE product_outbox ADD CONSTRAINT injected_failure CHECK(false) NOT VALID",
    )
    .execute(&pool)
    .await
    .unwrap();
    let cmd = command(id, 3);
    assert!(adjustment::execute(&pool, &cmd).await.is_err());
    assert_eq!(facts(&pool, id).await, (10, 1, 0));
    let count: i64 =
        sqlx::query_scalar("SELECT count(*) FROM inventory_adjustments WHERE command_id=$1")
            .bind(cmd.command_id)
            .fetch_one(&pool)
            .await
            .unwrap();
    assert_eq!(count, 0);
}

#[sqlx::test(migrations = "../services/catalog/migrations")]
async fn replenishment_preserves_release_headroom(pool: PgPool) {
    let id = product(&pool, i32::MAX - 2).await;
    let reservation = Reservation {
        saga_id: Uuid::new_v4(),
        product_id: id,
        quantity: 2,
        unit_price_cents: 100,
    };
    inventory::execute(&pool, &reservation, Action::Reserve)
        .await
        .unwrap();
    let result = adjustment::execute(&pool, &command(id, 3)).await.unwrap();
    assert_eq!(result.outcome, "rejected");
    inventory::execute(&pool, &reservation, Action::Release)
        .await
        .unwrap();
    assert_eq!(facts(&pool, id).await.0, i32::MAX - 2);
}

#[sqlx::test(migrations = "../services/catalog/migrations")]
async fn normal_replenishment_then_release(pool: PgPool) {
    let id = product(&pool, 10).await;
    let reservation = Reservation {
        saga_id: Uuid::new_v4(),
        product_id: id,
        quantity: 2,
        unit_price_cents: 100,
    };
    inventory::execute(&pool, &reservation, Action::Reserve)
        .await
        .unwrap();
    assert_eq!(
        adjustment::execute(&pool, &command(id, 3))
            .await
            .unwrap()
            .outcome,
        "applied"
    );
    inventory::execute(&pool, &reservation, Action::Release)
        .await
        .unwrap();
    assert_eq!(facts(&pool, id).await, (13, 4, 3));
}

#[sqlx::test(migrations = "../services/catalog/migrations")]
async fn legacy_overwrite_is_disabled(pool: PgPool) {
    let id = product(&pool, 10).await;
    let draft = messaging::store::Draft {
        name: "不能覆盖库存".into(),
        price_cents: 100,
        stock: 999,
    };
    assert!(messaging::store::update(&pool, id, &draft).await.is_err());
    assert_eq!(facts(&pool, id).await, (10, 1, 0));
}

#[sqlx::test(migrations = "../services/catalog/migrations")]
async fn concurrent_same_identity_has_one_effect(pool: PgPool) {
    let id = product(&pool, 10).await;
    let cmd = command(id, 3);
    let (a, b) = tokio::join!(
        adjustment::execute(&pool, &cmd),
        adjustment::execute(&pool, &cmd)
    );
    assert_eq!(a.unwrap(), b.unwrap());
    assert_eq!(facts(&pool, id).await, (13, 2, 1));
}

#[sqlx::test(migrations = "../services/catalog/migrations")]
async fn query_keeps_original_result_and_checks_identity(pool: PgPool) {
    let id = product(&pool, 10).await;
    let cmd = command(id, 3);
    assert!(adjustment::find(&pool, &cmd).await.unwrap().is_none());
    let original = adjustment::execute(&pool, &cmd).await.unwrap();
    adjustment::execute(&pool, &command(id, 5)).await.unwrap();
    assert_eq!(adjustment::find(&pool, &cmd).await.unwrap(), Some(original));
    for changed in [
        Command {
            delta: 4,
            ..cmd.clone()
        },
        Command {
            actor_id: 8,
            ..cmd.clone()
        },
        Command {
            reason: "另一个原因".into(),
            ..cmd.clone()
        },
        Command {
            product_id: id + 1,
            ..cmd.clone()
        },
    ] {
        assert!(matches!(
            adjustment::find(&pool, &changed).await,
            Err(Error::IdentityConflict)
        ));
        assert!(matches!(
            adjustment::execute(&pool, &changed).await,
            Err(Error::IdentityConflict)
        ));
    }
    assert_eq!(facts(&pool, id).await, (18, 3, 2));
}

#[sqlx::test(migrations = "../services/catalog/migrations")]
async fn missing_is_stable_after_product_is_created(pool: PgPool) {
    // This isolated test database has no products; the first generated id is 1.
    let cmd = command(1, 3);
    let first = adjustment::execute(&pool, &cmd).await.unwrap();
    assert_eq!(first.outcome, "missing");
    let id = product(&pool, 10).await;
    assert_eq!(id, cmd.product_id);
    assert_eq!(adjustment::execute(&pool, &cmd).await.unwrap(), first);
    assert_eq!(facts(&pool, id).await, (10, 1, 0));
}

#[sqlx::test(migrations = "../services/catalog/migrations")]
async fn delisted_product_can_be_adjusted_without_relisting(pool: PgPool) {
    let id = product(&pool, 10).await;
    sqlx::query("UPDATE products SET delisted_at=now() WHERE id=$1")
        .bind(id)
        .execute(&pool)
        .await
        .unwrap();
    assert_eq!(
        adjustment::execute(&pool, &command(id, 3))
            .await
            .unwrap()
            .outcome,
        "applied"
    );
    let listed: bool = sqlx::query_scalar("SELECT delisted_at IS NULL FROM products WHERE id=$1")
        .bind(id)
        .fetch_one(&pool)
        .await
        .unwrap();
    assert!(!listed);
    let payload: sqlx::types::Json<messaging::event::Envelope> =
        sqlx::query_scalar("SELECT payload FROM product_outbox WHERE aggregate_id=$1")
            .bind(id)
            .fetch_one(&pool)
            .await
            .unwrap();
    assert!(!payload.0.payload.listed);
}

#[sqlx::test(migrations = "../services/catalog/migrations")]
async fn committed_pending_is_rejected_without_writing(pool: PgPool) {
    let id = product(&pool, 10).await;
    let cmd = command(id, 3);
    sqlx::query("INSERT INTO inventory_adjustments(command_id,product_id,delta,actor_id,reason,outcome) VALUES($1,$2,$3,$4,$5,'pending')")
        .bind(cmd.command_id).bind(id).bind(cmd.delta).bind(cmd.actor_id).bind(&cmd.reason)
        .execute(&pool).await.unwrap();
    assert!(matches!(
        adjustment::find(&pool, &cmd).await,
        Err(Error::CorruptReceipt)
    ));
    assert!(matches!(
        adjustment::execute(&pool, &cmd).await,
        Err(Error::CorruptReceipt)
    ));
    assert_eq!(facts(&pool, id).await, (10, 1, 0));
}

#[sqlx::test(migrations = "../services/catalog/migrations")]
async fn lock_timeout_leaves_no_receipt(pool: PgPool) {
    let id = product(&pool, 10).await;
    let cmd = command(id, 3);
    let mut blocker = pool.begin().await.unwrap();
    sqlx::query("SELECT id FROM products WHERE id=$1 FOR UPDATE")
        .bind(id)
        .execute(&mut *blocker)
        .await
        .unwrap();
    let result = adjustment::execute(&pool, &cmd).await;
    blocker.rollback().await.unwrap();
    assert!(matches!(result, Err(Error::Database(ref e))
        if e.as_database_error().and_then(|e| e.code()).as_deref() == Some("55P03")));
    assert!(adjustment::find(&pool, &cmd).await.unwrap().is_none());
    assert_eq!(facts(&pool, id).await, (10, 1, 0));
}

#[sqlx::test(migrations = "../services/catalog/migrations")]
async fn release_and_adjustment_serialize_correctly(pool: PgPool) {
    let id = product(&pool, 10).await;
    let reservation = Reservation {
        saga_id: Uuid::new_v4(),
        product_id: id,
        quantity: 2,
        unit_price_cents: 100,
    };
    inventory::execute(&pool, &reservation, Action::Reserve)
        .await
        .unwrap();
    let cmd = command(id, 3);
    let (a, b) = tokio::join!(
        adjustment::execute(&pool, &cmd),
        inventory::execute(&pool, &reservation, Action::Release)
    );
    assert_eq!(a.unwrap().outcome, "applied");
    assert_eq!(b.unwrap(), inventory::model::State::Released);
    assert_eq!(facts(&pool, id).await, (13, 4, 3));
}
