use crate::{ProductRow, append_snapshot};
use sqlx::PgPool;
use uuid::Uuid;

#[derive(Debug, Clone)]
pub struct Command {
    pub command_id: Uuid,
    pub product_id: i64,
    pub delta: i32,
    pub actor_id: i64,
    pub reason: String,
}

#[derive(Debug, thiserror::Error)]
pub enum Error {
    #[error("invalid adjustment input")]
    InvalidInput,
    #[error("adjustment identity reused with different input")]
    IdentityConflict,
    #[error("invalid stored adjustment receipt")]
    CorruptReceipt,
    #[error("operation deadline exceeded; result may be unknown")]
    Deadline,
    #[error(transparent)]
    Database(#[from] sqlx::Error),
    #[error(transparent)]
    Snapshot(#[from] crate::Error),
}

#[derive(Debug, Clone, PartialEq, Eq, sqlx::FromRow)]
pub struct Outcome {
    pub outcome: String,
    pub before_stock: Option<i32>,
    pub after_stock: Option<i32>,
}

#[derive(sqlx::FromRow)]
struct Receipt {
    product_id: i64,
    delta: i32,
    actor_id: i64,
    reason: String,
    outcome: String,
    before_stock: Option<i32>,
    after_stock: Option<i32>,
}

impl Receipt {
    fn verify(&self, cmd: &Command) -> Result<Outcome, Error> {
        if self.product_id != cmd.product_id
            || self.delta != cmd.delta
            || self.actor_id != cmd.actor_id
            || self.reason != cmd.reason
        {
            return Err(Error::IdentityConflict);
        }
        let valid = match (self.outcome.as_str(), self.before_stock, self.after_stock) {
            ("applied", Some(before), Some(after)) => {
                before >= 0
                    && after >= 0
                    && i64::from(after) == i64::from(before) + i64::from(self.delta)
            }
            ("rejected", Some(before), Some(after)) => before >= 0 && before == after,
            ("missing", None, None) => true,
            _ => false,
        };
        if !valid {
            return Err(Error::CorruptReceipt);
        }
        Ok(Outcome {
            outcome: self.outcome.clone(),
            before_stock: self.before_stock,
            after_stock: self.after_stock,
        })
    }
}

pub async fn find(pool: &PgPool, cmd: &Command) -> Result<Option<Outcome>, Error> {
    cmd.validate()?;
    let row = tokio::time::timeout(
        std::time::Duration::from_millis(1200),
        sqlx::query_as::<_, Receipt>(
            "SELECT product_id,delta,actor_id,reason,outcome,before_stock,after_stock
             FROM inventory_adjustments WHERE command_id=$1",
        )
        .bind(cmd.command_id)
        .fetch_optional(pool),
    )
    .await
    .map_err(|_| Error::Deadline)??;
    row.map(|r| r.verify(cmd)).transpose()
}

impl Command {
    pub fn validate(&self) -> Result<(), Error> {
        if self.command_id.is_nil()
            || self.product_id <= 0
            || self.actor_id <= 0
            || self.delta == 0
            || !(-1_000_000..=1_000_000).contains(&self.delta)
            || self.reason != self.reason.trim()
            || !(1..=200).contains(&self.reason.chars().count())
            || self.reason.chars().any(char::is_control)
        {
            return Err(Error::InvalidInput);
        }
        Ok(())
    }
}

/// Held quantities must still fit when they are all released later.
pub fn next_stock(stock: i32, held: i64, delta: i32) -> Option<i32> {
    if stock < 0 || held < 0 {
        return None;
    }
    let next = i64::from(stock).checked_add(i64::from(delta))?;
    let after_release = next.checked_add(held)?;
    if next < 0 || after_release > i64::from(i32::MAX) {
        return None;
    }
    i32::try_from(next).ok()
}

async fn inside(pool: &PgPool, cmd: &Command) -> Result<Outcome, Error> {
    let mut tx = pool.begin().await?;
    sqlx::query("SET TRANSACTION ISOLATION LEVEL READ COMMITTED")
        .execute(&mut *tx)
        .await?;
    sqlx::query("SET LOCAL lock_timeout='400ms'")
        .execute(&mut *tx)
        .await?;
    sqlx::query("SET LOCAL statement_timeout='500ms'")
        .execute(&mut *tx)
        .await?;
    let inserted = sqlx::query(
        "INSERT INTO inventory_adjustments
         (command_id,product_id,delta,actor_id,reason,outcome)
         VALUES($1,$2,$3,$4,$5,'pending') ON CONFLICT DO NOTHING",
    )
    .bind(cmd.command_id)
    .bind(cmd.product_id)
    .bind(cmd.delta)
    .bind(cmd.actor_id)
    .bind(&cmd.reason)
    .execute(&mut *tx)
    .await?;
    let old = sqlx::query_as::<_, Receipt>(
        "SELECT product_id,delta,actor_id,reason,outcome,before_stock,after_stock
         FROM inventory_adjustments WHERE command_id=$1 FOR UPDATE",
    )
    .bind(cmd.command_id)
    .fetch_one(&mut *tx)
    .await?;
    if old.outcome != "pending" {
        let result = old.verify(cmd)?;
        tx.commit().await?;
        return Ok(result);
    }
    // A committed pending row cannot be produced by this transaction protocol.
    if inserted.rows_affected() != 1 {
        return Err(Error::CorruptReceipt);
    }
    let product = sqlx::query_as::<_, ProductRow>(
        "SELECT id,name,price_cents,stock,revision,
                delisted_at IS NULL AS listed
         FROM products WHERE id=$1 FOR UPDATE",
    )
    .bind(cmd.product_id)
    .fetch_optional(&mut *tx)
    .await?;
    let result = if let Some(row) = product {
        let held: i64 = sqlx::query_scalar(
            "SELECT COALESCE(sum(quantity),0)::bigint
             FROM inventory_reservations WHERE product_id=$1 AND state='held'",
        )
        .bind(cmd.product_id)
        .fetch_one(&mut *tx)
        .await?;
        if let Some(next) = next_stock(row.stock, held, cmd.delta) {
            let updated = sqlx::query_as::<_, ProductRow>(
                "UPDATE products SET stock=$2,revision=revision+1,updated_at=now()
                 WHERE id=$1
                 RETURNING id,name,price_cents,stock,revision,
                           delisted_at IS NULL AS listed",
            )
            .bind(cmd.product_id)
            .bind(next)
            .fetch_one(&mut *tx)
            .await?;
            append_snapshot(&mut tx, updated).await?;
            Outcome {
                outcome: "applied".into(),
                before_stock: Some(row.stock),
                after_stock: Some(next),
            }
        } else {
            Outcome {
                outcome: "rejected".into(),
                before_stock: Some(row.stock),
                after_stock: Some(row.stock),
            }
        }
    } else {
        Outcome {
            outcome: "missing".into(),
            before_stock: None,
            after_stock: None,
        }
    };
    sqlx::query(
        "UPDATE inventory_adjustments
         SET outcome=$2,before_stock=$3,after_stock=$4 WHERE command_id=$1",
    )
    .bind(cmd.command_id)
    .bind(&result.outcome)
    .bind(result.before_stock)
    .bind(result.after_stock)
    .execute(&mut *tx)
    .await?;
    tx.commit().await?;
    Ok(result)
}

pub async fn execute(pool: &PgPool, cmd: &Command) -> Result<Outcome, Error> {
    cmd.validate()?;
    tokio::time::timeout(std::time::Duration::from_millis(1200), inside(pool, cmd))
        .await
        .map_err(|_| Error::Deadline)?
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn ordinary_add_and_subtract() {
        assert_eq!(next_stock(10, 2, 3), Some(13));
        assert_eq!(next_stock(10, 2, -4), Some(6));
    }
    #[test]
    fn cannot_spend_unavailable_stock() {
        assert_eq!(next_stock(2, 100, -3), None);
        assert_eq!(next_stock(2, 100, -2), Some(0));
    }
    #[test]
    fn leaves_room_for_all_releases() {
        assert_eq!(next_stock(i32::MAX - 2, 2, 1), None);
        assert_eq!(next_stock(i32::MAX - 2, 2, 0), Some(i32::MAX - 2));
    }
    #[test]
    fn invalid_stored_numbers_fail_closed() {
        assert_eq!(next_stock(-1, 0, 1), None);
        assert_eq!(next_stock(0, -1, 1), None);
        assert_eq!(next_stock(1, i64::MAX, 1), None);
    }
    #[test]
    fn input_is_bounded() {
        let valid = Command {
            command_id: Uuid::new_v4(),
            product_id: 1,
            delta: 2,
            actor_id: 7,
            reason: "入库复核单 42".into(),
        };
        assert!(valid.validate().is_ok());
        for delta in [0, i32::MIN, i32::MAX] {
            assert!(
                Command {
                    delta,
                    ..valid.clone()
                }
                .validate()
                .is_err()
            );
        }
        for reason in ["", " 前导空格", "换\n行"] {
            assert!(
                Command {
                    reason: reason.into(),
                    ..valid.clone()
                }
                .validate()
                .is_err()
            );
        }
    }
}
