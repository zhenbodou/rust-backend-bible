CREATE TABLE inventory_adjustments (
    command_id UUID PRIMARY KEY,
    product_id BIGINT NOT NULL CHECK (product_id > 0),
    delta INT NOT NULL CHECK (delta <> 0 AND delta BETWEEN -1000000 AND 1000000),
    actor_id BIGINT NOT NULL CHECK (actor_id > 0),
    reason TEXT NOT NULL CHECK (char_length(reason) BETWEEN 1 AND 200),
    outcome TEXT NOT NULL CHECK (outcome IN ('pending','applied','rejected','missing')),
    before_stock INT CHECK (before_stock >= 0),
    after_stock INT CHECK (after_stock >= 0),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    CHECK (
        (outcome IN ('pending','missing') AND before_stock IS NULL AND after_stock IS NULL)
        OR (outcome='applied' AND before_stock IS NOT NULL AND after_stock IS NOT NULL
            AND after_stock::bigint = before_stock::bigint + delta::bigint)
        OR (outcome='rejected' AND before_stock IS NOT NULL AND after_stock IS NOT NULL
            AND after_stock=before_stock)
    )
);
CREATE INDEX inventory_reservations_product_held_idx
    ON inventory_reservations(product_id) INCLUDE (quantity) WHERE state='held';
