//! Shared observability, without taking ownership of business timeouts or retries.
pub mod metrics;
use http::HeaderMap;
use opentelemetry::{
    Context,
    propagation::{Extractor, TextMapPropagator},
    trace::{TraceContextExt, TracerProvider},
};
use opentelemetry_sdk::{
    propagation::TraceContextPropagator,
    trace::{BatchConfigBuilder, BatchSpanProcessor, Sampler, SdkTracerProvider},
};
use std::time::Duration;
use tracing_opentelemetry::OpenTelemetrySpanExt;
use tracing_subscriber::prelude::*;

pub struct Telemetry {
    provider: Option<SdkTracerProvider>,
    metrics: Option<(
        tokio_util::sync::CancellationToken,
        tokio::task::JoinHandle<std::io::Result<()>>,
    )>,
}
impl Telemetry {
    pub async fn shutdown(self) {
        if let Some((stop, mut task)) = self.metrics {
            stop.cancel();
            if !matches!(
                tokio::time::timeout(Duration::from_secs(1), &mut task).await,
                Ok(Ok(Ok(())))
            ) {
                task.abort();
                tracing::warn!(
                    category = "metrics-shutdown",
                    "metrics listener shutdown incomplete"
                );
            }
        }
        if let Some(provider) = self.provider {
            // Telemetry failure must not replace a successful business result.
            match tokio::task::spawn_blocking(move || {
                provider.shutdown_with_timeout(Duration::from_secs(2))
            })
            .await
            {
                Ok(Ok(())) => {}
                _ => tracing::warn!(
                    category = "telemetry-shutdown",
                    "trace export shutdown incomplete"
                ),
            }
        }
    }
}
pub fn init(service: &str) -> anyhow::Result<Telemetry> {
    opentelemetry::global::set_text_map_propagator(TraceContextPropagator::new());
    let provider = if std::env::var_os("OTEL_EXPORTER_OTLP_ENDPOINT").is_some() {
        use opentelemetry_otlp::WithExportConfig;
        let ratio = std::env::var("RUSTMALL_TRACE_SAMPLE_RATIO")
            .unwrap_or_else(|_| "0.1".into())
            .parse::<f64>()?;
        anyhow::ensure!(
            ratio.is_finite() && (0.0..=1.0).contains(&ratio),
            "trace sample ratio must be between 0 and 1"
        );
        let exporter = opentelemetry_otlp::SpanExporter::builder()
            .with_tonic()
            .with_timeout(Duration::from_secs(1))
            .build()?;
        let processor = BatchSpanProcessor::builder(exporter)
            .with_batch_config(
                BatchConfigBuilder::default()
                    .with_max_queue_size(1024)
                    .with_max_export_batch_size(128)
                    .with_scheduled_delay(Duration::from_millis(200))
                    .build(),
            )
            .build();
        Some(
            SdkTracerProvider::builder()
                .with_resource(
                    opentelemetry_sdk::Resource::builder()
                        .with_service_name(service.to_owned())
                        .build(),
                )
                .with_sampler(Sampler::ParentBased(Box::new(Sampler::TraceIdRatioBased(
                    ratio,
                ))))
                .with_span_processor(processor)
                .build(),
        )
    } else {
        None
    };
    let layer = provider
        .as_ref()
        .map(|p| tracing_opentelemetry::layer().with_tracer(p.tracer("rustmall")));
    tracing_subscriber::registry()
        .with(
            tracing_subscriber::EnvFilter::try_from_default_env().unwrap_or_else(|_| "info".into()),
        )
        .with(tracing_subscriber::fmt::layer().json())
        .with(layer)
        .try_init()
        .map_err(|_| anyhow::anyhow!("telemetry subscriber initialization failed"))?;
    let metrics = if let Ok(raw) = std::env::var("METRICS_ADDR") {
        let addr: std::net::SocketAddr = raw.parse()?;
        anyhow::ensure!(
            addr.ip().is_loopback(),
            "dedicated metrics listener must bind loopback in the local profile"
        );
        let listener = std::net::TcpListener::bind(addr)?;
        listener.set_nonblocking(true)?;
        let listener = tokio::net::TcpListener::from_std(listener)?;
        let stop = tokio_util::sync::CancellationToken::new();
        let stopped = stop.clone();
        let router = axum::Router::new().route(
            "/metrics",
            axum::routing::get(|| async {
                (
                    [("content-type", "text/plain; version=0.0.4; charset=utf-8")],
                    metrics::process_metrics(),
                )
            }),
        );
        let task = tokio::spawn(async move {
            axum::serve(listener, router)
                .with_graceful_shutdown(stopped.cancelled_owned())
                .await
        });
        Some((stop, task))
    } else {
        None
    };
    Ok(Telemetry { provider, metrics })
}
struct HttpExtract<'a>(&'a HeaderMap);
impl Extractor for HttpExtract<'_> {
    fn get(&self, key: &str) -> Option<&str> {
        if self.0.get_all(key).iter().count() != 1 {
            return None;
        }
        self.0
            .get(key)
            .and_then(|v| v.to_str().ok())
            .filter(|v| v.len() <= 512)
    }
    fn keys(&self) -> Vec<&str> {
        self.0.keys().map(|k| k.as_str()).collect()
    }
}
struct RpcExtract<'a>(&'a tonic::metadata::MetadataMap);
impl Extractor for RpcExtract<'_> {
    fn get(&self, key: &str) -> Option<&str> {
        if self.0.get_all(key).iter().count() != 1 {
            return None;
        }
        self.0
            .get(key)
            .and_then(|v| v.to_str().ok())
            .filter(|v| v.len() <= 512)
    }
    fn keys(&self) -> Vec<&str> {
        vec!["traceparent", "tracestate"]
    }
}
fn extract(source: &impl Extractor) -> Context {
    // Only W3C trace context, no arbitrary baggage or credentials.
    TraceContextPropagator::new().extract_with_context(&Context::new(), source)
}
pub fn http_span(headers: &HeaderMap, method: &str, route: &str) -> tracing::Span {
    let span = tracing::info_span!(
        "http.server",
        otel.kind = "server",
        http.method = method,
        http.route = route,
        otel.status_code = tracing::field::Empty
    );
    let _ = span.set_parent(extract(&HttpExtract(headers)));
    span
}
pub fn rpc_span<T>(request: &tonic::Request<T>, method: &str) -> tracing::Span {
    let span = tracing::info_span!(
        "rpc.server",
        otel.kind = "server",
        rpc.system = "grpc",
        rpc.method = method,
        otel.status_code = tracing::field::Empty
    );
    let _ = span.set_parent(extract(&RpcExtract(request.metadata())));
    span
}
pub async fn rpc_server<T>(
    span: tracing::Span,
    future: impl std::future::Future<Output = Result<T, tonic::Status>>,
) -> Result<T, tonic::Status> {
    use tracing::Instrument;
    async {
        let start = std::time::Instant::now();
        let result = future.await;
        let rpc_code = result
            .as_ref()
            .err()
            .map_or(tonic::Code::Ok, tonic::Status::code);
        metrics::observe_rpc(start.elapsed(), rpc_code);
        let code = rpc_code as i32;
        if code != 0 {
            tracing::Span::current().record("otel.status_code", "ERROR");
        }
        let (trace_id, span_id) = ids();
        tracing::info!(%trace_id,%span_id,rpc_code=code,"RPC completed");
        result
    }
    .instrument(span)
    .await
}
pub fn ids() -> (String, String) {
    let context = tracing::Span::current().context();
    let span = context.span();
    let c = span.span_context();
    if c.is_valid() {
        (c.trace_id().to_string(), c.span_id().to_string())
    } else {
        (String::new(), String::new())
    }
}
fn carrier() -> std::collections::HashMap<String, String> {
    let mut headers = std::collections::HashMap::new();
    TraceContextPropagator::new().inject_context(&tracing::Span::current().context(), &mut headers);
    headers
}
pub fn http(request: reqwest::RequestBuilder) -> reqwest::RequestBuilder {
    let mut headers = HeaderMap::new();
    for (k, v) in carrier() {
        if let (Ok(k), Ok(v)) = (k.parse::<http::header::HeaderName>(), v.parse()) {
            headers.insert(k, v);
        }
    }
    request.headers(headers)
}
pub fn rpc<T>(request: &mut tonic::Request<T>) {
    for (k, v) in carrier() {
        if let (Ok(k), Ok(v)) = (
            k.parse::<tonic::metadata::MetadataKey<tonic::metadata::Ascii>>(),
            v.parse(),
        ) {
            request.metadata_mut().insert(k, v);
        }
    }
}
