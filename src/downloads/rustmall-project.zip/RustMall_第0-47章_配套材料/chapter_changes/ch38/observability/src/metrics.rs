//! A fixed-cardinality local HTTP histogram; snapshot under one short lock.
use std::{fmt::Write, sync::Mutex, time::Duration};

const BOUNDS: [u64; 10] = [5, 10, 25, 50, 100, 250, 500, 1000, 2500, 5000];
#[derive(Clone, Default)]
struct Snapshot {
    completed: u64,
    errors: u64,
    rejected: u64,
    deadlines: u64,
    sum: f64,
    buckets: [u64; 10],
}
#[derive(Default)]
pub struct HttpMetrics(Mutex<Snapshot>);
impl HttpMetrics {
    pub fn observe(&self, duration: Duration, status: u16) {
        self.observe_result(
            duration,
            (500..600).contains(&status),
            status == 429,
            status == 504,
        );
    }
    fn observe_result(&self, duration: Duration, failed: bool, rejected: bool, deadline: bool) {
        let mut m = self.0.lock().unwrap_or_else(|p| p.into_inner());
        if m.completed == u64::MAX {
            return;
        }
        m.completed += 1;
        m.errors += u64::from(failed);
        m.rejected += u64::from(rejected);
        m.deadlines += u64::from(deadline);
        m.sum += duration.as_secs_f64();
        for (bucket, bound) in m.buckets.iter_mut().zip(BOUNDS) {
            if duration <= Duration::from_millis(bound) {
                *bucket += 1;
            }
        }
    }
    pub fn encode(&self) -> String {
        self.encode_as("rustmall_http")
    }
    fn encode_as(&self, prefix: &str) -> String {
        // Never keep the lock while formatting or sending the scrape body.
        let m = self.0.lock().unwrap_or_else(|p| p.into_inner()).clone();
        let mut out = String::new();
        for (name, count) in [
            ("rustmall_http_requests_total", m.completed),
            ("rustmall_http_errors_total", m.errors),
            ("rustmall_http_rejected_total", m.rejected),
            ("rustmall_http_deadlines_total", m.deadlines),
        ] {
            writeln!(out, "# TYPE {name} counter\n{name} {count}").expect("String write");
        }
        out.push_str("# TYPE rustmall_http_request_duration_seconds histogram\n");
        for (bound, count) in BOUNDS.into_iter().zip(m.buckets) {
            writeln!(
                out,
                "rustmall_http_request_duration_seconds_bucket{{le=\"{}\"}} {count}",
                bound as f64 / 1000.0
            )
            .expect("String write");
        }
        writeln!(out,"rustmall_http_request_duration_seconds_bucket{{le=\"+Inf\"}} {}\nrustmall_http_request_duration_seconds_count {}\nrustmall_http_request_duration_seconds_sum {}",m.completed,m.completed,m.sum).expect("String write");
        out.replace("rustmall_http", prefix)
    }
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn histogram_uses_exact_duration_instead_of_floor_milliseconds() {
        let m = HttpMetrics::default();
        m.observe(Duration::from_micros(5000), 200);
        m.observe(Duration::from_micros(5900), 503);
        let text = m.encode();
        assert!(text.contains("bucket{le=\"0.005\"} 1\n"));
        assert!(text.contains("bucket{le=\"0.01\"} 2\n"));
        assert!(text.contains("errors_total 1\n"));
        assert!(text.contains("seconds_sum 0.0109\n"));
    }
    #[test]
    fn rpc_errors_keep_deadline_and_capacity_categories() {
        observe_rpc(Duration::from_millis(1), tonic::Code::ResourceExhausted);
        observe_rpc(Duration::from_millis(2), tonic::Code::DeadlineExceeded);
        let text = process_metrics();
        assert!(text.contains("rustmall_rpc_errors_total 2\n"));
        assert!(text.contains("rustmall_rpc_rejected_total 1\n"));
        assert!(text.contains("rustmall_rpc_deadlines_total 1\n"));
    }
    #[test]
    fn concurrent_scrapes_never_observe_a_bucket_ahead_of_count() {
        let m = std::sync::Arc::new(HttpMetrics::default());
        let writers: Vec<_> = (0..4)
            .map(|_| {
                let m = m.clone();
                std::thread::spawn(move || {
                    for _ in 0..2000 {
                        m.observe(Duration::from_micros(100), 200);
                    }
                })
            })
            .collect();
        for _ in 0..500 {
            let text = m.encode();
            let values: Vec<u64> = text
                .lines()
                .filter(|s| {
                    s.contains("seconds_bucket")
                        || s.starts_with("rustmall_http_request_duration_seconds_count")
                })
                .map(|s| s.rsplit_once(' ').unwrap().1.parse().unwrap())
                .collect();
            assert_eq!(values.len(), 12);
            assert!(values.windows(2).all(|w| w[0] == w[1]));
        }
        for writer in writers {
            writer.join().unwrap();
        }
        assert!(m.encode().contains("requests_total 8000\n"));
    }
}

/// Export only a fixed vocabulary. A business ID can never become a metric name.
#[derive(Clone, Copy)]
pub enum Gauge {
    OrdersPending,
    OrdersManual,
    OrdersOldestSeconds,
    OrdersSampleUnix,
    OutboxPending,
    OutboxOldestSeconds,
    OutboxMaxAttempts,
    OutboxSampleUnix,
    ProjectionAppliedUnix,
}
const GAUGES: [&str; 9] = [
    "rustmall_orders_pending",
    "rustmall_orders_manual",
    "rustmall_orders_oldest_seconds",
    "rustmall_orders_sample_timestamp_seconds",
    "rustmall_outbox_pending",
    "rustmall_outbox_oldest_seconds",
    "rustmall_outbox_max_attempts",
    "rustmall_outbox_sample_timestamp_seconds",
    "rustmall_projection_apply_timestamp_seconds",
];
static BUSINESS: std::sync::OnceLock<Mutex<[f64; 9]>> = std::sync::OnceLock::new();
static RPC: std::sync::OnceLock<HttpMetrics> = std::sync::OnceLock::new();
pub fn unix_seconds() -> f64 {
    std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .unwrap_or_default()
        .as_secs_f64()
}
pub fn set_gauges(values: &[(Gauge, f64)]) {
    let mut m = BUSINESS
        .get_or_init(Default::default)
        .lock()
        .unwrap_or_else(|p| p.into_inner());
    for (key, value) in values {
        if value.is_finite() && *value >= 0.0 {
            m[*key as usize] = *value;
        }
    }
}
pub fn observe_rpc(elapsed: Duration, code: tonic::Code) {
    RPC.get_or_init(Default::default).observe_result(
        elapsed,
        code != tonic::Code::Ok,
        code == tonic::Code::ResourceExhausted,
        code == tonic::Code::DeadlineExceeded,
    );
}
pub fn process_metrics() -> String {
    let mut out = RPC.get_or_init(Default::default).encode_as("rustmall_rpc");
    let values = *BUSINESS
        .get_or_init(Default::default)
        .lock()
        .unwrap_or_else(|p| p.into_inner());
    for (name, value) in GAUGES.into_iter().zip(values) {
        writeln!(out, "# TYPE {name} gauge\n{name} {value}").expect("String write");
    }
    out
}
