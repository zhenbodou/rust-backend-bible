use http::HeaderMap;
use opentelemetry::trace::{TraceContextExt, TracerProvider};
use opentelemetry_sdk::trace::{InMemorySpanExporter, SdkTracerProvider};
use tracing::{Instrument, instrument::WithSubscriber};
use tracing_subscriber::prelude::*;

#[tokio::test]
async fn parent_survives_http_and_rpc_without_forwarding_credentials_or_baggage() {
    let exporter = InMemorySpanExporter::default();
    let provider = SdkTracerProvider::builder()
        .with_simple_exporter(exporter.clone())
        .build();
    let subscriber = tracing_subscriber::registry()
        .with(tracing_opentelemetry::layer().with_tracer(provider.tracer("test")));
    async {
        let mut headers = HeaderMap::new();
        headers.insert(
            "traceparent",
            "00-1234567890abcdef1234567890abcdef-1234567890abcdef-01"
                .parse()
                .unwrap(),
        );
        headers.insert("authorization", "Bearer do-not-export".parse().unwrap());
        headers.insert("baggage", "password=do-not-export".parse().unwrap());
        let http = observability::http_span(&headers, "GET", "/api/v1/products/{id}");
        async {
            let client = tracing::info_span!("rpc.client", otel.kind = "client");
            async {
                let mut request = tonic::Request::new(());
                observability::rpc(&mut request);
                assert!(request.metadata().get("authorization").is_none());
                assert!(request.metadata().get("baggage").is_none());
                assert_eq!(request.metadata().get_all("traceparent").iter().count(), 1);
                let server = observability::rpc_span(&request, "Catalog/get_product");
                observability::rpc_server(server, async { Ok::<_, tonic::Status>(()) })
                    .await
                    .unwrap();
                let request = observability::http(
                    reqwest::Client::new()
                        .get("http://localhost:1/")
                        .header("traceparent", "old-value"),
                )
                .build()
                .unwrap();
                assert_eq!(request.headers().get_all("traceparent").iter().count(), 1);
            }
            .instrument(client)
            .await;
        }
        .instrument(http)
        .await;
    }
    .with_subscriber(subscriber)
    .await;
    provider.force_flush().unwrap();
    let spans = exporter.get_finished_spans().unwrap();
    assert_eq!(spans.len(), 3);
    assert!(
        spans
            .iter()
            .all(|s| s.span_context.trace_id().to_string() == "1234567890abcdef1234567890abcdef")
    );
    let http = spans.iter().find(|s| s.name == "http.server").unwrap();
    let client = spans.iter().find(|s| s.name == "rpc.client").unwrap();
    let server = spans.iter().find(|s| s.name == "rpc.server").unwrap();
    assert_eq!(client.parent_span_id, http.span_context.span_id());
    assert_eq!(server.parent_span_id, client.span_context.span_id());
    assert!(!format!("{spans:?}").contains("do-not-export"));
    provider.shutdown().unwrap();
}

#[test]
fn malformed_duplicate_or_zero_parent_starts_a_new_trace() {
    use tracing_opentelemetry::OpenTelemetrySpanExt;
    let exporter = InMemorySpanExporter::default();
    let provider = SdkTracerProvider::builder()
        .with_simple_exporter(exporter.clone())
        .build();
    let subscriber = tracing_subscriber::registry()
        .with(tracing_opentelemetry::layer().with_tracer(provider.tracer("test")));
    tracing::subscriber::with_default(subscriber, || {
        for bad in [
            "invalid",
            "00-00000000000000000000000000000000-0000000000000000-01",
        ] {
            let mut h = HeaderMap::new();
            h.insert("traceparent", bad.parse().unwrap());
            let span = observability::http_span(&h, "GET", "/test");
            assert!(span.context().span().span_context().is_valid());
        }
        let mut h = HeaderMap::new();
        let p = "00-1234567890abcdef1234567890abcdef-1234567890abcdef-01";
        h.append("traceparent", p.parse().unwrap());
        h.append("traceparent", p.parse().unwrap());
        let span = observability::http_span(&h, "GET", "/test");
        assert_ne!(
            span.context().span().span_context().trace_id().to_string(),
            "1234567890abcdef1234567890abcdef"
        );
    });
    provider.force_flush().unwrap();
    assert_eq!(exporter.get_finished_spans().unwrap().len(), 3);
    provider.shutdown().unwrap();
}
