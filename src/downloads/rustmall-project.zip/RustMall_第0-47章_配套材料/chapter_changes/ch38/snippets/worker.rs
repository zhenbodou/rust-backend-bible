#[tracing::instrument(name="saga.attempt",skip_all,fields(order_id=%row.id,state=%row.state,attempt=row.attempts))]
async fn attempt(s: &Worker, row: &Order, token: Uuid) -> anyhow::Result<()> {
    let result = tokio::time::timeout(Duration::from_secs(5), step(s, row)).await;
    match result {
        Ok(Ok(Outcome::Advance(next, reason))) => {
            let owned = advance(&s.pool, row, token, next, reason).await?;
            tracing::info!(order_id=%row.id,from=%row.state,to=next,owned,"saga transition attempted");
        }
        Ok(Ok(Outcome::Retry(reason))) => {
            defer(&s.pool, row, token, reason).await?;
        }
        Ok(Err(error)) => {
            tracing::error!(order_id=%row.id,%error,"invalid saga work");
            return Err(error);
        }
        Err(_) => {
            defer(&s.pool, row, token, "step-budget-unknown").await?;
        }
    }
    Ok(())
}
async fn sample_queue(pool: &PgPool) {
    use observability::metrics::{self, Gauge};
    let query = sqlx::query_as::<_, (i64, i64, f64)>(
        "SELECT count(*) FILTER(WHERE state NOT IN ('completed','cancelled','manual')),count(*) FILTER(WHERE state='manual'),GREATEST(COALESCE(EXTRACT(EPOCH FROM clock_timestamp()-min(created_at) FILTER(WHERE state NOT IN ('completed','cancelled','manual'))),0),0)::float8 FROM orders",
    );
    if let Ok(Ok((pending, manual, oldest))) =
        tokio::time::timeout(Duration::from_millis(250), query.fetch_one(pool)).await
    {
        metrics::set_gauges(&[
            (Gauge::OrdersPending, pending as f64),
            (Gauge::OrdersManual, manual as f64),
            (Gauge::OrdersOldestSeconds, oldest),
            (Gauge::OrdersSampleUnix, metrics::unix_seconds()),
        ]);
    }
}
pub async fn run(s: Worker, stop: CancellationToken) -> anyhow::Result<()> {
    let mut sampled = std::time::Instant::now() - Duration::from_secs(5);
    loop {
        if sampled.elapsed() >= Duration::from_secs(5) {
            sample_queue(&s.pool).await;
            sampled = std::time::Instant::now();
        }
        if stop.is_cancelled() {
            return Ok(());
        }
        match claim(&s.pool).await {
            Ok(Some((row, token))) => {
                attempt(&s, &row, token).await?;
            }
            Ok(None) => {
                tokio::select! {_=stop.cancelled()=>return Ok(()),_=tokio::time::sleep(Duration::from_millis(200))=>{}}
            }
            Err(error) => {
                tracing::error!(%error,"order claim failed");
                tokio::select! {_=stop.cancelled()=>return Ok(()),_=tokio::time::sleep(Duration::from_secs(1))=>{}}
            }
        }
    }
}
