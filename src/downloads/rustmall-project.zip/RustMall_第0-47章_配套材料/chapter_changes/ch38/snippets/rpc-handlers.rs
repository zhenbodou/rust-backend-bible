// Inside impl Catalog for CatalogApi
    async fn get_product(
        &self,
        request: Request<GetProductRequest>,
    ) -> Result<Response<Product>, Status> {
        let span = observability::rpc_span(&request, "Catalog/get_product");
        observability::rpc_server(span, async {
            let id = validate_id(request.into_inner().id)?;
            let row = bounded(sqlx::query_as::<_, Row>(
             "SELECT id,name,price_cents,stock FROM products WHERE id=$1 AND delisted_at IS NULL"
         ).bind(id).fetch_optional(&self.pool)).await?
             .ok_or_else(|| Status::not_found("product not found"))?;
            Ok(Response::new(row.wire()?))
        })
        .await
    }

// Inside impl Inventory for InventoryApi
    async fn reserve(
        &self,
        request: Request<ReservationCommand>,
    ) -> Result<Response<ReservationReply>, Status> {
        let span = observability::rpc_span(&request, "Inventory/reserve");
        observability::rpc_server(span, async {
            self.apply(request.into_inner(), Action::Reserve).await
        })
        .await
    }
