"""Add local telemetry settings to existing private chapter-37 profiles once."""
import argparse
from pathlib import Path
import os,stat
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--profile-dir',type=Path,default=Path('.saga.local'))
args=parser.parse_args();root=args.profile_dir
settings={name:{'OTEL_EXPORTER_OTLP_ENDPOINT':'http://127.0.0.1:14317','RUSTMALL_TRACE_SAMPLE_RATIO':'1'}
          for name in ['catalog','users','payments','orders','worker','catalog-http','edge','relay','projection','projection-rebuild']}
for name,port in [('catalog',19051),('worker',19084),('relay',19087),('projection',19088),('projection-rebuild',19089)]:
    settings[name]['METRICS_ADDR']='127.0.0.1:'+str(port)
planned=[]
for name,updates in settings.items():
    path=root/(name+'.env');text=path.read_text()
    if stat.S_IMODE(path.stat().st_mode)&0o077:raise SystemExit('private profile files must have mode 0600')
    existing=dict(line.split('=',1) for line in text.splitlines() if line and not line.startswith('#'))
    if any(key in existing and existing[key]!=value for key,value in updates.items()):
        raise SystemExit('existing telemetry setting differs; inspect it before changing the profile')
    additions=''.join(f'{key}={value}\n' for key,value in updates.items() if key not in existing)
    planned.append((path,text,additions))
# Check every role before mutating any; each replacement retains private permissions.
for path,text,additions in planned:
    if additions:
        temporary=path.with_suffix('.env.observability-tmp')
        fd=os.open(temporary,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
        with os.fdopen(fd,'w') as out:out.write(text+('' if text.endswith('\n') else '\n')+additions)
        os.replace(temporary,path)
print('Enabled local OTLP and fixed metrics ports; repeated invocation preserves settings and credentials.')
