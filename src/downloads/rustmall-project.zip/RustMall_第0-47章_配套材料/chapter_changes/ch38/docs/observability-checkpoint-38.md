# Chapter 38: operational observability

Continue the repaired chapter-37 source and private `.saga.local` profiles.
Stop the old native roles before restarting their replacements; retain all
business and Kafka volumes, credentials and consumer generations.

```sh
cargo +1.92.0 build --locked --workspace --all-features --bins
python3 scripts/enable-saga-observability.py
docker compose -p rustmall-observability38 -f deploy/observability38/compose.yaml up -d
```

Start catalog first, then users/payments/orders/catalog-http/edge/worker, plus
relay/projection/projection-rebuild, with the existing `run-saga-role.py` launcher.
Migrations and infrastructure preparation follow chapter 37; the observability
overlay itself has no database migration. All ten private role files are checked
before mutation, preserve secrets, and use0600 replacements. Repeating the helper
is safe; conflicting existing telemetry settings require inspection.

Five HTTP roles expose `/metrics` on18082-18086. Dedicated loopback-only listeners
are catalog19051, worker19084, relay19087, projection19088 and rebuild19089.
Prometheus is59090 and the Collector OTLP gRPC receiver is14317. This local profile
uses Docker Desktop's host.docker.internal to scrape native loopback services;
that route was actually tested here. Linux deployment needs its own networking
configuration and is not proved by this test.

The HTTP protection layer still has32 in-flight slots and a5-second budget.
Health/readiness/metrics bypass business capacity and do not dilute business
request counters. The histogram measures time until Response construction,
not future streaming-body completion or every client-cancelled network attempt.
Latency buckets use Duration comparisons and a consistent short-lock snapshot.
Labels and gauge names have a fixed vocabulary; IDs remain in logs/spans.

Tracing covers synchronous HTTP clients/servers and authorized Catalog/Inventory
RPC handlers, plus per-attempt Saga, Outbox delivery and projection application.
Authentication interceptors run before RPC business spans; denied transport/auth
requests are not claimed as business-handler observations. Catalog now uses the
same typed constant-time/duplicate-rejecting interceptor as Inventory with its
own distinct credential. Telemetry propagation is independent of service auth.

No persisted W3C context was added to the immutable product event schema. Async
attempts are new root traces correlated by order_id or event_id/revision, rather
than one artificially long HTTP trace. Arbitrary baggage and secrets are not
extracted into span attributes. Local sampling1 is for deterministic exercises;
root default0.1 and ParentBased remote sampling need a production trust policy.

Business gauges are sampled by their own worker/relay using existing local DB
connections, every5seconds with250ms per-query budget. Successful sample time is
exported; failure preserves the previous value/time. Production volume may need
indexed/aggregated sampling rather than repeated full aggregates. Prometheus
has no database credentials. The seven rules distinguish stale sampling from
fresh observed backlog and require minimum HTTP traffic before error-ratio
alarms. They evaluate locally; there is no configured external notification
sender or automatic business repair.

```sh
docker run --rm --entrypoint /bin/promtool \
  --mount "type=bind,src=$PWD/deploy/observability38,dst=/rules,readonly" \
  quay.io/prometheus/prometheus:v3.5.0 test rules /rules/alerts-test.yaml
python3 scripts/check-saga-http.py --local-admin-fixture --delist-after-order
```

Temporarily stop only the Collector and repeat the real order exercise. Orders
must still complete. Resume the Collector and generate a new query; verify new
span delivery, without claiming all lost spans were recovered. The bounded SDK
queue and rotating Collector file exporter are diagnostic infrastructure, not
a durable business log or a production tracing search backend.

```sh
docker compose -p rustmall-observability38 -f deploy/observability38/compose.yaml stop otel-collector
python3 scripts/check-saga-http.py --local-admin-fixture --delist-after-order
docker compose -p rustmall-observability38 -f deploy/observability38/compose.yaml start otel-collector
```

After pausing actual business writers, drain the relay and repeat both chapter37
projection audits. Real business facts remain the correctness evidence even if
telemetry is unavailable. `run-saga-tests.py` runs the complete workspace with
isolated PostgreSQL/Redis; ignored container tests are not silently selected.

The Collector's local file-export volume uses root only for this disposable lab;
production needs independent storage permissions, retention and access policy.
Application images, real cluster deployment, production tracing backend,
long-term retention and external paging remain outside this chapter's evidence.
