use crate::{
    Error, Reservation, execute, find,
    model::{Action, Command, State},
};
use contracts::catalog::{
    GetReservationRequest, ReservationCommand, ReservationReply, ReservationState,
    inventory_server::Inventory,
};
use sqlx::PgPool;
use std::sync::Arc;
use subtle::ConstantTimeEq;
use tokio::sync::{OwnedSemaphorePermit, Semaphore};
use tonic::{
    Request, Response, Status,
    metadata::{Ascii, MetadataValue},
    service::Interceptor,
};
use uuid::Uuid;

pub const MAX_MESSAGE_BYTES: usize = 64 * 1024;
pub const SERVICE_TOKEN_HEADER: &str = "x-rustmall-service-token";

pub fn service(
    pool: PgPool,
    key: ServiceKey,
) -> tonic::service::interceptor::InterceptedService<
    contracts::catalog::inventory_server::InventoryServer<InventoryApi>,
    ServiceKey,
> {
    let server =
        contracts::catalog::inventory_server::InventoryServer::new(InventoryApi::new(pool))
            .max_decoding_message_size(MAX_MESSAGE_BYTES)
            .max_encoding_message_size(MAX_MESSAGE_BYTES);
    tonic::service::interceptor::InterceptedService::new(server, key)
}

#[derive(Clone)]
pub struct ServiceKey {
    value: MetadataValue<Ascii>,
}

impl ServiceKey {
    pub fn parse(raw: &str) -> anyhow::Result<Self> {
        anyhow::ensure!(
            (32..=256).contains(&raw.len())
                && raw
                    .bytes()
                    .all(|b| b.is_ascii_alphanumeric() || b == b'-' || b == b'_'),
            "service token must contain 32..256 ASCII letters, digits, '-' or '_'"
        );
        Ok(Self {
            value: raw.parse()?,
        })
    }

    pub fn attach<T>(&self, request: &mut Request<T>) {
        request
            .metadata_mut()
            .insert(SERVICE_TOKEN_HEADER, self.value.clone());
    }
}

impl Interceptor for ServiceKey {
    fn call(&mut self, request: Request<()>) -> Result<Request<()>, Status> {
        let mut values = request.metadata().get_all(SERVICE_TOKEN_HEADER).iter();
        let Some(received) = values.next() else {
            return Err(Status::unauthenticated("service identity required"));
        };
        if values.next().is_some()
            || !bool::from(
                received
                    .as_encoded_bytes()
                    .ct_eq(self.value.as_encoded_bytes()),
            )
        {
            return Err(Status::unauthenticated("service identity required"));
        }
        Ok(request)
    }
}

#[derive(Clone)]
pub struct InventoryApi {
    pool: PgPool,
    capacity: Arc<Semaphore>,
}

impl InventoryApi {
    pub fn new(pool: PgPool) -> Self {
        Self {
            pool,
            capacity: Arc::new(Semaphore::new(16)),
        }
    }

    fn enter(&self) -> Result<OwnedSemaphorePermit, Status> {
        self.capacity
            .clone()
            .try_acquire_owned()
            .map_err(|_| Status::resource_exhausted("inventory capacity exhausted"))
    }

    async fn apply(
        &self,
        command: ReservationCommand,
        action: Action,
    ) -> Result<Response<ReservationReply>, Status> {
        let _permit = self.enter()?;
        let input = Command {
            saga_id: parse_id(&command.saga_id)?,
            product_id: command.product_id,
            quantity: command.quantity,
            unit_price_cents: command.unit_price_cents,
        };
        let state = execute(&self.pool, &input, action)
            .await
            .map_err(map_error)?;
        Ok(Response::new(reply(&input, state)?))
    }
}

fn parse_id(raw: &str) -> Result<Uuid, Status> {
    let id = Uuid::parse_str(raw).map_err(|_| Status::invalid_argument("invalid saga UUID"))?;
    if id.is_nil() {
        return Err(Status::invalid_argument("nil saga UUID"));
    }
    Ok(id)
}

fn reply(command: &Command, state: State) -> Result<ReservationReply, Status> {
    let state = match state {
        State::Held => ReservationState::Held,
        State::Confirmed => ReservationState::Confirmed,
        State::Released => ReservationState::Released,
        State::Rejected => ReservationState::Rejected,
        State::Pending => return Err(Status::internal("reservation result unavailable")),
    };
    Ok(ReservationReply {
        saga_id: command.saga_id.to_string(),
        product_id: command.product_id,
        quantity: command.quantity,
        unit_price_cents: command.unit_price_cents,
        state: state as i32,
    })
}

fn row_reply(row: Reservation) -> Result<ReservationReply, Status> {
    let state = State::from_stored(&row.state).map_err(map_error)?;
    reply(
        &Command {
            saga_id: row.saga_id,
            product_id: row.product_id,
            quantity: row.quantity,
            unit_price_cents: row.unit_price_cents,
        },
        state,
    )
}

pub fn map_error(error: Error) -> Status {
    match error {
        Error::InvalidInput => Status::invalid_argument("invalid reservation input"),
        Error::IdentityConflict => Status::failed_precondition("reservation identity conflict"),
        Error::Deadline => Status::deadline_exceeded("inventory result may be unknown"),
        Error::Database(error) => {
            tracing::error!(%error, "inventory database failure");
            let code = error.as_database_error().and_then(|e| e.code());
            match code.as_deref() {
                Some("55P03") => Status::unavailable("inventory lock unavailable"),
                Some("57014") => Status::deadline_exceeded("inventory database budget exhausted"),
                Some("40001" | "40P01") => Status::aborted("inventory transaction must be retried"),
                _ => Status::internal("inventory database failure"),
            }
        }
        Error::CorruptState => {
            tracing::error!("invalid inventory reservation state");
            Status::internal("inventory stored state invalid")
        }
    }
}

#[tonic::async_trait]
impl Inventory for InventoryApi {
    async fn reserve(
        &self,
        request: Request<ReservationCommand>,
    ) -> Result<Response<ReservationReply>, Status> {
        let span = observability::rpc_span(&request, "Inventory/reserve");
        observability::rpc_server(span, async {
            self.apply(request.into_inner(), Action::Reserve).await
        })
        .await
    }

    async fn confirm(
        &self,
        request: Request<ReservationCommand>,
    ) -> Result<Response<ReservationReply>, Status> {
        let span = observability::rpc_span(&request, "Inventory/confirm");
        observability::rpc_server(span, async {
            self.apply(request.into_inner(), Action::Confirm).await
        })
        .await
    }

    async fn release(
        &self,
        request: Request<ReservationCommand>,
    ) -> Result<Response<ReservationReply>, Status> {
        let span = observability::rpc_span(&request, "Inventory/release");
        observability::rpc_server(span, async {
            self.apply(request.into_inner(), Action::Release).await
        })
        .await
    }

    async fn get_reservation(
        &self,
        request: Request<GetReservationRequest>,
    ) -> Result<Response<ReservationReply>, Status> {
        let span = observability::rpc_span(&request, "Inventory/get_reservation");
        observability::rpc_server(span, async {
            let _permit = self.enter()?;
            let id = parse_id(&request.into_inner().saga_id)?;
            let row = find(&self.pool, id)
                .await
                .map_err(map_error)?
                .ok_or_else(|| Status::not_found("reservation not found"))?;
            Ok(Response::new(row_reply(row)?))
        })
        .await
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn key_validation_and_duplicate_metadata() {
        assert!(ServiceKey::parse("short").is_err());
        assert!(ServiceKey::parse(&"x".repeat(257)).is_err());
        assert!(ServiceKey::parse(&format!("{}\n", "x".repeat(32))).is_err());
        let mut key = ServiceKey::parse(&"x".repeat(32)).unwrap();
        assert!(key.call(Request::new(())).is_err());
        let mut request = Request::new(());
        key.attach(&mut request);
        assert!(key.call(request).is_ok());
        let mut duplicate = Request::new(());
        key.attach(&mut duplicate);
        duplicate
            .metadata_mut()
            .append(SERVICE_TOKEN_HEADER, "wrong".parse().unwrap());
        assert_eq!(
            key.call(duplicate).unwrap_err().code(),
            tonic::Code::Unauthenticated
        );
    }

    #[tokio::test]
    async fn clones_share_the_same_capacity() {
        let pool = sqlx::postgres::PgPoolOptions::new()
            .connect_lazy("postgres://localhost/not_connected")
            .unwrap();
        let api = InventoryApi::new(pool);
        let clone = api.clone();
        let permits: Vec<_> = (0..16).map(|_| api.enter().unwrap()).collect();
        assert_eq!(
            clone.enter().unwrap_err().code(),
            tonic::Code::ResourceExhausted
        );
        drop(permits);
        assert!(clone.enter().is_ok());
    }
}
