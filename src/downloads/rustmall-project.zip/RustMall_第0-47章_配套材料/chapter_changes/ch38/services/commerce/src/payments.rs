use crate::runtime::*;
use axum::{
    Json, Router,
    extract::{Path, Request, State as ExtractState},
    http::StatusCode,
    middleware::{self, Next},
    response::Response,
    routing::{get, post},
};
use inventory::rpc::{SERVICE_TOKEN_HEADER, ServiceKey};
use serde::{Deserialize, Serialize};
use sqlx::{PgPool, Postgres, Transaction};
use std::time::Duration;
use uuid::Uuid;

#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub enum State {
    Paid,
    Declined,
    Refunded,
}
impl State {
    fn stored(self) -> &'static str {
        match self {
            Self::Paid => "paid",
            Self::Declined => "declined",
            Self::Refunded => "refunded",
        }
    }
}
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Action {
    Charge,
    Refund,
}
#[derive(Debug, Serialize, Deserialize, Clone, PartialEq, Eq)]
#[serde(deny_unknown_fields)]
pub struct Charge {
    pub saga_id: Uuid,
    pub actor_id: i64,
    pub amount: i64,
}
impl Charge {
    pub fn valid(&self) -> bool {
        !self.saga_id.is_nil() && self.actor_id > 0 && (1..=100_000_000).contains(&self.amount)
    }
}
#[derive(Debug, Serialize, Deserialize, Clone, PartialEq, Eq)]
pub struct Payment {
    pub saga_id: Uuid,
    pub actor_id: i64,
    pub amount: i64,
    pub state: State,
}
#[derive(sqlx::FromRow)]
struct Row {
    saga_id: Uuid,
    actor_id: i64,
    amount: i64,
    state: String,
}
impl TryFrom<Row> for Payment {
    type Error = ApiError;
    fn try_from(row: Row) -> ApiResult<Self> {
        let state = match row.state.as_str() {
            "paid" => State::Paid,
            "declined" => State::Declined,
            "refunded" => State::Refunded,
            _ => {
                return Err(ApiError(
                    StatusCode::INTERNAL_SERVER_ERROR,
                    "invalid stored payment",
                ));
            }
        };
        let payment = Self {
            saga_id: row.saga_id,
            actor_id: row.actor_id,
            amount: row.amount,
            state,
        };
        if !(Charge {
            saga_id: payment.saga_id,
            actor_id: payment.actor_id,
            amount: payment.amount,
        })
        .valid()
        {
            return Err(ApiError(
                StatusCode::INTERNAL_SERVER_ERROR,
                "invalid stored payment",
            ));
        }
        Ok(payment)
    }
}
/// A deterministic simulation. This function has no channel or bank side effect.
pub fn initial(amount: i64, action: Action) -> State {
    if action == Action::Refund {
        State::Refunded
    } else if amount > 500_000 {
        State::Declined
    } else {
        State::Paid
    }
}
pub fn next(state: State, action: Action) -> State {
    if state == State::Paid && action == Action::Refund {
        State::Refunded
    } else {
        state
    }
}
async fn effect(tx: &mut Transaction<'_, Postgres>, c: &Charge, kind: &str) -> ApiResult<()> {
    sqlx::query("INSERT INTO payment_effects(effect_id,saga_id,kind,amount) VALUES($1,$2,$3,$4)")
        .bind(Uuid::new_v4())
        .bind(c.saga_id)
        .bind(kind)
        .bind(c.amount)
        .execute(&mut **tx)
        .await?;
    Ok(())
}
async fn inside(pool: &PgPool, c: &Charge, action: Action) -> ApiResult<Payment> {
    let mut tx = pool.begin().await?;
    sqlx::query("SET TRANSACTION ISOLATION LEVEL READ COMMITTED")
        .execute(&mut *tx)
        .await?;
    sqlx::query("SET LOCAL lock_timeout='400ms'")
        .execute(&mut *tx)
        .await?;
    sqlx::query("SET LOCAL statement_timeout='500ms'")
        .execute(&mut *tx)
        .await?;
    let first = initial(c.amount, action);
    let inserted = sqlx::query(
        "INSERT INTO payments(saga_id,actor_id,amount,state)
         VALUES($1,$2,$3,$4) ON CONFLICT DO NOTHING",
    )
    .bind(c.saga_id)
    .bind(c.actor_id)
    .bind(c.amount)
    .bind(first.stored())
    .execute(&mut *tx)
    .await?
    .rows_affected()
        == 1;
    let mut row: Payment = sqlx::query_as::<_, Row>(
        "SELECT saga_id,actor_id,amount,state FROM payments WHERE saga_id=$1 FOR UPDATE",
    )
    .bind(c.saga_id)
    .fetch_one(&mut *tx)
    .await?
    .try_into()?;
    if row.actor_id != c.actor_id || row.amount != c.amount {
        return Err(ApiError(StatusCode::CONFLICT, "payment identity conflict"));
    }
    if inserted {
        effect(
            &mut tx,
            c,
            if action == Action::Refund {
                "refund_barrier"
            } else {
                first.stored()
            },
        )
        .await?;
    }
    let state = next(row.state, action);
    if state != row.state {
        sqlx::query("UPDATE payments SET state=$2,updated_at=now() WHERE saga_id=$1")
            .bind(c.saga_id)
            .bind(state.stored())
            .execute(&mut *tx)
            .await?;
        effect(&mut tx, c, "refunded").await?;
        row.state = state;
    }
    tx.commit().await?;
    Ok(row)
}
pub async fn apply(pool: &PgPool, c: &Charge, action: Action) -> ApiResult<Payment> {
    if !c.valid() {
        return Err(invalid());
    }
    tokio::time::timeout(Duration::from_millis(700), inside(pool, c, action))
        .await
        .map_err(|_| ApiError(StatusCode::GATEWAY_TIMEOUT, "payment result may be unknown"))?
}
pub async fn find(pool: &PgPool, id: Uuid) -> ApiResult<Option<Payment>> {
    if id.is_nil() {
        return Err(invalid());
    }
    let row = tokio::time::timeout(
        Duration::from_millis(700),
        sqlx::query_as::<_, Row>(
            "SELECT saga_id,actor_id,amount,state FROM payments WHERE saga_id=$1",
        )
        .bind(id)
        .fetch_optional(pool),
    )
    .await
    .map_err(|_| {
        ApiError(
            StatusCode::GATEWAY_TIMEOUT,
            "payment query budget exhausted",
        )
    })??;
    row.map(Payment::try_from).transpose()
}

#[derive(Clone)]
pub struct Payments {
    pub pool: PgPool,
    pub key: ServiceKey,
}
async fn authorize(
    ExtractState(mut key): ExtractState<ServiceKey>,
    request: Request,
    next: Next,
) -> ApiResult<Response> {
    let token = bearer(request.headers())?;
    let mut internal = tonic::Request::new(());
    internal.metadata_mut().insert(
        SERVICE_TOKEN_HEADER,
        token.parse().map_err(|_| unauthorized())?,
    );
    tonic::service::Interceptor::call(&mut key, internal).map_err(|_| unauthorized())?;
    Ok(next.run(request).await)
}
pub fn router(s: Payments) -> Router {
    let ready = s.pool.clone();
    let protected = Router::new()
        .route("/internal/payments", post(charge))
        .route("/internal/payments/refund", post(refund))
        .route("/internal/payments/{id}", get(query))
        .route_layer(middleware::from_fn_with_state(s.key.clone(), authorize));
    Router::new()
        .merge(protected)
        .route("/healthz", get(|| async { StatusCode::OK }))
        .route("/readyz", get(move || readiness(ready.clone())))
        .layer(axum::extract::DefaultBodyLimit::max(4096))
        .with_state(s)
}
async fn charge(
    ExtractState(s): ExtractState<Payments>,
    BodyJson(c): BodyJson<Charge>,
) -> ApiResult<Json<Payment>> {
    Ok(Json(apply(&s.pool, &c, Action::Charge).await?))
}
async fn refund(
    ExtractState(s): ExtractState<Payments>,
    BodyJson(c): BodyJson<Charge>,
) -> ApiResult<Json<Payment>> {
    Ok(Json(apply(&s.pool, &c, Action::Refund).await?))
}
async fn query(
    ExtractState(s): ExtractState<Payments>,
    Path(raw): Path<String>,
) -> ApiResult<Json<Payment>> {
    let id = Uuid::parse_str(&raw).map_err(|_| invalid())?;
    Ok(Json(find(&s.pool, id).await?.ok_or(ApiError(
        StatusCode::NOT_FOUND,
        "payment not found",
    ))?))
}

#[derive(Debug, thiserror::Error, PartialEq, Eq)]
pub enum RemoteError {
    #[error("invalid payment input")]
    InvalidInput,
    #[error("payment identity conflict")]
    IdentityConflict,
    #[error("payment service identity rejected")]
    Unauthenticated,
    #[error("payment deadline; result may be unknown")]
    Deadline,
    #[error("payment dependency unavailable; result may be unknown")]
    Unavailable,
    #[error("invalid payment response")]
    Protocol,
}
#[derive(Clone)]
pub struct PaymentRemote {
    client: reqwest::Client,
    base: String,
    key: String,
}
impl PaymentRemote {
    pub fn new(base: &str, key: String) -> anyhow::Result<Self> {
        let url = reqwest::Url::parse(base)?;
        anyhow::ensure!(
            matches!(url.scheme(), "http" | "https")
                && url.host_str().is_some()
                && url.username().is_empty()
                && url.password().is_none()
                && url.path() == "/"
                && url.query().is_none()
                && url.fragment().is_none(),
            "payment endpoint must be an HTTP(S) origin without credentials"
        );
        ServiceKey::parse(&key)?;
        Ok(Self {
            client: client()?,
            base: base.trim_end_matches('/').into(),
            key,
        })
    }
    #[tracing::instrument(name="http.client",skip_all,fields(otel.kind="client",peer.service="payments"))]
    async fn request(
        &self,
        c: &Charge,
        action: Option<Action>,
    ) -> Result<Option<Payment>, RemoteError> {
        if !c.valid() {
            return Err(RemoteError::InvalidInput);
        }
        let request = match action {
            Some(Action::Charge) => self
                .client
                .post(format!("{}/internal/payments", self.base))
                .json(c),
            Some(Action::Refund) => self
                .client
                .post(format!("{}/internal/payments/refund", self.base))
                .json(c),
            None => self
                .client
                .get(format!("{}/internal/payments/{}", self.base, c.saga_id)),
        }
        .bearer_auth(&self.key);
        let mut response = observability::http(request).send().await.map_err(|e| {
            if e.is_timeout() {
                RemoteError::Deadline
            } else {
                RemoteError::Unavailable
            }
        })?;
        match response.status().as_u16() {
            200 => {}
            404 if action.is_none() => return Ok(None),
            400 | 422 => return Err(RemoteError::InvalidInput),
            409 => return Err(RemoteError::IdentityConflict),
            401 | 403 => return Err(RemoteError::Unauthenticated),
            504 => return Err(RemoteError::Deadline),
            429 | 500 | 502 | 503 => return Err(RemoteError::Unavailable),
            _ => return Err(RemoteError::Protocol),
        }
        let mut bytes = Vec::new();
        while let Some(chunk) = response.chunk().await.map_err(|e| {
            if e.is_timeout() {
                RemoteError::Deadline
            } else {
                RemoteError::Unavailable
            }
        })? {
            if bytes.len().saturating_add(chunk.len()) > 4096 {
                return Err(RemoteError::Protocol);
            }
            bytes.extend_from_slice(&chunk);
        }
        let row: Payment = serde_json::from_slice(&bytes).map_err(|_| RemoteError::Protocol)?;
        if (row.saga_id, row.actor_id, row.amount) != (c.saga_id, c.actor_id, c.amount) {
            return Err(RemoteError::Protocol);
        }
        Ok(Some(row))
    }
    pub async fn apply(&self, c: &Charge, action: Action) -> Result<Payment, RemoteError> {
        tokio::time::timeout(Duration::from_secs(2), self.request(c, Some(action)))
            .await
            .map_err(|_| RemoteError::Deadline)?
            .and_then(|r| r.ok_or(RemoteError::Protocol))
    }
    pub async fn query(&self, c: &Charge) -> Result<Option<Payment>, RemoteError> {
        tokio::time::timeout(Duration::from_secs(2), self.request(c, None))
            .await
            .map_err(|_| RemoteError::Deadline)?
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn every_existing_state_and_action_has_a_stable_transition() {
        for state in [State::Paid, State::Declined, State::Refunded] {
            assert_eq!(next(state, Action::Charge), state);
        }
        assert_eq!(next(State::Paid, Action::Refund), State::Refunded);
        assert_eq!(next(State::Declined, Action::Refund), State::Declined);
        assert_eq!(next(State::Refunded, Action::Refund), State::Refunded);
    }
    #[test]
    fn deterministic_threshold_and_refund_barrier() {
        assert_eq!(initial(500_000, Action::Charge), State::Paid);
        assert_eq!(initial(500_001, Action::Charge), State::Declined);
        assert_eq!(initial(100, Action::Refund), State::Refunded);
    }
}
