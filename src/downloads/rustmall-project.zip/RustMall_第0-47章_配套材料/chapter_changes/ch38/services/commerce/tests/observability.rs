use axum::{Router, body::Body, http::Request, routing::get};
use http_body_util::BodyExt;
use tower::ServiceExt;
async fn scrape(app: &Router, path: &str) -> (u16, String) {
    let response = app
        .clone()
        .oneshot(Request::builder().uri(path).body(Body::empty()).unwrap())
        .await
        .unwrap();
    let status = response.status().as_u16();
    (
        status,
        String::from_utf8(
            response
                .into_body()
                .collect()
                .await
                .unwrap()
                .to_bytes()
                .to_vec(),
        )
        .unwrap(),
    )
}
#[tokio::test]
async fn probes_and_scrapes_do_not_dilute_business_errors_or_add_dynamic_labels() {
    let app = commerce::runtime::bounded(
        Router::new()
            .route("/healthz", get(|| async { "ok" }))
            .route("/readyz", get(|| async { "ok" }))
            .route(
                "/item/{id}",
                get(|| async { axum::http::StatusCode::SERVICE_UNAVAILABLE }),
            ),
    );
    scrape(&app, "/healthz").await;
    scrape(&app, "/readyz").await;
    scrape(&app, "/metrics").await;
    let initial = scrape(&app, "/metrics").await.1;
    assert!(initial.contains("rustmall_http_requests_total 0\n"));
    assert_eq!(scrape(&app, "/item/secret-business-id").await.0, 503);
    let metrics = scrape(&app, "/metrics").await.1;
    assert!(metrics.contains("rustmall_http_requests_total 1\n"));
    assert!(metrics.contains("rustmall_http_errors_total 1\n"));
    assert!(!metrics.contains("secret-business-id"));
    assert!(!metrics.contains("/item"));
}
#[tokio::test]
async fn nil_or_duplicate_request_ids_are_replaced_before_the_handler() {
    let app = commerce::runtime::bounded(Router::new().route(
        "/",
        get(|headers: axum::http::HeaderMap| async move {
            headers
                .get("x-request-id")
                .unwrap()
                .to_str()
                .unwrap()
                .to_owned()
        }),
    ));
    for duplicate in [false, true] {
        let mut request = Request::builder()
            .uri("/")
            .header("x-request-id", uuid::Uuid::nil().to_string());
        if duplicate {
            request = request.header("x-request-id", uuid::Uuid::new_v4().to_string());
        }
        let r = app
            .clone()
            .oneshot(request.body(Body::empty()).unwrap())
            .await
            .unwrap();
        let h = r.headers()["x-request-id"].to_str().unwrap().to_owned();
        let id = uuid::Uuid::parse_str(&h).unwrap();
        assert!(!id.is_nil());
        assert_eq!(
            h,
            String::from_utf8(r.into_body().collect().await.unwrap().to_bytes().to_vec()).unwrap()
        );
    }
}
#[tokio::test]
async fn existing_32_request_capacity_is_preserved_and_rejections_are_measured() {
    use std::sync::{
        Arc,
        atomic::{AtomicUsize, Ordering},
    };
    let active = Arc::new(AtomicUsize::new(0));
    let release = Arc::new(tokio::sync::Semaphore::new(0));
    let app = commerce::runtime::bounded(Router::new().route(
        "/",
        get({
            let active = active.clone();
            let release = release.clone();
            move || {
                let active = active.clone();
                let release = release.clone();
                async move {
                    active.fetch_add(1, Ordering::SeqCst);
                    let permit = release.acquire().await.unwrap();
                    permit.forget();
                    "ok"
                }
            }
        }),
    ));
    let tasks: Vec<_> = (0..32)
        .map(|_| {
            let app = app.clone();
            tokio::spawn(async move { scrape(&app, "/").await.0 })
        })
        .collect();
    tokio::time::timeout(std::time::Duration::from_secs(2), async {
        while active.load(Ordering::SeqCst) != 32 {
            tokio::task::yield_now().await;
        }
    })
    .await
    .unwrap();
    assert_eq!(scrape(&app, "/").await.0, 429);
    // Control-plane scrape remains available even when all business slots are occupied.
    assert!(
        scrape(&app, "/metrics")
            .await
            .1
            .contains("rustmall_http_rejected_total 1\n")
    );
    release.add_permits(32);
    for task in tasks {
        assert_eq!(task.await.unwrap(), 200);
    }
    assert!(
        scrape(&app, "/metrics")
            .await
            .1
            .contains("rustmall_http_requests_total 33\n")
    );
}
#[tokio::test]
async fn deadline_keeps_the_json_contract_and_is_counted() {
    let app = commerce::runtime::bounded(Router::new().route(
        "/",
        get(|| async { std::future::pending::<axum::http::StatusCode>().await }),
    ));
    let (status, body) = scrape(&app, "/").await;
    assert_eq!(status, 504);
    let value: serde_json::Value = serde_json::from_str(&body).unwrap();
    assert_eq!(value["code"], "DEADLINE_EXCEEDED");
    assert!(
        scrape(&app, "/metrics")
            .await
            .1
            .contains("rustmall_http_deadlines_total 1\n")
    );
}
