"""Read-only HTTPS readiness probe. No insecure bypass, no proxy environment.

Certificate verification is mandatory. --ca supplies a private trust bundle only
for this client process; it does not install trust into the OS or browser.
"""
import argparse,hashlib,http.client,json,ssl,urllib.parse
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--url',required=True)
p.add_argument('--ca')
a=p.parse_args();url=urllib.parse.urlsplit(a.url)
if url.scheme!='https' or not url.hostname or url.username or url.password or url.path not in ('','/') or url.query or url.fragment:
 p.error('HTTPS origin required, without credentials/path/query/fragment')
context=ssl.create_default_context(cafile=a.ca)
context.minimum_version=ssl.TLSVersion.TLSv1_2
connection=http.client.HTTPSConnection(url.hostname,url.port or 443,context=context,timeout=2)
try:
 connection.connect()
 protocol=connection.sock.version()
 certificate=connection.sock.getpeercert(binary_form=True)
 connection.request('GET','/readyz',headers={'Connection':'close'})
 response=connection.getresponse();response.read(4097)
 result={'status':response.status,'tls':protocol,'certificate_sha256':hashlib.sha256(certificate).hexdigest()}
 print(json.dumps(result))
 if response.status!=200:raise SystemExit('readiness not200')
finally:connection.close()
