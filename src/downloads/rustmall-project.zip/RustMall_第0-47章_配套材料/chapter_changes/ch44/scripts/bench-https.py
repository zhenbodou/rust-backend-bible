"""Bounded, read-only HTTPS GET observations with one reusable connection/worker.

Includes client waiting andTLS costs. Reports all statuses, never treats429/503
as successful business throughput. Closed-loop fixture, not a production SLO.
"""
import argparse,collections,concurrent.futures,http.client,json,os,ssl,threading,time,urllib.parse
from pathlib import Path
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--url',required=True)
p.add_argument('--ca',type=Path,required=True)
p.add_argument('--token-file',type=Path,required=True)
p.add_argument('--output',type=Path,required=True)
p.add_argument('--requests',type=int,default=120)
p.add_argument('--concurrency',type=int,default=8)
a=p.parse_args();url=urllib.parse.urlsplit(a.url)
if url.scheme!='https' or not url.hostname or url.username or url.password or url.path not in ('','/') or url.query or url.fragment:p.error('HTTPS origin without credentials/path required')
if not (1<=a.requests<=2000 and 1<=a.concurrency<=128):p.error('requests1..2000 concurrency1..128')
if a.output.exists():p.error('output already exists')
if a.token_file.stat().st_size>8192:p.error('token file too large')
token=a.token_file.read_text().strip()
if not token or any(c in token for c in '\r\n'):p.error('single token required')
context=ssl.create_default_context(cafile=str(a.ca));context.minimum_version=ssl.TLSVersion.TLSv1_2
local=threading.local();connections=[];lock=threading.Lock()
def one(_):
 if not hasattr(local,'connection'):
  local.connection=http.client.HTTPSConnection(url.hostname,url.port or 443,timeout=3,context=context)
  with lock:connections.append(local.connection)
 start=time.monotonic()
 try:
  local.connection.request('GET','/api/v1/products',headers={'Authorization':'Bearer '+token})
  response=local.connection.getresponse();data=response.read(65537)
  if len(data)>65536:raise ValueError('response too large')
  status=str(response.status)
 except (OSError,http.client.HTTPException,ValueError):
  local.connection.close();status='transport_error'
 return status,(time.monotonic()-start)*1000
started=time.monotonic()
try:
 with concurrent.futures.ThreadPoolExecutor(max_workers=a.concurrency) as pool:
  rows=list(pool.map(one,range(a.requests)))
finally:
 for connection in connections:connection.close()
elapsed=time.monotonic()-started;counts=collections.Counter(s for s,_ in rows)
times=sorted(t for _,t in rows)
def percentile(p):return times[max(0,min(len(times)-1,int((len(times)*p+99)//100)-1))]
report={'requests':a.requests,'concurrency':a.concurrency,'elapsed_seconds':elapsed,'status_counts':dict(counts),'all_response_rps':len(rows)/elapsed,'http200_rps':counts['200']/elapsed,'latency_ms_all_responses':{'p50':percentile(50),'p95':percentile(95),'p99':percentile(99),'max':max(times)},'scope':'closed-loop GET products, bounded samples, connection reuse per worker; no order capacity or production SLO claim'}
success_times=sorted(t for status,t in rows if status=='200')
if success_times:
 def successful_percentile(p):return success_times[max(0,min(len(success_times)-1,(len(success_times)*p+99)//100-1))]
 report['latency_ms_http200']={'p50':successful_percentile(50),'p95':successful_percentile(95),'p99':successful_percentile(99),'max':max(success_times)}
else:report['latency_ms_http200']=None
fd=os.open(a.output,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
with os.fdopen(fd,'w') as out:json.dump(report,out,indent=2);out.write('\n')
print(json.dumps(report))
