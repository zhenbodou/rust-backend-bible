"""Issue a NEW localhost leaf under the existing LAB CA. Does not modify old files.

The new directory contains no CA private key. Recreate only the TLS proxy with
its new secret mounts; this simple local procedure does not promise zero downtime.
"""
from pathlib import Path
import argparse,os,re,secrets,shutil,subprocess
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--ca-dir',type=Path,required=True)
p.add_argument('--output-dir',type=Path,required=True)
p.add_argument('--openssl',default='openssl')
a=p.parse_args();ca=a.ca_dir.resolve();out=a.output_dir.resolve()
exe=shutil.which(a.openssl)
if not exe:raise SystemExit('OpenSSL not found')
r=subprocess.run([exe,'version'],capture_output=True,text=True,timeout=5)
m=re.match(r'OpenSSL (\d+)\.',r.stdout)
if r.returncode or not m or int(m[1])<3:raise SystemExit('OpenSSL>=3 required')
for name in ['ca.pem','ca.key','server.cnf']:
 if not (ca/name).is_file():raise SystemExit('original lab CA directory required')
check=subprocess.run([exe,'x509','-in',str(ca/'ca.pem'),'-checkend',str(8*86400),'-noout'],capture_output=True,text=True)
if check.returncode:raise SystemExit('CA needs more than8days validity for this lab leaf')
os.umask(0o077);out.mkdir(mode=0o700)
def run(*args):
 r=subprocess.run([exe,*map(str,args)],cwd=out,capture_output=True,text=True)
 if r.returncode:raise RuntimeError('leaf rotation failed; incomplete new directory retained')
shutil.copyfile(ca/'ca.pem',out/'ca.pem')
run('req','-new','-newkey','rsa:3072','-noenc','-config',ca/'server.cnf','-keyout','server.key','-out','server.csr')
run('x509','-req','-in','server.csr','-CA',ca/'ca.pem','-CAkey',ca/'ca.key','-set_serial',str(secrets.randbits(127)+1),'-days','7','-sha256','-extfile',ca/'server.cnf','-extensions','server','-out','server.pem')
run('verify','-CAfile','ca.pem','-verify_hostname','localhost','server.pem')
for name in ['server.pem','server.key']:(out/name).chmod(0o444)
print('Created new local leaf under unchanged CA; old deployment and CA files untouched.')
