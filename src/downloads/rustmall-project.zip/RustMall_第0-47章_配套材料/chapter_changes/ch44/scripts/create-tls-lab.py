"""Create NEW local-only CA and server certificate. Never installs a trusted root.

Use an explicit --openssl executable if needed. Keep this private directory with
its deployment. Files mounted into a non-root container are readable only via
this0700 parent directory, as in chapter40; this is not an encrypted secret store.
"""
from pathlib import Path
import argparse,os,re,shutil,subprocess
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--output-dir',type=Path,required=True)
p.add_argument('--openssl',default='openssl')
a=p.parse_args();root=a.output_dir.resolve()
exe=shutil.which(a.openssl)
if not exe:raise SystemExit('OpenSSL executable not found')
version=subprocess.run([exe,'version'],capture_output=True,text=True,timeout=5)
match=re.match(r'OpenSSL (\d+)\.',version.stdout)
if version.returncode or not match or int(match[1])<3:
 raise SystemExit('OpenSSL3 or newer required; pass --openssl /absolute/path/to/openssl')
root.mkdir(mode=0o700)
os.umask(0o077)
def openssl(*args):
 result=subprocess.run([exe,*map(str,args)],cwd=root,text=True,capture_output=True)
 if result.returncode:raise RuntimeError('certificate generation failed; incomplete private directory retained')
(root/'ca.cnf').write_text('''[req]
distinguished_name=dn
x509_extensions=ca
prompt=no
[dn]
CN=RustMall44 Local Lab CA
[ca]
basicConstraints=critical,CA:TRUE,pathlen:0
keyUsage=critical,keyCertSign,cRLSign
subjectKeyIdentifier=hash
''')
(root/'server.cnf').write_text('''[req]
distinguished_name=dn
prompt=no
[dn]
CN=localhost
[server]
basicConstraints=critical,CA:FALSE
keyUsage=critical,digitalSignature,keyEncipherment
extendedKeyUsage=serverAuth
subjectAltName=DNS:localhost
subjectKeyIdentifier=hash
authorityKeyIdentifier=keyid,issuer
''')
openssl('req','-x509','-newkey','rsa:3072','-noenc','-sha256','-days','30','-config','ca.cnf','-keyout','ca.key','-out','ca.pem')
openssl('req','-new','-newkey','rsa:3072','-noenc','-config','server.cnf','-keyout','server.key','-out','server.csr')
openssl('x509','-req','-in','server.csr','-CA','ca.pem','-CAkey','ca.key','-CAcreateserial','-days','7','-sha256','-extfile','server.cnf','-extensions','server','-out','server.pem')
openssl('verify','-CAfile','ca.pem','-verify_hostname','localhost','server.pem')
for name in ['server.pem','server.key']:(root/name).chmod(0o444)
print('Created local-only CA and7-day localhost certificate. Root trust was NOT installed. Keep private files outside source control.')
