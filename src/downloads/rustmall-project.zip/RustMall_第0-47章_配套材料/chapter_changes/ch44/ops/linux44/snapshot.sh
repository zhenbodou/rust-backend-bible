#!/bin/sh
# Read-only container-local observations. Never reads environment or command-line secrets.
set -eu
printf 'kernel '
uname -r
for file in /proc/1/limits /sys/fs/cgroup/cpu.max /sys/fs/cgroup/cpu.stat /sys/fs/cgroup/memory.current /sys/fs/cgroup/memory.max /sys/fs/cgroup/memory.events /sys/fs/cgroup/pids.current /sys/fs/cgroup/pids.max; do
    if [ -r "$file" ]; then
        printf '\n%s\n' "$file"
        cat "$file"
    fi
done
count=0
for descriptor in /proc/1/fd/*; do
    if [ -e "$descriptor" ] || [ -L "$descriptor" ]; then count=$((count + 1)); fi
done
printf '\npid1_fd_count %s\n' "$count"
