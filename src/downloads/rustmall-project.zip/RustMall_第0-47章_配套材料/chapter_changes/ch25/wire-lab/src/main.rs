use prost::Message;

#[derive(Clone, PartialEq, Message)]
struct Brief {
    #[prost(int64, tag = "1")]
    id: i64,
    #[prost(string, tag = "2")]
    name: String,
}

fn main() -> Result<(), Box<dyn std::error::Error>> {
    let value = Brief {
        id: 150,
        name: "键盘".to_string(),
    };
    let bytes = value.encode_to_vec();
    println!("{bytes:02x?}");
    let decoded = Brief::decode(bytes.as_slice())?;
    assert_eq!(decoded, value);
    Ok(())
}
