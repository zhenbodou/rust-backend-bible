use contracts::catalog::{
    catalog_client::CatalogClient,
    catalog_server::{Catalog, CatalogServer},
    *,
};
use std::time::Duration;
use tokio_util::sync::CancellationToken;
use tonic::{
    Request, Response, Status,
    transport::{Endpoint, Server},
};

#[derive(Default)]
struct Demo;
#[tonic::async_trait]
impl Catalog for Demo {
    async fn get_product(
        &self,
        request: Request<GetProductRequest>,
    ) -> Result<Response<Product>, Status> {
        if request
            .metadata()
            .get("x-demo-token")
            .and_then(|v| v.to_str().ok())
            != Some("test-only")
        {
            return Err(Status::unauthenticated("demo token required"));
        }
        let id = request.into_inner().id;
        if id <= 0 {
            return Err(Status::invalid_argument("id must be positive"));
        }
        match id {
            1 => Ok(Response::new(Product {
                id: 1,
                name: "键盘".into(),
                price_cents: 19900,
                stock: 10,
            })),
            3 => std::future::pending().await,
            _ => Err(Status::not_found("product not found")),
        }
    }
    async fn list_products(
        &self,
        _: Request<ListProductsRequest>,
    ) -> Result<Response<ListProductsResponse>, Status> {
        Err(Status::unimplemented("transport demo"))
    }
    async fn create_product(
        &self,
        _: Request<CreateProductRequest>,
    ) -> Result<Response<Product>, Status> {
        Err(Status::unimplemented("transport demo"))
    }
    async fn update_product(
        &self,
        _: Request<UpdateProductRequest>,
    ) -> Result<Response<Product>, Status> {
        Err(Status::unimplemented("transport demo"))
    }
    async fn delist_product(
        &self,
        _: Request<GetProductRequest>,
    ) -> Result<Response<DelistProductResponse>, Status> {
        Err(Status::unimplemented("transport demo"))
    }
}
async fn start() -> (
    CatalogClient<tonic::transport::Channel>,
    CancellationToken,
    tokio::task::JoinHandle<()>,
) {
    let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
    let addr = listener.local_addr().unwrap();
    let token = CancellationToken::new();
    let shutdown = token.clone();
    let task = tokio::spawn(async move {
        Server::builder()
            .add_service(CatalogServer::new(Demo))
            .serve_with_incoming_shutdown(
                tokio_stream::wrappers::TcpListenerStream::new(listener),
                shutdown.cancelled_owned(),
            )
            .await
            .unwrap();
    });
    let channel = Endpoint::from_shared(format!("http://{addr}"))
        .unwrap()
        .connect_timeout(Duration::from_secs(2))
        .timeout(Duration::from_millis(150))
        .connect()
        .await
        .unwrap();
    (CatalogClient::new(channel), token, task)
}
fn request(id: i64, token: bool) -> Request<GetProductRequest> {
    let mut r = Request::new(GetProductRequest { id });
    r.set_timeout(Duration::from_millis(150));
    if token {
        r.metadata_mut()
            .insert("x-demo-token", "test-only".parse().unwrap());
    }
    r
}
#[tokio::test]
async fn unary_round_trip_keeps_integer_money() {
    let (mut client, token, task) = start().await;
    let value = client
        .get_product(request(1, true))
        .await
        .unwrap()
        .into_inner();
    assert_eq!((value.id, value.price_cents, value.stock), (1, 19900, 10));
    stop(token, task).await;
}
#[tokio::test]
async fn missing_identity_is_rejected() {
    let (mut client, token, task) = start().await;
    assert_eq!(
        client
            .get_product(request(1, false))
            .await
            .unwrap_err()
            .code(),
        tonic::Code::Unauthenticated
    );
    stop(token, task).await;
}
#[tokio::test]
async fn not_found_is_a_status_not_an_empty_product() {
    let (mut client, token, task) = start().await;
    assert_eq!(
        client
            .get_product(request(2, true))
            .await
            .unwrap_err()
            .code(),
        tonic::Code::NotFound
    );
    stop(token, task).await;
}
#[tokio::test]
async fn stalled_rpc_is_bounded_by_the_client() {
    let (mut client, token, task) = start().await;
    let result =
        tokio::time::timeout(Duration::from_secs(2), client.get_product(request(3, true))).await;
    let status = result
        .expect("outer two-second guard must not expire")
        .expect_err("stalled RPC must fail inside the transport budget");
    assert!(matches!(
        status.code(),
        tonic::Code::Cancelled | tonic::Code::DeadlineExceeded
    ));
    println!("bounded RPC status: {:?}", status.code());
    stop(token, task).await;
}

async fn stop(token: CancellationToken, mut task: tokio::task::JoinHandle<()>) {
    token.cancel();
    match tokio::time::timeout(Duration::from_secs(1), &mut task).await {
        Ok(result) => result.expect("demo server task must finish without panic"),
        Err(_) => {
            task.abort();
            match task.await {
                Ok(()) => {} // Completion may race with the abort request.
                Err(error) if error.is_cancelled() => {}
                Err(error) => panic!("demo server failed during cleanup: {error}"),
            }
        }
    }
}

#[tokio::test]
async fn invalid_id_is_distinct_from_an_absent_product() {
    let (mut client, token, task) = start().await;
    assert_eq!(
        client
            .get_product(request(0, true))
            .await
            .unwrap_err()
            .code(),
        tonic::Code::InvalidArgument
    );
    stop(token, task).await;
}
