use anyhow::{Context, Result};
use std::future::Future;
use std::time::Duration;
use tokio::time::{Instant, timeout_at};

pub fn migration_enabled(raw: Option<&str>) -> Result<bool> {
    match raw {
        None | Some("true") => Ok(true),
        Some("false") => Ok(false),
        Some(_) => anyhow::bail!("RUSTMALL_RUN_MIGRATIONS must be true or false"),
    }
}

pub struct ShutdownBudget {
    deadline: Instant,
}
impl ShutdownBudget {
    pub fn new(grace: Duration) -> Self {
        Self {
            deadline: Instant::now() + grace,
        }
    }
    pub async fn wait<F: Future>(&self, label: &str, future: F) -> Result<F::Output> {
        timeout_at(self.deadline, future)
            .await
            .with_context(|| format!("shutdown budget exhausted at {label}"))
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn migration_switch_is_strict() {
        assert!(migration_enabled(None).unwrap());
        assert!(migration_enabled(Some("true")).unwrap());
        assert!(!migration_enabled(Some("false")).unwrap());
        assert!(migration_enabled(Some("FALSE")).is_err());
        assert!(migration_enabled(Some("")).is_err());
    }
    #[tokio::test(start_paused = true)]
    async fn stages_share_one_deadline() {
        let budget = ShutdownBudget::new(Duration::from_secs(10));
        budget
            .wait("http", tokio::time::sleep(Duration::from_secs(8)))
            .await
            .unwrap();
        assert!(
            budget
                .wait("database", tokio::time::sleep(Duration::from_secs(3)))
                .await
                .is_err()
        );
    }
    #[tokio::test(start_paused = true)]
    async fn completed_stages_return_their_result() {
        let budget = ShutdownBudget::new(Duration::from_secs(10));
        assert_eq!(budget.wait("stage", async { 42 }).await.unwrap(), 42);
    }
}
