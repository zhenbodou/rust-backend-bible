"""仅生成本章实验凭据；不连接集群，不输出秘密，拒绝覆盖。"""
from pathlib import Path
import os
import secrets

password = secrets.token_urlsafe(36)
values = {
    "POSTGRES_PASSWORD": password,
    "DATABASE_URL": f"postgres://rustmall:{password}@postgres:5432/rustmall",
    "MIGRATION_DATABASE_URL": f"postgres://rustmall:{password}@postgres:5432/rustmall",
    "JWT_SECRET": secrets.token_urlsafe(48),
}
path = Path(".env.k8s")
fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
with os.fdopen(fd, "w") as output:
    for key, value in values.items():
        output.write(f"{key}={value}\n")
print("已生成 .env.k8s；请保持在 Git 与日志之外。")
