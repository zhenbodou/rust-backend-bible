# monolith 容器运行约定

- 阶段：第 20 章，业务与 AppState 沿用第 18 章。
- 构建上下文：RustMall workspace 根目录。
- 程序：/app/monolith。
- 静态配置目录：/app/config。
- 容器监听：0.0.0.0:8080。
- 存活接口：/health/live。
- 就绪接口：/health/ready。
- 探针：/app/rustmall-healthcheck，总等待预算两秒。
- 运行身份：10001:10001。
- 运行秘密：数据库与 JWT 配置在启动时注入，不进入镜像。
- 数据库迁移：按前文章节约定执行，不随意删除已有记录。
