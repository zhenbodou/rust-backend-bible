"""生成需要审查的 Argo CD Application；不连接集群或远端仓库。"""
import argparse
import json
import re
from urllib.parse import urlsplit

parser = argparse.ArgumentParser()
parser.add_argument("--repo", required=True, help="不包含令牌的 HTTPS Git 仓库地址")
parser.add_argument("--revision", required=True, help="经过审查的完整 Git 提交 SHA")
args = parser.parse_args()
try:
    url = urlsplit(args.repo)
except ValueError:
    parser.error("仓库 URL 无法解析")
if (url.scheme != "https" or not url.hostname or not url.path.strip("/")
        or url.username is not None or url.password is not None or url.query or url.fragment):
    parser.error("仓库必须是无内嵌凭据、无查询参数的 HTTPS 地址")
if not re.fullmatch(r"[0-9a-f]{40}", args.revision):
    parser.error("revision 必须是完整的 40 位小写十六进制 Git SHA")
application = {
    "apiVersion": "argoproj.io/v1alpha1",
    "kind": "Application",
    "metadata": {"name": "rustmall-lab", "namespace": "argocd"},
    "spec": {
        "project": "default",
        "source": {
            "repoURL": args.repo,
            "targetRevision": args.revision,
            "path": "charts/rustmall",
            "helm": {
                "releaseName": "book",
                "valueFiles": ["../../deploy/environments/lab.yaml"],
            },
        },
        "destination": {
            "server": "https://kubernetes.default.svc",
            "namespace": "rustmall-gitops",
        },
    },
}
# JSON 也是 YAML 可接受的表示；这里使用标准库避免额外模板替换与转义依赖。
print(json.dumps(application, ensure_ascii=False, indent=2))
