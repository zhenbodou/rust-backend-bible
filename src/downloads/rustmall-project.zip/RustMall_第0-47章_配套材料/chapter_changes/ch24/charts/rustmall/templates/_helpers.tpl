{{- define "rustmall.name" -}}
{{- if gt (len .Release.Name) 40 -}}
{{- fail "This teaching chart requires a release name of at most 40 characters" -}}
{{- end -}}
{{- printf "%s-rustmall" .Release.Name -}}
{{- end -}}
{{- define "rustmall.image" -}}
{{- if .Values.image.digest -}}
{{- printf "%s@%s" .Values.image.repository .Values.image.digest -}}
{{- else -}}
{{- printf "%s:%s" .Values.image.repository .Values.image.tag -}}
{{- end -}}
{{- end -}}
