CREATE TABLE inventory_reservations (
    saga_id UUID PRIMARY KEY,
    product_id BIGINT NOT NULL CHECK (product_id > 0),
    quantity INT NOT NULL CHECK (quantity BETWEEN 1 AND 999),
    unit_price_cents BIGINT NOT NULL CHECK (unit_price_cents >= 0),
    state TEXT NOT NULL CHECK (
        state IN ('pending', 'held', 'confirmed', 'released', 'rejected')
    ),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX inventory_reservations_held_idx
  ON inventory_reservations(updated_at, saga_id)
  WHERE state = 'held';
