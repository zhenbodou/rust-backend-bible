use crate::event::{Envelope, Snapshot, retry_delay_secs};
use serde::Serialize;
use sha2::{Digest, Sha256};
use sqlx::{PgPool, Postgres, Transaction, types::Json};
use uuid::Uuid;

#[derive(Debug, Clone, Serialize)]
pub struct Draft {
    pub name: String,
    pub price_cents: i64,
    pub stock: i32,
}
#[derive(sqlx::FromRow)]
struct Row {
    id: i64,
    name: String,
    price_cents: i64,
    stock: i32,
    listed: bool,
    revision: i64,
}
impl Row {
    fn event(self) -> Envelope {
        Envelope::new(
            Snapshot {
                id: self.id,
                name: self.name,
                price_cents: self.price_cents,
                stock: self.stock,
                listed: self.listed,
            },
            self.revision,
        )
    }
}
fn protocol(error: impl std::fmt::Display) -> sqlx::Error {
    sqlx::Error::Protocol(error.to_string())
}
pub async fn append(
    tx: &mut Transaction<'_, Postgres>,
    event: &Envelope,
) -> Result<(), sqlx::Error> {
    event.validate().map_err(protocol)?;
    sqlx::query(
        "INSERT INTO product_outbox(event_id,aggregate_id,revision,payload) VALUES($1,$2,$3,$4)",
    )
    .bind(event.event_id)
    .bind(event.aggregate_id)
    .bind(event.revision)
    .bind(Json(event))
    .execute(&mut **tx)
    .await?;
    Ok(())
}
async fn insert(
    tx: &mut Transaction<'_, Postgres>,
    draft: &Draft,
) -> Result<Envelope, sqlx::Error> {
    let row=sqlx::query_as::<_,Row>("INSERT INTO products(name,price_cents,stock) VALUES($1,$2,$3) RETURNING id,name,price_cents,stock,true AS listed,revision")
        .bind(&draft.name).bind(draft.price_cents).bind(draft.stock).fetch_one(&mut **tx).await?;
    let event = row.event();
    append(tx, &event).await?;
    Ok(event)
}
pub async fn create(pool: &PgPool, draft: &Draft) -> Result<Envelope, sqlx::Error> {
    let mut tx = pool.begin().await?;
    let event = insert(&mut tx, draft).await?;
    tx.commit().await?;
    Ok(event)
}
#[derive(Debug, thiserror::Error)]
pub enum UpdateError {
    #[error("product update cannot replace inventory; use inventory commands")]
    StockWriteForbidden,
    #[error(transparent)]
    Database(#[from] sqlx::Error),
}
pub async fn update(
    pool: &PgPool,
    id: i64,
    draft: &Draft,
) -> Result<Option<Envelope>, UpdateError> {
    let mut tx = pool.begin().await?;
    let current_stock: Option<i32> = sqlx::query_scalar(
        "SELECT stock FROM products WHERE id=$1 AND delisted_at IS NULL FOR UPDATE",
    )
    .bind(id)
    .fetch_optional(&mut *tx)
    .await?;
    let Some(current_stock) = current_stock else {
        return Ok(None);
    };
    if current_stock != draft.stock {
        return Err(UpdateError::StockWriteForbidden);
    }
    let row=sqlx::query_as::<_,Row>("UPDATE products SET name=$2,price_cents=$3,stock=$4,updated_at=now(),revision=revision+1 WHERE id=$1 AND delisted_at IS NULL RETURNING id,name,price_cents,stock,true AS listed,revision")
        .bind(id).bind(&draft.name).bind(draft.price_cents).bind(draft.stock).fetch_optional(&mut *tx).await?;
    let Some(row) = row else { return Ok(None) };
    let event = row.event();
    append(&mut tx, &event).await?;
    tx.commit().await?;
    Ok(Some(event))
}
pub async fn delist(pool: &PgPool, id: i64) -> Result<Option<Envelope>, sqlx::Error> {
    let mut tx = pool.begin().await?;
    let row=sqlx::query_as::<_,Row>("UPDATE products SET delisted_at=now(),updated_at=now(),revision=revision+1 WHERE id=$1 AND delisted_at IS NULL RETURNING id,name,price_cents,stock,false AS listed,revision")
        .bind(id).fetch_optional(&mut *tx).await?;
    let Some(row) = row else { return Ok(None) };
    let event = row.event();
    append(&mut tx, &event).await?;
    tx.commit().await?;
    Ok(Some(event))
}

#[derive(Debug, thiserror::Error)]
pub enum CommandError {
    #[error("idempotency key already used with different input")]
    Conflict,
    #[error(transparent)]
    Database(#[from] sqlx::Error),
}
pub async fn create_once(
    pool: &PgPool,
    actor: i64,
    key: Uuid,
    draft: &Draft,
) -> Result<Envelope, CommandError> {
    if actor <= 0 {
        return Err(protocol("trusted actor required").into());
    }
    let hash = Sha256::digest(serde_json::to_vec(draft).map_err(protocol)?).to_vec();
    let mut tx = pool.begin().await?;
    let inserted=sqlx::query("INSERT INTO product_create_receipts(actor_id,command_id,request_hash) VALUES($1,$2,$3) ON CONFLICT DO NOTHING")
        .bind(actor).bind(key).bind(&hash).execute(&mut *tx).await?.rows_affected();
    if inserted == 0 {
        let (stored_hash,response):(Vec<u8>,Option<Json<Envelope>>)=sqlx::query_as("SELECT request_hash,response FROM product_create_receipts WHERE actor_id=$1 AND command_id=$2")
            .bind(actor).bind(key).fetch_one(&mut *tx).await?;
        if stored_hash != hash {
            return Err(CommandError::Conflict);
        };
        let response = response
            .ok_or_else(|| protocol("incomplete command receipt"))?
            .0;
        tx.commit().await?;
        return Ok(response);
    }
    let event = insert(&mut tx, draft).await?;
    sqlx::query(
        "UPDATE product_create_receipts SET response=$3 WHERE actor_id=$1 AND command_id=$2",
    )
    .bind(actor)
    .bind(key)
    .bind(Json(&event))
    .execute(&mut *tx)
    .await?;
    tx.commit().await?;
    Ok(event)
}

#[derive(sqlx::FromRow)]
pub struct Lease {
    pub event_id: Uuid,
    pub payload: Json<Envelope>,
    pub attempts: i32,
    pub lease_token: Uuid,
}
pub async fn claim_one(pool: &PgPool) -> Result<Option<Lease>, sqlx::Error> {
    let token = Uuid::new_v4();
    sqlx::query_as::<_,Lease>(
        "WITH candidate AS (SELECT event_id FROM product_outbox WHERE delivered_at IS NULL AND next_attempt_at<=now() AND (leased_until IS NULL OR leased_until<now()) ORDER BY occurred_at,event_id FOR UPDATE SKIP LOCKED LIMIT 1) UPDATE product_outbox AS o SET lease_token=$1,leased_until=now()+interval '30 seconds',attempts=attempts+1 FROM candidate AS c WHERE o.event_id=c.event_id RETURNING o.event_id,o.payload,o.attempts,o.lease_token"
    ).bind(token).fetch_optional(pool).await
}
pub async fn delivered(pool: &PgPool, lease: &Lease) -> Result<bool, sqlx::Error> {
    Ok(sqlx::query("UPDATE product_outbox SET delivered_at=now(),lease_token=NULL,leased_until=NULL,last_error=NULL WHERE event_id=$1 AND lease_token=$2 AND delivered_at IS NULL")
        .bind(lease.event_id).bind(lease.lease_token).execute(pool).await?.rows_affected()==1)
}
pub async fn failed(pool: &PgPool, lease: &Lease, error: &str) -> Result<bool, sqlx::Error> {
    let bounded: String = error.chars().take(500).collect();
    Ok(sqlx::query("UPDATE product_outbox SET next_attempt_at=now()+($3::bigint*interval '1 second'),lease_token=NULL,leased_until=NULL,last_error=$4 WHERE event_id=$1 AND lease_token=$2 AND delivered_at IS NULL")
        .bind(lease.event_id).bind(lease.lease_token).bind(retry_delay_secs(lease.attempts)).bind(bounded)
        .execute(pool).await?.rows_affected()==1)
}
