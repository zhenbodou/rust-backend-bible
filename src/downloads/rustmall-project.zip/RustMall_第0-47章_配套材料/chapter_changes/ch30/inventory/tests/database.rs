use inventory::{
    Error, execute, find,
    model::{Action, Command, State},
};
use messaging::store::{self, Draft};
use sqlx::PgPool;
use uuid::Uuid;

async fn setup(pool: &PgPool, stock: i32) -> Command {
    for sql in [
        include_str!("../../services/catalog/migrations/0001_catalog.sql"),
        include_str!("../../services/catalog/migrations/0002_product_outbox.sql"),
        include_str!("../../services/catalog/migrations/0003_inventory_reservations.sql"),
    ] {
        sqlx::raw_sql(sql).execute(pool).await.unwrap();
    }
    let event = store::create(
        pool,
        &Draft {
            name: "机械键盘".into(),
            price_cents: 19900,
            stock,
        },
    )
    .await
    .unwrap();
    Command {
        saga_id: Uuid::new_v4(),
        product_id: event.aggregate_id,
        quantity: 1,
        unit_price_cents: 19900,
    }
}

async fn product(pool: &PgPool, id: i64) -> (i32, i64, i64) {
    sqlx::query_as(
        "SELECT stock,revision,(SELECT count(*) FROM product_outbox
         WHERE aggregate_id=$1) FROM products WHERE id=$1",
    )
    .bind(id)
    .fetch_one(pool)
    .await
    .unwrap()
}

#[sqlx::test(migrations = false)]
async fn reserve_retry_confirm_and_release_after_confirm(pool: PgPool) {
    let command = setup(&pool, 10).await;
    assert_eq!(
        execute(&pool, &command, Action::Reserve).await.unwrap(),
        State::Held
    );
    assert_eq!(
        execute(&pool, &command, Action::Reserve).await.unwrap(),
        State::Held
    );
    assert_eq!(product(&pool, command.product_id).await, (9, 2, 2));
    assert_eq!(
        execute(&pool, &command, Action::Confirm).await.unwrap(),
        State::Confirmed
    );
    assert_eq!(
        execute(&pool, &command, Action::Confirm).await.unwrap(),
        State::Confirmed
    );
    assert_eq!(
        execute(&pool, &command, Action::Release).await.unwrap(),
        State::Confirmed
    );
    assert_eq!(product(&pool, command.product_id).await, (9, 2, 2));
}

#[sqlx::test(migrations = false)]
async fn release_gives_back_exactly_once(pool: PgPool) {
    let command = setup(&pool, 10).await;
    execute(&pool, &command, Action::Reserve).await.unwrap();
    assert_eq!(
        execute(&pool, &command, Action::Release).await.unwrap(),
        State::Released
    );
    assert_eq!(
        execute(&pool, &command, Action::Release).await.unwrap(),
        State::Released
    );
    assert_eq!(
        execute(&pool, &command, Action::Reserve).await.unwrap(),
        State::Released
    );
    assert_eq!(product(&pool, command.product_id).await, (10, 3, 3));
}

#[sqlx::test(migrations = false)]
async fn cancellation_before_reserve_blocks_late_messages(pool: PgPool) {
    let command = setup(&pool, 10).await;
    assert_eq!(
        execute(&pool, &command, Action::Release).await.unwrap(),
        State::Released
    );
    assert_eq!(
        execute(&pool, &command, Action::Reserve).await.unwrap(),
        State::Released
    );
    assert_eq!(product(&pool, command.product_id).await, (10, 1, 1));
}

#[sqlx::test(migrations = false)]
async fn early_confirm_does_not_invent_a_reservation(pool: PgPool) {
    let command = setup(&pool, 10).await;
    assert_eq!(
        execute(&pool, &command, Action::Confirm).await.unwrap(),
        State::Released
    );
    assert_eq!(
        execute(&pool, &command, Action::Reserve).await.unwrap(),
        State::Released
    );
    assert_eq!(product(&pool, command.product_id).await, (10, 1, 1));
}

#[sqlx::test(migrations = false)]
async fn changed_identity_parameters_are_rejected(pool: PgPool) {
    let command = setup(&pool, 10).await;
    execute(&pool, &command, Action::Reserve).await.unwrap();
    for changed in [
        Command {
            quantity: 2,
            ..command.clone()
        },
        Command {
            product_id: command.product_id + 1,
            ..command.clone()
        },
        Command {
            unit_price_cents: 1,
            ..command.clone()
        },
    ] {
        assert!(matches!(
            execute(&pool, &changed, Action::Release).await,
            Err(Error::IdentityConflict)
        ));
    }
    assert_eq!(product(&pool, command.product_id).await, (9, 2, 2));
    assert_eq!(
        find(&pool, command.saga_id).await.unwrap().unwrap().state,
        "held"
    );
}

#[sqlx::test(migrations = false)]
async fn rejected_attempt_is_stable_after_replenishment(pool: PgPool) {
    let command = setup(&pool, 0).await;
    assert_eq!(
        execute(&pool, &command, Action::Reserve).await.unwrap(),
        State::Rejected
    );
    sqlx::query("UPDATE products SET stock=5 WHERE id=$1")
        .bind(command.product_id)
        .execute(&pool)
        .await
        .unwrap();
    assert_eq!(
        execute(&pool, &command, Action::Reserve).await.unwrap(),
        State::Rejected
    );
    assert_eq!(product(&pool, command.product_id).await.0, 5);
    let another = Command {
        saga_id: Uuid::new_v4(),
        ..command
    };
    assert_eq!(
        execute(&pool, &another, Action::Reserve).await.unwrap(),
        State::Held
    );
}

#[sqlx::test(migrations = false)]
async fn competing_orders_cannot_both_take_the_last_unit(pool: PgPool) {
    let first = setup(&pool, 1).await;
    let second = Command {
        saga_id: Uuid::new_v4(),
        ..first.clone()
    };
    let (a, b) = tokio::join!(
        execute(&pool, &first, Action::Reserve),
        execute(&pool, &second, Action::Reserve),
    );
    let results = [a.unwrap(), b.unwrap()];
    assert_eq!(results.iter().filter(|s| **s == State::Held).count(), 1);
    assert_eq!(results.iter().filter(|s| **s == State::Rejected).count(), 1);
    assert_eq!(product(&pool, first.product_id).await, (0, 2, 2));
}

#[sqlx::test(migrations = false)]
async fn concurrent_duplicate_reserve_has_one_effect(pool: PgPool) {
    let command = setup(&pool, 10).await;
    let (a, b) = tokio::join!(
        execute(&pool, &command, Action::Reserve),
        execute(&pool, &command, Action::Reserve),
    );
    assert_eq!((a.unwrap(), b.unwrap()), (State::Held, State::Held));
    assert_eq!(product(&pool, command.product_id).await, (9, 2, 2));
}

#[sqlx::test(migrations = false)]
async fn outbox_failure_rolls_back_stock_and_receipt(pool: PgPool) {
    let command = setup(&pool, 10).await;
    sqlx::query("ALTER TABLE product_outbox ADD CONSTRAINT fail_new_event CHECK (revision < 2)")
        .execute(&pool)
        .await
        .unwrap();
    assert!(matches!(
        execute(&pool, &command, Action::Reserve).await,
        Err(Error::Database(_))
    ));
    assert_eq!(product(&pool, command.product_id).await, (10, 1, 1));
    assert!(find(&pool, command.saga_id).await.unwrap().is_none());
    sqlx::query("ALTER TABLE product_outbox DROP CONSTRAINT fail_new_event")
        .execute(&pool)
        .await
        .unwrap();
    assert_eq!(
        execute(&pool, &command, Action::Reserve).await.unwrap(),
        State::Held
    );
}

#[sqlx::test(migrations = false)]
async fn price_change_or_delist_prevents_new_holds(pool: PgPool) {
    let command = setup(&pool, 10).await;
    let wrong_price = Command {
        unit_price_cents: 1,
        ..command.clone()
    };
    assert_eq!(
        execute(&pool, &wrong_price, Action::Reserve).await.unwrap(),
        State::Rejected
    );
    store::delist(&pool, command.product_id)
        .await
        .unwrap()
        .unwrap();
    let another = Command {
        saga_id: Uuid::new_v4(),
        ..command
    };
    assert_eq!(
        execute(&pool, &another, Action::Reserve).await.unwrap(),
        State::Rejected
    );
    assert_eq!(product(&pool, another.product_id).await, (10, 2, 2));
}

#[sqlx::test(migrations = false)]
async fn release_of_delisted_product_keeps_it_delisted(pool: PgPool) {
    let command = setup(&pool, 10).await;
    execute(&pool, &command, Action::Reserve).await.unwrap();
    store::delist(&pool, command.product_id)
        .await
        .unwrap()
        .unwrap();
    assert_eq!(
        execute(&pool, &command, Action::Release).await.unwrap(),
        State::Released
    );
    assert_eq!(product(&pool, command.product_id).await, (10, 4, 4));
    let listed: bool = sqlx::query_scalar(
        "SELECT (payload->'payload'->>'listed')::boolean FROM product_outbox
         WHERE aggregate_id=$1 ORDER BY revision DESC LIMIT 1",
    )
    .bind(command.product_id)
    .fetch_one(&pool)
    .await
    .unwrap();
    assert!(!listed);
}

#[sqlx::test(migrations = false)]
async fn invalid_inputs_never_create_receipts(pool: PgPool) {
    let command = setup(&pool, 10).await;
    for bad in [
        Command {
            saga_id: Uuid::nil(),
            ..command.clone()
        },
        Command {
            product_id: 0,
            ..command.clone()
        },
        Command {
            quantity: 0,
            ..command.clone()
        },
        Command {
            quantity: 1000,
            ..command.clone()
        },
        Command {
            unit_price_cents: -1,
            ..command.clone()
        },
    ] {
        assert!(matches!(
            execute(&pool, &bad, Action::Reserve).await,
            Err(Error::InvalidInput)
        ));
    }
    let count: i64 = sqlx::query_scalar("SELECT count(*) FROM inventory_reservations")
        .fetch_one(&pool)
        .await
        .unwrap();
    assert_eq!(count, 0);
}

#[sqlx::test(migrations = false)]
async fn missing_product_cancellation_still_records_a_fence(pool: PgPool) {
    let command = setup(&pool, 10).await;
    let missing = Command {
        product_id: 99999,
        ..command
    };
    assert!(find(&pool, missing.saga_id).await.unwrap().is_none());
    assert_eq!(
        execute(&pool, &missing, Action::Release).await.unwrap(),
        State::Released
    );
    assert_eq!(
        execute(&pool, &missing, Action::Reserve).await.unwrap(),
        State::Released
    );
}

#[sqlx::test(migrations = false)]
async fn lock_timeout_can_be_retried_without_a_new_key(pool: PgPool) {
    let command = setup(&pool, 10).await;
    let mut blocker = pool.begin().await.unwrap();
    sqlx::query("SELECT id FROM products WHERE id=$1 FOR UPDATE")
        .bind(command.product_id)
        .execute(&mut *blocker)
        .await
        .unwrap();
    let error = execute(&pool, &command, Action::Reserve).await.unwrap_err();
    assert!(matches!(error, Error::Database(_)));
    blocker.rollback().await.unwrap();
    assert!(find(&pool, command.saga_id).await.unwrap().is_none());
    assert_eq!(
        execute(&pool, &command, Action::Reserve).await.unwrap(),
        State::Held
    );
}

#[sqlx::test(migrations = false)]
async fn release_overflow_preserves_the_held_receipt(pool: PgPool) {
    let command = setup(&pool, 10).await;
    execute(&pool, &command, Action::Reserve).await.unwrap();
    // Deliberately corrupt the stock accounting to exercise rollback.
    sqlx::query("UPDATE products SET stock=2147483647 WHERE id=$1")
        .bind(command.product_id)
        .execute(&pool)
        .await
        .unwrap();
    assert!(matches!(
        execute(&pool, &command, Action::Release).await,
        Err(Error::Database(_))
    ));
    assert_eq!(
        find(&pool, command.saga_id).await.unwrap().unwrap().state,
        "held"
    );
    assert_eq!(product(&pool, command.product_id).await, (i32::MAX, 2, 2));
}

#[sqlx::test(migrations = false)]
async fn legacy_product_update_cannot_replace_held_inventory(pool: PgPool) {
    let command = setup(&pool, 10).await;
    execute(&pool, &command, Action::Reserve).await.unwrap();
    let stale = Draft {
        name: "新名称".into(),
        price_cents: 19900,
        stock: 10,
    };
    assert!(matches!(
        store::update(&pool, command.product_id, &stale).await,
        Err(store::UpdateError::StockWriteForbidden)
    ));
    assert_eq!(product(&pool, command.product_id).await, (9, 2, 2));
    let metadata = Draft { stock: 9, ..stale };
    store::update(&pool, command.product_id, &metadata)
        .await
        .unwrap()
        .unwrap();
    assert_eq!(product(&pool, command.product_id).await, (9, 3, 3));
    execute(&pool, &command, Action::Release).await.unwrap();
    assert_eq!(product(&pool, command.product_id).await, (10, 4, 4));
}
