use uuid::Uuid;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Action {
    Reserve,
    Confirm,
    Release,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum State {
    Pending,
    Held,
    Confirmed,
    Released,
    Rejected,
}

impl State {
    pub fn as_str(self) -> &'static str {
        match self {
            Self::Pending => "pending",
            Self::Held => "held",
            Self::Confirmed => "confirmed",
            Self::Released => "released",
            Self::Rejected => "rejected",
        }
    }

    pub fn from_stored(value: &str) -> Result<Self, crate::Error> {
        match value {
            "pending" => Ok(Self::Pending),
            "held" => Ok(Self::Held),
            "confirmed" => Ok(Self::Confirmed),
            "released" => Ok(Self::Released),
            "rejected" => Ok(Self::Rejected),
            _ => Err(crate::Error::CorruptState),
        }
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Command {
    pub saga_id: Uuid,
    pub product_id: i64,
    pub quantity: i32,
    pub unit_price_cents: i64,
}

impl Command {
    pub fn validate(&self) -> Result<(), crate::Error> {
        if self.saga_id.is_nil()
            || self.product_id <= 0
            || !(1..=999).contains(&self.quantity)
            || self.unit_price_cents < 0
        {
            return Err(crate::Error::InvalidInput);
        }
        Ok(())
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Step {
    TryHold,
    GiveBack,
    Store(State),
}

pub fn decide(state: State, action: Action) -> Step {
    match (state, action) {
        (State::Pending, Action::Reserve) => Step::TryHold,
        (State::Pending, Action::Confirm | Action::Release) => Step::Store(State::Released),
        (State::Held, Action::Confirm) => Step::Store(State::Confirmed),
        (State::Held, Action::Release) => Step::GiveBack,
        _ => Step::Store(state),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn every_terminal_state_is_stable() {
        for state in [State::Confirmed, State::Released, State::Rejected] {
            for action in [Action::Reserve, Action::Confirm, Action::Release] {
                assert_eq!(decide(state, action), Step::Store(state));
            }
        }
    }

    #[test]
    fn cancellation_before_reservation_leaves_a_fence() {
        assert_eq!(
            decide(State::Pending, Action::Release),
            Step::Store(State::Released)
        );
        assert_eq!(
            decide(State::Released, Action::Reserve),
            Step::Store(State::Released)
        );
        assert_eq!(
            decide(State::Pending, Action::Confirm),
            Step::Store(State::Released)
        );
    }

    #[test]
    fn holding_and_settlement_are_different_effects() {
        assert_eq!(decide(State::Pending, Action::Reserve), Step::TryHold);
        assert_eq!(
            decide(State::Held, Action::Reserve),
            Step::Store(State::Held)
        );
        assert_eq!(
            decide(State::Held, Action::Confirm),
            Step::Store(State::Confirmed)
        );
        assert_eq!(decide(State::Held, Action::Release), Step::GiveBack);
    }
}
