-- Empty-cluster bootstrap only. Passwords come from fixed mounted files, never Git.
\set ON_ERROR_STOP on
REVOKE ALL ON DATABASE postgres FROM PUBLIC;
REVOKE ALL ON DATABASE template1 FROM PUBLIC;
\set migrate_catalog_pw `cat /run/secrets/migrate_catalog_password`
CREATE ROLE migrate_catalog LOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE NOREPLICATION NOBYPASSRLS NOINHERIT PASSWORD :'migrate_catalog_pw';
\set app_catalog_pw `cat /run/secrets/app_catalog_password`
CREATE ROLE app_catalog LOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE NOREPLICATION NOBYPASSRLS NOINHERIT PASSWORD :'app_catalog_pw';
\set relay_catalog_pw `cat /run/secrets/relay_catalog_password`
CREATE ROLE relay_catalog LOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE NOREPLICATION NOBYPASSRLS NOINHERIT PASSWORD :'relay_catalog_pw';
\set inventory_admin_pw `cat /run/secrets/inventory_admin_password`
CREATE ROLE inventory_admin LOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE NOREPLICATION NOBYPASSRLS NOINHERIT PASSWORD :'inventory_admin_pw';
CREATE DATABASE rustmall_catalog OWNER migrate_catalog;
REVOKE ALL ON DATABASE rustmall_catalog FROM PUBLIC;
GRANT CONNECT ON DATABASE rustmall_catalog TO app_catalog;
GRANT CONNECT ON DATABASE rustmall_catalog TO relay_catalog;
GRANT CONNECT ON DATABASE rustmall_catalog TO inventory_admin;
\set migrate_users_pw `cat /run/secrets/migrate_users_password`
CREATE ROLE migrate_users LOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE NOREPLICATION NOBYPASSRLS NOINHERIT PASSWORD :'migrate_users_pw';
\set app_users_pw `cat /run/secrets/app_users_password`
CREATE ROLE app_users LOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE NOREPLICATION NOBYPASSRLS NOINHERIT PASSWORD :'app_users_pw';
CREATE DATABASE rustmall_users OWNER migrate_users;
REVOKE ALL ON DATABASE rustmall_users FROM PUBLIC;
GRANT CONNECT ON DATABASE rustmall_users TO app_users;
\set migrate_payments_pw `cat /run/secrets/migrate_payments_password`
CREATE ROLE migrate_payments LOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE NOREPLICATION NOBYPASSRLS NOINHERIT PASSWORD :'migrate_payments_pw';
\set app_payments_pw `cat /run/secrets/app_payments_password`
CREATE ROLE app_payments LOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE NOREPLICATION NOBYPASSRLS NOINHERIT PASSWORD :'app_payments_pw';
CREATE DATABASE rustmall_payments OWNER migrate_payments;
REVOKE ALL ON DATABASE rustmall_payments FROM PUBLIC;
GRANT CONNECT ON DATABASE rustmall_payments TO app_payments;
\set migrate_orders_pw `cat /run/secrets/migrate_orders_password`
CREATE ROLE migrate_orders LOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE NOREPLICATION NOBYPASSRLS NOINHERIT PASSWORD :'migrate_orders_pw';
\set app_orders_pw `cat /run/secrets/app_orders_password`
CREATE ROLE app_orders LOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE NOREPLICATION NOBYPASSRLS NOINHERIT PASSWORD :'app_orders_pw';
\set worker_orders_pw `cat /run/secrets/worker_orders_password`
CREATE ROLE worker_orders LOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE NOREPLICATION NOBYPASSRLS NOINHERIT PASSWORD :'worker_orders_pw';
CREATE DATABASE rustmall_orders OWNER migrate_orders;
REVOKE ALL ON DATABASE rustmall_orders FROM PUBLIC;
GRANT CONNECT ON DATABASE rustmall_orders TO app_orders;
GRANT CONNECT ON DATABASE rustmall_orders TO worker_orders;
\set migrate_projection_pw `cat /run/secrets/migrate_projection_password`
CREATE ROLE migrate_projection LOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE NOREPLICATION NOBYPASSRLS NOINHERIT PASSWORD :'migrate_projection_pw';
\set app_projection_pw `cat /run/secrets/app_projection_password`
CREATE ROLE app_projection LOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE NOREPLICATION NOBYPASSRLS NOINHERIT PASSWORD :'app_projection_pw';
CREATE DATABASE rustmall_projection OWNER migrate_projection;
REVOKE ALL ON DATABASE rustmall_projection FROM PUBLIC;
GRANT CONNECT ON DATABASE rustmall_projection TO app_projection;
\set migrate_rebuild_pw `cat /run/secrets/migrate_rebuild_password`
CREATE ROLE migrate_rebuild LOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE NOREPLICATION NOBYPASSRLS NOINHERIT PASSWORD :'migrate_rebuild_pw';
\set app_rebuild_pw `cat /run/secrets/app_rebuild_password`
CREATE ROLE app_rebuild LOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE NOREPLICATION NOBYPASSRLS NOINHERIT PASSWORD :'app_rebuild_pw';
CREATE DATABASE rustmall_rebuild OWNER migrate_rebuild;
REVOKE ALL ON DATABASE rustmall_rebuild FROM PUBLIC;
GRANT CONNECT ON DATABASE rustmall_rebuild TO app_rebuild;
