#![cfg(unix)]
use std::{
    fs::{self, OpenOptions},
    io::Write,
    os::unix::fs::OpenOptionsExt,
    process::Command,
    sync::atomic::{AtomicU64, Ordering},
};
static NEXT: AtomicU64 = AtomicU64::new(0);
struct File(std::path::PathBuf);
impl File {
    fn new(bytes: &[u8]) -> Self {
        let path = std::env::temp_dir().join(format!(
            "rustmall-launch-{}-{}",
            std::process::id(),
            NEXT.fetch_add(1, Ordering::SeqCst)
        ));
        let mut f = OpenOptions::new()
            .write(true)
            .create_new(true)
            .mode(0o600)
            .open(&path)
            .unwrap();
        f.write_all(bytes).unwrap();
        Self(path)
    }
}
impl Drop for File {
    fn drop(&mut self) {
        let _ = fs::remove_file(&self.0);
    }
}
fn launch() -> Command {
    let mut c = Command::new(env!("CARGO_BIN_EXE_rustmall-launch"));
    c.env_clear();
    c
}
#[test]
fn file_secret_is_loaded_and_file_variable_removed_before_exec() {
    let f = File::new(b"fixture-value\n");
    let result = launch()
        .env("JWT_SECRET_FILE", &f.0)
        .args([
            "/bin/sh",
            "-ec",
            "test \"$JWT_SECRET\" = fixture-value; test -z \"${JWT_SECRET_FILE+x}\"",
        ])
        .output()
        .unwrap();
    assert!(result.status.success());
    assert!(result.stdout.is_empty());
}
#[test]
fn launcher_execs_arguments_as_data_without_a_shell() {
    let text = "literal $(should-not-run); `also-not-run`";
    assert!(
        launch()
            .args(["/bin/test", text, "=", text])
            .status()
            .unwrap()
            .success()
    );
}
#[test]
fn invalid_or_ambiguous_secrets_fail_before_child_and_hide_values() {
    for bytes in [
        b"\n".to_vec(),
        b"fixture-value\nsecond-line".to_vec(),
        vec![b'x'; 16 * 1024 + 1],
    ] {
        let f = File::new(&bytes);
        let result = launch()
            .env("JWT_SECRET_FILE", &f.0)
            .args(["/bin/sh", "-c", "exit 0"])
            .output()
            .unwrap();
        assert!(!result.status.success());
        assert!(!String::from_utf8_lossy(&result.stderr).contains("fixture-value"));
    }
    let f = File::new(b"file-fixture");
    let result = launch()
        .env("JWT_SECRET_FILE", &f.0)
        .env("JWT_SECRET", "env-fixture")
        .args(["/bin/sh", "-c", "exit 0"])
        .output()
        .unwrap();
    assert!(!result.status.success());
    assert!(!String::from_utf8_lossy(&result.stderr).contains("env-fixture"));
}
