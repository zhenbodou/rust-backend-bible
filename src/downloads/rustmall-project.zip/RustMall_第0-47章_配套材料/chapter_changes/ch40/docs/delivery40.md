# 第40章交付实验：把同一个项目装进容器

第39章的订单、支付、库存、用户、Outbox、投影、观测和治理代码继续使用。这个配置创建独立的新实验数据集，不会导入第36章的原生实验数据。应用镜像是一份，运行角色由启动参数决定。

## 先理解三个阶段

1. 构建阶段把锁定依赖的Rust源码编译为Linux程序。编译工具只存在于构建层。
2. 初始化阶段由六个数据库迁移账号建表，再以显式列级授权把运行时权限发给业务账号。迁移失败时业务角色不能提前启动。
3. 运行阶段十个角色使用同一镜像，凭据从单独文件注入。应用以10001身份运行，只读根文件系统；需要临时文件时使用受限的临时目录。

不能把“容器正在运行”当作“下单正确”。本章验收既检查探针，也检查真实HTTP、持久账、事件和越权操作。

## 在新目录启动

需要可运行Linux容器的Docker和Compose插件，且本机18086端口空闲。在本检查点根目录执行：

```sh
docker build --tag rustmall/book:ch40-candidate .
python3 scripts/create-delivery-env.py

docker compose --env-file .delivery.local/compose.env \
  -f deploy/delivery40/compose.yaml config --quiet

docker compose --env-file .delivery.local/compose.env \
  -f deploy/delivery40/compose.yaml up -d --wait --wait-timeout 240
```

首次构建要下载编译器、系统包和依赖。`create-delivery-env.py`拒绝覆盖已有目录；再次启动直接使用原配置。不要为了重启服务重新生成凭据，也不要把私有目录提交到版本控制。

浏览器或HTTP客户端访问 `http://127.0.0.1:18086`。唯一发布到宿主机的业务端口属于edge；内部HTTP服务、gRPC、数据库、Redis、Kafka和指标端点不发布到宿主机。edge接入前端和内部两张网络，否则内部网络隔离会导致其宿主机映射也无法正常访问。

查看状态：

```sh
docker compose --env-file .delivery.local/compose.env \
  -f deploy/delivery40/compose.yaml ps --all
```

迁移和授权任务成功后退出0是正常现象，不能给它们配置无限重启策略。worker/relay/投影的指标探针只证明进程仍响应；业务是否推进还要看订单、Outbox最老年龄和投影对账。

## 完整验收应使用单独的临时数据集

```sh
python3 scripts/check-delivery.py \
  --image rustmall/book:ch40-candidate \
  --report-dir /tmp/rustmall-delivery40-report
```

脚本生成随机Compose项目名和私有临时凭据。它执行真实注册、登录、管理员测试夹具设置、商品创建幂等重放、下单、库存调整、下架、两套投影收敛和注销。付款效果必须恰好一条，重复POST不能创建新订单；商品资料修改仍成功，绝对库存覆盖必须返回409。

脚本还实际执行九条本应失败的SQL，验证用户不能自升管理员、订单API不能直接改终态、worker不能创建订单、relay不能改事件内容或商品库存、支付账号不能删审计、投影账号不能删数据或改消费身份。仅在YAML里写账号名不能证明权限有效。

验收用管理员在隔离库里设置测试用户角色，这是测试夹具，不是业务接口能力。脚本结束清理自己创建的卷和容器，输出脱敏报告。脚本固定使用18086，因此不要与手动实验同时运行；先停止手动实验但保留卷，再执行验收。

## 凭据与权限边界

主目录和secrets目录权限为0700，秘密文件0444。Compose文件秘密实际以单文件绑定挂载；宿主机上的文件拥有者不会自动转换成容器10001。内部文件可读配合宿主机私有目录，使非root容器能读取特定挂载文件。这个实验并不提供加密存储，宿主机管理员和拥有容器管理权的人仍能读取它们。

`rustmall-launch`仅识别明确列出的`*_FILE`变量；拒绝同一变量同时给值和文件、目录、空文件、多行、NUL和超过16KiB内容。启动时读取文件后设置子进程变量，移除文件变量，然后直接exec程序。它不会把参数拼接为shell命令，也不会在报错时打印秘密值。进程环境仍属于敏感信息。

数据库角色分为迁移所有者和业务运行者。新表不会自动获得宽泛权限；以后增加迁移时，要一并核对`permissions.sql`。Redis关闭默认用户，用户服务仅访问自己的键前缀和必要命令，监控账号只有探测权限。

## CI与发布的因果关系

质量任务运行格式、Clippy、全workspace测试、被显式选择的容器测试及密码实验。镜像任务必须等待质量任务成功；PR也构建并执行完整容器验收。只有main分支push触发发布步骤。

`ci-image-smoke.sh`构建一次，验收记录保存十个实际运行容器共同使用的image ID；发布步骤给这个ID加上提交号标签后推送，不再次构建。注册表返回的digest与本地image ID含义不同：部署清单最终应记录注册表digest，不能把本地ID冒充可拉取的远端digest。仓库地址由当前GitHub仓库产生，不在书中假造一个可用账号。

参考：[GitHub任务依赖](https://docs.github.com/en/actions/how-tos/write-workflows/choose-what-workflows-do/use-jobs)、[Docker镜像推送](https://docs.docker.com/reference/cli/docker/image/push/)。此处描述配置语义；本地容器验收通过不等于远端Actions已经运行或镜像已发布。

## 停止、保留与销毁

暂时停止而保留数据库卷：

```sh
docker compose --env-file .delivery.local/compose.env \
  -f deploy/delivery40/compose.yaml down
```

只有明确放弃这套实验数据时，才在该命令上添加`--volumes`。重建容器不是备份；删除卷后无法靠应用镜像恢复付款账和订单账。

## 当前证据范围

本地已实际构建Linux arm64镜像，并通过十角色完整链路、六库迁移和权限检查。当前已完成单节点Kind 0.33.0、Kubernetes 1.36.4与Helm 4.3.1实际部署、迁移阻断、配置升级失败回滚与依赖故障探针验收。没有远端Actions、注册表发布、Argo实际同步和多节点高可用的执行证据。默认kindnet不能证明NetworkPolicy被执行。不能将本文件当作整章或全书已经完稿的声明。

本机完整集群实验入口（需kind、kubectl、helm和可运行Linux容器的Docker）：

```sh
python3 scripts/check-kubernetes.py --kind kind --helm helm \
  --image rustmall/book:ch40-candidate \
  --report-dir /tmp/rustmall-kubernetes40-report
```

它使用随机集群名和独立kubeconfig，建立并清理本次基础设施及数据卷，不修改默认集群配置。仍使用18086，不能与其他本章实验并行。

若本地DockerHub的Rust认证下载超时，可使用已经实测的同版本官方公开ECR镜像：

```sh
docker build --build-arg RUST_IMAGE=public.ecr.aws/docker/library/rust:1.92.0-bookworm \
  --tag rustmall/book:ch40-candidate .
```

这是构建源选择，不更改Rust版本或绕过测试。CI包装脚本也接受可选RUSTMALL_RUST_IMAGE构建镜像参数；本地模拟runner已经按此完成构建及七组容器验收，未登录或推送远端。其他依赖镜像仍需要可访问的可信来源。
