-- Apply after all six migrations. New objects need an explicit permission review.
\set ON_ERROR_STOP on
\connect rustmall_catalog
REVOKE ALL ON SCHEMA public FROM PUBLIC;
GRANT USAGE ON SCHEMA public TO app_catalog,relay_catalog,inventory_admin;
GRANT SELECT ON products,product_outbox,product_create_receipts,inventory_reservations TO app_catalog;
GRANT INSERT(name,price_cents,stock) ON products TO app_catalog;
GRANT UPDATE(name,price_cents,stock,revision,delisted_at,updated_at) ON products TO app_catalog;
GRANT USAGE,SELECT ON SEQUENCE products_id_seq TO app_catalog;
GRANT INSERT(event_id,aggregate_id,revision,payload) ON product_outbox TO app_catalog;
GRANT INSERT(actor_id,command_id,request_hash) ON product_create_receipts TO app_catalog;
GRANT UPDATE(response) ON product_create_receipts TO app_catalog;
GRANT INSERT(saga_id,product_id,quantity,unit_price_cents,state) ON inventory_reservations TO app_catalog;
GRANT UPDATE(state,updated_at) ON inventory_reservations TO app_catalog;
GRANT SELECT ON product_outbox TO relay_catalog;
GRANT UPDATE(attempts,next_attempt_at,lease_token,leased_until,delivered_at,last_error) ON product_outbox TO relay_catalog;
GRANT SELECT ON products,product_outbox,inventory_reservations,inventory_adjustments TO inventory_admin;
GRANT UPDATE(stock,revision,updated_at) ON products TO inventory_admin;
GRANT INSERT(event_id,aggregate_id,revision,payload) ON product_outbox TO inventory_admin;
GRANT INSERT(command_id,product_id,delta,actor_id,reason,outcome) ON inventory_adjustments TO inventory_admin;
GRANT UPDATE(outcome,before_stock,after_stock) ON inventory_adjustments TO inventory_admin;
\connect rustmall_users
REVOKE ALL ON SCHEMA public FROM PUBLIC;
GRANT USAGE ON SCHEMA public TO app_users;
GRANT SELECT ON users,sessions TO app_users;
GRANT INSERT(username,password_hash) ON users TO app_users;
GRANT USAGE,SELECT ON SEQUENCE users_id_seq TO app_users;
GRANT INSERT(jti,user_id,expires_at) ON sessions TO app_users;
GRANT UPDATE(revoked_at) ON sessions TO app_users;
\connect rustmall_payments
REVOKE ALL ON SCHEMA public FROM PUBLIC;
GRANT USAGE ON SCHEMA public TO app_payments;
GRANT SELECT ON payments TO app_payments;
GRANT INSERT(saga_id,actor_id,amount,state) ON payments TO app_payments;
GRANT UPDATE(state,updated_at) ON payments TO app_payments;
GRANT INSERT(effect_id,saga_id,kind,amount) ON payment_effects TO app_payments;
\connect rustmall_orders
REVOKE ALL ON SCHEMA public FROM PUBLIC;
GRANT USAGE ON SCHEMA public TO app_orders,worker_orders;
GRANT SELECT ON orders TO app_orders,worker_orders;
GRANT INSERT(id,actor_id,request_key,product_id,quantity,unit_price,amount) ON orders TO app_orders;
GRANT UPDATE(state,attempts,next_attempt,lease_token,leased_until,last_error,updated_at) ON orders TO worker_orders;
GRANT SELECT,INSERT ON order_transitions TO worker_orders;
GRANT USAGE,SELECT ON SEQUENCE order_transitions_id_seq TO worker_orders;
\connect rustmall_projection
REVOKE ALL ON SCHEMA public FROM PUBLIC;
GRANT USAGE ON SCHEMA public TO app_projection;
GRANT SELECT ON consumer_inbox,catalog_view,projection_identity TO app_projection;
GRANT INSERT(consumer_name,event_id,payload_hash) ON consumer_inbox TO app_projection;
GRANT INSERT(singleton,consumer_name) ON projection_identity TO app_projection;
GRANT INSERT(product_id,revision,payload) ON catalog_view TO app_projection;
GRANT UPDATE(revision,payload,updated_at) ON catalog_view TO app_projection;
\connect rustmall_rebuild
REVOKE ALL ON SCHEMA public FROM PUBLIC;
GRANT USAGE ON SCHEMA public TO app_rebuild;
GRANT SELECT ON consumer_inbox,catalog_view,projection_identity TO app_rebuild;
GRANT INSERT(consumer_name,event_id,payload_hash) ON consumer_inbox TO app_rebuild;
GRANT INSERT(singleton,consumer_name) ON projection_identity TO app_rebuild;
GRANT INSERT(product_id,revision,payload) ON catalog_view TO app_rebuild;
GRANT UPDATE(revision,payload,updated_at) ON catalog_view TO app_rebuild;
