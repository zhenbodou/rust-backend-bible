{{- define "rustmall.name" -}}
{{- if and .Values.pdb.enabled (lt (int .Values.replicas) 2) }}{{ fail "PDB minAvailable=1 requires at least two replicas in this checkpoint" }}{{ end -}}
{{- if gt (len .Release.Name) 30 -}}{{ fail "release name must have at most 30 characters" }}{{- end -}}
{{- printf "%s-rustmall" .Release.Name -}}
{{- end -}}
{{- define "rustmall.image" -}}
{{- if and .Values.image.requireDigest (not .Values.image.digest) -}}{{ fail "a tested registry digest is required" }}{{- end -}}
{{- if .Values.image.digest -}}
{{- printf "%s@%s" .Values.image.repository .Values.image.digest -}}
{{- else -}}
{{- printf "%s:%s" .Values.image.repository .Values.image.tag -}}
{{- end -}}
{{- end -}}
{{- define "rustmall.podSecurity" -}}
automountServiceAccountToken: false
terminationGracePeriodSeconds: {{ .Values.shutdownGraceSeconds }}
securityContext:
  runAsNonRoot: true
  runAsUser: 10001
  runAsGroup: 10001
  fsGroup: 10001
  seccompProfile:
    type: RuntimeDefault
{{- end -}}
{{- define "rustmall.containerSecurity" -}}
allowPrivilegeEscalation: false
readOnlyRootFilesystem: true
capabilities:
  drop: [ALL]
{{- end -}}
{{- define "rustmall.hook" -}}
{{- if eq .root.Values.controller "argocd" }}
argocd.argoproj.io/hook: PreSync
argocd.argoproj.io/sync-wave: {{ .weight | quote }}
argocd.argoproj.io/hook-delete-policy: BeforeHookCreation,HookSucceeded
{{- else }}
helm.sh/hook: pre-install,pre-upgrade
helm.sh/hook-weight: {{ .weight | quote }}
helm.sh/hook-delete-policy: before-hook-creation,hook-succeeded
{{- end }}
{{- end -}}
