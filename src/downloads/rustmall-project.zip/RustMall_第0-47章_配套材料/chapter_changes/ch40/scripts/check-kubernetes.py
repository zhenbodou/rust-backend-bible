"""Isolated real Kind/Helm verification of checkpoint40; never uses user's kubeconfig."""
from pathlib import Path
import argparse,json,os,re,secrets,subprocess,tempfile,time,urllib.request,urllib.error,urllib.parse,uuid
stage=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--kind',default='kind')
p.add_argument('--helm',default='helm')
p.add_argument('--image',default='rustmall/book:ch40-candidate')
p.add_argument('--report-dir',type=Path,required=True)
args=p.parse_args()
if not re.fullmatch(r'[a-zA-Z0-9][a-zA-Z0-9_./:-]*',args.image) or ':' not in args.image.rsplit('/',1)[-1]:p.error('use an explicit local image tag, without a digest')
args.report_dir.mkdir(parents=True,exist_ok=True)
kind=args.kind;helm=args.helm
work=tempfile.TemporaryDirectory(prefix='rustmall-k8s40-');private=[];output=[];checks=[];report={};compose=None;forward=None;cluster_owned=False;compose_owned=False
name='rustmall40-'+uuid.uuid4().hex[:10];node=name+'-control-plane';namespace='rustmall-book';kube=Path(work.name)/'kubeconfig';success=False
progress=args.report_dir/'progress.log';progress.write_text('starting isolated Kubernetes verification\n')
def run(command,ok=True,input=None,timeout=600,stdin=None):
 r=subprocess.run([str(x) for x in command],cwd=stage,capture_output=True,text=True,input=input,timeout=timeout,stdin=stdin)
 text=r.stdout+'\n'+r.stderr
 for value in private:text=text.replace(value,'[REDACTED]')
 output.append(text)
 with progress.open('a') as f:f.write('finished '+str(command[0]).rsplit('/',1)[-1]+' exit='+str(r.returncode)+'\n')
 if ok and r.returncode:raise RuntimeError('isolated Kubernetes command failed; inspect commands.log in the selected report directory')
 return r
def k(*args,**kw):return run(['kubectl','--kubeconfig',str(kube),'-n',namespace,*args],**kw)
def h(*args,**kw):return run([helm,'--kubeconfig',str(kube),'-n',namespace,*args],**kw)
def apply(obj):return k('apply','-f','-',input=json.dumps(obj))
def until(test,label,seconds=90):
 deadline=time.monotonic()+seconds
 while True:
  if test():return
  if time.monotonic()>deadline:raise RuntimeError('timeout: '+label)
  time.sleep(.3)
try:
 profile=Path(work.name)/'.delivery.local'
 run(['python3','scripts/create-delivery-env.py','--output-dir',str(profile),'--image',args.image])
 values={p.name:p.read_text().strip() for p in (profile/'secrets').iterdir()};private.extend(v for v in values.values() if len(v)>20)
 compose=['docker','compose','-p',name,'--env-file',str(profile/'compose.env'),'-f','deploy/delivery40/compose.yaml']
 assert not run(compose+['ps','-a','-q']).stdout.strip();compose_owned=True
 run(compose+['up','-d','--wait','--wait-timeout','180','postgres','redis','kafka-topic'])
 assert name not in run([kind,'get','clusters']).stdout.splitlines(),'cluster already exists'
 cluster_owned=True
 run([kind,'create','cluster','--name',name,'--kubeconfig',kube,'--image','kindest/node:v1.36.4@sha256:099e049362a1526b2db71494e1947aae99bd16290d7c895f2b7ea312e3cbfaed','--wait','120s'])
 report['cluster_version']=json.loads(k('version','-o','json').stdout)['serverVersion']['gitVersion']
 report['helm_version']=run([helm,'version','--short']).stdout.strip()
 network=name+'_backend';run(['docker','network','connect',network,node])
 k('create','namespace',namespace)
 # Only the disposable node is attached to our isolated infrastructure network.
 for role,port in [('postgres',5432),('redis',6379),('kafka',9092)]:
  cid=run(compose+['ps','-q',role]).stdout.strip();spec=json.loads(run(['docker','inspect',cid]).stdout)[0]
  ip=spec['NetworkSettings']['Networks'][network]['IPAddress'];assert re.fullmatch(r'[0-9.]+',ip)
  apply({'apiVersion':'v1','kind':'Service','metadata':{'name':role},'spec':{'ports':[{'name':'tcp','port':port,'targetPort':port}]}})
  apply({'apiVersion':'discovery.k8s.io/v1','kind':'EndpointSlice','metadata':{'name':role+'-external','labels':{'kubernetes.io/service-name':role}},'addressType':'IPv4','ports':[{'name':'tcp','protocol':'TCP','port':port}],'endpoints':[{'addresses':[ip]}]})
 image=args.image;image_spec=json.loads(run(['docker','image','inspect',image]).stdout)[0];image_id=image_spec['Id'];report['loaded_source_image_id']=image_id
 assert image_spec['Os']=='linux' and image_spec['Architecture'] in ('arm64','amd64')
 node_image=json.loads(run(['docker','inspect',node]).stdout)[0]['Image']
 assert json.loads(run(['docker','image','inspect',node_image]).stdout)[0]['Architecture']==image_spec['Architecture'],'application image must match the native node architecture'
 image_platform='linux/'+image_spec['Architecture'];report['tested_platform']=image_platform
 # Docker's containerd store may expose a multi-platform index with only local
 # layers cached. Import only the verified host platform, not --all-platforms.
 archive=Path(work.name)/'images-native.tar'
 run(['docker','image','save','--platform',image_platform,'--output',archive,image,'postgres:17-bookworm'])
 with archive.open('rb') as source:
  run(['docker','exec','--privileged','-i',node,'ctr','--namespace=k8s.io','images','import','--platform',image_platform,'--digests','--snapshotter=overlayfs','-'],stdin=source)

 v=json.loads(run(['ruby','-rjson','-ryaml','-e','puts JSON.generate(YAML.safe_load(File.read(ARGV[0])))','charts/rustmall/values.yaml']).stdout)
 def secret(name,data):apply({'apiVersion':'v1','kind':'Secret','metadata':{'name':name},'type':'Opaque','stringData':data})
 for role,spec in v['roles'].items():
  if spec['secretFiles']:secret(spec['existingSecret'],{key:values[key] for key in spec['secretFiles'].values()})
 for migration,spec in v['migrations'].items():secret(spec['existingSecret'],{key:values[key] for key in spec['secretFiles'].values()})
 secret(v['permissions']['existingSecret'],{'PGHOST':'postgres','PGPORT':'5432','PGUSER':'postgres','PGPASSWORD':values['postgres_admin_password'],'PGDATABASE':'postgres','PGSSLMODE':'disable'})
 # Prove a failed migration blocks first-install business deployments.
 user_owner=v['migrations']['users'];bad=values['migrate_users_url'].replace('@postgres:', '@unreachable.invalid:')
 secret(user_owner['existingSecret'],{'migrate_users_url':bad})
 cmd=['upgrade','--install','book','charts/rustmall','--set','image.pullPolicy=Never','--set-string','image.repository='+image.rsplit(':',1)[0],'--set-string','image.tag='+image.rsplit(':',1)[1],'--wait','--timeout','120s']
 failed=h(*cmd,ok=False);assert failed.returncode
 assert json.loads(k('get','deployments','-o','json').stdout)['items']==[]
 checks.append('real failed owner migration blocks all first-install business Deployments')
 secret(user_owner['existingSecret'],{'migrate_users_url':values['migrate_users_url']})
 h(*cmd)
 deployments=json.loads(k('get','deployments','-o','json').stdout)['items'];assert len(deployments)==10
 assert all(d['status'].get('readyReplicas')==1 for d in deployments)
 pods=json.loads(k('get','pods','-l','app.kubernetes.io/instance=book','-o','json').stdout)['items']
 running=[p for p in pods if p['status']['phase']=='Running'];assert len(running)==10
 assert all(p['spec']['containers'][0]['image']==image and p['spec']['securityContext']['runAsUser']==10001 for p in running)
 report['running_pod_image_ids']=sorted({p['status']['containerStatuses'][0]['imageID'] for p in running})
 assert len(report['running_pod_image_ids'])==1
 checks.append('Helm hooks migrate six DBs then grant privileges; all ten actual Pods become Ready from one loaded Linux image with UID10001 and mounted runtime secrets')
 def admin(db,query):return run(compose+['exec','-T','postgres','psql','-X','-v','ON_ERROR_STOP=1','-U','postgres','-d','rustmall_'+db,'-Atc',query]).stdout.strip()
 def as_role(role,db,query,ok=True):
  assert re.fullmatch('[a-z_]+',role) and re.fullmatch('[a-z_]+',db)
  command='export PGPASSWORD="$(cat /run/secrets/'+role+'_password)"; exec psql -h 127.0.0.1 -U '+role+' -d rustmall_'+db+' -X -v ON_ERROR_STOP=1 -At'
  return run(compose+['exec','-T','postgres','sh','-ec',command],input=query+'\n',ok=ok)
 forward_log=open(Path(work.name)/'port-forward.log','w')
 forward=subprocess.Popen(['kubectl','--kubeconfig',str(kube),'-n',namespace,'port-forward','--address','127.0.0.1','service/book-rustmall-edge','18086:8080'],stdout=forward_log,stderr=subprocess.STDOUT)
 def forwarded():
  if forward.poll() is not None:raise RuntimeError('owned port-forward exited')
  return 'Forwarding from' in (Path(work.name)/'port-forward.log').read_text()
 until(forwarded,'port-forward',seconds=30)
 base='http://127.0.0.1:18086'
 def api(path,method='GET',body=None,token=None,key=None):
  h={'Content-Type':'application/json'}
  if token:h['Authorization']='Bearer '+token
  if key:h['Idempotency-Key']=str(key)
  r=urllib.request.Request(base+path,headers=h,method=method,data=None if body is None else json.dumps(body).encode())
  try:reply=urllib.request.urlopen(r,timeout=8)
  except urllib.error.HTTPError as error:reply=error
  with reply:
   raw=reply.read();return reply.status,json.loads(raw) if raw else None
 assert api('/readyz')[0]==200
 c={'username':'delivery_'+secrets.token_hex(4),'password':secrets.token_urlsafe(24)};private.append(c['password'])
 assert api('/api/v1/auth/register','POST',c)[0]==201
 status,reply=api('/api/v1/auth/login','POST',c);assert status==200;token=reply['access_token'];private.append(token)
 status,identity=api('/api/v1/auth/me',token=token);assert status==200;actor=int(identity['id']);assert actor>0
 admin('users',f"UPDATE users SET role='admin' WHERE id={actor}")
 draft={'name':'容器交付键盘','price_cents':19900,'stock':10};create_key=uuid.uuid4()
 status,p=api('/api/v1/products','POST',draft,token,create_key);assert status==201;pid=int(p['id'])
 assert api('/api/v1/products','POST',draft,token,create_key)[1]['id']==pid
 request={'product_id':pid,'quantity':2};key=uuid.uuid4();status,o=api('/api/v1/orders','POST',request,token,key);assert status==202;oid=str(uuid.UUID(o['id']))
 until(lambda:admin('orders',f"SELECT state FROM orders WHERE id='{oid}'")=='completed','container Saga complete')
 assert admin('payments',f"SELECT count(*) FROM payment_effects WHERE saga_id='{oid}' AND kind='paid'")=='1'
 assert admin('catalog',f'SELECT stock FROM products WHERE id={pid}')=='8'
 assert api('/api/v1/orders','POST',request,token,key)[1]['id']==oid
 assert api(f'/api/v1/products/{pid}','PUT',{**draft,'stock':999},token)[0]==409
 assert api(f'/api/v1/products/{pid}','PUT',{**draft,'name':'容器键盘资料修订','stock':8},token)[0]==200
 checks.append('real container HTTP auth/product/idempotent order/Saga completes with one paid effect, stock8, preserved metadata edits and rejected stock overwrite')
 adjust_id=uuid.uuid4()
 run(compose+['run','--rm','--no-deps','inventory-admin','/app/inventory-adjust','apply',str(adjust_id),str(pid),'3',str(actor),'container-check','--local-admin'])
 assert admin('catalog',f'SELECT stock FROM products WHERE id={pid}')=='11'
 assert api(f'/api/v1/products/{pid}','DELETE',token=token)[0]==204
 def projection_ok(db):return admin(db,f"SELECT count(*) FROM catalog_view WHERE product_id={pid} AND (payload->>'stock')::int=11 AND NOT (payload->>'listed')::boolean")=='1'
 until(lambda:projection_ok('projection') and projection_ok('rebuild'),'independent container projections')
 assert admin('catalog','SELECT count(*) FROM product_outbox WHERE delivered_at IS NULL')=='0'
 checks.append('least-privilege inventory-admin adjusts stock and records audit; relay and both independent projections converge to the stock11 tombstone')
 refusals=[
  ('app_users','users',"UPDATE users SET role='admin' WHERE false"),
  ('app_users','users','CREATE TABLE should_not_exist(id int)'),
  ('app_orders','orders',"UPDATE orders SET state='completed' WHERE false"),
  ('worker_orders','orders','INSERT INTO orders(id,actor_id,request_key,product_id,quantity,unit_price,amount) SELECT gen_random_uuid(),1,gen_random_uuid(),1,1,1,1 WHERE false'),
  ('relay_catalog','catalog',"UPDATE product_outbox SET payload='{}'::jsonb WHERE false"),
  ('relay_catalog','catalog','UPDATE products SET stock=0 WHERE false'),
  ('app_payments','payments','DELETE FROM payment_effects WHERE false'),
  ('app_projection','projection','DELETE FROM catalog_view WHERE false'),
  ('app_projection','projection',"UPDATE projection_identity SET consumer_name='different' WHERE false"),
 ]
 for role,db,query in refusals:
  r=as_role(role,db,query,ok=False);assert r.returncode and 'permission denied' in r.stderr,(role,db)
 checks.append('nine actual SQL privilege denials protect user promotion/DDL, order state, worker creation, event content, product stock, payment audit and projection identity/tombstones')
 redis='export REDISCLI_AUTH="$(awk \'$1=="user" && $2=="app_users" {print substr($4,2)}\' /run/secrets/redis_acl)"; exec redis-cli -e --user app_users FLUSHDB'
 r=run(compose+['exec','-T','redis','sh','-ec',redis],ok=False);assert r.returncode and 'NOPERM' in (r.stdout+r.stderr)
 assert api('/api/v1/auth/logout','POST',token=token)[0]==204
 assert api('/api/v1/auth/me',token=token)[0]==401
 checks.append('Redis ACL supports login/Lua/session revocation but denies application FLUSHDB; logout remains effective')
 good_revision=json.loads(h('history','book','-o','json').stdout)[-1]['revision']
 # A bad new users Pod must not replace the only healthy old Pod; then rollback.
 fail_roll=h('upgrade','book','charts/rustmall','--reuse-values','--set','roles.users.env.HTTP_ADDR=invalid-address','--wait','--timeout','70s',ok=False)
 assert fail_roll.returncode
 user_deployment=json.loads(k('get','deployment','book-rustmall-users','-o','json').stdout)
 assert user_deployment['status'].get('availableReplicas',0)>=1
 h('rollback','book',str(good_revision),'--wait','--timeout','180s')
 until(lambda:api('/readyz')[0]==200,'rollback edge readiness')
 assert admin('orders',f"SELECT state FROM orders WHERE id='{oid}'")=='completed'
 assert admin('payments',f"SELECT count(*) FROM payment_effects WHERE saga_id='{oid}' AND kind='paid'")=='1'
 assert admin('catalog',f'SELECT stock FROM products WHERE id={pid}')=='11'
 checks.append('failed application configuration rollout retains old Ready users Pod; actual Helm rollback restores configuration while completed order/one payment/stock11 survive')
 # Dependency-aware readiness must fail without restarting otherwise live processes.
 user_pod=json.loads(k('get','pods','-l','app.kubernetes.io/instance=book,app.kubernetes.io/component=users','-o','json').stdout)['items']
 user_pod=next(p for p in user_pod if p['status']['phase']=='Running' and p['status']['containerStatuses'][0]['ready']);pod_name=user_pod['metadata']['name']
 restarts=user_pod['status']['containerStatuses'][0]['restartCount']
 run(compose+['stop','redis'])
 def users_not_ready():
  p=json.loads(k('get','pod',pod_name,'-o','json').stdout)
  return not p['status']['containerStatuses'][0]['ready']
 until(users_not_ready,'users dependency readiness false')
 k('exec',pod_name,'--','/app/rustmall-probe','http','http://127.0.0.1:8080/healthz')
 run(compose+['start','redis'])
 until(lambda:json.loads(k('get','pod',pod_name,'-o','json').stdout)['status']['containerStatuses'][0]['ready'],'users ready again')
 assert json.loads(k('get','pod',pod_name,'-o','json').stdout)['status']['containerStatuses'][0]['restartCount']==restarts
 checks.append('actual Kubernetes readiness removes users during Redis outage; liveness remains successful and the same Pod recovers without restart')
 report['network_policy_scope']='kindnet does not enforce NetworkPolicy; policies were rendered/applied, not proved enforced'
 assert json.loads(run(['docker','image','inspect',image]).stdout)[0]['Id']==image_id
 success=True
finally:
 if forward is not None and forward.poll() is None:
  forward.terminate()
  try:forward.wait(timeout=10)
  except subprocess.TimeoutExpired:forward.kill();forward.wait()
 if kube.exists():
  try:
   pods=json.loads(k('get','pods','-o','json',ok=False).stdout).get('items',[])
   for pod in pods:
    pod_name=pod['metadata']['name']
    k('logs',pod_name,'--all-containers=true',ok=False)
    if any(c.get('restartCount',0) for c in pod.get('status',{}).get('containerStatuses',[])):
     k('logs',pod_name,'--all-containers=true','--previous',ok=False)
  except Exception:pass
  for diagnostic_args in [('get','pods','-o','wide'),('get','events','--sort-by=.metadata.creationTimestamp')]:
   try:k(*diagnostic_args,ok=False)
   except Exception:pass
 if cluster_owned:
  report['cluster_cleanup_exit']=subprocess.run([str(kind),'delete','cluster','--name',name,'--kubeconfig',str(kube)],capture_output=True).returncode
 if compose_owned:
  logs=subprocess.run(compose+['logs','--no-color'],cwd=stage,capture_output=True,text=True).stdout
  for value in private:logs=logs.replace(value,'[REDACTED]')
  report['infrastructure_cleanup_exit']=subprocess.run(compose+['down','--volumes','--remove-orphans'],cwd=stage,capture_output=True).returncode
  (args.report_dir/'infrastructure.log').write_text(logs)
 work.cleanup()
 text='\n'.join(output)
 for value in private:text=text.replace(value,'[REDACTED]')
 (args.report_dir/'commands.log').write_text(text)
 report.update(success=success and report.get('cluster_cleanup_exit')==0 and report.get('infrastructure_cleanup_exit')==0,checks=checks,passed=len(checks),scope='actual local single-node native-platform Kind and Helm applications, external disposable PG/Redis/Kafka; no remote Actions/Argo/production HA proof')
 (args.report_dir/'result.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(report,ensure_ascii=False,indent=2))
if not report['success']:raise SystemExit(1)
