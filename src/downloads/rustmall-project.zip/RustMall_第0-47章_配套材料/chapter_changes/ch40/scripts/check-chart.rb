# Render and inspect complete manifests; this does not contact a Kubernetes API.
require 'yaml'
require 'json'
require 'open3'
require 'tempfile'
require 'digest'
root=File.expand_path('..',__dir__)
chart=File.join(root,'charts/rustmall')
helm=ENV.fetch('HELM','helm')
checks=[]
def need(condition,message)
  raise message unless condition
end
run=->(*args) {
  out,err,status=Open3.capture3(helm,*args)
  need(status.success?,"Helm failed: #{err}")
  out
}
parse=->(text) { YAML.load_stream(text).compact }
values=YAML.safe_load(File.read(File.join(chart,'values.yaml')))
run.call('lint',chart,'--strict')
checks << 'strict Helm lint'
%w[helm argocd].each do |mode|
  all=parse.call(run.call('template','book',chart,'--set',"controller=#{mode}"))
  select=->(kind) {all.select {|x|x['kind']==kind}}
  apps=select.call('Deployment');jobs=select.call('Job');services=select.call('Service')
  need(apps.size==10 && jobs.size==7 && services.size==10,'incorrect complete role count')
  need(select.call('Secret').empty?,'chart must reference preprovisioned secrets')
  images=apps.map {|x|x.dig('spec','template','spec','containers',0,'image')}.uniq
  need(images==['rustmall/book:ch40-candidate'],'runtime image diverged')
  need(jobs.count {|x|x.dig('spec','template','spec','containers',0,'image')==images[0]}==6,'migration images diverged')
  apps.each do |app|
    role=app.dig('spec','template','metadata','labels','app.kubernetes.io/component')
    expected=values.fetch('roles').fetch(role)
    pod=app.dig('spec','template','spec');container=pod.fetch('containers').fetch(0)
    need(pod['automountServiceAccountToken']==false,'unnecessary API token')
    need(pod.dig('securityContext','runAsUser')==10001,'wrong UID')
    need(container.dig('securityContext','readOnlyRootFilesystem'),'rootfs writable')
    need(container.dig('securityContext','allowPrivilegeEscalation')==false,'privilege escalation')
    need(container.dig('securityContext','capabilities','drop')==['ALL'],'capabilities retained')
    need(container['command']==['/app/rustmall-launch'] && container['args']==expected['args'],'wrong entrypoint/arguments')
    env=container.fetch('env');need(env.map {|e|e['name']}.uniq.size==env.size,'duplicate env var')
    need(env.all? {|e|e.key?('value')},'runtime unexpectedly injected secret value through env')
    actual_files=env.select {|e|e['name'].end_with?('_FILE')}.to_h {|e|[e['name'],e['value'].sub('/run/secrets/','')]}
    need(actual_files==expected['secretFiles'],'missing or excessive file credentials')
    volume=pod.fetch('volumes').find {|x|x['name']=='credentials'}
    if expected['secretFiles'].empty?
      need(volume.nil?,'edge must not mount other services secrets')
    else
      need(volume.dig('secret','secretName')==expected['existingSecret'],'wrong runtime credential identity')
      need(volume.dig('secret','items').map {|x|x['key']}.sort==expected['secretFiles'].values.sort,'extra secret keys mounted')
    end
    live=container.dig('livenessProbe','exec','command');ready=container.dig('readinessProbe','exec','command')
    case expected['kind']
    when 'http'
      need(live.last.end_with?('/healthz') && ready.last.end_with?('/readyz'),'HTTP readiness used for liveness')
      source=File.read(File.join(root,'services/commerce/src',role.tr('-','_')+'.rs'))
      need(source.include?('"/healthz"') && source.include?('"/readyz"'),'probe routes absent from actual role source')
    when 'grpc'
      need(live.last=='liveness' && ready.last=='readiness','gRPC probe identities swapped')
    else
      need(live.last.end_with?('/metrics') && live==ready,'background liveness scope changed')
    end
  end
  jobs.each do |job|
    annotations=job.dig('metadata','annotations');name=job.dig('metadata','name')
    if mode=='helm'
      need(annotations['helm.sh/hook']=='pre-install,pre-upgrade','Helm ordering missing')
      need(!annotations.key?('argocd.argoproj.io/hook'),'mixed controllers')
      weight=annotations['helm.sh/hook-weight']
    else
      need(annotations['argocd.argoproj.io/hook']=='PreSync','Argo ordering missing')
      need(!annotations.key?('helm.sh/hook'),'mixed controllers')
      weight=annotations['argocd.argoproj.io/sync-wave']
    end
    need(weight==(name.end_with?('-permissions') ? '-5' : '-10'),'migration/grant ordering wrong')
    need(job.dig('spec','backoffLimit')==0,'unexpected migration retry')
    next if name.end_with?('-permissions')
    migration=values['migrations'].find {|key,_|name.end_with?("-migrate-#{key}")}&.last
    need(migration,'unknown migration')
    pod=job.dig('spec','template','spec')
    secret=pod['volumes'].find {|x|x['name']=='credentials'}.dig('secret','secretName')
    need(secret==migration['existingSecret'],'runtime credential used for DDL')
    need(!values['roles'].values.map {|x|x['existingSecret']}.include?(secret),'owner/runtime secrets shared')
  end
  cm=select.call('ConfigMap').fetch(0)
  need(cm.dig('data','permissions.sql')==File.read(File.join(root,'deploy/delivery40/permissions.sql')),'permission policies drifted')
  deletion=cm.dig('metadata','annotations',mode=='helm' ? 'helm.sh/hook-delete-policy' : 'argocd.argoproj.io/hook-delete-policy')
  need(!deletion.downcase.include?('succeeded'),'permissions ConfigMap deleted before dependent hook runs')
  need(select.call('NetworkPolicy').size==2,'ingress boundaries missing')
  checks << "#{mode}: 10 workloads/services, 6 owner migrations then grants, correct probes, secret isolation and retained hook SQL"
end
%w[image.requireDigest=true image.digest=sha256:bad pdb.enabled=true roles.unexpected.kind=http controller=both].each do |bad|
  _,_,status=Open3.capture3(helm,'template','book',chart,'--set',bad)
  need(!status.success?,"bad values accepted: #{bad}")
end
checks << 'five invalid configurations rejected'
digest='sha256:'+'a'*64
all=parse.call(run.call('template','book',chart,'--set',"image.requireDigest=true,image.digest=#{digest},replicas=2,pdb.enabled=true"))
need(all.count {|x|x['kind']=='PodDisruptionBudget'}==10,'missing PDBs')
need(all.select {|x|x['kind']=='Deployment'}.all? {|x|x.dig('spec','template','spec','containers',0,'image')=="rustmall/book@#{digest}"},'digest pinning failed')
checks << 'registry digest and two-replica PDB rendering'
script=File.join(root,'scripts/render-gitops-app.py')
args=['python3',script,'--repo','https://example.invalid/team/rustmall.git','--revision','b'*40,'--image-repository','registry.example.invalid/team/rustmall','--image-digest',digest]
out,err,status=Open3.capture3(*args);need(status.success?,err)
app=JSON.parse(out)
params=app.dig('spec','source','helm','parameters').to_h {|x|[x['name'],x['value']]}
need(params['controller']=='argocd' && params['image.requireDigest']=='true' && params['image.digest']==digest,'GitOps artifact unpinned')
need(!app.dig('spec','syncPolicy','automated'),'unexpected automatic remote apply')
_,_,status=Open3.capture3(*args.map {|x|x=='https://example.invalid/team/rustmall.git' ? 'https://user:password@example.invalid/repo' : x})
need(!status.success?,'embedded repo credentials accepted')
checks << 'GitOps generator pins commit/digest/controller and rejects embedded credentials; fixture URLs are not real deployment evidence'
puts JSON.pretty_generate({passed:checks.size,checks:checks,scope:'local lint and rendered manifest assertions only; no Kubernetes or Argo runtime proof'})
