"""一次性生成独立库存服务凭据；不覆盖已有文件，不打印秘密。"""
import os
import secrets

fd = os.open(".env.inventory.local", os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
with os.fdopen(fd, "w") as output:
    output.write("RUSTMALL_INVENTORY_TOKEN=" + secrets.token_urlsafe(48) + "\n")
print("已生成 .env.inventory.local；未输出秘密。")
