use anyhow::Context;
use contracts::catalog::catalog_server::CatalogServer;
use platform::ShutdownBudget;
use sqlx::postgres::PgPoolOptions;
use std::time::Duration;
use tokio_util::sync::CancellationToken;
use tonic::{Request, Status, transport::Server};
use tonic_health::ServingStatus;

async fn signal() {
    #[cfg(unix)]
    {
        let mut term = tokio::signal::unix::signal(tokio::signal::unix::SignalKind::terminate())
            .expect("install SIGTERM handler");
        tokio::select! { _ = tokio::signal::ctrl_c() => {}, _ = term.recv() => {} }
    }
    #[cfg(not(unix))]
    {
        tokio::signal::ctrl_c()
            .await
            .expect("install ctrl-c handler");
    }
}
#[tokio::main]
async fn main() -> anyhow::Result<()> {
    tracing_subscriber::fmt()
        .with_env_filter("info,catalog=debug")
        .init();
    let key = std::env::var("RUSTMALL_CATALOG_TOKEN").context("catalog token missing")?;
    anyhow::ensure!(
        key.len() >= 32 && key.bytes().all(|byte| byte.is_ascii_graphic()),
        "catalog token must be >=32 visible ASCII bytes"
    );
    let inventory_raw =
        std::env::var("RUSTMALL_INVENTORY_TOKEN").context("inventory token missing")?;
    anyhow::ensure!(
        inventory_raw != key,
        "catalog and inventory tokens must differ"
    );
    let inventory_key = inventory::rpc::ServiceKey::parse(&inventory_raw)?;
    let url = std::env::var("DATABASE_URL").context("catalog database missing")?;
    let pool = PgPoolOptions::new()
        .max_connections(10)
        .acquire_timeout(Duration::from_millis(500))
        .connect(&url)
        .await?;
    let api = catalog::CatalogApi::new(pool.clone());
    let auth = move |request: Request<()>| -> Result<Request<()>, Status> {
        match request
            .metadata()
            .get("x-rustmall-service-token")
            .and_then(|v| v.to_str().ok())
        {
            Some(value) if value == key => Ok(request),
            _ => Err(Status::unauthenticated("service identity required")),
        }
    };
    let (reporter, health) = tonic_health::server::health_reporter();
    reporter
        .set_service_status("liveness", ServingStatus::Serving)
        .await;
    reporter
        .set_service_status("readiness", ServingStatus::NotServing)
        .await;
    let token = CancellationToken::new();
    let health_pool = pool.clone();
    let health_token = token.clone();
    let mut checker = tokio::spawn(async move {
        loop {
            let ok = matches!(
                tokio::time::timeout(
                    Duration::from_millis(500),
                    sqlx::query("SELECT 1").execute(&health_pool)
                )
                .await,
                Ok(Ok(_))
            );
            reporter
                .set_service_status(
                    "readiness",
                    if ok {
                        ServingStatus::Serving
                    } else {
                        ServingStatus::NotServing
                    },
                )
                .await;
            tokio::select! {
                () = health_token.cancelled() => break,
                () = tokio::time::sleep(Duration::from_secs(2)) => {}
            }
        }
    });
    let addr = std::env::var("CATALOG_ADDR")
        .unwrap_or_else(|_| "127.0.0.1:50051".into())
        .parse()?;
    let server = Server::builder()
        .add_service(health)
        .add_service(inventory::rpc::service(pool.clone(), inventory_key))
        .add_service(CatalogServer::with_interceptor(api, auth))
        .serve_with_shutdown(addr, token.clone().cancelled_owned());
    tokio::pin!(server);
    let (result, budget) = tokio::select! {
       result = &mut server => {
            token.cancel();
            (result.context("gRPC server failed"), ShutdownBudget::new(Duration::from_secs(20)))
       },
       () = signal() => {
            token.cancel();
            let budget = ShutdownBudget::new(Duration::from_secs(20));
            let result = match budget.wait("gRPC", &mut server).await {
                Ok(result) => result.context("gRPC server failed"),
                Err(error) => { checker.abort(); return Err(error); }
            };
            (result, budget)
       }
    };
    match budget.wait("health checker", &mut checker).await {
        Ok(result) => result?,
        Err(error) => {
            checker.abort();
            return Err(error);
        }
    }
    budget.wait("database", pool.close()).await?;
    result
}
