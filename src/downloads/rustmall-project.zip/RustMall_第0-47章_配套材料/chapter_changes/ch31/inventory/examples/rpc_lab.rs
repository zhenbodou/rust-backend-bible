use anyhow::Context;
use inventory::rpc::{ServiceKey, service};
use sqlx::postgres::PgPoolOptions;
use std::{net::SocketAddr, time::Duration};
use tokio_util::sync::CancellationToken;
use tonic::transport::Server;

#[tokio::main]
async fn main() -> anyhow::Result<()> {
    let address: SocketAddr = std::env::var("INVENTORY_LAB_ADDR")
        .unwrap_or_else(|_| "127.0.0.1:50052".into())
        .parse()?;
    anyhow::ensure!(
        address.ip().is_loopback(),
        "lab must listen on loopback only"
    );
    let key = ServiceKey::parse(
        &std::env::var("RUSTMALL_INVENTORY_TOKEN").context("inventory token missing")?,
    )?;
    let pool = PgPoolOptions::new()
        .max_connections(10)
        .acquire_timeout(Duration::from_millis(500))
        .connect(&std::env::var("DATABASE_URL").context("database missing")?)
        .await?;
    let stop = CancellationToken::new();
    let server = Server::builder()
        .add_service(service(pool.clone(), key))
        .serve_with_shutdown(address, stop.clone().cancelled_owned());
    tokio::pin!(server);
    let result = tokio::select! {
        result = &mut server => result.context("lab server failed"),
        result = tokio::signal::ctrl_c() => {
            result?;
            stop.cancel();
            tokio::time::timeout(Duration::from_secs(20), &mut server).await
                 .context("lab shutdown budget exhausted")?
                 .context("lab server failed")
        }
    };
    tokio::time::timeout(Duration::from_secs(2), pool.close())
        .await
        .context("lab pool close budget exhausted")?;
    result
}
