use contracts::catalog::{
    GetReservationRequest, ReservationCommand, ReservationReply,
    inventory_client::InventoryClient,
    inventory_server::{Inventory, InventoryServer},
};
use inventory::{
    model::{Action, Command, State},
    remote::InventoryRemote,
    rpc::{InventoryApi, ServiceKey},
};
use messaging::store::{self, Draft};
use sqlx::PgPool;
use std::{
    sync::{
        Arc,
        atomic::{AtomicBool, Ordering},
    },
    time::Duration,
};
use tokio::sync::Notify;
use tokio_util::sync::CancellationToken;
use tonic::{
    Code, Request, Response, Status,
    transport::{Endpoint, Server},
};
use uuid::Uuid;

const KEY: &str = "inventory-response-loss-lab-token-0123456789";
#[derive(Clone)]
struct HoldFirstReply {
    inner: InventoryApi,
    first: Arc<AtomicBool>,
    committed: Arc<Notify>,
    release_reply: Arc<Notify>,
}
#[tonic::async_trait]
impl Inventory for HoldFirstReply {
    async fn reserve(
        &self,
        request: Request<ReservationCommand>,
    ) -> Result<Response<ReservationReply>, Status> {
        let response = self.inner.reserve(request).await?;
        // The real inventory transaction has committed, but no reply has been returned.
        if self.first.swap(false, Ordering::SeqCst) {
            self.committed.notify_one();
            self.release_reply.notified().await;
        }
        Ok(response)
    }
    async fn confirm(
        &self,
        request: Request<ReservationCommand>,
    ) -> Result<Response<ReservationReply>, Status> {
        self.inner.confirm(request).await
    }
    async fn release(
        &self,
        request: Request<ReservationCommand>,
    ) -> Result<Response<ReservationReply>, Status> {
        self.inner.release(request).await
    }
    async fn get_reservation(
        &self,
        request: Request<GetReservationRequest>,
    ) -> Result<Response<ReservationReply>, Status> {
        self.inner.get_reservation(request).await
    }
}

#[sqlx::test(migrations = false)]
async fn client_deadline_after_commit_recovers_by_same_identity(pool: PgPool) {
    for sql in [
        include_str!("../../services/catalog/migrations/0001_catalog.sql"),
        include_str!("../../services/catalog/migrations/0002_product_outbox.sql"),
        include_str!("../../services/catalog/migrations/0003_inventory_reservations.sql"),
    ] {
        sqlx::raw_sql(sql).execute(&pool).await.unwrap();
    }
    let event = store::create(
        &pool,
        &Draft {
            name: "响应丢失实验".into(),
            price_cents: 19900,
            stock: 10,
        },
    )
    .await
    .unwrap();
    let command = Command {
        saga_id: Uuid::new_v4(),
        product_id: event.aggregate_id,
        quantity: 1,
        unit_price_cents: 19900,
    };
    let committed = Arc::new(Notify::new());
    let release_reply = Arc::new(Notify::new());
    let api = HoldFirstReply {
        inner: InventoryApi::new(pool.clone()),
        first: Arc::new(AtomicBool::new(true)),
        committed: committed.clone(),
        release_reply: release_reply.clone(),
    };
    let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
    let address = format!("http://{}", listener.local_addr().unwrap());
    let stop = CancellationToken::new();
    let shutdown = stop.clone();
    let mut server = tokio::spawn(async move {
        Server::builder()
            .add_service(InventoryServer::with_interceptor(
                api,
                ServiceKey::parse(KEY).unwrap(),
            ))
            .serve_with_incoming_shutdown(
                tokio_stream::wrappers::TcpListenerStream::new(listener),
                shutdown.cancelled_owned(),
            )
            .await
            .unwrap();
    });
    let channel = Endpoint::from_shared(address.clone())
        .unwrap()
        .connect()
        .await
        .unwrap();
    let mut raw = InventoryClient::new(channel);
    let mut request = Request::new(ReservationCommand {
        saga_id: command.saga_id.to_string(),
        product_id: command.product_id,
        quantity: 1,
        unit_price_cents: 19900,
    });
    ServiceKey::parse(KEY).unwrap().attach(&mut request);
    request.set_timeout(Duration::from_secs(1));
    let pending = tokio::spawn(async move { raw.reserve(request).await });
    tokio::time::timeout(Duration::from_millis(900), committed.notified())
        .await
        .expect("real transaction must commit before the client deadline");
    let result = tokio::time::timeout(Duration::from_secs(2), pending)
        .await
        .expect("client must not wait forever")
        .unwrap();
    let error = result.expect_err("first reply must not reach the caller");
    assert!(matches!(
        error.code(),
        Code::Cancelled | Code::DeadlineExceeded
    ));
    // Release the test handler even if the transport already cancelled it.
    release_reply.notify_one();
    let client = InventoryRemote::connect(&address, ServiceKey::parse(KEY).unwrap())
        .await
        .unwrap();
    let receipt = client.query(command.saga_id).await.unwrap().unwrap();
    assert_eq!(
        (
            receipt.product_id,
            receipt.quantity,
            receipt.unit_price_cents
        ),
        (command.product_id, 1, 19900)
    );
    assert_eq!(
        client.apply(&command, Action::Reserve).await.unwrap(),
        State::Held
    );
    let state: (i32, i64, i64) = sqlx::query_as("SELECT stock,revision,(SELECT count(*) FROM product_outbox WHERE aggregate_id=$1) FROM products WHERE id=$1").bind(command.product_id).fetch_one(&pool).await.unwrap();
    assert_eq!(state, (9, 2, 2));
    drop(client);
    stop.cancel();
    match tokio::time::timeout(Duration::from_secs(2), &mut server).await {
        Ok(result) => result.unwrap(),
        Err(_) => {
            server.abort();
            let outcome = server.await;
            assert!(outcome.is_ok() || outcome.unwrap_err().is_cancelled());
        }
    }
}
