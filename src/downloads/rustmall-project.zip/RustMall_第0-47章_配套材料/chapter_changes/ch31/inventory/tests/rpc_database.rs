use contracts::catalog::{
    GetReservationRequest, ReservationCommand, inventory_client::InventoryClient,
};
use inventory::{
    model::{Action, Command, State},
    remote::InventoryRemote,
    rpc::{SERVICE_TOKEN_HEADER, ServiceKey},
};
use messaging::store::{self, Draft};
use sqlx::PgPool;
use std::time::Duration;
use tokio_util::sync::CancellationToken;
use tonic::{
    Code, Request,
    transport::{Channel, Endpoint, Server},
};
use uuid::Uuid;

const KEY: &str = "inventory-test-key-32-bytes-minimum";
const PRODUCT_KEY: &str = "catalog-product-test-key-different";

struct Host {
    client: InventoryRemote,
    raw: InventoryClient<Channel>,
    stop: CancellationToken,
    task: tokio::task::JoinHandle<()>,
}

impl Host {
    async fn start(pool: PgPool) -> Self {
        let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
        let address = format!("http://{}", listener.local_addr().unwrap());
        let stop = CancellationToken::new();
        let shutdown = stop.clone();
        let task = tokio::spawn(async move {
            Server::builder()
                .add_service(inventory::rpc::service(
                    pool,
                    ServiceKey::parse(KEY).unwrap(),
                ))
                .serve_with_incoming_shutdown(
                    tokio_stream::wrappers::TcpListenerStream::new(listener),
                    shutdown.cancelled_owned(),
                )
                .await
                .unwrap();
        });
        let client = InventoryRemote::connect(&address, ServiceKey::parse(KEY).unwrap())
            .await
            .unwrap();
        let channel = Endpoint::from_shared(address)
            .unwrap()
            .timeout(Duration::from_secs(2))
            .connect()
            .await
            .unwrap();
        Self {
            client,
            raw: InventoryClient::new(channel),
            stop,
            task,
        }
    }

    async fn close(mut self) {
        drop(self.client);
        drop(self.raw);
        self.stop.cancel();
        match tokio::time::timeout(Duration::from_secs(2), &mut self.task).await {
            Ok(result) => result.unwrap(),
            Err(_) => {
                self.task.abort();
                let result = self.task.await;
                assert!(result.is_ok() || result.unwrap_err().is_cancelled());
            }
        }
    }
}

async fn setup(pool: &PgPool, stock: i32) -> Command {
    for sql in [
        include_str!("../../services/catalog/migrations/0001_catalog.sql"),
        include_str!("../../services/catalog/migrations/0002_product_outbox.sql"),
        include_str!("../../services/catalog/migrations/0003_inventory_reservations.sql"),
    ] {
        sqlx::raw_sql(sql).execute(pool).await.unwrap();
    }
    let event = store::create(
        pool,
        &Draft {
            name: "协议测试键盘".into(),
            price_cents: 19900,
            stock,
        },
    )
    .await
    .unwrap();
    Command {
        saga_id: Uuid::new_v4(),
        product_id: event.aggregate_id,
        quantity: 1,
        unit_price_cents: 19900,
    }
}

fn request(command: &Command, token: Option<&str>) -> Request<ReservationCommand> {
    let mut request = Request::new(ReservationCommand {
        saga_id: command.saga_id.to_string(),
        product_id: command.product_id,
        quantity: command.quantity,
        unit_price_cents: command.unit_price_cents,
    });
    if let Some(token) = token {
        request
            .metadata_mut()
            .insert(SERVICE_TOKEN_HEADER, token.parse().unwrap());
    }
    request.set_timeout(Duration::from_millis(900));
    request
}

async fn totals(pool: &PgPool, id: i64) -> (i32, i64, i64) {
    sqlx::query_as(
        "SELECT stock,revision,(SELECT count(*) FROM product_outbox
        WHERE aggregate_id=$1) FROM products WHERE id=$1",
    )
    .bind(id)
    .fetch_one(pool)
    .await
    .unwrap()
}

#[sqlx::test(migrations = false)]
async fn lifecycle_uses_real_grpc_and_real_database(pool: PgPool) {
    let command = setup(&pool, 10).await;
    let host = Host::start(pool.clone()).await;
    assert!(host.client.query(command.saga_id).await.unwrap().is_none());
    assert_eq!(
        host.client.apply(&command, Action::Reserve).await.unwrap(),
        State::Held
    );
    assert_eq!(
        host.client.apply(&command, Action::Reserve).await.unwrap(),
        State::Held
    );
    let row = host.client.query(command.saga_id).await.unwrap().unwrap();
    assert_eq!(
        (row.product_id, row.quantity, row.unit_price_cents),
        (command.product_id, 1, 19900)
    );
    assert_eq!(
        host.client.apply(&command, Action::Confirm).await.unwrap(),
        State::Confirmed
    );
    assert_eq!(
        host.client.apply(&command, Action::Release).await.unwrap(),
        State::Confirmed
    );
    assert_eq!(totals(&pool, command.product_id).await, (9, 2, 2));
    host.close().await;
}

#[sqlx::test(migrations = false)]
async fn missing_wrong_product_and_duplicate_tokens_are_denied(pool: PgPool) {
    let command = setup(&pool, 10).await;
    let mut host = Host::start(pool.clone()).await;
    for token in [None, Some("wrong"), Some(PRODUCT_KEY)] {
        let error = host
            .raw
            .reserve(request(&command, token))
            .await
            .unwrap_err();
        assert_eq!(error.code(), Code::Unauthenticated);
    }
    let mut duplicate = request(&command, Some(KEY));
    duplicate
        .metadata_mut()
        .append(SERVICE_TOKEN_HEADER, KEY.parse().unwrap());
    assert_eq!(
        host.raw.reserve(duplicate).await.unwrap_err().code(),
        Code::Unauthenticated
    );
    let rows: i64 = sqlx::query_scalar("SELECT count(*) FROM inventory_reservations")
        .fetch_one(&pool)
        .await
        .unwrap();
    assert_eq!(rows, 0);
    assert_eq!(totals(&pool, command.product_id).await, (10, 1, 1));
    host.close().await;
}

#[sqlx::test(migrations = false)]
async fn invalid_input_and_identity_conflict_keep_distinct_statuses(pool: PgPool) {
    let command = setup(&pool, 10).await;
    let mut host = Host::start(pool.clone()).await;
    let mut invalid = request(&command, Some(KEY));
    invalid.get_mut().saga_id = "not-a-uuid".into();
    assert_eq!(
        host.raw.reserve(invalid).await.unwrap_err().code(),
        Code::InvalidArgument
    );
    let mut invalid = request(&command, Some(KEY));
    invalid.get_mut().quantity = 0;
    assert_eq!(
        host.raw.reserve(invalid).await.unwrap_err().code(),
        Code::InvalidArgument
    );
    host.client.apply(&command, Action::Reserve).await.unwrap();
    let changed = Command {
        quantity: 2,
        ..command.clone()
    };
    assert_eq!(
        host.client
            .apply(&changed, Action::Release)
            .await
            .unwrap_err()
            .code(),
        Code::FailedPrecondition
    );
    assert_eq!(totals(&pool, command.product_id).await, (9, 2, 2));
    host.close().await;
}

#[sqlx::test(migrations = false)]
async fn business_rejection_is_a_normal_typed_reply(pool: PgPool) {
    let command = setup(&pool, 0).await;
    let host = Host::start(pool.clone()).await;
    assert_eq!(
        host.client.apply(&command, Action::Reserve).await.unwrap(),
        State::Rejected
    );
    assert_eq!(totals(&pool, command.product_id).await, (0, 1, 1));
    assert!(host.client.query(command.saga_id).await.unwrap().is_some());
    host.close().await;
}

#[sqlx::test(migrations = false)]
async fn cancellation_fences_late_reserve_across_network(pool: PgPool) {
    let command = setup(&pool, 10).await;
    let host = Host::start(pool.clone()).await;
    assert_eq!(
        host.client.apply(&command, Action::Release).await.unwrap(),
        State::Released
    );
    assert_eq!(
        host.client.apply(&command, Action::Reserve).await.unwrap(),
        State::Released
    );
    assert_eq!(totals(&pool, command.product_id).await, (10, 1, 1));
    host.close().await;
}

#[sqlx::test(migrations = false)]
async fn two_clients_compete_for_the_last_unit(pool: PgPool) {
    let first = setup(&pool, 1).await;
    let second = Command {
        saga_id: Uuid::new_v4(),
        ..first.clone()
    };
    let host = Host::start(pool.clone()).await;
    let other_client = host.client.clone();
    let (a, b) = tokio::join!(
        host.client.apply(&first, Action::Reserve),
        other_client.apply(&second, Action::Reserve)
    );
    let outcomes = [a.unwrap(), b.unwrap()];
    assert_eq!(outcomes.iter().filter(|s| **s == State::Held).count(), 1);
    assert_eq!(
        outcomes.iter().filter(|s| **s == State::Rejected).count(),
        1
    );
    assert_eq!(totals(&pool, first.product_id).await, (0, 2, 2));
    host.close().await;
}

#[sqlx::test(migrations = false)]
async fn outbox_failure_is_sanitized_and_atomic_over_rpc(pool: PgPool) {
    let command = setup(&pool, 10).await;
    let host = Host::start(pool.clone()).await;
    sqlx::query("ALTER TABLE product_outbox ADD CONSTRAINT injected_failure CHECK(revision<2)")
        .execute(&pool)
        .await
        .unwrap();
    let error = host
        .client
        .apply(&command, Action::Reserve)
        .await
        .unwrap_err();
    assert_eq!(error.code(), Code::Internal);
    assert_eq!(error.message(), "inventory database failure");
    assert_eq!(totals(&pool, command.product_id).await, (10, 1, 1));
    assert!(host.client.query(command.saga_id).await.unwrap().is_none());
    host.close().await;
}

#[sqlx::test(migrations = false)]
async fn lock_failure_keeps_identity_available_for_same_key_retry(pool: PgPool) {
    let command = setup(&pool, 10).await;
    let host = Host::start(pool.clone()).await;
    let mut blocker = pool.begin().await.unwrap();
    sqlx::query("SELECT id FROM products WHERE id=$1 FOR UPDATE")
        .bind(command.product_id)
        .execute(&mut *blocker)
        .await
        .unwrap();
    let error = host
        .client
        .apply(&command, Action::Reserve)
        .await
        .unwrap_err();
    assert_eq!(error.code(), Code::Unavailable);
    blocker.rollback().await.unwrap();
    assert_eq!(
        host.client.apply(&command, Action::Reserve).await.unwrap(),
        State::Held
    );
    assert_eq!(totals(&pool, command.product_id).await, (9, 2, 2));
    host.close().await;
}

#[sqlx::test(migrations = false)]
async fn reconnect_and_retry_after_discarded_response_has_one_effect(pool: PgPool) {
    let command = setup(&pool, 10).await;
    let host = Host::start(pool.clone()).await;
    host.client.apply(&command, Action::Reserve).await.unwrap();
    // Discard the result, stop the transport host, then start a new host on the same database.
    host.close().await;
    let restarted = Host::start(pool.clone()).await;
    assert_eq!(
        restarted
            .client
            .apply(&command, Action::Reserve)
            .await
            .unwrap(),
        State::Held
    );
    assert_eq!(totals(&pool, command.product_id).await, (9, 2, 2));
    restarted.close().await;
}

#[sqlx::test(migrations = false)]
async fn oversized_message_is_rejected_before_business_effect(pool: PgPool) {
    let command = setup(&pool, 10).await;
    let mut host = Host::start(pool.clone()).await;
    let mut oversized = request(&command, Some(KEY));
    oversized.get_mut().saga_id = "x".repeat(70 * 1024);
    let error = host.raw.reserve(oversized).await.unwrap_err();
    assert!(matches!(
        error.code(),
        Code::OutOfRange | Code::ResourceExhausted
    ));
    assert_eq!(totals(&pool, command.product_id).await, (10, 1, 1));
    let missing = Request::new(GetReservationRequest {
        saga_id: command.saga_id.to_string(),
    });
    assert_eq!(
        host.raw.get_reservation(missing).await.unwrap_err().code(),
        Code::Unauthenticated
    );
    host.close().await;
}
