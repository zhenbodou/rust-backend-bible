pub mod model;
pub mod remote;
pub mod rpc;

use messaging::{
    event::{Envelope, Snapshot},
    store,
};
use model::{Action, Command, State, Step};
use sqlx::{PgPool, Postgres, Transaction};
use std::time::Duration;
use uuid::Uuid;

#[derive(Debug, thiserror::Error)]
pub enum Error {
    #[error("invalid reservation input")]
    InvalidInput,
    #[error("saga identity reused with different reservation parameters")]
    IdentityConflict,
    #[error("stored reservation state is invalid")]
    CorruptState,
    #[error("reservation operation exceeded its budget; result may be unknown")]
    Deadline,
    #[error(transparent)]
    Database(#[from] sqlx::Error),
}

#[derive(Debug, Clone, sqlx::FromRow)]
pub struct Reservation {
    pub saga_id: Uuid,
    pub product_id: i64,
    pub quantity: i32,
    pub unit_price_cents: i64,
    pub state: String,
}

#[derive(sqlx::FromRow)]
struct ProductRow {
    id: i64,
    name: String,
    price_cents: i64,
    stock: i32,
    revision: i64,
    listed: bool,
}

async fn append_snapshot(tx: &mut Transaction<'_, Postgres>, row: ProductRow) -> Result<(), Error> {
    let event = Envelope::new(
        Snapshot {
            id: row.id,
            name: row.name,
            price_cents: row.price_cents,
            stock: row.stock,
            listed: row.listed,
        },
        row.revision,
    );
    store::append(tx, &event).await?;
    Ok(())
}

async fn inside_transaction(
    pool: &PgPool,
    command: &Command,
    action: Action,
) -> Result<State, Error> {
    let mut tx = pool.begin().await?;
    sqlx::query("SET LOCAL lock_timeout = '400ms'")
        .execute(&mut *tx)
        .await?;
    sqlx::query("SET LOCAL statement_timeout = '500ms'")
        .execute(&mut *tx)
        .await?;
    sqlx::query(
        "INSERT INTO inventory_reservations
         (saga_id,product_id,quantity,unit_price_cents,state)
         VALUES($1,$2,$3,$4,'pending') ON CONFLICT DO NOTHING",
    )
    .bind(command.saga_id)
    .bind(command.product_id)
    .bind(command.quantity)
    .bind(command.unit_price_cents)
    .execute(&mut *tx)
    .await?;
    let old = sqlx::query_as::<_, Reservation>(
        "SELECT saga_id,product_id,quantity,unit_price_cents,state
         FROM inventory_reservations WHERE saga_id=$1 FOR UPDATE",
    )
    .bind(command.saga_id)
    .fetch_one(&mut *tx)
    .await?;
    if (old.product_id, old.quantity, old.unit_price_cents)
        != (
            command.product_id,
            command.quantity,
            command.unit_price_cents,
        )
    {
        return Err(Error::IdentityConflict);
    }
    let next = match model::decide(State::from_stored(&old.state)?, action) {
        Step::TryHold => {
            let product = sqlx::query_as::<_, ProductRow>(
                "UPDATE products
                 SET stock=stock-$2,revision=revision+1,updated_at=now()
                 WHERE id=$1 AND stock >= $2 AND price_cents=$3
                   AND delisted_at IS NULL
                 RETURNING id,name,price_cents,stock,revision,true AS listed",
            )
            .bind(command.product_id)
            .bind(command.quantity)
            .bind(command.unit_price_cents)
            .fetch_optional(&mut *tx)
            .await?;
            if let Some(product) = product {
                append_snapshot(&mut tx, product).await?;
                State::Held
            } else {
                State::Rejected
            }
        }
        Step::GiveBack => {
            let product = sqlx::query_as::<_, ProductRow>(
                "UPDATE products
                 SET stock=stock+$2,revision=revision+1,updated_at=now()
                 WHERE id=$1
                 RETURNING id,name,price_cents,stock,revision,
                   delisted_at IS NULL AS listed",
            )
            .bind(command.product_id)
            .bind(command.quantity)
            .fetch_one(&mut *tx)
            .await?;
            append_snapshot(&mut tx, product).await?;
            State::Released
        }
        Step::Store(state) => state,
    };
    sqlx::query(
        "UPDATE inventory_reservations SET state=$2,updated_at=now()
         WHERE saga_id=$1",
    )
    .bind(command.saga_id)
    .bind(next.as_str())
    .execute(&mut *tx)
    .await?;
    tx.commit().await?;
    Ok(next)
}

pub async fn execute(pool: &PgPool, command: &Command, action: Action) -> Result<State, Error> {
    command.validate()?;
    tokio::time::timeout(
        Duration::from_millis(700),
        inside_transaction(pool, command, action),
    )
    .await
    .map_err(|_| Error::Deadline)?
}

pub async fn find(pool: &PgPool, saga_id: Uuid) -> Result<Option<Reservation>, Error> {
    if saga_id.is_nil() {
        return Err(Error::InvalidInput);
    }
    tokio::time::timeout(
        Duration::from_millis(700),
        sqlx::query_as::<_, Reservation>(
            "SELECT saga_id,product_id,quantity,unit_price_cents,state
             FROM inventory_reservations WHERE saga_id=$1",
        )
        .bind(saga_id)
        .fetch_optional(pool),
    )
    .await
    .map_err(|_| Error::Deadline)?
    .map_err(Error::from)
}
