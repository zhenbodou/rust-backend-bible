use crate::{
    model::{Action, Command, State},
    rpc::{MAX_MESSAGE_BYTES, ServiceKey},
};
use contracts::catalog::{
    GetReservationRequest, ReservationCommand, ReservationReply, ReservationState,
    inventory_client::InventoryClient,
};
use std::time::Duration;
use tonic::{
    Request, Status,
    transport::{Channel, Endpoint},
};
use uuid::Uuid;

#[derive(Clone)]
pub struct InventoryRemote {
    client: InventoryClient<Channel>,
    key: ServiceKey,
}

fn validate_reply(row: &ReservationReply, saga_id: Uuid) -> Result<State, Status> {
    if Uuid::parse_str(&row.saga_id).ok() != Some(saga_id)
        || row.product_id <= 0
        || !(1..=999).contains(&row.quantity)
        || row.unit_price_cents < 0
    {
        return Err(Status::data_loss("invalid reservation reply identity"));
    }
    match ReservationState::try_from(row.state) {
        Ok(ReservationState::Held) => Ok(State::Held),
        Ok(ReservationState::Confirmed) => Ok(State::Confirmed),
        Ok(ReservationState::Released) => Ok(State::Released),
        Ok(ReservationState::Rejected) => Ok(State::Rejected),
        _ => Err(Status::data_loss("unknown reservation reply state")),
    }
}

impl InventoryRemote {
    pub async fn connect(address: &str, key: ServiceKey) -> anyhow::Result<Self> {
        let endpoint = Endpoint::from_shared(address.to_owned())?
            .connect_timeout(Duration::from_millis(300))
            .timeout(Duration::from_millis(900));
        let channel = tokio::time::timeout(Duration::from_secs(1), endpoint.connect()).await??;
        Ok(Self {
            client: InventoryClient::new(channel)
                .max_decoding_message_size(MAX_MESSAGE_BYTES)
                .max_encoding_message_size(MAX_MESSAGE_BYTES),
            key,
        })
    }

    pub async fn apply(&self, command: &Command, action: Action) -> Result<State, Status> {
        command
            .validate()
            .map_err(|_| Status::invalid_argument("invalid reservation input"))?;
        let mut request = Request::new(ReservationCommand {
            saga_id: command.saga_id.to_string(),
            product_id: command.product_id,
            quantity: command.quantity,
            unit_price_cents: command.unit_price_cents,
        });
        self.key.attach(&mut request);
        request.set_timeout(Duration::from_millis(900));
        let mut client = self.client.clone();
        let response = tokio::time::timeout(Duration::from_secs(1), async {
            match action {
                Action::Reserve => client.reserve(request).await,
                Action::Confirm => client.confirm(request).await,
                Action::Release => client.release(request).await,
            }
        })
        .await
        .map_err(|_| Status::deadline_exceeded("inventory result may be unknown"))??
        .into_inner();
        let state = validate_reply(&response, command.saga_id)?;
        if (
            response.product_id,
            response.quantity,
            response.unit_price_cents,
        ) != (
            command.product_id,
            command.quantity,
            command.unit_price_cents,
        ) {
            return Err(Status::data_loss("reservation reply parameters differ"));
        }
        Ok(state)
    }

    pub async fn query(&self, saga_id: Uuid) -> Result<Option<ReservationReply>, Status> {
        if saga_id.is_nil() {
            return Err(Status::invalid_argument("nil saga UUID"));
        }
        let mut request = Request::new(GetReservationRequest {
            saga_id: saga_id.to_string(),
        });
        self.key.attach(&mut request);
        request.set_timeout(Duration::from_millis(900));
        let mut client = self.client.clone();
        match tokio::time::timeout(Duration::from_secs(1), client.get_reservation(request)).await {
            Err(_) => Err(Status::deadline_exceeded(
                "inventory query budget exhausted",
            )),
            Ok(Err(error)) if error.code() == tonic::Code::NotFound => Ok(None),
            Ok(Err(error)) => Err(error),
            Ok(Ok(response)) => {
                let row = response.into_inner();
                validate_reply(&row, saga_id)?;
                Ok(Some(row))
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn future_or_unspecified_state_is_not_assumed_successful() {
        let id = Uuid::new_v4();
        let mut reply = ReservationReply {
            saga_id: id.to_string(),
            product_id: 1,
            quantity: 1,
            unit_price_cents: 19900,
            state: 0,
        };
        assert_eq!(
            validate_reply(&reply, id).unwrap_err().code(),
            tonic::Code::DataLoss
        );
        reply.state = 99;
        assert!(validate_reply(&reply, id).is_err());
        reply.state = ReservationState::Held as i32;
        assert_eq!(validate_reply(&reply, id).unwrap(), State::Held);
        assert!(validate_reply(&reply, Uuid::new_v4()).is_err());
    }
}
