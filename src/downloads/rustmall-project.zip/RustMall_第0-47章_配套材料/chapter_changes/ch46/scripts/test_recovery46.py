"""Negative histories for the read-only recovery classifier (no Docker required)."""
import copy
import unittest
from recovery46 import reconcile


def completed():
    product = {'id': 7, 'name': 'Keyboard', 'price_cents': 100, 'stock': 8, 'listed': False}
    row = {'product_id': 7, 'revision': 4, 'payload': product.copy()}
    return {'orders': [{'id': 'order-1', 'actor_id': 2, 'product_id': 7, 'quantity': 2,
                       'unit_price': 100, 'amount': 200, 'state': 'completed'}],
            'payments': [{'saga_id': 'order-1', 'actor_id': 2, 'amount': 200, 'state': 'paid'}],
            'effects': [{'saga_id': 'order-1', 'kind': 'paid', 'amount': 200}],
            'inventory': [{'saga_id': 'order-1', 'product_id': 7, 'quantity': 2,
                           'unit_price_cents': 100, 'state': 'confirmed'}],
            'users': [{'id': 2}], 'products': [{**product, 'revision': 4}],
            'projection': [copy.deepcopy(row)], 'rebuild': [copy.deepcopy(row)]}


class RecoveryHistories(unittest.TestCase):
    def codes(self, data):
        return {x['code'] for x in reconcile(data)['findings']}

    def test_completed_tombstone_is_clean_and_input_unchanged(self):
        data = completed(); original = copy.deepcopy(data)
        self.assertTrue(reconcile(data)['clean'])
        self.assertEqual(data, original)

    def test_completed_receipt_loss_is_not_a_success(self):
        data = completed(); data['payments'] = []; data['effects'] = []
        self.assertIn('completed_participants_mismatch', self.codes(data))

    def test_other_users_receipt_is_not_accepted(self):
        data = completed(); data['payments'][0]['actor_id'] = 9
        self.assertIn('payment_binding_mismatch', self.codes(data))

    def test_same_total_different_quantity_or_price_is_not_accepted(self):
        data = completed(); data['inventory'][0].update(quantity=1, unit_price_cents=200)
        self.assertIn('inventory_binding_mismatch', self.codes(data))

    def test_paid_order_restored_to_charging_needs_resume_not_corruption_claim(self):
        data = completed(); data['orders'][0]['state'] = 'charging'
        self.assertEqual(self.codes(data), {'pending_requires_resume'})

    def test_cancelled_cannot_hide_confirmed_stock(self):
        data = completed(); data['orders'][0]['state'] = 'cancelled'
        data['payments'][0]['state'] = 'refunded'
        data['effects'].append({'saga_id': 'order-1', 'kind': 'refunded', 'amount': 200})
        self.assertIn('cancelled_retains_effect', self.codes(data))

    def test_refund_barrier_is_not_an_actual_refund_effect(self):
        data = completed(); data['orders'][0]['state'] = 'cancelled'
        data['inventory'][0]['state'] = 'released'; data['payments'][0]['state'] = 'refunded'
        data['effects'] = [{'saga_id': 'order-1', 'kind': 'refund_barrier', 'amount': 200}]
        self.assertTrue(reconcile(data)['clean'])

    def test_real_paid_then_refunded_is_clean_when_stock_released(self):
        data = completed(); data['orders'][0]['state'] = 'cancelled'
        data['inventory'][0]['state'] = 'released'; data['payments'][0]['state'] = 'refunded'
        data['effects'].append({'saga_id': 'order-1', 'kind': 'refunded', 'amount': 200})
        self.assertTrue(reconcile(data)['clean'])

    def test_refund_without_paid_effect_is_rejected(self):
        data = completed(); data['payments'][0]['state'] = 'refunded'
        data['effects'] = [{'saga_id': 'order-1', 'kind': 'refunded', 'amount': 200}]
        self.assertIn('payment_effects_mismatch', self.codes(data))

    def test_duplicate_effect_or_wrong_amount_is_detected(self):
        data = completed(); data['effects'].append(dict(data['effects'][0], amount=201))
        self.assertTrue({'payment_effects_mismatch', 'effect_amount_mismatch'} <= self.codes(data))

    def test_missing_order_does_not_erase_participant_responsibility(self):
        data = completed(); data['orders'] = []
        self.assertIn('orphan_participant_receipt', self.codes(data))

    def test_same_revision_different_payload_is_detected(self):
        data = completed(); data['rebuild'][0]['payload']['stock'] = 999
        self.assertEqual(self.codes(data), {'rebuild_not_converged'})

    def test_missing_actor_or_projection_is_detected(self):
        data = completed(); data['users'] = []; data['projection'] = []
        self.assertEqual(self.codes(data), {'order_actor_missing', 'projection_not_converged'})

    def test_manual_has_explicit_owner_responsibility(self):
        data = completed(); data['orders'][0]['state'] = 'manual'
        self.assertIn('manual_requires_owner', self.codes(data))


if __name__ == '__main__':
    unittest.main()
