"""Read-only reconciliation and quiesced six-database logical recovery lab.

Trusted local admin only. Archives can contain executable SQL and private user data.
No live cross-database snapshot, role/ACL restoration, Kafka rewind, or cutover.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time
import uuid

DATABASES = ('catalog', 'users', 'payments', 'orders', 'projection', 'rebuild')
LIMIT = 100000


def execute(container, command, input=None):
    r = subprocess.run(['docker', 'exec', '-i', container, *command], input=input,
                       stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=900)
    if r.returncode:
        raise RuntimeError(f'{command[0]} failed (exit {r.returncode}); private database response suppressed')
    return r.stdout


def sql(container, database, query):
    if not re.fullmatch(r'rustmall_(?:[a-z0-9_]{1,60})', database):
        raise ValueError('invalid database name')
    return execute(container, ['psql', '-X', '-qAt', '-v', 'ON_ERROR_STOP=1', '-U',
                              'postgres', '-d', database],
                   ("SET timezone='UTC'; SET statement_timeout='30s';\n" + query).encode()).decode().strip()


def records(container, database, query):
    return [json.loads(x) for x in sql(container, database,
            'SELECT row_to_json(r) FROM (' + query + ') r;').splitlines()]


def fingerprint(container, database):
    tables = sql(container, database, "SELECT tablename FROM pg_tables WHERE schemaname='public' ORDER BY 1;").splitlines()
    result = {'tables': {}, 'sequences': {}}
    for name in tables:
        if not re.fullmatch(r'[a-z_][a-z0-9_]*', name):
            raise ValueError('unsupported table identifier')
        count = int(sql(container, database, f'SELECT count(*) FROM public.{name};'))
        if count > LIMIT:
            raise ValueError('lab table exceeds bounded fingerprint limit; use a streaming production verifier')
        # JSONB normalizes object key order. Sort complete rows, preserving duplicates.
        rows = sql(container, database, f'SELECT to_jsonb(r)::text FROM public.{name} r ORDER BY to_jsonb(r)::text;')
        result['tables'][name] = {'rows': count, 'sha256': hashlib.sha256(rows.encode()).hexdigest()}
    sequences = sql(container, database, "SELECT sequencename FROM pg_sequences WHERE schemaname='public' ORDER BY 1;").splitlines()
    for name in sequences:
        if not re.fullmatch(r'[a-z_][a-z0-9_]*', name):
            raise ValueError('unsupported sequence identifier')
        result['sequences'][name] = sql(container, database, f'SELECT last_value,is_called FROM public.{name};')
    result['invalid_constraints'] = int(sql(container, database,
        "SELECT count(*) FROM pg_constraint WHERE connamespace='public'::regnamespace AND NOT convalidated;"))
    return result


def snapshot(container, databases):
    if set(databases) != set(DATABASES):
        raise ValueError('all six logical database names required')
    return {name: fingerprint(container, databases[name]) for name in DATABASES}


def quiet(container):
    names = ','.join("'rustmall_" + name + "'" for name in DATABASES)
    count = int(sql(container, 'rustmall_orders',
        f"SELECT count(*) FROM pg_stat_activity WHERE datname IN ({names}) AND backend_type='client backend' AND pid<>pg_backend_pid();"))
    if count:
        raise ValueError('other database clients remain; stop ALL lab roles and migrations before backup')


def file_hash(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def backup(container, directory):
    # Operator must first stop every writer, reader and migration; this check is
    # evidence of present clients, not a fence against future privileged clients.
    quiet(container)
    directory.mkdir(mode=0o700)  # New bundle only, never overwrite.
    started = time.monotonic()
    databases = {name: 'rustmall_' + name for name in DATABASES}
    before = snapshot(container, databases)
    archives = {}
    for name, database in databases.items():
        path = directory / (name + '.dump')
        with path.open('xb') as output:
            os.chmod(path, 0o600)
            r = subprocess.run(['docker', 'exec', '-i', container, 'pg_dump', '-U', 'postgres',
                '--format=custom', '--no-owner', '--no-acl', '--dbname', database],
                stdout=output, stderr=subprocess.PIPE, timeout=900)
            if r.returncode:
                raise RuntimeError('pg_dump failed; incomplete bundle retained without manifest')
            output.flush()
            os.fsync(output.fileno())
        archives[name] = {'file': path.name, 'sha256': file_hash(path), 'bytes': path.stat().st_size}
    quiet(container)
    after = snapshot(container, databases)
    if before != after:
        raise ValueError('database contents changed during backup; bundle has NO success manifest')
    manifest = {'format': 1, 'set_id': uuid.uuid4().hex, 'archives': archives,
                'fingerprints': before, 'elapsed_seconds': round(time.monotonic() - started, 3),
                'scope': 'operator-quiesced local six DB logical set; no future-writer fence, roles, ACL, Kafka, external payment or cutover'}
    path = directory / 'manifest.json'
    path.write_text(json.dumps(manifest, indent=2) + '\n')
    os.chmod(path, 0o600)
    return {'manifest_sha256': file_hash(path), 'databases': 6, 'seconds': manifest['elapsed_seconds']}


def restore(container, directory, expected_sha256, prefix, bootstrap_owners=False):
    if not re.fullmatch(r'rustmall_restore_[a-z0-9]{1,20}', prefix):
        raise ValueError('new verification prefix must be rustmall_restore_*')
    path = directory / 'manifest.json'
    if path.is_symlink() or not re.fullmatch('[0-9a-f]{64}', expected_sha256) or file_hash(path) != expected_sha256:
        raise ValueError('manifest checksum mismatch')
    manifest = json.loads(path.read_text())
    if manifest['format'] != 1 or set(manifest['archives']) != set(DATABASES) or set(manifest['fingerprints']) != set(DATABASES):
        raise ValueError('invalid six-database manifest')
    targets = {name: prefix + '_' + name for name in DATABASES}
    for name in DATABASES:
        entry = manifest['archives'][name]
        if entry['file'] != name + '.dump':
            raise ValueError('archive must use fixed local basename')
        archive = directory / entry['file']
        if archive.is_symlink() or file_hash(archive) != entry['sha256'] or archive.stat().st_size != entry['bytes']:
            raise ValueError('archive integrity mismatch')
        with archive.open('rb') as header:
            if header.read(5) != b'PGDMP':
                raise ValueError('custom archive required')
        with archive.open('rb') as stream:
            # Do not buffer a header read before passing this descriptor to Docker.
            r = subprocess.run(['docker', 'exec', '-i', container, 'pg_restore', '--list'],
                stdin=stream, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, timeout=90)
            if r.returncode:
                raise ValueError('invalid archive index')
        exists = sql(container, 'rustmall_orders', "SELECT count(*) FROM pg_database WHERE datname='" + targets[name] + "';")
        if exists != '0':
            raise ValueError('verification target already exists; no databases were created')
    if bootstrap_owners:
        for name in DATABASES:
            exists = sql(container, 'rustmall_orders', "SELECT count(*) FROM pg_roles WHERE rolname='migrate_" + name + "' AND NOT rolsuper AND NOT rolcreatedb AND NOT rolcreaterole;")
            if exists != '1':
                raise ValueError('expected restricted bootstrap owner missing')
    # All integrity and target checks precede the first mutation. A concurrent
    # creator still causes createdb to fail; never reuse, DROP or --clean a target.
    started = time.monotonic()
    for name in DATABASES:
        target = targets[name]
        owner_args = ['--owner', 'migrate_' + name] if bootstrap_owners else []
        execute(container, ['createdb', '-U', 'postgres', '--template=template0', *owner_args, target])
        with (directory / (name + '.dump')).open('rb') as stream:
            r = subprocess.run(['docker', 'exec', '-i', container, 'pg_restore', '-U', 'postgres',
                '--exit-on-error', '--single-transaction', '--no-owner', '--no-acl',
                *(['--role=migrate_' + name] if bootstrap_owners else []), '--dbname', target],
                stdin=stream, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, timeout=900)
            if r.returncode:
                raise RuntimeError('restore failed; created verification targets retained for diagnosis')
    actual = snapshot(container, targets)
    if actual != manifest['fingerprints']:
        raise ValueError('restored table/sequence/constraint fingerprints differ; no recovery success')
    return {'databases': targets, 'verified_tables': sum(len(x['tables']) for x in actual.values()),
            'verified_sequences': sum(len(x['sequences']) for x in actual.values()),
            'seconds': round(time.monotonic() - started, 3), 'matches': True,
            'scope': 'new offline verification DBs only; privileges and application cutover not restored'}


def collect(container, databases):
    def rows(name, query):
        return records(container, databases[name], query)
    # Exports intentionally exclude usernames, password hashes, tokens and sessions.
    return {
        'orders': rows('orders', 'SELECT id,actor_id,product_id,quantity,unit_price,amount,state FROM orders'),
        'payments': rows('payments', 'SELECT saga_id,actor_id,amount,state FROM payments'),
        'effects': rows('payments', 'SELECT saga_id,kind,amount FROM payment_effects'),
        'inventory': rows('catalog', 'SELECT saga_id,product_id,quantity,unit_price_cents,state FROM inventory_reservations'),
        'users': rows('users', 'SELECT id FROM users'),
        'products': rows('catalog', 'SELECT id,revision,name,price_cents,stock,(delisted_at IS NULL) AS listed FROM products'),
        'projection': rows('projection', 'SELECT product_id,revision,payload FROM catalog_view'),
        'rebuild': rows('rebuild', 'SELECT product_id,revision,payload FROM catalog_view'),
    }


def reconcile(data):
    """Classify a quiesced cut. Never issues repair commands or rewrites states."""
    findings = []
    def add(code, identity):
        findings.append({'code': code, 'identity': str(identity)})
    orders = {x['id']: x for x in data['orders']}
    payments = {x['saga_id']: x for x in data['payments']}
    inventory = {x['saga_id']: x for x in data['inventory']}
    users = {x['id'] for x in data['users']}
    effects = {}
    for effect in data['effects']:
        effects.setdefault(effect['saga_id'], []).append(effect)
    for identity in sorted(set(payments) | set(inventory)):
        if identity not in orders:
            add('orphan_participant_receipt', identity)
    for identity, order in sorted(orders.items()):
        payment, reservation = payments.get(identity), inventory.get(identity)
        if order['actor_id'] not in users:
            add('order_actor_missing', identity)
        if payment and (payment['actor_id'], payment['amount']) != (order['actor_id'], order['amount']):
            add('payment_binding_mismatch', identity)
        if reservation and (reservation['product_id'], reservation['quantity'], reservation['unit_price_cents']) != (order['product_id'], order['quantity'], order['unit_price']):
            add('inventory_binding_mismatch', identity)
        pstate = payment['state'] if payment else None
        istate = reservation['state'] if reservation else None
        if order['state'] == 'completed':
            if pstate != 'paid' or istate != 'confirmed':
                add('completed_participants_mismatch', identity)
        elif order['state'] == 'cancelled':
            if pstate == 'paid' or istate in ('held', 'confirmed', 'pending'):
                add('cancelled_retains_effect', identity)
        else:
            # Some intermediate cuts are legitimate. Classify for review/resume,
            # not as corruption or proof that an automatic repair is safe.
            add('manual_requires_owner' if order['state'] == 'manual' else 'pending_requires_resume', identity)
    for identity, payment in sorted(payments.items()):
        entries = effects.get(identity, [])
        kinds = [x['kind'] for x in entries]
        if any(x['amount'] != payment['amount'] for x in entries):
            add('effect_amount_mismatch', identity)
        expected = {'paid': {'paid'}, 'declined': {'declined'}}.get(payment['state'])
        if payment['state'] == 'refunded':
            valid = set(kinds) in ({'paid', 'refunded'}, {'refund_barrier'})
        else:
            valid = set(kinds) == expected
        if not valid or len(kinds) != len(set(kinds)):
            add('payment_effects_mismatch', identity)
    for identity in sorted(set(effects) - set(payments)):
        add('orphan_effect', identity)
    products = {x['id']: x for x in data['products']}
    for name in ('projection', 'rebuild'):
        view = {x['product_id']: x for x in data[name]}
        for identity in sorted(set(products) | set(view)):
            product, row = products.get(identity), view.get(identity)
            if not product or not row or row['revision'] != product['revision'] or row['payload'] != {k: product[k] for k in ('id','name','price_cents','stock','listed')}:
                add(name + '_not_converged', identity)
    return {'clean': not findings, 'findings': findings, 'orders': len(orders),
            'scope': 'read-only quiesced lab classification; pending is review, not corruption; no repair or live consistent snapshot'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('operation', choices=['backup', 'restore', 'audit'])
    parser.add_argument('--container', required=True)
    parser.add_argument('--directory', type=Path)
    parser.add_argument('--expected-manifest-sha256')
    parser.add_argument('--prefix')
    parser.add_argument('--ack-quiesced-lab', action='store_true')
    args = parser.parse_args()
    if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]{0,127}', args.container):
        parser.error('invalid container identity')
    if args.operation == 'backup':
        if not args.ack_quiesced_lab or not args.directory or args.prefix or args.expected_manifest_sha256:
            parser.error('backup needs NEW directory and --ack-quiesced-lab after stopping ALL roles')
        report = backup(args.container, args.directory)
    elif args.operation == 'restore':
        if not args.directory or not args.prefix or not args.expected_manifest_sha256:
            parser.error('restore needs directory, new prefix and expected manifest SHA256')
        report = restore(args.container, args.directory, args.expected_manifest_sha256, args.prefix)
    else:
        if not args.ack_quiesced_lab or args.directory or args.expected_manifest_sha256:
            parser.error('audit needs --ack-quiesced-lab; optional restored prefix')
        if args.prefix and not re.fullmatch(r'rustmall_restore_[a-z0-9]{1,20}', args.prefix):
            parser.error('invalid verification prefix')
        if not args.prefix:
            quiet(args.container)
        databases = {x: (args.prefix or 'rustmall') + '_' + x for x in DATABASES}
        report = reconcile(collect(args.container, databases))
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 2 if report.get('clean') is False else 0


if __name__ == '__main__':
    try:
        sys.exit(main())
    except (OSError, ValueError, KeyError, RuntimeError, subprocess.TimeoutExpired) as error:
        sys.exit('Recovery lab failed: ' + type(error).__name__ + '; no success or application cutover is claimed')
