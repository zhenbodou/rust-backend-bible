#!/usr/bin/env bash
set -euo pipefail
# 只允许一次性 GitHub runner；本地验收使用 check-delivery.py。
[[ "${CI:-}" == true && "${GITHUB_ACTIONS:-}" == true ]] || {
  echo '请在 GitHub Actions 的临时 runner 中执行。' >&2; exit 2;
}
[[ "${GITHUB_RUN_ID:-}" =~ ^[0-9]+$ && "${GITHUB_RUN_ATTEMPT:-}" =~ ^[0-9]+$ ]] || {
  echo '缺少有效的运行编号。' >&2; exit 2;
}
[[ -n "${GITHUB_OUTPUT:-}" ]] || { echo '缺少步骤输出文件。' >&2; exit 2; }
image="rustmall/ci:run-${GITHUB_RUN_ID}-${GITHUB_RUN_ATTEMPT}"
report_dir="${RUNNER_TEMP:?}/rustmall-delivery-${GITHUB_RUN_ID}-${GITHUB_RUN_ATTEMPT}"
build_args=()
if [[ -n "${RUSTMALL_RUST_IMAGE:-}" ]]; then
  build_args+=(--build-arg "RUST_IMAGE=$RUSTMALL_RUST_IMAGE")
fi
docker build "${build_args[@]}" --tag "$image" .
python3 scripts/check-delivery.py --image "$image" --report-dir "$report_dir" --recovery-cutover
# 直接取本次验收记录的镜像 ID；发布步骤不能重新 build，也不能只相信可变标签。
python3 - "$report_dir/container.json" "$GITHUB_OUTPUT" <<'PY'
import json,re,sys
from pathlib import Path
r=json.loads(Path(sys.argv[1]).read_text())
assert r['success'] and r['cleanup_exit']==0 and r['passed']==15
assert r['new_cluster_cutover']['new_order_only_in_target'] and r['new_cluster_cutover']['existing_revocation_preserved']
assert r['new_cluster_cutover']['final_audit']['clean']
image=r['image_id'];assert re.fullmatch(r'sha256:[0-9a-f]{64}',image)
with open(sys.argv[2],'a') as f:f.write('tested_image_id='+image+'\n')
PY
