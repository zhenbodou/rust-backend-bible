"""Planned local DB-only cutover of the checker's OWN disposable deployment.

Source remains intact. Same Kafka, Redis, signing keys and service tokens retained;
this does not claim regional DR, broker recovery or a safe rollback after new writes.
"""
import copy
import json
from pathlib import Path
import re
import shutil
import uuid
import recovery46


def exercise_cutover(stage, compose, config, profile, work, args, run, until, api,
                     roles, report, checks, private, source, bundle, metadata,
                     actor, live_token, revoke_token, request, key, oid, pid):
    stopped = roles + (['tls'] if args.tls_dir else [])
    run(compose + ['stop', *stopped])
    spec = copy.deepcopy(config['services']['postgres'])
    for volume in spec['volumes']:
        if volume['target'] == '/var/lib/postgresql/data':
            volume['source'] = 'recovery-data'
    overlay = Path(work.name) / 'recovery-overlay.json'
    overlay.write_text(json.dumps({'services': {'postgres-recovery': spec},
                                   'volumes': {'recovery-data': {}}}))
    alternate = compose + ['-f', str(overlay)]
    # The parent uses its original compose command for cleanup even if this
    # function fails. Register extra resources with the parent before mutations.
    compose.extend(['-f', str(overlay)])
    run(alternate + ['up', '-d', '--wait', '--wait-timeout', '120', 'postgres-recovery'])
    target = run(alternate + ['ps', '-q', 'postgres-recovery']).stdout.strip()
    prefix = 'rustmall_restore_' + uuid.uuid4().hex[:12]
    restored = recovery46.restore(target, bundle, metadata['manifest_sha256'], prefix,
                                  bootstrap_owners=True)
    assert restored['matches']
    for name, verification in restored['databases'].items():
        # Bootstrap creates EMPTY databases with role credentials. Keep them under
        # other names; never DROP or replace a populated business database.
        db = 'rustmall_' + name
        assert recovery46.sql(target, db,
            "SELECT count(*) FROM pg_tables WHERE schemaname='public';") == '0'
        # PostgreSQL cannot rename the database of the active connection.
        connection = 'rustmall_catalog' if name == 'orders' else 'rustmall_orders'
        recovery46.sql(target, connection, f'ALTER DATABASE {db} RENAME TO rustmall_bootstrap_{name};')
        recovery46.sql(target, connection, f'ALTER DATABASE {verification} RENAME TO {db};')
        accounts = {'catalog': ['app_catalog','relay_catalog','inventory_admin'],
                    'orders': ['app_orders','worker_orders']}.get(name, ['app_' + name])
        recovery46.sql(target, db, f'REVOKE ALL ON DATABASE {db} FROM PUBLIC;')
        recovery46.sql(target, db, f'GRANT CONNECT ON DATABASE {db} TO ' + ','.join(accounts) + ';')
    recovery46.execute(target, ['psql','-X','-q','-v','ON_ERROR_STOP=1','-U','postgres','-d','rustmall_orders'],
                       (stage/'deploy/delivery40/permissions.sql').read_bytes())
    original = {name:'rustmall_'+name for name in recovery46.DATABASES}
    assert recovery46.reconcile(recovery46.collect(target, original))['clean']
    candidate = Path(work.name)/'recovery-profile'
    shutil.copytree(profile, candidate)
    candidate.chmod(0o700); (candidate/'secrets').chmod(0o700)
    for path in (candidate/'secrets').iterdir():
        if path.name.endswith('_url'):
            value = path.read_text()
            if '@postgres:5432/' in value:
                path.chmod(0o600)
                path.write_text(value.replace('@postgres:5432/', '@postgres-recovery:5432/'))
                path.chmod(0o444)
        value = path.read_text().strip()
        if len(value)>20:private.append(value)
    env = candidate/'compose.env'
    env.write_text(env.read_text().replace(str(profile/'secrets'), str(candidate/'secrets')))
    env.chmod(0o600)
    # Preserve logical consumer identities and JWT/internal tokens exactly. Only
    # the DB host changes. Force recreation reloads new file-mounted URLs.
    switched = list(alternate)
    switched[switched.index('--env-file')+1] = str(env)
    run(switched + ['up','-d','--no-deps','--force-recreate','--wait','--wait-timeout','180',*stopped])
    assert api('/api/v1/auth/me',token=live_token)[0] == 200
    assert api('/api/v1/auth/me',token=revoke_token)[0] == 401
    assert api('/api/v1/orders','POST',request,live_token,key)[1]['id'] == oid
    status, product = api('/api/v1/products','POST',
        {'name':'恢复环境新商品','price_cents':900,'stock':4}, live_token, uuid.uuid4())
    assert status == 201 and int(product['id']) > pid
    new_pid = int(product['id']); new_key = uuid.uuid4()
    status, order = api('/api/v1/orders','POST',{'product_id':new_pid,'quantity':1},live_token,new_key)
    assert status == 202
    new_oid = str(uuid.UUID(order['id']))
    until(lambda: recovery46.sql(target,'rustmall_orders',
        f"SELECT state FROM orders WHERE id='{new_oid}';") == 'completed', 'new DB restored Saga complete')
    assert recovery46.sql(target,'rustmall_payments',
        f"SELECT count(*) FROM payment_effects WHERE saga_id='{new_oid}' AND kind='paid';") == '1'
    assert recovery46.sql(source,'rustmall_orders',f"SELECT count(*) FROM orders WHERE id='{new_oid}';") == '0'
    assert recovery46.sql(target,'rustmall_catalog',f'SELECT stock FROM products WHERE id={new_pid};') == '3'
    assert api('/api/v1/orders','POST',{'product_id':new_pid,'quantity':1},live_token,new_key)[1]['id'] == new_oid
    def projected(db):
        return recovery46.sql(target,db,f"SELECT count(*) FROM catalog_view WHERE product_id={new_pid} AND (payload->>'stock')::int=3;") == '1'
    until(lambda: projected('rustmall_projection') and projected('rustmall_rebuild'), 'restored projections converge')
    # Use actual TCP login and password-mounted credentials for the new server.
    command='export PGPASSWORD="$(cat /run/secrets/app_users_password)"; exec psql -h 127.0.0.1 -U app_users -d rustmall_catalog -X -v ON_ERROR_STOP=1 -At'
    denied=run(switched+['exec','-T','postgres-recovery','sh','-ec',command],input='SELECT 1;\n',ok=False)
    assert denied.returncode and 'permission denied for database' in denied.stderr
    run(switched+['stop',*stopped])
    final_audit=recovery46.reconcile(recovery46.collect(target,original))
    assert final_audit['clean'],final_audit
    report['new_cluster_cutover']={'restored_tables':restored['verified_tables'],
        'source_retained':True,'new_order_only_in_target':True,'existing_revocation_preserved':True,
        'new_paid_effects':1,'new_stock':3,'final_audit':final_audit,
        'scope':'planned local PostgreSQL-only cutover; same Kafka/Redis/keys retained; no post-write rollback or regional DR proof'}
    checks.append('NEW PostgreSQL cluster restores all six DBs with restricted owners, grants and fresh URL mounts; existing session/revocation and original order identity preserved')
    checks.append('real HTTPS new product/order completes ONLY in restored cluster, paid once and stock3; same-key replay, both projections and cross-DB access denial pass; final quiesced audit clean')
    return switched
