BEGIN TRANSACTION ISOLATION LEVEL REPEATABLE READ READ ONLY;
SET LOCAL statement_timeout='5s';
SELECT state,count(*) AS receipts,sum(amount) AS receipt_amount
FROM payments GROUP BY state ORDER BY state;
SELECT kind,count(*) AS effects,sum(amount) AS effect_amount
FROM payment_effects GROUP BY kind ORDER BY kind;
SELECT p.saga_id,p.state,p.amount,
       count(e.effect_id) AS effects,
       bool_and(e.amount=p.amount) AS all_amounts_match
FROM payments p LEFT JOIN payment_effects e USING(saga_id)
GROUP BY p.saga_id,p.state,p.amount
HAVING count(e.effect_id)=0 OR NOT bool_and(e.amount=p.amount);
COMMIT;
