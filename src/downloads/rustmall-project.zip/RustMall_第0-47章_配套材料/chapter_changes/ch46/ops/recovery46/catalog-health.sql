BEGIN TRANSACTION ISOLATION LEVEL REPEATABLE READ READ ONLY;
SET LOCAL statement_timeout='5s';
SELECT state,count(*) AS receipts,min(updated_at) AS oldest_update
FROM inventory_reservations GROUP BY state ORDER BY state;
SELECT count(*) FILTER (WHERE delivered_at IS NULL) AS pending,
       min(occurred_at) FILTER (WHERE delivered_at IS NULL) AS oldest_pending,
       max(attempts) FILTER (WHERE delivered_at IS NULL) AS max_attempts
FROM product_outbox;
SELECT event_id,aggregate_id,revision,attempts,last_error,leased_until
FROM product_outbox WHERE delivered_at IS NULL
ORDER BY occurred_at,event_id LIMIT 50;
COMMIT;
