BEGIN TRANSACTION ISOLATION LEVEL REPEATABLE READ READ ONLY;
SET LOCAL statement_timeout='5s';
SELECT state,count(*) AS orders,
       min(created_at) AS earliest_created,
       max(attempts) AS highest_attempts,
       count(*) FILTER (WHERE next_attempt<=statement_timestamp()) AS due,
       count(*) FILTER (WHERE leased_until>statement_timestamp()) AS active_leases,
       count(*) FILTER (WHERE lease_token IS NOT NULL AND leased_until<=statement_timestamp()) AS expired_leases
FROM orders GROUP BY state ORDER BY state;
SELECT id,state,attempts,last_error,next_attempt,leased_until,
       extract(epoch FROM statement_timestamp()-created_at)::bigint AS age_seconds
FROM orders WHERE state NOT IN ('completed','cancelled')
ORDER BY created_at,id LIMIT 50;
SELECT order_id,from_state,to_state,reason,occurred_at
FROM order_transitions ORDER BY occurred_at DESC,id DESC LIMIT 50;
COMMIT;
