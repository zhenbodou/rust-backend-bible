# RustMall 第0—42章累积工程

本检查点继续同一套用户、商品库存、实验支付、持久订单、Outbox/Inbox、Kafka双投影、观测和治理代码。Rust固定1.92.0。第40章新增完整容器镜像、六库迁移与分角色权限、CI、Helm和GitOps配置。

## 当前推荐入口

在本检查点根目录运行：

```sh
docker build --tag rustmall/book:ch42-candidate .
python3 scripts/create-delivery-env.py
docker compose --env-file .delivery.local/compose.env up -d --wait --wait-timeout 240
```

访问 `http://127.0.0.1:18086`。根Compose入口包含deploy/delivery40的完整配置，等价于显式指定该配置文件。本地数据集与原生.saga.local数据集隔离；不要重建已有凭据或把旧账户ID直接当作新身份。初始化新卷不等于迁移历史业务数据。

完整说明：[启动、秘密、权限与发布边界](docs/delivery40.md)。秘密目录不进入版本控制、镜像或配套归档。

## 对自己的新临时数据集验收

先停止其他占用18086的本章实验。以下两个入口不能并行：

```sh
python3 scripts/check-delivery.py --image rustmall/book:ch42-candidate \
  --report-dir /tmp/rustmall-delivery40-report

python3 scripts/check-kubernetes.py --kind kind --helm helm \
  --image rustmall/book:ch42-candidate \
  --report-dir /tmp/rustmall-kubernetes40-report
```

第二条需要kind、kubectl、Helm。它创建随机命名的单节点集群、独立kubeconfig及实验基础设施，不修改默认集群配置。两个入口只清理自己创建的资源，结束时删除其临时实验数据卷。手动环境的down不带--volumes时保留数据库卷。

第40章已实测Kind0.33.0/Kubernetes1.36.4/Helm4.3.1；第41章重新实测Linux arm64镜像、Docker完整链路、数据库计划与逻辑恢复，未以旧集群记录冒充新一轮Kind验收。单节点与单副本实验不证明生产高可用。kindnet没有证明NetworkPolicy执行；远端Actions、注册表发布和Argo同步未在本轮执行。

## 源码检查

需要C/C++工具链、CMake及相应开发库。数据库测试使用专门可丢弃的测试PostgreSQL管理员和Redis；不要指向运行中的业务数据库。

```sh
cargo +1.92.0 fmt --all --check
cargo +1.92.0 clippy --locked --workspace --all-targets --all-features -- -D warnings
cargo +1.92.0 test --locked --workspace --all-features
ruby scripts/check-chart.rb
```

不同检查点使用独立CARGO_TARGET_DIR，防止同名包的旧编译产物混用。369项workspace测试包含8项新增数据库并发测试及3项入口子进程测试；5项旧ignored容器测试需要单独选择，不能把ignored算作通过。

## 业务约束

普通商品PUT仍可修改资料，但不能覆盖锁定后的绝对库存；补货/盘亏由inventory-adjust及专用管理凭据执行。请求重试保留原Idempotency-Key和Saga身份，付款未知时继续查询/恢复。注销先持久撤销，Redis键丢失不会恢复会话。两个投影使用不同数据库、消费身份和Inbox，offset在数据库提交之后推进。

payments是实验幂等付款模型，不连接真实渠道，也不是复式会计总账。

## 前面章节的原生运行路线

[第36章订单与Saga](docs/saga-checkpoint-36.md)、[第37章事件与重建](docs/events-checkpoint-37.md)、[第38章观测](docs/observability-checkpoint-38.md)继续保留。第39章故障脚本使用其专用.saga.local配置，不能拿容器凭据混跑。更早单体Compose/Kubernetes实验请使用对应历史检查点；当前Dockerfile与Chart已切换为完整微服务入口。

后续继续缓存、Kafka运维、TLS、分布式原理、跨库恢复与全书迁移验收。此检查点不是全书最终验收完成的声明。

若本地DockerHub的Rust认证下载超时，可使用已经实测的同版本官方公开ECR镜像：

```sh
docker build --build-arg RUST_IMAGE=public.ecr.aws/docker/library/rust:1.92.0-bookworm \
  --tag rustmall/book:ch42-candidate .
```

这是构建源选择，不更改Rust版本或绕过测试。CI包装脚本也接受可选RUSTMALL_RUST_IMAGE构建镜像参数；本地模拟runner已经按此完成构建及七组容器验收，未登录或推送远端。其他依赖镜像仍需要可访问的可信来源。

## 第41章 PostgreSQL 深入

当前worker候选筛选采用statement_timestamp，租约发放和过期条件写继续使用clock_timestamp。八项新增真实SQLx并发测试已纳入369项完整workspace测试。没有取消幂等、租约或库存事务约束。

```sh
python3 scripts/check-postgres.py --image rustmall/book:ch42-candidate \
  --report-dir /tmp/rustmall-postgres41-report
```

报告目录必须不存在。脚本用实际镜像迁移两个隔离实验库，验证20万行计划、分页、部分索引、只读诊断和新库逻辑恢复，并清理容器及网络。报告和归档只含合成数据。pg-archive.py只能恢复到新验证库，不负责多库PITR、所有者/权限恢复或应用切流。第40章已交付文件不因本检查点而改变。

## 第42章Redis增量

monolith的教学缓存升级v2同槽键与回填许可；当前catalog-http仍读取Catalog RPC，库存与价格判断不改用缓存。users使用固定10次/60秒的有界Lua计数；异常计数或Redis故障均503，注销先提交数据库。两种故障策略不能混用。

```sh
python3 scripts/check-redis.py --report-dir /tmp/rustmall-redis42-report
```

此入口新建不公开端口的实验Redis，使用生成器的实际users ACL，结束时清理自己的容器/卷。仅写合成数据，验证脚本、内存错误、SCAN与有本地fsync确认后的优雅AOF重启；不是断电或Sentinel/Cluster验收。主Compose Redis仍明确无持久化，重启会丢登录窗口；会话撤销的权威记录保存在PostgreSQL。生产限流连续性需要单独设计恢复策略。
