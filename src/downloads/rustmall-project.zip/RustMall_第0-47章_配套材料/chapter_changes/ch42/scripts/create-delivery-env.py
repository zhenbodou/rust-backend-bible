"""Create a NEW isolated container dataset. Never overwrites an existing profile.

Files are readable inside non-root containers; their host directory is0700.
No credential value is printed or included in Compose's environment file.
"""
import argparse,json,os,secrets,uuid
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--output-dir',type=Path,default=Path('.delivery.local'))
p.add_argument('--image',default='rustmall/book:ch42-candidate')
a=p.parse_args();root=a.output_dir.resolve();root.mkdir(mode=0o700);secret_dir=root/'secrets';secret_dir.mkdir(mode=0o700)
roles=json.loads((ROOT/'deploy/delivery40/roles.json').read_text())['databases']
def write(name,value,mode=0o444):
    fd=os.open(secret_dir/name,os.O_WRONLY|os.O_CREAT|os.O_EXCL,mode)
    with os.fdopen(fd,'w') as out:out.write(value+'\n')
for db,spec in roles.items():
    for role in [spec['owner']]+spec['runtime']:
        password=secrets.token_urlsafe(48)
        write(role+'_password',password)
        write(role+'_url',f'postgres://{role}:{password}@postgres:5432/rustmall_{db}?sslmode=disable')
for key in ['postgres_admin_password','jwt_key','catalog_token','inventory_token','payment_token']:
    write(key,secrets.token_urlsafe(48))
redis_user,redis_monitor=secrets.token_urlsafe(48),secrets.token_urlsafe(48)
write('redis_users_url',f'redis://app_users:{redis_user}@redis:6379/0')
write('redis_monitor_password',redis_monitor)
write('redis_acl',f'''user default off
user app_users on >{redis_user} ~users:v1:* +auth +hello +ping +quit +select +client|setname +client|setinfo +eval +evalsha +script|load +strlen +get +pttl +exists +set
user monitor on >{redis_monitor} -@all +auth +hello +ping +quit
'''.rstrip())
group='catalog-view-'+uuid.uuid4().hex
fd=os.open(root/'compose.env',os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
with os.fdopen(fd,'w') as out:
    out.write(f'RUSTMALL_SECRET_DIR={secret_dir}\nRUSTMALL_IMAGE={a.image}\nPROJECTION_GROUP={group}\nREBUILD_GROUP={group}-rebuild\n')
print('Created private container profile; keep it with its volumes. No credentials printed.')
