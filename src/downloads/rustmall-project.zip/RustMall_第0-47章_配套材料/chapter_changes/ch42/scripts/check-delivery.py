"""Verify the actual Linux image and complete role-scoped container deployment."""
from pathlib import Path
import argparse,json,os,re,secrets,stat,subprocess,tempfile,time,urllib.request,urllib.error,uuid,sys
stage=Path(__file__).resolve().parents[1]
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--image',default='rustmall/book:ch42-candidate')
parser.add_argument('--report-dir',type=Path,required=True)
args=parser.parse_args()
if not re.fullmatch(r'[a-zA-Z0-9][a-zA-Z0-9_./:@-]*',args.image):parser.error('invalid image reference')
args.report_dir.mkdir(parents=True,exist_ok=True)
project='rustmall-delivery40-'+uuid.uuid4().hex[:12]
owned=False
success=False
work=tempfile.TemporaryDirectory(prefix='rustmall-delivery40-');checks=[];report={};compose=None;private=[];output=[]
def run(command,ok=True,input=None):
 r=subprocess.run(command,cwd=stage,capture_output=True,text=True,input=input)
 text=r.stdout+'\n'+r.stderr
 for value in private:text=text.replace(value,'[REDACTED]')
 output.append(text)
 if ok and r.returncode:raise RuntimeError('container delivery command failed; inspect container.log in the selected report directory')
 return r
def until(test,label,seconds=90):
 deadline=time.monotonic()+seconds
 while True:
  if test():return
  if time.monotonic()>deadline:raise RuntimeError('timeout: '+label)
  time.sleep(.25)
try:
 profile=Path(work.name)/'.delivery.local'
 run(['python3',str(stage/'scripts/create-delivery-env.py'),'--output-dir',str(profile),'--image',args.image])
 values={p.name:p.read_text().strip() for p in (profile/'secrets').iterdir()}
 private.extend(v for v in values.values() if len(v)>20)
 assert stat.S_IMODE(profile.stat().st_mode)==0o700 and stat.S_IMODE((profile/'secrets').stat().st_mode)==0o700
 before={p.name:p.read_bytes() for p in (profile/'secrets').iterdir()}
 r=run(['python3',str(stage/'scripts/create-delivery-env.py'),'--output-dir',str(profile),'--image',args.image],ok=False);assert r.returncode
 assert before=={p.name:p.read_bytes() for p in (profile/'secrets').iterdir()}
 compose=['docker','compose','-p',project,'--env-file',str(profile/'compose.env'),'-f',str(stage/'deploy/delivery40/compose.yaml')]
 assert not run(compose+['ps','-a','-q']).stdout.strip(),'test project already exists'
 owned=True
 config=json.loads(run(compose+['config','--format','json']).stdout)
 assert all(secret not in json.dumps(config) for secret in private)
 published=[name for name,spec in config['services'].items() if spec.get('ports')];assert published==['edge'],published
 checks.append('private profile refuses overwrite; Compose contains no credential values and publishes only edge')
 run(compose+['up','-d','--wait','--wait-timeout','120','postgres','redis'])
 def admin(db,query):return run(compose+['exec','-T','postgres','psql','-X','-v','ON_ERROR_STOP=1','-U','postgres','-d','rustmall_'+db,'-Atc',query]).stdout.strip()
 assert admin('catalog',"SELECT count(*) FROM pg_database WHERE datname IN ('rustmall_catalog','rustmall_users','rustmall_payments','rustmall_orders','rustmall_projection','rustmall_rebuild')")=='6'
 def as_role(role,db,query,ok=True):
  assert re.fullmatch('[a-z_]+',role) and re.fullmatch('[a-z_]+',db)
  command='export PGPASSWORD="$(cat /run/secrets/'+role+'_password)"; exec psql -h 127.0.0.1 -U '+role+' -d rustmall_'+db+' -X -v ON_ERROR_STOP=1 -At'
  return run(compose+['exec','-T','postgres','sh','-ec',command],input=query+'\n',ok=ok)
 denied=as_role('app_users','catalog','SELECT 1',ok=False);assert denied.returncode and 'permission denied for database' in denied.stderr
 checks.append('empty-volume bootstrap creates six isolated DBs; users runtime cannot connect to catalog')
 # The named build process is observed by the caller; image availability is only a dependency here.
 until(lambda:run(['docker','image','inspect',args.image],ok=False).returncode==0,'Linux image build',seconds=1200)
 image=json.loads(run(['docker','image','inspect',args.image]).stdout)[0]
 report['image_id']=image['Id'];report['image_os']=image['Os'];report['image_architecture']=image['Architecture']
 assert image['Os']=='linux' and image['Config']['User']=='10001:10001'
 run(compose+['up','-d','--wait','--wait-timeout','240'])
 roles=['catalog','users','payments','orders','worker','catalog-http','edge','relay','projection','projection-rebuild']
 for role in roles:
  cid=run(compose+['ps','-q',role]).stdout.strip();container=json.loads(run(['docker','inspect',cid]).stdout)[0]
  assert container['Image']==image['Id'] and container['Config']['User']=='10001:10001'
  assert container['HostConfig']['ReadonlyRootfs'] and 'ALL' in container['HostConfig']['CapDrop']
 checks.append('all ten logical roles use the same actually built Linux image, UID10001, read-only rootfs and dropped capabilities; six migrations and grants precede startup')
 base='http://127.0.0.1:18086'
 def api(path,method='GET',body=None,token=None,key=None):
  h={'Content-Type':'application/json'}
  if token:h['Authorization']='Bearer '+token
  if key:h['Idempotency-Key']=str(key)
  r=urllib.request.Request(base+path,headers=h,method=method,data=None if body is None else json.dumps(body).encode())
  try:reply=urllib.request.urlopen(r,timeout=8)
  except urllib.error.HTTPError as error:reply=error
  with reply:
   raw=reply.read();return reply.status,json.loads(raw) if raw else None
 assert api('/readyz')[0]==200
 c={'username':'delivery_'+secrets.token_hex(4),'password':secrets.token_urlsafe(24)};private.append(c['password'])
 assert api('/api/v1/auth/register','POST',c)[0]==201
 status,reply=api('/api/v1/auth/login','POST',c);assert status==200;token=reply['access_token'];private.append(token)
 status,identity=api('/api/v1/auth/me',token=token);assert status==200;actor=int(identity['id']);assert actor>0
 admin('users',f"UPDATE users SET role='admin' WHERE id={actor}")
 draft={'name':'容器交付键盘','price_cents':19900,'stock':10};create_key=uuid.uuid4()
 status,p=api('/api/v1/products','POST',draft,token,create_key);assert status==201;pid=int(p['id'])
 assert api('/api/v1/products','POST',draft,token,create_key)[1]['id']==pid
 request={'product_id':pid,'quantity':2};key=uuid.uuid4();status,o=api('/api/v1/orders','POST',request,token,key);assert status==202;oid=str(uuid.UUID(o['id']))
 until(lambda:admin('orders',f"SELECT state FROM orders WHERE id='{oid}'")=='completed','container Saga complete')
 assert admin('payments',f"SELECT count(*) FROM payment_effects WHERE saga_id='{oid}' AND kind='paid'")=='1'
 assert admin('catalog',f'SELECT stock FROM products WHERE id={pid}')=='8'
 assert api('/api/v1/orders','POST',request,token,key)[1]['id']==oid
 assert api(f'/api/v1/products/{pid}','PUT',{**draft,'stock':999},token)[0]==409
 assert api(f'/api/v1/products/{pid}','PUT',{**draft,'name':'容器键盘资料修订','stock':8},token)[0]==200
 checks.append('real container HTTP auth/product/idempotent order/Saga completes with one paid effect, stock8, preserved metadata edits and rejected stock overwrite')
 adjust_id=uuid.uuid4()
 run(compose+['run','--rm','--no-deps','inventory-admin','/app/inventory-adjust','apply',str(adjust_id),str(pid),'3',str(actor),'container-check','--local-admin'])
 assert admin('catalog',f'SELECT stock FROM products WHERE id={pid}')=='11'
 assert api(f'/api/v1/products/{pid}','DELETE',token=token)[0]==204
 def projection_ok(db):return admin(db,f"SELECT count(*) FROM catalog_view WHERE product_id={pid} AND (payload->>'stock')::int=11 AND NOT (payload->>'listed')::boolean")=='1'
 until(lambda:projection_ok('projection') and projection_ok('rebuild'),'independent container projections')
 assert admin('catalog','SELECT count(*) FROM product_outbox WHERE delivered_at IS NULL')=='0'
 checks.append('least-privilege inventory-admin adjusts stock and records audit; relay and both independent projections converge to the stock11 tombstone')
 refusals=[
  ('app_users','users',"UPDATE users SET role='admin' WHERE false"),
  ('app_users','users','CREATE TABLE should_not_exist(id int)'),
  ('app_orders','orders',"UPDATE orders SET state='completed' WHERE false"),
  ('worker_orders','orders','INSERT INTO orders(id,actor_id,request_key,product_id,quantity,unit_price,amount) SELECT gen_random_uuid(),1,gen_random_uuid(),1,1,1,1 WHERE false'),
  ('relay_catalog','catalog',"UPDATE product_outbox SET payload='{}'::jsonb WHERE false"),
  ('relay_catalog','catalog','UPDATE products SET stock=0 WHERE false'),
  ('app_payments','payments','DELETE FROM payment_effects WHERE false'),
  ('app_projection','projection','DELETE FROM catalog_view WHERE false'),
  ('app_projection','projection',"UPDATE projection_identity SET consumer_name='different' WHERE false"),
 ]
 for role,db,query in refusals:
  r=as_role(role,db,query,ok=False);assert r.returncode and 'permission denied' in r.stderr,(role,db)
 checks.append('nine actual SQL privilege denials protect user promotion/DDL, order state, worker creation, event content, product stock, payment audit and projection identity/tombstones')
 redis='export REDISCLI_AUTH="$(awk \'$1=="user" && $2=="app_users" {print substr($4,2)}\' /run/secrets/redis_acl)"; exec redis-cli -e --user app_users FLUSHDB'
 r=run(compose+['exec','-T','redis','sh','-ec',redis],ok=False);assert r.returncode and 'NOPERM' in (r.stdout+r.stderr)
 assert api('/api/v1/auth/logout','POST',token=token)[0]==204
 assert api('/api/v1/auth/me',token=token)[0]==401
 checks.append('Redis ACL supports login/Lua/session revocation but denies application FLUSHDB; logout remains effective')
 fresh=[]
 for _ in range(2):
  status,reply=api('/api/v1/auth/login','POST',c);assert status==200
  fresh.append(reply['access_token']);private.append(fresh[-1])
 live_token,revoke_token=fresh
 run(compose+['stop','redis'])
 started=time.monotonic()
 assert api('/api/v1/auth/me',token=live_token)[0]==503
 assert time.monotonic()-started<3
 assert api('/api/v1/auth/login','POST',c)[0]==503
 assert api('/api/v1/auth/logout','POST',token=revoke_token)[0]==503
 assert admin('users',f'SELECT count(*) FROM sessions WHERE user_id={actor} AND revoked_at IS NOT NULL')=='2'
 run(compose+['start','redis'])
 until(lambda:api('/api/v1/auth/me',token=live_token)[0]==200,'users Redis reconnection')
 assert api('/api/v1/auth/me',token=revoke_token)[0]==401
 assert api('/api/v1/auth/logout','POST',token=revoke_token)[0]==204
 checks.append('real Redis outage: me/login return503, logout commits DB revocation before503; empty restart reconnects and never revives revoked session, retry logout204')

 # Health probes and metrics are executed in their real namespaces, not merely rendered.
 run(compose+['exec','-T','edge','/app/rustmall-probe','http','http://127.0.0.1:8080/readyz'])
 run(compose+['exec','-T','catalog','/app/rustmall-probe','grpc','http://127.0.0.1:50051','readiness'])
 report['containers_verified']=roles
 success=True
finally:
 if compose and owned:
  logs=subprocess.run(compose+['logs','--no-color'],capture_output=True,text=True).stdout
  for value in private:logs=logs.replace(value,'[REDACTED]')
  (args.report_dir/'container-runtime.log').write_text(logs)
  report['cleanup_exit']=subprocess.run(compose+['down','--volumes','--remove-orphans'],capture_output=True).returncode
 work.cleanup()
 text='\n'.join(output)
 for value in private:text=text.replace(value,'[REDACTED]')
 (args.report_dir/'container.log').write_text(text)
 report.update(success=success and report.get('cleanup_exit')==0,checks=checks,passed=len(checks),scope='actual single-architecture Linux image and complete local Docker Compose with DB/Redis privileges; no remote CI/cluster proof')
 (args.report_dir/'container.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(report,ensure_ascii=False,indent=2))

if not report['success']:sys.exit(1)
