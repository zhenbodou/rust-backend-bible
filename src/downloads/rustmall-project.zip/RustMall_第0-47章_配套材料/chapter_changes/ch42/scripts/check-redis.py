"""Run bounded Redis42 experiments in a NEW private container; never touches an existing Redis.

Uses the delivered ACL generator and actual Lua source. This is an operational
experiment, separate from Rust workspace tests and complete application delivery.
Only synthetic state is persisted. Restart means graceful stop/start, not power loss.
"""
from pathlib import Path
import argparse, hashlib, json, os, secrets, subprocess, tempfile, time

ROOT = Path(__file__).resolve().parents[1]
p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--report-dir', type=Path, required=True)
a = p.parse_args()
a.report_dir.mkdir(parents=True, exist_ok=False)
report = {'success': False, 'checks': [], 'scope': 'single Redis7.4, generated application ACL, synthetic state; graceful AOF restart only'}
name = 'rustmall-redis42-' + secrets.token_hex(6)
created = False
volume = name + '-data'
volume_created = False
admin_password = secrets.token_urlsafe(48)
private = [admin_password]

def run(command, allowed=False, input=None):
    result = subprocess.run(command, capture_output=True, text=True, timeout=60, input=input)
    if result.returncode and not allowed:
        raise RuntimeError('Redis42 command failed; response values deliberately omitted')
    return result

def until(test, label):
    end = time.monotonic() + 30
    while True:
        if test(): return
        if time.monotonic() >= end: raise RuntimeError('timeout: ' + label)
        time.sleep(.1)

def cli(*args, user='lab_admin', allowed=False):
    password = admin_password if user == 'lab_admin' else app_password
    result = run(['docker', 'exec', '-e', 'REDISCLI_AUTH=' + password, name,
                  'redis-cli', '--user', user, '--json', '-e', *map(str, args)], allowed=allowed)
    return result

def value(*args, user='lab_admin'):
    return json.loads(cli(*args, user=user).stdout)

try:
    with tempfile.TemporaryDirectory(prefix='rustmall-redis42-') as tmp:
        profile = Path(tmp) / 'profile'
        run(['python3', str(ROOT/'scripts/create-delivery-env.py'), '--output-dir', str(profile)])
        secret_dir = profile/'secrets'
        acl = (secret_dir/'redis_acl').read_text()
        line = next(x for x in acl.splitlines() if x.startswith('user app_users '))
        app_password = next(x[1:] for x in line.split() if x.startswith('>'))
        private.append(app_password)
        # Only the lab has an admin; the delivered application ACL remains unchanged.
        acl_path = Path(tmp)/'lab.acl'
        acl_path.write_text(acl + '\nuser lab_admin on >' + admin_password + ' ~* &* +@all\n')
        acl_path.chmod(0o444)
        run(['docker', 'volume', 'create', volume]); volume_created = True
        run(['docker', 'run', '-d', '--name', name, '--network', 'none',
             '--mount', f'type=bind,src={acl_path},dst=/run/lab.acl,readonly',
             '--mount', f'type=volume,src={volume},dst=/data',
             'redis:7.4-alpine', 'redis-server', '--aclfile', '/run/lab.acl',
             '--appendonly', 'yes', '--appendfsync', 'everysec', '--save', '',
             '--maxmemory-policy', 'noeviction']); created = True
        until(lambda: cli('PING', allowed=True).returncode == 0, 'Redis ready')
        server = cli('INFO', 'server').stdout
        report['redis_version'] = next(x.split(':',1)[1].strip() for x in server.splitlines() if x.startswith('redis_version:'))
        script = (ROOT/'services/commerce/src/lua/login_limit.lua').read_text()
        sha = hashlib.sha1(script.encode()).hexdigest()
        report['login_script_sha1'] = sha
        key = 'users:v1:login:lab42'
        results = [value('EVAL', script, 1, key, user='app_users') for _ in range(64)]
        assert sum(x[0] for x in results) == 10
        assert all(1 <= x[1] <= 10 and 0 < x[2] <= 60000 for x in results)
        assert value('GET', key, user='app_users') == '10'
        for args in [('FLUSHDB',), ('SET', 'outside:scope', 'no')]:
            failure = cli(*args, user='app_users', allowed=True)
            assert failure.returncode != 0 and 'NOPERM' in failure.stdout + failure.stderr
        report['checks'].append('actual users Lua: exactly10 of64 admitted, bounded counter/TTL; generated ACL rejects FLUSHDB and out-of-scope key')
        value('SCRIPT', 'FLUSH')
        missing = cli('EVALSHA', sha, 1, key, user='app_users', allowed=True)
        assert missing.returncode and 'NOSCRIPT' in missing.stdout + missing.stderr
        assert value('SCRIPT', 'LOAD', script, user='app_users') == sha
        assert value('EVALSHA', sha, 1, key, user='app_users')[0] == 0
        report['checks'].append('script cache flush produces NOSCRIPT; application ACL can reload exact source and evaluate it')
        partial_key = 'users:v1:lab:partial'
        partial = cli('EVAL', "redis.call('SET',KEYS[1],'already-written'); return redis.call('LPUSH',KEYS[1],'x')", 1, partial_key, allowed=True)
        assert partial.returncode and 'WRONGTYPE' in partial.stdout + partial.stderr
        assert value('GET', partial_key) == 'already-written'
        report['checks'].append('later Lua WRONGTYPE error does not roll back an earlier SET')
        # Existing reads still work; a write requiring new memory must reject.
        value('CONFIG', 'SET', 'maxmemory', 1)
        try:
            failure = cli('EVAL', script, 1, 'users:v1:login:oom42', user='app_users', allowed=True)
            assert failure.returncode and 'OOM' in failure.stdout + failure.stderr
            assert value('EXISTS', 'users:v1:login:oom42') == 0
            assert value('GET', key) == '10'
        finally:
            value('CONFIG', 'SET', 'maxmemory', 0)
        report['checks'].append('noeviction memory exhaustion rejects new login state; existing counter preserved, no permissive fallback')
        for i in range(200): value('SET', f'users:v1:lab:scan:{i}', 'synthetic')
        cursor = '0'; seen = set(); calls = 0
        while True:
            result = value('SCAN', cursor, 'MATCH', 'users:v1:lab:scan:*', 'COUNT', 17)
            cursor = str(result[0]); seen.update(result[1]); calls += 1
            assert calls < 10000
            if cursor == '0': break
        assert seen == {f'users:v1:lab:scan:{i}' for i in range(200)}
        report['scan_calls'] = calls
        report['checks'].append('complete SCAN over static200-key fixture deduplicates keys and stops only at cursor0; COUNT treated as hint')
        # Both commands must use ONE connection: WAITAOF tracks this client's writes.
        persisted = run(['docker', 'exec', '-i', '-e', 'REDISCLI_AUTH=' + admin_password,
                         name, 'redis-cli', '--user', 'lab_admin', '--json', '-e'],
                        input='SET users:v1:lab:aof-marker synthetic-survives-restart\nWAITAOF 1 0 5000\n')
        replies = [json.loads(line) for line in persisted.stdout.splitlines() if line.strip()]
        assert replies == ['OK', [1, 0]], 'same-connection local AOF confirmation required'
        run(['docker', 'stop', '--time', '15', name])
        run(['docker', 'start', name])
        until(lambda: cli('PING', allowed=True).returncode == 0, 'AOF restart')
        assert value('GET', 'users:v1:lab:aof-marker') == 'synthetic-survives-restart'
        assert value('GET', key) == '10'
        assert 0 < value('PTTL', key) <= 60000
        assert not value('SCRIPT', 'EXISTS', sha)[0]
        assert value('SCRIPT', 'LOAD', script, user='app_users') == sha
        assert value('EVALSHA', sha, 1, key, user='app_users')[0] == 0
        report['checks'].append('graceful AOF restart retains synthetic data and absolute TTL; Lua cache is absent and reload succeeds')
        report['success'] = True
except Exception as error:
    message = str(error)
    for secret in private: message = message.replace(secret, '[REDACTED]')
    report['error'] = message
    raise
finally:
    cleanup = []
    if created: cleanup.append(subprocess.run(['docker','rm','-f',name],capture_output=True).returncode)
    if volume_created: cleanup.append(subprocess.run(['docker','volume','rm',volume],capture_output=True).returncode)
    report['cleanup'] = cleanup
    if any(cleanup): report['success'] = False
    (a.report_dir/'result.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
if not report['success']: raise SystemExit('Redis42 cleanup failed')
print(json.dumps(report,ensure_ascii=False))
