-- Both keys use the same product hash tag. Revoke in-flight Redis publication too.
return redis.call('DEL',KEYS[1],KEYS[2])
