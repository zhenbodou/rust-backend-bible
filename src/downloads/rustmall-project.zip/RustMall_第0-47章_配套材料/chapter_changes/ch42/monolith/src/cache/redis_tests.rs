//! Requires the isolated REDIS_URL supplied by the workspace quality harness.
use super::*;
use redis::AsyncCommands;

async fn fixture() -> (ProductCache, ConnectionManager, ProductId) {
    let manager = redis::Client::open(std::env::var("REDIS_URL").expect("isolated Redis required"))
        .unwrap()
        .get_connection_manager()
        .await
        .unwrap();
    let id = ProductId::new((Uuid::new_v4().as_u128() & i64::MAX as u128) as i64);
    let cache = ProductCache::new(
        &CacheSettings::default(),
        Some(manager.clone()),
        Duration::from_secs(1),
    );
    (cache, manager, id)
}
fn product(id: ProductId, name: &str) -> Lookup {
    Some(Product::try_new(id, name, 19900, 10).unwrap())
}

#[tokio::test]
async fn invalidation_revokes_older_fill_and_old_owner_cannot_remove_new_owner() {
    let (cache, mut connection, id) = fixture().await;
    let old = cache.begin_fill(id).await.expect("first owner");
    cache.invalidate(id).await;
    let new = cache.begin_fill(id).await.expect("replacement owner");
    cache.redis_put(id, &product(id, "old"), Some(old)).await;
    assert!(cache.redis_get(id).await.is_none());
    let owner: String = connection.get(fill_key(id)).await.unwrap();
    assert_eq!(owner, new.to_string());
    cache.redis_put(id, &product(id, "new"), Some(new)).await;
    assert_eq!(cache.redis_get(id).await.unwrap().unwrap().name(), "new");
    assert!(!connection.exists::<_, bool>(fill_key(id)).await.unwrap());
    cache.invalidate(id).await;
}

#[tokio::test]
async fn expired_permission_never_authorizes_an_old_fill() {
    let (cache, mut connection, id) = fixture().await;
    let old = cache.begin_fill(id).await.unwrap();
    let ttl: i64 = connection.pttl(fill_key(id)).await.unwrap();
    assert!((1..=2000).contains(&ttl));
    // Force server-side expiration, without guessing elapsed wall-clock time.
    let expired: bool = connection.pexpire(fill_key(id), 0).await.unwrap();
    assert!(expired);
    let new = cache.begin_fill(id).await.unwrap();
    assert_ne!(old, new);
    cache.redis_put(id, &product(id, "old"), Some(old)).await;
    assert!(cache.redis_get(id).await.is_none());
    cache.redis_put(id, &product(id, "new"), Some(new)).await;
    assert_eq!(cache.redis_get(id).await.unwrap().unwrap().name(), "new");
    cache.invalidate(id).await;
}

#[tokio::test]
async fn a_contender_has_no_permission_to_publish() {
    let (cache, _, id) = fixture().await;
    let owner = cache.begin_fill(id).await.unwrap();
    let contender = cache.begin_fill(id).await;
    assert!(contender.is_none());
    cache
        .redis_put(id, &product(id, "unowned"), contender)
        .await;
    assert!(cache.redis_get(id).await.is_none());
    cache.redis_put(id, &None, Some(owner)).await;
    assert_eq!(cache.redis_get(id).await, Some(None));
    cache.invalidate(id).await;
}

#[tokio::test]
async fn untrusted_cached_payloads_are_misses_and_can_be_repaired() {
    let (cache, mut connection, id) = fixture().await;
    let wrong_id = if id.get() == 1 { 2 } else { 1 };
    let wrong =
        serde_json::json!({"state":"found","id":wrong_id,"name":"other","price_cents":1,"stock":1});
    for raw in ["x".repeat(4097), "not-json".into(), wrong.to_string()] {
        let _: () = connection.set(product_key(id), raw).await.unwrap();
        assert!(cache.redis_get(id).await.is_none());
    }
    let _: usize = connection.del(product_key(id)).await.unwrap();
    let _: usize = connection
        .lpush(product_key(id), "wrong-type")
        .await
        .unwrap();
    assert!(cache.redis_get(id).await.is_none());
    let permit = cache.begin_fill(id).await;
    cache.redis_put(id, &product(id, "repaired"), permit).await;
    assert_eq!(
        cache.redis_get(id).await.unwrap().unwrap().name(),
        "repaired"
    );
    cache.invalidate(id).await;
}
