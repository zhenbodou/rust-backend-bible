-- Bound the reply before transferring a potentially corrupted value to the client.
if redis.call('STRLEN',KEYS[1]) > 4096 then return false end
return redis.call('GET',KEYS[1])
