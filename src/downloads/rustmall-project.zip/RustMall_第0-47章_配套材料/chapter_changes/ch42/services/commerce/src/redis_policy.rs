//! Authentication Redis is required; it never silently degrades to unlimited attempts.
use crate::runtime::*;
use redis::aio::ConnectionManager;
use std::{future::Future, time::Duration};
pub const LOGIN_SCRIPT: &str = include_str!("lua/login_limit.lua");
#[derive(Debug, PartialEq, Eq)]
pub struct Admission {
    pub allowed: bool,
    pub count: i64,
    pub remaining_ms: i64,
}
pub async fn bounded<T>(future: impl Future<Output = redis::RedisResult<T>>) -> ApiResult<T> {
    tokio::time::timeout(call_duration(Duration::from_millis(150))?, future)
        .await
        .map_err(|_| unavailable())?
        .map_err(|_| unavailable())
}
pub async fn login_attempt(redis: &mut ConnectionManager, username: &str) -> ApiResult<Admission> {
    let values: (i64, i64, i64) = bounded(
        redis::Script::new(LOGIN_SCRIPT)
            .key(format!("users:v1:login:{username}"))
            .invoke_async(redis),
    )
    .await?;
    if !matches!(values.0, 0 | 1)
        || !(1..=10).contains(&values.1)
        || !(1..=60_000).contains(&values.2)
    {
        return Err(unavailable());
    }
    Ok(Admission {
        allowed: values.0 == 1,
        count: values.1,
        remaining_ms: values.2,
    })
}
