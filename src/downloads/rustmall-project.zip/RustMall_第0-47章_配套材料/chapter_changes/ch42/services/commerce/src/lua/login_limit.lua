-- Fixed window, bounded state, one final write. Atomic execution is not rollback.
local maximum=10
local window=60000
if redis.call('STRLEN',KEYS[1])>18 then
  return redis.error_reply('invalid login counter')
end
local raw=redis.call('GET',KEYS[1])
local count=0
local ttl=window
local repair=false
if raw then
  if not string.match(raw,'^%d+$') or #raw>18 then
    return redis.error_reply('invalid login counter')
  end
  count=tonumber(raw)
  ttl=redis.call('PTTL',KEYS[1])
  if ttl<0 or ttl>window then ttl=window; repair=true end
  if ttl==0 then ttl=1 end
end
if count>=maximum then
  -- Repair old non-expiring or oversized counters, without extending valid windows.
  if count~=maximum or repair then
    redis.call('SET',KEYS[1],maximum,'PX',ttl)
  end
  return {0,maximum,ttl}
end
count=count+1
redis.call('SET',KEYS[1],count,'PX',ttl)
return {1,count,ttl}
