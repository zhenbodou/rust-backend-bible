use commerce::redis_policy::login_attempt;
use redis::{AsyncCommands, aio::ConnectionManager};
use uuid::Uuid;

async fn fixture() -> (ConnectionManager, String, String) {
    let redis = redis::Client::open(std::env::var("REDIS_URL").expect("isolated Redis required"))
        .unwrap()
        .get_connection_manager()
        .await
        .unwrap();
    let name = format!("r42_{}", Uuid::new_v4().simple());
    let key = format!("users:v1:login:{name}");
    (redis, name, key)
}

#[tokio::test]
async fn concurrent_attempts_admit_exactly_ten_and_saturate_with_expiry() {
    let (mut redis, name, key) = fixture().await;
    let tasks: Vec<_> = (0..64)
        .map(|_| {
            let mut connection = redis.clone();
            let name = name.clone();
            tokio::spawn(async move { login_attempt(&mut connection, &name).await.unwrap() })
        })
        .collect();
    let mut admitted = 0;
    for task in tasks {
        let result = task.await.unwrap();
        admitted += usize::from(result.allowed);
        assert!((1..=10).contains(&result.count));
        assert!((1..=60000).contains(&result.remaining_ms));
    }
    assert_eq!(admitted, 10);
    assert_eq!(redis.get::<_, i64>(&key).await.unwrap(), 10);
    assert!((1..=60000).contains(&redis.pttl::<_, i64>(&key).await.unwrap()));
    let _: usize = redis.del(key).await.unwrap();
}

#[tokio::test]
async fn a_valid_window_is_not_extended_and_expiration_starts_a_new_window() {
    let (mut redis, name, key) = fixture().await;
    let _: () = redis.set(&key, 9).await.unwrap();
    let _: bool = redis.pexpire(&key, 5000).await.unwrap();
    let first = login_attempt(&mut redis, &name).await.unwrap();
    assert!(first.allowed);
    assert_eq!(first.count, 10);
    assert!((1..=5000).contains(&first.remaining_ms));
    let denied = login_attempt(&mut redis, &name).await.unwrap();
    assert!(!denied.allowed);
    assert!(denied.remaining_ms <= first.remaining_ms);
    let _: bool = redis.pexpire(&key, 0).await.unwrap();
    let fresh = login_attempt(&mut redis, &name).await.unwrap();
    assert!(fresh.allowed);
    assert_eq!(fresh.count, 1);
    let _: usize = redis.del(key).await.unwrap();
}

#[tokio::test]
async fn legacy_nonexpiring_and_oversized_numeric_counters_are_repaired() {
    let (mut redis, name, key) = fixture().await;
    for raw in ["3", "999999999999999999"] {
        let _: () = redis.set(&key, raw).await.unwrap();
        assert_eq!(redis.pttl::<_, i64>(&key).await.unwrap(), -1);
        let result = login_attempt(&mut redis, &name).await.unwrap();
        assert!((1..=60000).contains(&result.remaining_ms));
        assert_eq!(result.allowed, raw == "3");
        assert_eq!(result.count, if raw == "3" { 4 } else { 10 });
        assert_eq!(redis.get::<_, i64>(&key).await.unwrap(), result.count);
        assert!(redis.pttl::<_, i64>(&key).await.unwrap() > 0);
    }
    let _: usize = redis.del(key).await.unwrap();
}

#[tokio::test]
async fn corrupt_counter_fails_closed_without_mutating_it() {
    let (mut redis, name, key) = fixture().await;
    for raw in ["-1".to_owned(), "NaN".into(), "8".repeat(4096)] {
        let _: () = redis.set(&key, &raw).await.unwrap();
        let error = login_attempt(&mut redis, &name).await.unwrap_err();
        assert_eq!(error.0, axum::http::StatusCode::SERVICE_UNAVAILABLE);
        assert_eq!(redis.get::<_, String>(&key).await.unwrap(), raw);
    }
    let _: usize = redis.del(&key).await.unwrap();
    let _: usize = redis.lpush(&key, "wrong-type").await.unwrap();
    assert!(login_attempt(&mut redis, &name).await.is_err());
    assert_eq!(redis.llen::<_, usize>(&key).await.unwrap(), 1);
    let _: usize = redis.del(key).await.unwrap();
}
