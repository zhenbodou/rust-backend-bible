use crate::runtime::*;
use argon2::{
    Argon2, PasswordHasher, PasswordVerifier,
    password_hash::{PasswordHash, SaltString},
};
use axum::{
    Json, Router,
    extract::State,
    http::{HeaderMap, StatusCode},
    routing::{get, post},
};
use jsonwebtoken::{Algorithm, DecodingKey, EncodingKey, Header, Validation};
use rand_core::OsRng;
use serde::{Deserialize, Serialize};
use sqlx::PgPool;
use std::{
    sync::Arc,
    time::{SystemTime, UNIX_EPOCH},
};
use tokio::sync::Semaphore;
use uuid::Uuid;

#[derive(Clone)]
pub struct Users {
    pub pool: PgPool,
    pub redis: redis::aio::ConnectionManager,
    pub key: Arc<String>,
    pub hashes: Arc<Semaphore>,
    pub dummy: Arc<String>,
}
#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Credentials {
    pub username: String,
    pub password: String,
}
#[derive(Serialize, Deserialize)]
struct Claims {
    sub: String,
    jti: Uuid,
    exp: u64,
    iss: String,
    aud: String,
}
#[derive(Serialize, Deserialize, Debug)]
pub struct Identity {
    pub id: i64,
    pub role: String,
}
fn now() -> ApiResult<u64> {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_secs())
        .map_err(|_| unavailable())
}
impl Claims {
    fn user_id(&self) -> ApiResult<i64> {
        self.sub
            .parse::<i64>()
            .ok()
            .filter(|id| *id > 0)
            .ok_or_else(unauthorized)
    }
}
fn valid(c: &Credentials) -> bool {
    common::text::normalize_username(&c.username).is_ok() && (12..=128).contains(&c.password.len())
}
pub async fn hash(password: String) -> anyhow::Result<String> {
    tokio::task::spawn_blocking(move || {
        Argon2::default()
            .hash_password(password.as_bytes(), &SaltString::generate(&mut OsRng))
            .map(|p| p.to_string())
            .map_err(|e| anyhow::anyhow!(e.to_string()))
    })
    .await?
}
pub fn router(s: Users) -> Router {
    let ready = s.clone();
    Router::new()
        .route("/api/v1/auth/register", post(register))
        .route("/api/v1/auth/login", post(login))
        .route("/api/v1/auth/me", get(me))
        .route("/api/v1/users/me", get(me))
        .route("/api/v1/auth/logout", post(logout))
        .route("/healthz", get(|| async { StatusCode::OK }))
        .route("/readyz", get(move || users_readiness(ready.clone())))
        .layer(axum::extract::DefaultBodyLimit::max(4096))
        .with_state(s)
}
async fn register(
    State(s): State<Users>,
    BodyJson(mut c): BodyJson<Credentials>,
) -> ApiResult<(StatusCode, Json<Identity>)> {
    if !valid(&c) {
        return Err(invalid());
    }
    c.username = common::text::normalize_username(&c.username).map_err(|_| invalid())?;
    let permit = enter(&s.hashes)?;
    let password = c.password;
    let hashed = tokio::task::spawn_blocking(move || {
        let _permit = permit;
        Argon2::default()
            .hash_password(password.as_bytes(), &SaltString::generate(&mut OsRng))
            .map(|h| h.to_string())
            .map_err(|_| unavailable())
    })
    .await
    .map_err(|_| unavailable())??;
    let id=sqlx::query_scalar("INSERT INTO users(username,password_hash) VALUES($1,$2) ON CONFLICT(username) DO NOTHING RETURNING id")
  .bind(c.username).bind(hashed).fetch_optional(&s.pool).await?
  .ok_or(ApiError(StatusCode::CONFLICT,"username unavailable"))?;
    Ok((
        StatusCode::CREATED,
        Json(Identity {
            id,
            role: "user".into(),
        }),
    ))
}
async fn login(
    State(s): State<Users>,
    BodyJson(mut c): BodyJson<Credentials>,
) -> ApiResult<Json<serde_json::Value>> {
    if c.password.is_empty() || c.password.len() > 256 {
        return Err(unauthorized());
    }
    c.username = common::text::normalize_username(&c.username).map_err(|_| unauthorized())?;
    let mut redis = s.redis.clone();
    if !crate::redis_policy::login_attempt(&mut redis, &c.username)
        .await?
        .allowed
    {
        return Err(ApiError(StatusCode::TOO_MANY_REQUESTS, "try again later"));
    }
    let row: Option<(i64, String)> =
        sqlx::query_as("SELECT id,password_hash FROM users WHERE username=$1")
            .bind(c.username)
            .fetch_optional(&s.pool)
            .await?;
    let (id, stored) = row.unwrap_or((0, s.dummy.as_ref().clone()));
    let permit = enter(&s.hashes)?;
    let ok = tokio::task::spawn_blocking(move || {
        let _permit = permit;
        PasswordHash::new(&stored).is_ok_and(|p| {
            let supported = p.algorithm.as_str() == "argon2id"
                && p.version == Some(19)
                && p.params
                    .get_decimal("m")
                    .is_some_and(|m| (8..=65536).contains(&m))
                && p.params
                    .get_decimal("t")
                    .is_some_and(|t| (1..=4).contains(&t))
                && p.params
                    .get_decimal("p")
                    .is_some_and(|p| (1..=4).contains(&p));
            supported
                && Argon2::default()
                    .verify_password(c.password.as_bytes(), &p)
                    .is_ok()
        })
    })
    .await
    .map_err(|_| unavailable())?;
    if !ok || id <= 0 {
        return Err(unauthorized());
    }
    let claims = Claims {
        sub: id.to_string(),
        jti: Uuid::new_v4(),
        exp: now()? + 3600,
        iss: "rustmall-users".into(),
        aud: "rustmall-api".into(),
    };
    sqlx::query("INSERT INTO sessions(jti,user_id,expires_at) VALUES($1,$2,to_timestamp($3))")
        .bind(claims.jti)
        .bind(id)
        .bind(claims.exp as f64)
        .execute(&s.pool)
        .await?;
    let token = jsonwebtoken::encode(
        &Header::new(Algorithm::HS256),
        &claims,
        &EncodingKey::from_secret(s.key.as_bytes()),
    )
    .map_err(|_| unavailable())?;
    Ok(Json(
        serde_json::json!({"access_token":token,"token_type":"Bearer","expires_in":3600}),
    ))
}
fn decode_claims(s: &Users, h: &HeaderMap) -> ApiResult<Claims> {
    let raw = bearer(h)?;
    let mut v = Validation::new(Algorithm::HS256);
    v.set_issuer(&["rustmall-users"]);
    v.set_audience(&["rustmall-api"]);
    v.leeway = 0;
    let c = jsonwebtoken::decode::<Claims>(raw, &DecodingKey::from_secret(s.key.as_bytes()), &v)
        .map_err(|_| unauthorized())?
        .claims;
    c.user_id()?;
    if c.jti.is_nil() {
        return Err(unauthorized());
    }
    Ok(c)
}
async fn claims(s: &Users, h: &HeaderMap) -> ApiResult<Claims> {
    let c = decode_claims(s, h)?;
    let mut redis = s.redis.clone();
    let revoked: bool = crate::redis_policy::bounded(
        redis::cmd("EXISTS")
            .arg(format!("users:v1:revoked:{}", c.jti))
            .query_async(&mut redis),
    )
    .await?;
    if revoked {
        return Err(unauthorized());
    }
    let active:bool=sqlx::query_scalar("SELECT EXISTS(SELECT 1 FROM sessions WHERE jti=$1 AND user_id=$2 AND revoked_at IS NULL AND expires_at>now())")
        .bind(c.jti).bind(c.user_id()?).fetch_one(&s.pool).await?;
    if !active {
        return Err(unauthorized());
    }
    Ok(c)
}
async fn me(State(s): State<Users>, h: HeaderMap) -> ApiResult<Json<Identity>> {
    let id = claims(&s, &h).await?.user_id()?;
    let role = sqlx::query_scalar("SELECT role FROM users WHERE id=$1")
        .bind(id)
        .fetch_optional(&s.pool)
        .await?
        .ok_or_else(unauthorized)?;
    Ok(Json(Identity { id, role }))
}
async fn logout(State(s): State<Users>, h: HeaderMap) -> ApiResult<StatusCode> {
    let c = decode_claims(&s, &h)?;
    let changed = sqlx::query("UPDATE sessions SET revoked_at=COALESCE(revoked_at,now()) WHERE jti=$1 AND user_id=$2 AND expires_at>now()")
        .bind(c.jti).bind(c.user_id()?).execute(&s.pool).await?;
    if changed.rows_affected() != 1 {
        return Err(unauthorized());
    }
    let mut redis = s.redis.clone();
    let _: () = crate::redis_policy::bounded(
        redis::cmd("SET")
            .arg(format!("users:v1:revoked:{}", c.jti))
            .arg(1)
            .arg("EX")
            .arg(c.exp.saturating_sub(now()?).max(1))
            .query_async(&mut redis),
    )
    .await?;
    Ok(StatusCode::NO_CONTENT)
}
#[derive(Clone)]
pub struct UserRemote {
    client: reqwest::Client,
    base: String,
}
impl UserRemote {
    pub fn new(base: &str) -> anyhow::Result<Self> {
        let url = reqwest::Url::parse(base)?;
        anyhow::ensure!(
            matches!(url.scheme(), "http" | "https")
                && url.host_str().is_some()
                && url.username().is_empty()
                && url.password().is_none()
                && url.path() == "/"
                && url.query().is_none()
                && url.fragment().is_none(),
            "users endpoint must be an HTTP(S) origin without credentials"
        );
        Ok(Self {
            client: client()?,
            base: base.trim_end_matches('/').to_owned(),
        })
    }

    pub async fn ready(&self) -> bool {
        matches!(tokio::time::timeout(std::time::Duration::from_millis(500),
            self.client.get(format!("{}/readyz",self.base)).send()).await,
            Ok(Ok(response)) if response.status()==axum::http::StatusCode::OK)
    }
    pub async fn authenticate(&self, h: &HeaderMap) -> ApiResult<i64> {
        Ok(self.identity(h).await?.id)
    }
    pub async fn identity(&self, h: &HeaderMap) -> ApiResult<Identity> {
        tokio::time::timeout(
            call_duration(std::time::Duration::from_secs(2))?,
            self.lookup(h),
        )
        .await
        .map_err(|_| unavailable())?
    }
    #[tracing::instrument(name="http.client",skip_all,fields(otel.kind="client",peer.service="users"))]
    async fn lookup(&self, h: &HeaderMap) -> ApiResult<Identity> {
        let request = self
            .client
            .get(format!("{}/api/v1/auth/me", self.base))
            .bearer_auth(bearer(h)?);
        let r = observability::http(outbound(request, std::time::Duration::from_secs(2))?)
            .send()
            .await
            .map_err(|_| unavailable())?;
        if r.status() == StatusCode::UNAUTHORIZED {
            return Err(unauthorized());
        }
        if !r.status().is_success() {
            return Err(unavailable());
        }
        let mut r = r;
        let mut bytes = Vec::new();
        while let Some(chunk) = r.chunk().await.map_err(|_| unavailable())? {
            if bytes.len().saturating_add(chunk.len()) > 4096 {
                return Err(unavailable());
            }
            bytes.extend_from_slice(&chunk);
        }
        let id: Identity = serde_json::from_slice(&bytes).map_err(|_| unavailable())?;
        if id.id <= 0 || !matches!(id.role.as_str(), "user" | "admin") {
            return Err(unavailable());
        }
        Ok(id)
    }
}

async fn users_readiness(s: Users) -> StatusCode {
    let mut redis = s.redis.clone();
    match tokio::time::timeout(std::time::Duration::from_millis(500), async {
        let ping = redis::cmd("PING");
        let (pg, redis) = tokio::join!(
            sqlx::query("SELECT 1").execute(&s.pool),
            ping.query_async::<String>(&mut redis)
        );
        pg.map_err(|_| ())?;
        if redis.map_err(|_| ())? != "PONG" {
            return Err(());
        }
        Ok(())
    })
    .await
    {
        Ok(Ok(())) => StatusCode::OK,
        _ => StatusCode::SERVICE_UNAVAILABLE,
    }
}
