//! 带缓存的商品仓储：按 cache-aside 模式包装任意 `ProductRepository`（第 18.9 节）。
//!
//! 读：进程内缓存 → Redis → 被包装的仓储（数据库）；回源结果写回 Redis。
//! 写：先写被包装的仓储，成功后删除两级缓存。

use common::error::{DomainError, DomainResult, ErrorKind};
use common::ids::ProductId;
use common::product::{NewProduct, Product};
use tracing::debug;

use crate::cache::{Lookup, ProductCache};
use crate::repo::ProductRepository;

const ENTITY: &str = "商品";

#[derive(Clone)]
pub struct CachedProductRepo<R> {
    inner: R,
    cache: ProductCache,
}

impl<R: ProductRepository> CachedProductRepo<R> {
    pub fn new(inner: R, cache: ProductCache) -> Self {
        Self { inner, cache }
    }

    /// 进程内缓存未命中时执行。同一个 ID 同时只有一个任务执行它，其余任务等待结果。
    async fn load(&self, id: ProductId) -> DomainResult<Lookup> {
        if let Some(hit) = self.cache.redis_get(id).await {
            debug!(%id, "商品缓存：Redis 命中");
            return Ok(hit);
        }
        let permit = self.cache.begin_fill(id).await;
        let loaded = match self.inner.get(id).await {
            Ok(product) => Some(product),
            Err(err) if err.kind() == ErrorKind::NotFound => None,
            Err(err) => return Err(err),
        };
        debug!(%id, found = loaded.is_some(), "商品缓存：未命中，已回源");
        self.cache.redis_put(id, &loaded, permit).await;
        Ok(loaded)
    }
}

impl<R: ProductRepository> ProductRepository for CachedProductRepo<R> {
    async fn insert(&self, draft: &NewProduct) -> DomainResult<Product> {
        let product = self.inner.insert(draft).await?;
        // 新分配的 ID 可能已经被缓存为“不存在”（有人提前查询过它）
        self.cache.invalidate(product.id()).await;
        Ok(product)
    }

    async fn get(&self, id: ProductId) -> DomainResult<Product> {
        if let Some(hit) = self.cache.local().get(&id).await {
            return hit.ok_or_else(|| DomainError::not_found(ENTITY, id));
        }
        let _guard = self.cache.gate(id).await;
        let lookup = if let Some(hit) = self.cache.local().get(&id).await {
            hit
        } else {
            let loaded = self.load(id).await?;
            self.cache.local().insert(id, loaded.clone()).await;
            loaded
        };
        lookup.ok_or_else(|| DomainError::not_found(ENTITY, id))
    }

    async fn list(&self, limit: i64, offset: i64) -> DomainResult<(Vec<Product>, i64)> {
        // 列表的组合太多（页码 × 每页数量），任何一次写入都会让它们全部过时，暂不缓存
        self.inner.list(limit, offset).await
    }

    async fn update(&self, product: &Product) -> DomainResult<Product> {
        let updated = self.inner.update(product).await?;
        self.cache.invalidate(updated.id()).await;
        Ok(updated)
    }

    async fn delist(&self, id: ProductId) -> DomainResult<()> {
        self.inner.delist(id).await?;
        self.cache.invalidate(id).await;
        Ok(())
    }
}
