//! 商品缓存：进程内缓存（moka，L1）+ Redis（L2）（第 18 章）。
//!
//! Redis 是可选的：没有配置、连接失败、操作出错或超时，都自动降级，
//! 缓存的任何故障都不会让请求失败。

use std::future::Future;
use std::sync::Arc;
use std::time::Duration;
use tokio::sync::{Mutex, MutexGuard};
use uuid::Uuid;

use common::ids::ProductId;
use common::product::Product;
use moka::future::Cache;
use redis::aio::ConnectionManager;
use serde::{Deserialize, Serialize};
use tracing::{info, warn};

use crate::settings::{CacheSettings, RedisSettings};

/// 缓存值格式的版本。修改 `Entry` 的结构时加 1：旧格式的键不再被读取，随过期时间自然消失。
const KEY_VERSION: u32 = 2;
const FILL_LEASE_MS: u64 = 2000;

/// 一次查询的结论：`Some(商品)` 表示存在，`None` 表示确认不存在。两者都会被缓存。
pub type Lookup = Option<Product>;

/// 商品在 Redis 中的键，例如 `rustmall:product:v2:{42}:value`。
pub fn product_key(id: ProductId) -> String {
    format!("rustmall:product:v{KEY_VERSION}:{{{}}}:value", id.get())
}

/// Co-located with the value in Redis Cluster; not an inventory or payment lock.
pub fn fill_key(id: ProductId) -> String {
    format!("rustmall:product:v{KEY_VERSION}:{{{}}}:fill", id.get())
}

/// 正向缓存的过期秒数：基础时间加上按商品 ID 分散的偏移（最多约 10%），
/// 让同一批写入的键在不同时刻过期，避免缓存雪崩（第 18.9.4 节）。
pub fn ttl_with_jitter(base_secs: u64, id: ProductId) -> u64 {
    let spread = (base_secs / 10).max(1);
    base_secs.saturating_add(id.get().unsigned_abs() % spread)
}

/// Redis 中保存的值。“不存在”也要缓存，防止缓存穿透。
///
/// 单独定义而不是直接序列化 `Product`：缓存格式由缓存模块自己掌控，
/// 读回时经过 `Product::try_new` 校验，被改坏的缓存值不会变成非法的领域对象。
#[derive(Debug, PartialEq, Serialize, Deserialize)]
#[serde(tag = "state", rename_all = "snake_case")]
enum Entry {
    Found {
        id: i64,
        name: String,
        price_cents: i64,
        stock: i32,
    },
    Missing,
}

impl Entry {
    fn from_lookup(lookup: &Lookup) -> Self {
        match lookup {
            Some(p) => Entry::Found {
                id: p.id().get(),
                name: p.name().to_string(),
                price_cents: p.price_cents(),
                stock: p.stock(),
            },
            None => Entry::Missing,
        }
    }

    fn into_lookup(self) -> Result<Lookup, String> {
        match self {
            Entry::Found {
                id,
                name,
                price_cents,
                stock,
            } => Product::try_new(ProductId::new(id), &name, price_cents, stock).map(Some),
            Entry::Missing => Ok(None),
        }
    }
}

/// 两级缓存。克隆是廉价的：moka 缓存与 Redis 连接内部都是共享的。
#[derive(Clone)]
pub struct ProductCache {
    local: Cache<ProductId, Lookup>,
    gates: Arc<[Mutex<()>; 64]>,
    redis: Option<ConnectionManager>,
    op_timeout: Duration,
    ttl_secs: u64,
    missing_ttl_secs: u64,
}

impl ProductCache {
    pub fn new(
        settings: &CacheSettings,
        redis: Option<ConnectionManager>,
        op_timeout: Duration,
    ) -> Self {
        let local = Cache::builder()
            .max_capacity(settings.local_capacity)
            .time_to_live(Duration::from_secs(settings.local_ttl_secs))
            .build();
        Self {
            local,
            gates: Arc::new(std::array::from_fn(|_| Mutex::new(()))),
            redis,
            op_timeout,
            ttl_secs: settings.product_ttl_secs,
            missing_ttl_secs: settings.missing_ttl_secs,
        }
    }

    /// 只有进程内缓存：测试、以及没有配置 Redis 的环境使用。
    pub fn local_only(settings: &CacheSettings) -> Self {
        Self::new(settings, None, Duration::from_millis(200))
    }

    pub fn has_redis(&self) -> bool {
        self.redis.is_some()
    }

    pub(crate) fn local(&self) -> &Cache<ProductId, Lookup> {
        &self.local
    }

    /// Fixed memory: collisions serialize unrelated misses, but never grow a lock map.
    pub(crate) async fn gate(&self, id: ProductId) -> MutexGuard<'_, ()> {
        self.gates[(id.get().unsigned_abs() % 64) as usize]
            .lock()
            .await
    }

    pub(crate) async fn begin_fill(&self, id: ProductId) -> Option<Uuid> {
        let mut con = self.redis.clone()?;
        let token = Uuid::new_v4();
        let reply: Option<String> = with_timeout(
            self.op_timeout,
            "SET fill NX",
            redis::cmd("SET")
                .arg(fill_key(id))
                .arg(token.to_string())
                .arg("NX")
                .arg("PX")
                .arg(FILL_LEASE_MS)
                .query_async(&mut con),
        )
        .await?;
        reply.filter(|value| value == "OK").map(|_| token)
    }

    /// 读 Redis。返回 `None` 表示未命中--键不存在、Redis 不可用、值无法解析，都按未命中处理。
    pub(crate) async fn redis_get(&self, id: ProductId) -> Option<Lookup> {
        let mut con = self.redis.clone()?;
        let key = product_key(id);
        let raw: Option<String> = with_timeout(
            self.op_timeout,
            "bounded GET",
            redis::Script::new(include_str!("lua/read_value.lua"))
                .key(key)
                .invoke_async(&mut con),
        )
        .await?;
        let parsed = serde_json::from_str::<Entry>(&raw?)
            .map_err(|err| err.to_string())
            .and_then(Entry::into_lookup);
        match parsed {
            Ok(Some(product)) if product.id() != id => {
                warn!(expected = %id, actual = %product.id(), "Redis key and product identity differ; treating as cache miss");
                None
            }
            Ok(lookup) => Some(lookup),
            Err(reason) => {
                warn!(%id, reason, "Redis 中的缓存值无法解析，按未命中处理");
                None
            }
        }
    }

    /// 写 Redis。失败只记录警告：缓存写不进去，下一次再回源即可。
    pub(crate) async fn redis_put(&self, id: ProductId, lookup: &Lookup, permit: Option<Uuid>) {
        let Some(permit) = permit else { return };
        let Some(mut con) = self.redis.clone() else {
            return;
        };
        let ttl = match lookup {
            Some(_) => ttl_with_jitter(self.ttl_secs, id),
            None => self.missing_ttl_secs,
        };
        let json = match serde_json::to_string(&Entry::from_lookup(lookup)) {
            Ok(json) => json,
            Err(err) => {
                warn!(%id, error = %err, "缓存值序列化失败");
                return;
            }
        };
        let _: Option<i64> = with_timeout(
            self.op_timeout,
            "publish owned fill",
            redis::Script::new(include_str!("lua/publish_fill.lua"))
                .key(product_key(id))
                .key(fill_key(id))
                .arg(permit.to_string())
                .arg(json)
                .arg(ttl)
                .invoke_async(&mut con),
        )
        .await;
    }

    /// 写入数据库之后调用：删除两级缓存中的这个商品。
    pub async fn invalidate(&self, id: ProductId) {
        let _guard = self.gate(id).await;
        self.local.invalidate(&id).await;
        if let Some(mut con) = self.redis.clone() {
            let _: Option<i64> = with_timeout(
                self.op_timeout,
                "invalidate value and fill",
                redis::Script::new(include_str!("lua/invalidate.lua"))
                    .key(product_key(id))
                    .key(fill_key(id))
                    .invoke_async(&mut con),
            )
            .await;
        }
    }
}

/// 给 Redis 操作加上超时；出错或超时时记录警告并返回 `None`（降级）。
async fn with_timeout<T>(
    limit: Duration,
    op: &'static str,
    fut: impl Future<Output = redis::RedisResult<T>>,
) -> Option<T> {
    match tokio::time::timeout(limit, fut).await {
        Ok(Ok(value)) => Some(value),
        Ok(Err(err)) => {
            warn!(op, error = %err, "Redis 操作失败，已降级");
            None
        }
        Err(_) => {
            warn!(op, timeout = ?limit, "Redis 操作超时，已降级");
            None
        }
    }
}

/// 启动时连接 Redis。没有配置、地址无效、连接失败或超时，都返回 `None` 并记录原因。
pub async fn connect_redis(settings: &RedisSettings) -> Option<ConnectionManager> {
    let url = settings
        .url
        .as_deref()
        .filter(|url| !url.trim().is_empty())?;
    let client = match redis::Client::open(url) {
        Ok(client) => client,
        Err(err) => {
            warn!(error = %err, "Redis 地址无效，商品缓存只使用进程内缓存");
            return None;
        }
    };
    let limit = Duration::from_secs(settings.connect_timeout_secs);
    match tokio::time::timeout(limit, ConnectionManager::new(client)).await {
        Ok(Ok(manager)) => {
            info!("已连接 Redis");
            Some(manager)
        }
        Ok(Err(err)) => {
            warn!(error = %err, "连接 Redis 失败，商品缓存只使用进程内缓存");
            None
        }
        Err(_) => {
            warn!(timeout = ?limit, "连接 Redis 超时，商品缓存只使用进程内缓存");
            None
        }
    }
}
